
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export const ORDER_STATUS_CONFIG = {
  pending_payment: { label: 'Pagamento Pendente', color: 'bg-yellow-500 hover:bg-yellow-600', textColor: 'text-yellow-50' },
  payment_received: { label: 'Pago', color: 'bg-blue-500 hover:bg-blue-600', textColor: 'text-blue-50' },
  payment_failed: { label: 'Pagamento Falhou', color: 'bg-red-700 hover:bg-red-800', textColor: 'text-red-50' },
  processing: { label: 'Em Processamento', color: 'bg-purple-500 hover:bg-purple-600', textColor: 'text-purple-50' },
  shipped: { label: 'Enviado', color: 'bg-sky-500 hover:bg-sky-600', textColor: 'text-sky-50' },
  delivered: { label: 'Entregue', color: 'bg-green-500 hover:bg-green-600', textColor: 'text-green-50' },
  cancelled: { label: 'Cancelado', color: 'bg-gray-500 hover:bg-gray-600', textColor: 'text-gray-50' },
  refunded: { label: 'Reembolsado', color: 'bg-pink-500 hover:bg-pink-600', textColor: 'text-pink-50' },
  on_hold: { label: 'Em Espera', color: 'bg-orange-500 hover:bg-orange-600', textColor: 'text-orange-50' },
  partially_shipped: { label: 'Parcialmente Enviado', color: 'bg-teal-500 hover:bg-teal-600', textColor: 'text-teal-50' },
  default: { label: 'Desconhecido', color: 'bg-gray-300 hover:bg-gray-400', textColor: 'text-gray-800' },
};


const OrderStatusBadge = ({ status, className }) => {
  const config = ORDER_STATUS_CONFIG[status] || ORDER_STATUS_CONFIG.default;

  return (
    <Badge
      className={cn('text-xs font-semibold px-2.5 py-0.5 rounded-full', config.color, config.textColor, className)}
      data-testid="order-status-badge"
    >
      {config.label}
    </Badge>
  );
};

export default OrderStatusBadge;
