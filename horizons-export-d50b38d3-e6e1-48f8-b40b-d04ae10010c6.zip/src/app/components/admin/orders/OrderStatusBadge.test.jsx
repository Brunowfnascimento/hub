
import React from 'react';
import { render, screen } from '@testing-library/react';
import OrderStatusBadge, { ORDER_STATUS_CONFIG } from './OrderStatusBadge';

describe('OrderStatusBadge', () => {
  test('renders correctly for "pending_payment" status', () => {
    render(<OrderStatusBadge status="pending_payment" />);
    const badge = screen.getByTestId('order-status-badge');
    expect(badge).toBeInTheDocument();
    expect(badge).toHaveTextContent(ORDER_STATUS_CONFIG.pending_payment.label);
    expect(badge).toHaveClass(ORDER_STATUS_CONFIG.pending_payment.color);
    expect(badge).toHaveClass(ORDER_STATUS_CONFIG.pending_payment.textColor);
  });

  test('renders correctly for "delivered" status', () => {
    render(<OrderStatusBadge status="delivered" />);
    const badge = screen.getByTestId('order-status-badge');
    expect(badge).toHaveTextContent(ORDER_STATUS_CONFIG.delivered.label);
    expect(badge).toHaveClass(ORDER_STATUS_CONFIG.delivered.color);
    expect(badge).toHaveClass(ORDER_STATUS_CONFIG.delivered.textColor);
  });

  test('renders correctly for an unknown status with default styles', () => {
    render(<OrderStatusBadge status="unknown_status_value" />);
    const badge = screen.getByTestId('order-status-badge');
    expect(badge).toHaveTextContent(ORDER_STATUS_CONFIG.default.label);
    expect(badge).toHaveClass(ORDER_STATUS_CONFIG.default.color);
    expect(badge).toHaveClass(ORDER_STATUS_CONFIG.default.textColor);
  });

  test('applies custom className', () => {
    render(<OrderStatusBadge status="processing" className="extra-class" />);
    const badge = screen.getByTestId('order-status-badge');
    expect(badge).toHaveClass('extra-class');
  });

  // Test all defined statuses
  Object.keys(ORDER_STATUS_CONFIG).forEach((statusKey) => {
    if (statusKey === 'default') return; // Default is tested separately

    test(`renders correctly for status: ${statusKey}`, () => {
      render(<OrderStatusBadge status={statusKey} />);
      const badge = screen.getByTestId('order-status-badge');
      expect(badge).toHaveTextContent(ORDER_STATUS_CONFIG[statusKey].label);
      expect(badge).toHaveClass(ORDER_STATUS_CONFIG[statusKey].color);
      expect(badge).toHaveClass(ORDER_STATUS_CONFIG[statusKey].textColor);
    });
  });
});
