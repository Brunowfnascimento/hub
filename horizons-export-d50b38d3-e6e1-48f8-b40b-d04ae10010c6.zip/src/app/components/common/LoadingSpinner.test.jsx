
import React from 'react';
import { render, screen } from '@testing-library/react';
import LoadingSpinner from './LoadingSpinner';

describe('LoadingSpinner', () => {
  test('renders correctly with default props', () => {
    render(<LoadingSpinner />);
    const spinner = screen.getByTestId('loading-spinner');
    expect(spinner).toBeInTheDocument();
    expect(spinner).toHaveClass('animate-spin');
    expect(spinner).toHaveClass('h-8'); 
    expect(spinner).toHaveClass('w-8');
  });

  test('renders with specified size', () => {
    render(<LoadingSpinner size="lg" />);
    const spinner = screen.getByTestId('loading-spinner');
    expect(spinner).toHaveClass('h-12');
    expect(spinner).toHaveClass('w-12');
  });

  test('renders with custom className', () => {
    render(<LoadingSpinner className="text-red-500" />);
    const spinner = screen.getByTestId('loading-spinner');
    expect(spinner).toHaveClass('text-red-500');
  });

  test('has correct aria-label for accessibility', () => {
    render(<LoadingSpinner />);
    const spinner = screen.getByLabelText('Carregando');
    expect(spinner).toBeInTheDocument();
  });
});
