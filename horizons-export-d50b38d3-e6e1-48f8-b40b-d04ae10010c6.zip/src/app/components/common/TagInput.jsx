
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X as XIcon, PlusCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const TagInput = ({ value = [], onChange, placeholder = "Adicionar tag..." }) => {
  const [inputValue, setInputValue] = useState('');

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleInputKeyDown = (e) => {
    if (e.key === 'Enter' && inputValue.trim() !== '') {
      e.preventDefault();
      addTag(inputValue.trim());
    }
  };

  const addTag = (tagText) => {
    if (tagText && !value.includes(tagText)) {
      onChange([...value, tagText]);
    }
    setInputValue('');
  };

  const removeTag = (tagToRemove) => {
    onChange(value.filter(tag => tag !== tagToRemove));
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Input
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          onKeyDown={handleInputKeyDown}
          placeholder={placeholder}
          className="flex-grow bg-background dark:bg-slate-800"
        />
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={() => addTag(inputValue.trim())}
          disabled={!inputValue.trim()}
          className="shrink-0"
          aria-label="Adicionar tag"
        >
          <PlusCircle className="h-4 w-4" />
        </Button>
      </div>
      <AnimatePresence>
        {value.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-wrap gap-2 p-2 border rounded-md bg-slate-50 dark:bg-slate-800/50 min-h-[40px]"
          >
            {value.map((tag, index) => (
              <motion.div
                key={tag}
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.5 }}
                transition={{ delay: index * 0.05 }}
              >
                <Badge variant="secondary" className="text-sm py-1 px-2.5 bg-sky-100 dark:bg-sky-700 text-sky-700 dark:text-sky-200 border-sky-300 dark:border-sky-600">
                  {tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="ml-1.5 p-0.5 rounded-full hover:bg-sky-200 dark:hover:bg-sky-600 focus:outline-none focus:ring-1 focus:ring-sky-500"
                    aria-label={`Remover tag ${tag}`}
                  >
                    <XIcon className="h-3.5 w-3.5" />
                  </button>
                </Badge>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default TagInput;
