
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useQuery } from '@tanstack/react-query';
import { fetchStoreSettings } from '@/app/features/admin/settings-management/services/settingsAdmin.service';

const MetaTags = ({ title, description, keywords, author, image, type, url, children }) => {
  const { data: storeSettings } = useQuery({
    queryKey: ['storeSettings'],
    queryFn: fetchStoreSettings,
    staleTime: Infinity, 
  });

  const siteName = storeSettings?.store_name || 'VittaHub';
  const defaultDescription = storeSettings?.meta_description || 'Sua loja online completa.';
  const defaultImage = storeSettings?.logo_url || '/logo.png'; 

  const metaTitle = title ? `${title} | ${siteName}` : siteName;
  const metaDescription = description || defaultDescription;
  const metaImage = image || defaultImage;
  const metaUrl = url || window.location.href;

  return (
    <Helmet>
      <title>{metaTitle}</title>
      <meta name="description" content={metaDescription} />
      {keywords && <meta name="keywords" content={keywords.join(', ')} />}
      {author && <meta name="author" content={author} />}
      
      <meta property="og:title" content={metaTitle} />
      <meta property="og:description" content={metaDescription} />
      <meta property="og:image" content={metaImage} />
      <meta property="og:url" content={metaUrl} />
      <meta property="og:type" content={type || 'website'} />
      <meta property="og:site_name" content={siteName} />

      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={metaTitle} />
      <meta name="twitter:description" content={metaDescription} />
      <meta name="twitter:image" content={metaImage} />
      {children}
    </Helmet>
  );
};

export default MetaTags;
