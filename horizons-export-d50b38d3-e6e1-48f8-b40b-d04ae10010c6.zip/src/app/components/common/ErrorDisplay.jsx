
import React from 'react';
import { AlertTriangle } from 'lucide-react';

const ErrorDisplay = ({ message, details }) => {
  return (
    <div className="flex flex-col items-center justify-center p-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-lg shadow-md">
      <AlertTriangle className="h-12 w-12 text-red-500 dark:text-red-400 mb-4" />
      <h3 className="text-xl font-semibold text-red-700 dark:text-red-300 mb-2">
        Ocorreu um Erro
      </h3>
      <p className="text-red-600 dark:text-red-400 text-center">
        {message || "Não foi possível carregar os dados ou completar a ação."}
      </p>
      {details && (
        <pre className="mt-4 p-3 bg-red-100 dark:bg-red-800/30 text-xs text-red-700 dark:text-red-300 rounded overflow-auto max-w-full">
          {typeof details === 'string' ? details : JSON.stringify(details, null, 2)}
        </pre>
      )}
    </div>
  );
};

export default ErrorDisplay;
