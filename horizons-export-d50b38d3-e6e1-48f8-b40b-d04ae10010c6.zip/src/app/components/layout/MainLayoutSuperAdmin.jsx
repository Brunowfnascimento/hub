
    import React, { useState, useEffect } from 'react';
    import { Outlet } from 'react-router-dom';
    import HeaderSuperAdmin from '@/app/components/layout/HeaderSuperAdmin';
    import SidebarSuperAdmin from '@/app/components/layout/SidebarSuperAdmin';
    import { Toaster } from "@/components/ui/toaster";
    import { useTheme } from '@/app/contexts/ThemeContext';
    import { cn } from '@/lib/utils';

    const MainLayoutSuperAdmin = () => {
      const [isSidebarOpen, setIsSidebarOpen] = useState(true); 
      const { theme } = useTheme();

      const toggleSidebar = () => {
        setIsSidebarOpen(prev => !prev);
      };
    
      useEffect(() => {
        const handleResize = () => {
          if (window.innerWidth < 768) { 
            setIsSidebarOpen(false);
          } else {
            setIsSidebarOpen(true);
          }
        };
        window.addEventListener('resize', handleResize);
        handleResize();
        return () => window.removeEventListener('resize', handleResize);
      }, []);

      return (
        <div className={cn("flex h-screen bg-slate-100 dark:bg-slate-900", theme)}>
          <SidebarSuperAdmin isSidebarOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
          <div className={cn(
            "flex-1 flex flex-col overflow-hidden transition-all duration-300 ease-in-out",
            isSidebarOpen ? "md:ml-72" : "md:ml-20"
          )}>
            <HeaderSuperAdmin toggleSidebar={toggleSidebar} isSidebarOpen={isSidebarOpen} />
            <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-100 dark:bg-slate-900 p-4 md:p-6">
              <Outlet />
            </main>
          </div>
          <Toaster />
        </div>
      );
    };

    export default MainLayoutSuperAdmin;
  