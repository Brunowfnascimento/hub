
    import React from 'react';
    import { NavLink, useLocation } from 'react-router-dom';
    import { ChevronDown, ChevronRight } from 'lucide-react';
    import { cn } from '@/lib/utils';
    import { motion, AnimatePresence } from 'framer-motion';

    const SidebarAdminNavItem = ({ 
      item, 
      level = 0, 
      parentKey = '', 
      openMenus, 
      toggleMenu, 
      isSidebarOpen,
      onLinkClick 
    }) => {
      const location = useLocation();
      const currentItemKey = parentKey ? `${parentKey}-${item.key}` : item.key;
      const isMenuOpen = openMenus[currentItemKey];
      const hasSubItems = item.subItems && item.subItems.length > 0;
      const isActive = location.pathname === item.to || (item.toPrefix && location.pathname.startsWith(item.toPrefix) && (!item.subItems || item.subItems.length === 0));
      const isParentActive = item.toPrefix && location.pathname.startsWith(item.toPrefix);


      if (hasSubItems) {
        return (
          <div key={currentItemKey || item.label}>
            <button
              onClick={() => toggleMenu(currentItemKey)}
              className={cn(
                "flex items-center justify-between w-full rounded-lg p-3 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-all duration-150",
                !isSidebarOpen && "justify-center",
                isParentActive && "bg-slate-100 dark:bg-slate-800"
              )}
              style={{ paddingLeft: `${0.75 + level * 0.75}rem`, paddingRight: '0.75rem' }}
              aria-expanded={isMenuOpen}
              aria-controls={`submenu-${currentItemKey}`}
            >
              <div className="flex items-center">
                {item.icon && <item.icon className={cn(
                  "h-5 w-5 shrink-0",
                  isParentActive ? "text-sky-500 dark:text-sky-400" : "text-slate-500 dark:text-slate-400",
                  isSidebarOpen && "mr-3"
                )} />}
                {isSidebarOpen && <span className="truncate text-sm font-medium">{item.label}</span>}
              </div>
              {isSidebarOpen && (isMenuOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />)}
            </button>
            <AnimatePresence>
              {isMenuOpen && isSidebarOpen && (
                <motion.div
                  id={`submenu-${currentItemKey}`}
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="pt-1 space-y-1">
                    {item.subItems.map(subItem => (
                      <SidebarAdminNavItem 
                        key={subItem.key || subItem.label}
                        item={subItem} 
                        level={level + 1} 
                        parentKey={currentItemKey}
                        openMenus={openMenus}
                        toggleMenu={toggleMenu}
                        isSidebarOpen={isSidebarOpen}
                        onLinkClick={onLinkClick}
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      }

      return (
        <NavLink
          to={item.to}
          className={({ isActive: navLinkIsActive }) => cn(
            "flex items-center rounded-lg p-3 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-all duration-150",
            navLinkIsActive && "bg-sky-100 font-semibold text-sky-600 dark:bg-sky-700/30 dark:text-sky-400",
            !isSidebarOpen && "justify-center"
          )}
          style={{ paddingLeft: `${0.75 + level * (isSidebarOpen ? 0.75 : 0)}rem` }}
          onClick={onLinkClick}
        >
          {({ isActive: iconIsActive }) => (
            <>
              {item.icon && <item.icon className={cn(
                "h-5 w-5 shrink-0",
                iconIsActive ? "text-sky-500 dark:text-sky-400" : "text-slate-500 dark:text-slate-400",
                isSidebarOpen && "mr-3"
              )} />}
              {isSidebarOpen && <span className="truncate text-sm font-medium">{item.label}</span>}
            </>
          )}
        </NavLink>
      );
    };

    export default SidebarAdminNavItem;
  