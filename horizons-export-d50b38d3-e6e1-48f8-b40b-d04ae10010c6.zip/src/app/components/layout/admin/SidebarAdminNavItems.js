
    import { LayoutDashboard, ShoppingCart, Users, Package, Archive, Landmark, Settings, BarChart3, UserPlus, ListOrdered, Tag, Gift, Star, FileText, Repeat, ShoppingBag as ShoppingBagIcon, RotateCcw, FileArchive as ArchiveIcon, Ship, MapPin, Percent, Megaphone, AreaChart, Store, Palette, Mail, MessageSquare, CreditCard, Truck as TruckIcon, Globe, Webhook, TerminalSquare, UserCog, ShieldCheck, Map, Briefcase, MessageCircle, PlugZap, ListChecks, FileInput, Tag as LabelIcon, Box, KeyRound as UsersRound, HeartHandshake as Handshake } from 'lucide-react';

    export const mainNavItems = [
      { to: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard', key: 'dashboard' },
      { 
        to: '/admin/marketplace', 
        icon: Store, 
        label: 'Vitrine de Lojas', 
        key: 'marketplace',
        description: 'Marketplace de lojas para afiliação',
      },
      { 
        key: 'sales', icon: ShoppingCart, label: 'Vendas', toPrefix: '/admin/sales',
        subItems: [
          { to: '/admin/sales/transactions', label: 'Transações', icon: BarChart3, key: 'transactions' },
          { to: '/admin/sales/orders', label: 'Pedidos', icon: ListOrdered, key: 'orders' },
          { to: '/admin/sales/customers-report', label: 'Relatório de Clientes', icon: Users, key: 'customers-report' },
          { to: '/admin/sales/refunds', label: 'Reembolsos', icon: RotateCcw, key: 'refunds' },
          { to: '/admin/sales/abandoned-carts', label: 'Carrinhos Abandonados', icon: ShoppingBagIcon, key: 'abandoned-carts' },
        ]
      },
      { 
        key: 'customers', icon: Users, label: 'Clientes', toPrefix: '/admin/customers',
        subItems: [
          { to: '/admin/customers', label: 'Listar Clientes', icon: Users, key: 'list' },
          { to: '/admin/customers/new', label: 'Adicionar Cliente', icon: UserPlus, key: 'new' },
        ]
      },
      { 
        key: 'products-roles', icon: Package, label: 'Produtos & Papéis', toPrefix: '/admin',
        subItems: [
          {
            to: '/admin/my-products',
            icon: Box,
            label: 'Meus Produtos',
            key: 'my-products',
            description: 'Gerenciar seus produtos cadastrados',
          },
          {
            to: '/admin/roles/affiliate',
            icon: UsersRound,
            label: 'Como Afiliado',
            key: 'role-affiliate',
            description: 'Lojas/produtos que você promove como afiliado',
          },
          {
            to: '/admin/roles/coproducer',
            icon: Handshake,
            label: 'Como Coprodutor',
            key: 'role-coproducer',
            description: 'Lojas/produtos onde você é coprodutor',
          },
          {
            to: '/admin/roles/affiliate-manager',
            icon: Briefcase,
            label: 'Como Gerente de Afiliados',
            key: 'role-affiliate-manager',
            description: 'Lojas/produtos onde você gerencia afiliados',
          },
          {
            to: '/admin/roles/supplier',
            icon: TruckIcon,
            label: 'Como Fornecedor',
            key: 'role-supplier',
            description: 'Lojas/produtos para os quais você fornece',
          },
          {
            to: '/admin/roles/logistics-operator',
            icon: Ship,
            label: 'Como Operador Logístico',
            key: 'role-logistics-operator',
            description: 'Lojas/produtos com logística sob sua responsabilidade',
          },
        ]
      },
      { 
        key: 'inventory', icon: ArchiveIcon, label: 'Estoque', toPrefix: '/admin/inventory',
        subItems: [
          { to: '/admin/inventory/overview', label: 'Visão Geral', icon: Archive, key: 'overview' },
          { to: '/admin/inventory/adjustments', label: 'Ajustes Manuais', icon: Repeat, key: 'adjustments' },
          { to: '/admin/inventory/history', label: 'Histórico', icon: FileText, key: 'history' },
        ]
      },
      {
        key: 'finance-lojista', icon: Landmark, label: 'Financeiro', toPrefix: '/admin/finance',
        subItems: [
          { to: '/admin/finance/summary', label: 'Resumo', icon: BarChart3, key: 'summary' },
          { to: '/admin/finance/withdrawals', label: 'Saques', icon: CreditCard, key: 'withdrawals' },
          { to: '/admin/finance/advances', label: 'Antecipações', icon: Landmark, key: 'advances' },
          { to: '/admin/finance/bank-accounts', label: 'Contas Bancárias', icon: Landmark, key: 'bank-accounts' },
          { to: '/admin/finance/invoices', label: 'Faturas', icon: FileText, key: 'invoices' },
          { to: '/admin/finance/statement', label: 'Extrato', icon: ListOrdered, key: 'statement' },
        ]
      },
      { 
        key: 'shipping', icon: Ship, label: 'Logística / Envio', toPrefix: '/admin/shipping',
        subItems: [
          { to: '/admin/shipping/summary', label: 'Resumo de Envios', icon: LayoutDashboard, key: 'summary' },
          { to: '/admin/shipping/zones', label: 'Zonas de Entrega', icon: MapPin, key: 'zones' },
          { to: '/admin/shipping/methods-rates', label: 'Métodos e Taxas', icon: Percent, key: 'methods-rates' },
          { to: '/admin/shipping/labels', label: 'Etiquetas', icon: LabelIcon, key: 'labels' },
          { to: '/admin/shipping/plp', label: 'PLP', icon: ListChecks, key: 'plp' },
          { to: '/admin/shipping/quotes', label: 'Cotação', icon: FileInput, key: 'quotes' },
        ]
      },
      { 
        key: 'marketing', icon: Megaphone, label: 'Marketing', toPrefix: '/admin/marketing',
        subItems: [
          { to: '/admin/marketing/coupons', label: 'Campanhas de Cupons', icon: Tag, key: 'coupons' },
          { to: '/admin/marketing/promotions', label: 'Promoções', icon: Gift, key: 'promotions' },
          { to: '/admin/marketing/seo', label: 'SEO', icon: Globe, key: 'seo' },
        ]
      },
      { 
        key: 'reports', icon: AreaChart, label: 'Relatórios', toPrefix: '/admin/reports',
        subItems: [
          { to: '/admin/reports/sales', label: 'Vendas', icon: ShoppingCart, key: 'sales' },
          { to: '/admin/reports/inventory', label: 'Estoque', icon: Archive, key: 'inventory' },
          { to: '/admin/reports/customers', label: 'Clientes', icon: Users, key: 'customers' },
          { to: '/admin/reports/finance', label: 'Financeiro', icon: Landmark, key: 'finance' },
        ]
      },
      {
        to: '/admin/referral-program',
        icon: Gift,
        label: 'Indique e Ganhe',
        key: 'referral-program',
        description: 'Programa de indicação para recompensas',
      }
    ];

    export const secondaryNavItems = [
      { 
        to: '/admin/settings', 
        icon: Settings, 
        label: 'Configurações', 
        key: 'settings',
        description: 'Ajustes gerais do painel e da loja',
      },
    ];
  