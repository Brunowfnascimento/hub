
    import React from 'react';
    import { Menu, Search, Bell, User, Settings, LogOut, Sun, Moon, Maximize, Minimize } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
    import { useAuth } from '@/app/contexts/AuthContext';
    import { useTheme } from '@/app/contexts/ThemeContext';
    import { useNavigate } from 'react-router-dom';

    const HeaderSuperAdmin = ({ toggleSidebar, isSidebarOpen }) => {
      const { user, logout } = useAuth();
      const { theme, toggleTheme } = useTheme();
      const navigate = useNavigate();
      const [isFullscreen, setIsFullscreen] = React.useState(false);

      const handleLogout = async () => {
        await logout();
        navigate('/auth/login'); 
      };

      const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen();
          setIsFullscreen(true);
        } else {
          if (document.exitFullscreen) {
            document.exitFullscreen();
            setIsFullscreen(false);
          }
        }
      };
      
      return (
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-white px-4 shadow-sm dark:bg-slate-800 dark:border-slate-700">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={toggleSidebar} className="mr-2 text-slate-600 hover:text-slate-800 dark:text-slate-300 dark:hover:text-slate-100">
              <Menu className="h-6 w-6" />
            </Button>
            <h1 className="text-xl font-semibold text-slate-800 dark:text-slate-100">Super Admin Panel</h1>
          </div>

          <div className="flex items-center space-x-3">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <Input
                type="search"
                placeholder="Search platform..."
                className="h-10 w-72 rounded-lg border-slate-300 bg-slate-50 pl-10 pr-4 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-200 dark:placeholder-slate-400"
              />
            </div>

            <Button variant="ghost" size="icon" onClick={toggleTheme} className="text-slate-600 hover:text-slate-800 dark:text-slate-300 dark:hover:text-slate-100">
              {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>

            <Button variant="ghost" size="icon" onClick={toggleFullscreen} className="hidden lg:inline-flex text-slate-600 hover:text-slate-800 dark:text-slate-300 dark:hover:text-slate-100">
              {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="text-slate-600 hover:text-slate-800 dark:text-slate-300 dark:hover:text-slate-100 relative">
                  <Bell className="h-5 w-5" />
                  <span className="absolute -top-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-sky-500"></span>
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 dark:bg-slate-700 dark:border-slate-600">
                <div className="p-2 font-semibold text-slate-700 dark:text-slate-200">Notifications</div>
                <DropdownMenuSeparator className="dark:bg-slate-600"/>
                <DropdownMenuItem className="dark:hover:bg-slate-600">
                  <div className="text-sm text-slate-600 dark:text-slate-300">No new notifications</div>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2 text-slate-600 hover:text-slate-800 dark:text-slate-300 dark:hover:text-slate-100">
                  <User className="h-5 w-5" />
                  <span className="hidden md:inline text-sm">{user?.email || 'Super Admin'}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="dark:bg-slate-700 dark:border-slate-600">
                <DropdownMenuItem onClick={() => navigate('/superadmin/settings/profile')} className="dark:hover:bg-slate-600">
                  <User className="mr-2 h-4 w-4" /> Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/superadmin/platform-settings')} className="dark:hover:bg-slate-600">
                  <Settings className="mr-2 h-4 w-4" /> Platform Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator className="dark:bg-slate-600"/>
                <DropdownMenuItem onClick={handleLogout} className="text-red-500 dark:text-red-400 dark:hover:bg-red-700/20 focus:text-red-600 dark:focus:text-red-400">
                  <LogOut className="mr-2 h-4 w-4" /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
      );
    };

    export default HeaderSuperAdmin;
  