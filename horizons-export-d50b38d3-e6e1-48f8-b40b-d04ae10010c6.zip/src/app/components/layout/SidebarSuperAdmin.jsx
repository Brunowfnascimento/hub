
    import React, { useState, useEffect } from 'react';
    import { NavLink, useLocation, Link } from 'react-router-dom';
    import { ShieldCheck, Building2, Users, Tags, Settings, UserCog, ChevronDown, ChevronRight, Activity } from 'lucide-react';
    import { cn } from '@/lib/utils';
    import { motion, AnimatePresence } from 'framer-motion';

    const SidebarSuperAdmin = ({ isSidebarOpen, toggleSidebar }) => {
      const location = useLocation();
      const [openMenus, setOpenMenus] = useState({});

      const navItems = [
        { to: '/superadmin/dashboard', icon: Activity, label: 'Dashboard', key: 'dashboard' },
        { 
          key: 'tenants', icon: Building2, label: 'Gerenciamento de Tenants', toPrefix: '/superadmin/tenants',
          subItems: [
            { to: '/superadmin/tenants', label: 'Listar Tenants', icon: Users, key: 'list' },
            { to: '/superadmin/tenants/new', label: 'Adicionar Novo Tenant', icon: UserCog, key: 'new' },
          ]
        },
        { to: '/superadmin/plans', icon: Tags, label: 'Planos de Assinatura', key: 'plans' },
        { to: '/superadmin/platform-settings', icon: Settings, label: 'Configurações da Plataforma', key: 'platform-settings' },
        { to: '/superadmin/users', icon: UserCog, label: 'Usuários Super Admin', key: 'users' },
        { to: '/superadmin/settings/profile', icon: UserCog, label: 'Perfil Super Admin', key: 'profile' },
      ];
      
      useEffect(() => {
        const currentOpenMenus = {};
        const pathSegments = location.pathname.split('/').filter(Boolean);
        if (pathSegments.length > 1 && pathSegments[0] === 'superadmin') {
           const findAndOpenMenus = (items, parentKey = '') => {
            for (const item of items) {
              const itemFullKey = parentKey ? `${parentKey}-${item.key}` : item.key;
              if (location.pathname.startsWith(item.toPrefix || item.to)) {
                if (item.subItems && item.subItems.length > 0) {
                   currentOpenMenus[itemFullKey] = true; 
                   findAndOpenMenus(item.subItems, itemFullKey); 
                }
              }
            }
          };
          findAndOpenMenus(navItems, 'superadmin');
        }
        setOpenMenus(currentOpenMenus);
      }, [location.pathname, navItems]);


      const handleToggleMenu = (menuKey) => {
        setOpenMenus(prev => ({ ...prev, [menuKey]: !prev[menuKey] }));
      };

      const handleLinkClick = () => {
        if (isSidebarOpen && window.innerWidth < 768 && toggleSidebar) { 
          toggleSidebar();
        }
      };


      const renderNavItem = (item, level = 0, parentKey = '') => {
        const currentItemKey = parentKey ? `${parentKey}-${item.key}` : item.key;
        const isMenuOpen = openMenus[currentItemKey];
        const hasSubItems = item.subItems && item.subItems.length > 0;
        const isActive = location.pathname === item.to;
        const isParentActive = item.toPrefix && location.pathname.startsWith(item.toPrefix);


        if (hasSubItems) {
          return (
            <div key={currentItemKey || item.label}>
              <button
                onClick={() => handleToggleMenu(currentItemKey)}
                className={cn(
                  "flex items-center justify-between w-full rounded-lg p-3 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-all duration-150",
                  !isSidebarOpen && "justify-center",
                  isParentActive && "bg-slate-100 dark:bg-slate-800"
                )}
                style={{ paddingLeft: `${0.75 + level * 0.75}rem`, paddingRight: '0.75rem' }}
                aria-expanded={isMenuOpen}
                aria-controls={`submenu-sa-${currentItemKey}`}
              >
                <div className="flex items-center">
                  {item.icon && <item.icon className={cn(
                    "h-5 w-5 shrink-0",
                    isParentActive ? "text-red-500 dark:text-red-400" : "text-slate-500 dark:text-slate-400",
                    isSidebarOpen && "mr-3"
                  )} />}
                  {isSidebarOpen && <span className="truncate text-sm font-medium">{item.label}</span>}
                </div>
                {isSidebarOpen && (isMenuOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />)}
              </button>
              <AnimatePresence>
                {isMenuOpen && isSidebarOpen && (
                  <motion.div
                    id={`submenu-sa-${currentItemKey}`}
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="pt-1 space-y-1">
                      {item.subItems.map(subItem => renderNavItem(subItem, level + 1, currentItemKey))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        }

        return (
          <NavLink
            key={item.key || item.label}
            to={item.to}
            onClick={handleLinkClick}
            className={({ isActive: navLinkIsActive }) => cn(
              "flex items-center rounded-lg p-3 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-all duration-150",
              navLinkIsActive && "bg-red-100 font-semibold text-red-600 dark:bg-red-700/30 dark:text-red-400",
              !isSidebarOpen && "justify-center"
            )}
            style={{ paddingLeft: `${0.75 + level * (isSidebarOpen ? 0.75 : 0)}rem` }}
          >
            {({ isActive: iconIsActive }) => (
              <>
                {item.icon && <item.icon className={cn(
                  "h-5 w-5 shrink-0",
                  iconIsActive ? "text-red-500 dark:text-red-400" : "text-slate-500 dark:text-slate-400",
                  isSidebarOpen && "mr-3"
                )} />}
                {isSidebarOpen && <span className="truncate text-sm font-medium">{item.label}</span>}
              </>
            )}
          </NavLink>
        );
      };

      return (
        <aside className={cn(
          "fixed inset-y-0 left-0 z-30 flex-col border-r bg-white transition-transform duration-300 ease-in-out dark:bg-slate-900 dark:border-slate-700",
          "md:flex md:relative md:translate-x-0",
          isSidebarOpen ? "w-72 translate-x-0" : "w-72 -translate-x-full md:w-20 md:translate-x-0"
        )}>
          <div className={cn(
            "flex items-center border-b px-6 transition-all duration-300 ease-in-out dark:border-slate-700",
            isSidebarOpen ? "h-20" : "h-20 justify-center"
          )}>
            <Link to="/superadmin/dashboard" className="flex items-center">
              <ShieldCheck className={cn("transition-all duration-300 ease-in-out text-red-600", isSidebarOpen ? "h-10 w-10" : "h-8 w-8")} />
              {isSidebarOpen && <span className="ml-3 text-2xl font-bold text-slate-800 dark:text-slate-100">VittaHub <span className="text-red-600">SAAS</span></span>}
            </Link>
          </div>
          <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
            {navItems.map(item => renderNavItem(item, 0, 'superadmin'))}
          </nav>
        </aside>
      );
    };

    export default SidebarSuperAdmin;
  