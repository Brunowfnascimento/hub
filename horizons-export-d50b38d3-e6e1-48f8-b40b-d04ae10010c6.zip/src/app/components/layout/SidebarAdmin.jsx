
    import React, { useState, useEffect, useCallback } from 'react';
    import { useLocation, Link } from 'react-router-dom';
    import { cn } from '@/lib/utils';
    import { mainNavItems, secondaryNavItems } from './admin/SidebarAdminNavItems';
    import SidebarAdminNavItem from './admin/SidebarAdminNavItem';
    import { motion } from 'framer-motion';

    const SidebarHeader = ({ isSidebarOpen }) => (
      <div className={cn(
        "flex items-center border-b px-6 transition-all duration-300 ease-in-out dark:border-slate-700",
        isSidebarOpen ? "h-20" : "h-20 justify-center" 
      )}>
        <Link to="/admin/dashboard" className="flex items-center">
          <motion.img 
            alt="VittaHub Logo" 
            className={cn("transition-all duration-300 ease-in-out", isSidebarOpen ? "h-10" : "h-8")} 
            src="https://images.unsplash.com/photo-1593150543200-56e05bdb018e" // Placeholder, replace with actual logo
            animate={{ scale: isSidebarOpen ? 1 : 0.9 }}
            transition={{ duration: 0.3 }}
          />
          {isSidebarOpen && (
            <motion.span 
              className="ml-3 text-2xl font-bold text-slate-800 dark:text-slate-100"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2, delay: 0.1 }}
            >
              VittaHub
            </motion.span>
          )}
        </Link>
      </div>
    );

    const NavSection = ({ items, openMenus, toggleMenu, isSidebarOpen, onLinkClick, parentKeyPrefix, sectionTitle }) => (
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {sectionTitle && isSidebarOpen && (
          <h3 className="px-3 py-2 text-xs font-semibold uppercase text-slate-500 dark:text-slate-400 tracking-wider">
            {sectionTitle}
          </h3>
        )}
        {items.map(item => (
          <SidebarAdminNavItem 
            key={item.key}
            item={item}
            openMenus={openMenus}
            toggleMenu={toggleMenu}
            isSidebarOpen={isSidebarOpen}
            onLinkClick={onLinkClick}
            parentKey={parentKeyPrefix}
          />
        ))}
      </nav>
    );
    
    const useOpenMenus = (location) => {
      const [openMenus, setOpenMenus] = useState({});
    
      useEffect(() => {
        const currentOpenMenus = {};
        const pathSegments = location.pathname.split('/').filter(Boolean);
        
        if (pathSegments.length > 1 && pathSegments[0] === 'admin') {
          const findAndOpenMenus = (items, parentKey = '') => {
            for (const item of items) {
              const itemFullKey = parentKey ? `${parentKey}-${item.key}` : item.key;
              if (location.pathname.startsWith(item.toPrefix || item.to)) {
                if (item.subItems && item.subItems.length > 0) {
                   currentOpenMenus[itemFullKey] = true; 
                   findAndOpenMenus(item.subItems, itemFullKey); 
                }
              }
            }
          };
    
          findAndOpenMenus(mainNavItems, 'main');
          findAndOpenMenus(secondaryNavItems, 'secondary');
        }
        setOpenMenus(currentOpenMenus);
      }, [location.pathname]);
    
      const handleToggleMenu = useCallback((menuKey) => {
        setOpenMenus(prev => ({ ...prev, [menuKey]: !prev[menuKey] }));
      }, []);
    
      return { openMenus, handleToggleMenu };
    };
    
    const SidebarAdmin = ({ isSidebarOpen, toggleSidebar }) => {
      const location = useLocation();
      const { openMenus, handleToggleMenu } = useOpenMenus(location);
    
      const handleLinkClick = useCallback(() => {
        if (isSidebarOpen && window.innerWidth < 768 && toggleSidebar) { 
          toggleSidebar();
        }
      }, [isSidebarOpen, toggleSidebar]);
    
      return (
        <aside className={cn(
          "fixed inset-y-0 left-0 z-30 flex flex-col border-r bg-white transition-transform duration-300 ease-in-out dark:bg-slate-900 dark:border-slate-700",
          "md:flex md:relative md:translate-x-0", 
          isSidebarOpen ? "w-64 translate-x-0" : "w-64 -translate-x-full md:w-20 md:translate-x-0"
        )}>
          <SidebarHeader isSidebarOpen={isSidebarOpen} />
          
          <div className="flex-grow overflow-y-auto flex flex-col"> {/* Added flex flex-col here */}
            <NavSection 
              items={mainNavItems}
              openMenus={openMenus}
              toggleMenu={handleToggleMenu}
              isSidebarOpen={isSidebarOpen}
              onLinkClick={handleLinkClick}
              parentKeyPrefix="main"
              sectionTitle="Principal"
            />
            <div className="mt-auto border-t dark:border-slate-700"> {/* Ensures this section is pushed to the bottom */}
              <NavSection 
                items={secondaryNavItems}
                openMenus={openMenus}
                toggleMenu={handleToggleMenu}
                isSidebarOpen={isSidebarOpen}
                onLinkClick={handleLinkClick}
                parentKeyPrefix="secondary"
                sectionTitle="Configurações e Mais"
              />
            </div>
          </div>
        </aside>
      );
    };
    
    export default SidebarAdmin;
  