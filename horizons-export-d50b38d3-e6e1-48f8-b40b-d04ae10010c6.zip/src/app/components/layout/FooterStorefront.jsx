
import React from 'react';

const FooterStorefront = () => {
  return (
    <footer className="bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400 py-8 text-center mt-auto transition-colors duration-300">
      <div className="container mx-auto px-4">
        <p>&copy; {new Date().getFullYear()} Minha Loja. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
};

export default FooterStorefront;
  