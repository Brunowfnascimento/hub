
    import React from 'react';
    import { Link } from 'react-router-dom';
    import { ShoppingBag, Sun, Moon, Globe, User, LogIn, Menu as MenuIcon } from 'lucide-react';
    import { useTheme } from '@/app/contexts/ThemeContext';
    import { Button } from '@/components/ui/button';
    import { useTranslation } from 'react-i18next';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuTrigger,
      DropdownMenuSeparator
    } from "@/components/ui/dropdown-menu";
    import { useAuth } from '@/app/contexts/AuthContext';
    import { useCart } from '@/app/contexts/CartContext';


    const HeaderStorefront = () => {
      const { theme, toggleTheme } = useTheme();
      const { t, i18n } = useTranslation();
      const { user, logout } = useAuth();
      const { totalItems } = useCart();

      const changeLanguage = (lng) => {
        i18n.changeLanguage(lng);
      };

      const languages = [
        { code: 'pt-BR', name: 'Português (BR)' },
      ];

      return (
        <header className="bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-white shadow-lg sticky top-0 z-50">
          <div className="container mx-auto px-4 py-6 flex items-center justify-between">
            <Link to="/" className="text-3xl font-bold text-sky-600 dark:text-sky-400 hover:text-sky-500 dark:hover:text-sky-300 transition-colors">
              <ShoppingBag className="inline-block mr-2 h-8 w-8" />
              {t('header.storeName', 'VittaHub')}
            </Link>
            <nav className="flex items-center space-x-2 sm:space-x-4 md:space-x-6">
              <ul className="hidden sm:flex space-x-6 items-center">
                <li><Link to="/" className="hover:text-sky-600 dark:hover:text-sky-400 transition-colors font-medium">{t('header.home', 'Home')}</Link></li>
                <li><Link to="/products" className="hover:text-sky-600 dark:hover:text-sky-400 transition-colors font-medium">{t('header.products', 'Produtos')}</Link></li>
                <li>
                  <Link to="/cart" className="relative hover:text-sky-600 dark:hover:text-sky-400 transition-colors font-medium">
                    {t('header.cart', 'Carrinho')}
                    {totalItems > 0 && (
                      <span className="absolute -top-2 -right-3 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {totalItems}
                      </span>
                    )}
                  </Link>
                </li>
                {!user && (
                  <li><Link to="/auth/login" className="hover:text-sky-600 dark:hover:text-sky-400 transition-colors font-medium">{t('header.login', 'Login')}</Link></li>
                )}
              </ul>
               <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-slate-800 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700">
                    <Globe className="h-5 w-5" />
                    <span className="sr-only">Change language</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {languages.map((lang) => (
                    <DropdownMenuItem key={lang.code} onClick={() => changeLanguage(lang.code)} className={i18n.resolvedLanguage === lang.code ? 'bg-slate-100 dark:bg-slate-700' : ''}>
                      {lang.name}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                aria-label="Toggle theme"
                className="text-slate-800 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
              >
                {theme === 'dark' ? <Sun className="h-6 w-6" /> : <Moon className="h-6 w-6" />}
              </Button>
              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-slate-800 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full">
                      <User className="h-6 w-6" />
                       <span className="sr-only">User menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild><Link to="/profile">{t('header.profile', 'Meu Perfil')}</Link></DropdownMenuItem>
                    {(user.user_metadata?.role === 'admin' || user.user_metadata?.role === 'super_admin') && (
                       <DropdownMenuItem asChild><Link to="/admin/dashboard">{t('header.adminPanel', 'Painel Admin')}</Link></DropdownMenuItem>
                    )}
                     {user.user_metadata?.role === 'super_admin' && (
                       <DropdownMenuItem asChild><Link to="/superadmin/dashboard">{t('header.superAdminPanel', 'Painel Super Admin')}</Link></DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout}>{t('header.logout', 'Sair')}</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link to="/auth/login" className="hidden sm:inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-sky-500 text-primary-foreground hover:bg-sky-500/90 h-10 px-4 py-2">
                  <LogIn className="mr-2 h-4 w-4" /> {t('header.login', 'Login')}
                </Link>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild className="sm:hidden">
                  <Button variant="ghost" size="icon" className="text-slate-800 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700">
                    <MenuIcon className="h-6 w-6" />
                    <span className="sr-only">Toggle menu</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="sm:hidden">
                  <DropdownMenuItem asChild><Link to="/">{t('header.home', 'Home')}</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/products">{t('header.products', 'Produtos')}</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/cart" className="relative">
                      {t('header.cart', 'Carrinho')}
                      {totalItems > 0 && (
                        <span className="ml-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                          {totalItems}
                        </span>
                      )}
                    </Link>
                  </DropdownMenuItem>
                  {!user && (
                    <DropdownMenuItem asChild><Link to="/auth/login">{t('header.login', 'Login')}</Link></DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </nav>
          </div>
        </header>
      );
    };

    export default HeaderStorefront;
  