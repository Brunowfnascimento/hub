
import React from 'react';
import { UserCircle, LogOut, Sun, Moon } from 'lucide-react';
import { useTheme } from '@/app/contexts/ThemeContext';
import { Button } from '@/components/ui/button';

const HeaderAdmin = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-white shadow-md p-4 flex justify-between items-center sticky top-0 z-50">
      <h1 className="text-2xl font-semibold text-sky-600 dark:text-sky-400">Painel Admin</h1>
      <div className="flex items-center space-x-4">
        <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="text-slate-800 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
          >
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
        <span className="text-slate-600 dark:text-slate-300">Usuário Admin</span>
        <UserCircle className="h-6 w-6 text-slate-600 dark:text-slate-300" />
        <button title="Logout" className="text-slate-600 dark:text-slate-300 hover:text-red-500 dark:hover:text-red-400 transition-colors">
          <LogOut className="h-6 w-6" />
        </button>
      </div>
    </header>
  );
};

export default HeaderAdmin;
  