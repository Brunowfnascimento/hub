
    import React from 'react';
    import HeaderStorefront from '@/app/components/layout/HeaderStorefront';
    import FooterStorefront from '@/app/components/layout/FooterStorefront';
    import { Outlet } from 'react-router-dom';

    const MainLayoutStorefront = () => {
      return (
        <div className="flex flex-col min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
          <HeaderStorefront />
          <main className="flex-grow container mx-auto px-4 py-8">
            <Outlet /> {/* Changed from children to Outlet */}
          </main>
          <FooterStorefront />
        </div>
      );
    };

    export default MainLayoutStorefront;
  