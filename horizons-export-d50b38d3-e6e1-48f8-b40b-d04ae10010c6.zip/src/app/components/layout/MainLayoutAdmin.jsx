
    import React, { useState, useEffect } from 'react';
    import HeaderAdmin from '@/app/components/layout/HeaderAdmin';
    import SidebarAdmin from '@/app/components/layout/SidebarAdmin';
    import { Outlet } from 'react-router-dom';
    import { cn } from '@/lib/utils';
    
    const MainLayoutAdmin = () => {
      const [isSidebarOpen, setIsSidebarOpen] = useState(true); 
    
      const toggleSidebar = () => {
        setIsSidebarOpen(prev => !prev);
      };
    
      useEffect(() => {
        const handleResize = () => {
          if (window.innerWidth < 768) { 
            setIsSidebarOpen(false);
          } else {
            setIsSidebarOpen(true);
          }
        };
        window.addEventListener('resize', handleResize);
        handleResize(); 
        return () => window.removeEventListener('resize', handleResize);
      }, []);
    
      return (
        <div className="flex h-screen bg-slate-100 dark:bg-slate-900 transition-colors duration-300">
          <SidebarAdmin isSidebarOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
          <div className={cn(
            "flex-1 flex flex-col overflow-hidden transition-all duration-300 ease-in-out",
            isSidebarOpen ? "md:ml-64" : "md:ml-20"
          )}>
            <HeaderAdmin toggleSidebar={toggleSidebar} isSidebarOpen={isSidebarOpen} />
            <main className="flex-grow p-2 sm:p-3 md:p-4 lg:p-6 overflow-y-auto bg-slate-50 dark:bg-slate-800 transition-colors duration-300">
              <Outlet /> 
            </main>
          </div>
        </div>
      );
    };
    
    export default MainLayoutAdmin;
  