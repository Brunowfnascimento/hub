
    import React, { lazy } from 'react';
    import { Routes, Route, Navigate } from 'react-router-dom';
    import MainLayoutStorefront from '@/app/components/layout/MainLayoutStorefront';
    import ProtectedRoute from '@/app/routes/ProtectedRoutes';

    const HomePage = lazy(() => import('@/app/pages/storefront/HomePage'));
    const ProductsPage = lazy(() => import('@/app/pages/storefront/ProductsPage'));
    const ProductDetailPage = lazy(() => import('@/app/pages/storefront/ProductDetailPage'));
    const CartPage = lazy(() => import('@/app/pages/storefront/CartPage'));
    const CheckoutPage = lazy(() => import('@/app/pages/storefront/CheckoutPage'));
    const OrderConfirmationPage = lazy(() => import('@/app/pages/storefront/OrderConfirmationPage'));
    const ProfilePage = lazy(() => import('@/app/pages/storefront/ProfilePage'));
    // CustomerOrderDetailPage is now rendered within ProfilePage routes

    const StorefrontRoutes = () => {
      return (
        <Routes>
          <Route element={<MainLayoutStorefront />}>
            <Route index element={<HomePage />} />
            <Route path="products" element={<ProductsPage />} />
            <Route path="products/:categorySlug" element={<ProductsPage />} />
            <Route path="product/:slug" element={<ProductDetailPage />} />
            <Route path="cart" element={<CartPage />} />
            <Route path="checkout" element={<CheckoutPage />} />
            <Route path="order-confirmation/:orderId" element={<OrderConfirmationPage />} />
            <Route 
              path="profile/*" 
              element={
                <ProtectedRoute allowedRoles={['customer', 'admin', 'super_admin']}>
                  <ProfilePage />
                </ProtectedRoute>
              } 
            />
            {/* Fallback for any direct /profile access, redirect to /profile/orders */}
            <Route path="profile" element={<Navigate to="/profile/orders" replace />} /> 
          </Route>
        </Routes>
      );
    };

    export default StorefrontRoutes;
  