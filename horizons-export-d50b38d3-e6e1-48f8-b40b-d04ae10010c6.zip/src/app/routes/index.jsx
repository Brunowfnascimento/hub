
    import React, { lazy, Suspense } from 'react';
    import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
    import LoadingSpinner from '@/app/components/common/LoadingSpinner';
    import ErrorBoundary from '@/app/components/common/ErrorBoundary';

    // Páginas de Autenticação (Públicas)
    const AuthPage = lazy(() => import('@/app/pages/AuthPage'));
    const AdminLoginPage = lazy(() => import('@/app/pages/admin/AdminLoginPage'));
    const SuperAdminLoginPage = lazy(() => import('@/app/pages/superadmin/SuperAdminLoginPage')); // Nova página

    // Ferramentas de Admin (Públicas ou com proteção própria)
    const CreateSuperAdminTool = lazy(() => import('@/app/admin-tools/CreateSuperAdminTool'));

    // Módulos de Rotas Protegidas
    const StorefrontRoutes = lazy(() => import('@/app/routes/StorefrontRoutes'));
    const AdminRoutes = lazy(() => import('@/app/routes/AdminRoutes'));
    const SuperAdminRoutes = lazy(() => import('@/app/routes/SuperAdminRoutes'));

    // Página Não Encontrada
    const NotFoundPage = lazy(() => import('@/app/pages/NotFoundPage'));

    const AppRoutes = () => {
      return (
        <Router>
          <ErrorBoundary>
            <Suspense fallback={<div className="flex h-screen w-full items-center justify-center bg-slate-100 dark:bg-slate-900"><LoadingSpinner size="lg" /></div>}>
              <Routes>
                {/* Rotas Públicas de Autenticação */}
                <Route path="/auth/:action" element={<AuthPage />} />
                <Route path="/admin/login" element={<AdminLoginPage />} />
                <Route path="/superadmin/login" element={<SuperAdminLoginPage />} /> {/* Nova rota pública */}

                {/* Ferramentas (podem ter sua própria lógica de segurança interna se necessário) */}
                <Route path="/create-super-admin-tool" element={<CreateSuperAdminTool />} />

                {/* Rotas do Storefront (geralmente públicas, com algumas protegidas internamente) */}
                <Route path="/*" element={<StorefrontRoutes />} />
                
                {/* Rotas do Painel de Admin (Protegidas) */}
                <Route path="/admin/*" element={<AdminRoutes />} />

                {/* Rotas do Painel de Super Admin (Protegidas) */}
                <Route path="/superadmin/*" element={<SuperAdminRoutes />} />
                
                {/* Rota Não Encontrada */}
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </Router>
      );
    };

    export default AppRoutes;
  