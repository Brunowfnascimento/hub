
    import React from 'react';
    import { Navigate, useLocation } from 'react-router-dom';
    import { useAuth } from '@/app/contexts/AuthContext';
    import LoadingSpinner from '@/app/components/common/LoadingSpinner';

    const ProtectedRoute = ({ children, allowedRoles }) => {
      const { user, userProfile, isLoadingUser } = useAuth();
      const location = useLocation();

      console.log('[ProtectedRoute] Rendering. Location:', location.pathname);
      console.log('[ProtectedRoute] Auth state: isLoadingUser:', isLoadingUser, 'user:', user, 'userProfile:', userProfile);

      if (isLoadingUser) {
        console.log('[ProtectedRoute] isLoadingUser is true. Displaying LoadingSpinner.');
        return (
          <div className="flex justify-center items-center h-screen bg-slate-100 dark:bg-slate-900">
            <LoadingSpinner size="xl" />
          </div>
        );
      }

      if (!user) {
        let loginPath = '/auth/login';
        if (location.pathname.startsWith('/admin') && !location.pathname.startsWith('/admin/login')) {
          loginPath = '/admin/login';
        }
        if (location.pathname.startsWith('/superadmin')) {
           loginPath = '/admin/login'; 
        }
        console.log('[ProtectedRoute] No user. Redirecting to loginPath:', loginPath);
        return <Navigate to={loginPath} state={{ from: location }} replace />;
      }

      if (!userProfile) {
        console.warn("[ProtectedRoute] User is authenticated, but userProfile is null. Access denied. Redirecting to home. Current User:", user);
        return <Navigate to="/" state={{ from: location }} replace />;
      }

      // Temporarily commenting out role check for debugging
      /*
      if (allowedRoles && !allowedRoles.includes(userProfile.role)) {
        console.warn(`[ProtectedRoute] User role "${userProfile.role}" not in allowed roles: [${allowedRoles.join(', ')}]. Access denied. Redirecting to home.`);
        return <Navigate to="/" state={{ from: location }} replace />;
      }
      */
      console.log('[ProtectedRoute] User is authenticated and has a profile. Role check (temporarily commented out for debug):', userProfile.role, 'Allowed roles:', allowedRoles);


      console.log('[ProtectedRoute] Access granted. Rendering children.');
      return children;
    };

    export default ProtectedRoute;
  