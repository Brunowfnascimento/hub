
    import React, { lazy } from 'react';
    import { Routes, Route, Navigate } from 'react-router-dom';
    import MainLayoutSuperAdmin from '@/app/components/layout/MainLayoutSuperAdmin';
    import ProtectedRoute from '@/app/routes/ProtectedRoutes';

    const SuperAdminDashboardPage = lazy(() => import('@/app/pages/superadmin/SuperAdminDashboardPage'));
    const SuperAdminTenantsListPage = lazy(() => import('@/app/pages/superadmin/SuperAdminTenantsListPage'));
    const SuperAdminNewTenantPage = lazy(() => import('@/app/pages/superadmin/SuperAdminNewTenantPage'));
    const SuperAdminSaasPlansPage = lazy(() => import('@/app/pages/superadmin/SuperAdminSaasPlansPage'));
    const SuperAdminPlatformSettingsPage = lazy(() => import('@/app/pages/superadmin/SuperAdminPlatformSettingsPage'));
    const SuperAdminUsersPage = lazy(() => import('@/app/pages/superadmin/SuperAdminUsersPage'));
    const AdminSettingsProfilePage = lazy(() => import('@/app/pages/admin/settings/AdminSettingsProfilePage'));


    const SuperAdminRoutes = () => {
      return (
        <Routes>
          <Route element={
            <ProtectedRoute allowedRoles={['super_admin']}>
              <MainLayoutSuperAdmin />
            </ProtectedRoute>
          }>
            <Route path="dashboard" element={<SuperAdminDashboardPage />} />
            <Route path="tenants" element={<SuperAdminTenantsListPage />} />
            <Route path="tenants/new" element={<SuperAdminNewTenantPage />} />
            <Route path="plans" element={<SuperAdminSaasPlansPage />} />
            <Route path="platform-settings" element={<SuperAdminPlatformSettingsPage />} />
            <Route path="users" element={<SuperAdminUsersPage />} />
            <Route path="settings/profile" element={<AdminSettingsProfilePage />} /> {/* Reusing for now, can be specific SA profile page */}
            <Route index element={<Navigate to="dashboard" replace />} />
          </Route>
        </Routes>
      );
    };

    export default SuperAdminRoutes;
  