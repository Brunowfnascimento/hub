
    import React, { lazy } from 'react';
    import { Routes, Route, Navigate } from 'react-router-dom';
    import MainLayoutAdmin from '@/app/components/layout/MainLayoutAdmin';
    import ProtectedRoute from '@/app/routes/ProtectedRoutes';

    const AdminDashboardPage = lazy(() => import('@/app/pages/admin/AdminDashboardPage'));
    const AdminSalesTransactionsPage = lazy(() => import('@/app/pages/admin/sales/AdminSalesTransactionsPage'));
    const AdminOrdersPage = lazy(() => import('@/app/pages/admin/AdminOrdersPage')); 
    const AdminSalesCustomersReportPage = lazy(() => import('@/app/pages/admin/sales/AdminSalesCustomersReportPage'));
    const AdminSalesRefundsPage = lazy(() => import('@/app/pages/admin/sales/AdminSalesRefundsPage'));
    const AdminSalesAbandonedCartsPage = lazy(() => import('@/app/pages/admin/sales/AdminSalesAbandonedCartsPage'));
    const AdminCustomersPage = lazy(() => import('@/app/pages/admin/AdminCustomersPage'));
    const AdminCustomersNewPage = lazy(() => import('@/app/pages/admin/customers/AdminCustomersNewPage'));
    const AdminProductsPage = lazy(() => import('@/app/pages/admin/AdminProductsPage'));
    const AdminAddEditProductPage = lazy(() => import('@/app/pages/admin/AdminAddEditProductPage'));
    const AdminProductsCategoriesPage = lazy(() => import('@/app/pages/admin/products/AdminProductsCategoriesPage'));
    const AdminProductsBrandsPage = lazy(() => import('@/app/pages/admin/products/AdminProductsBrandsPage'));
    const AdminProductsAttributesPage = lazy(() => import('@/app/pages/admin/products/AdminProductsAttributesPage'));
    const AdminProductsReviewsPage = lazy(() => import('@/app/pages/admin/products/AdminProductsReviewsPage'));
    const AdminCouponsPage = lazy(() => import('@/app/pages/admin/AdminCouponsPage'));
    const AdminInventoryOverviewPage = lazy(() => import('@/app/pages/admin/inventory/AdminInventoryOverviewPage'));
    const AdminInventoryAdjustmentsPage = lazy(() => import('@/app/pages/admin/inventory/AdminInventoryAdjustmentsPage'));
    const AdminInventoryHistoryPage = lazy(() => import('@/app/pages/admin/inventory/AdminInventoryHistoryPage'));
    const AdminFinanceSummaryPage = lazy(() => import('@/app/pages/admin/finance/AdminFinanceSummaryPage'));
    const AdminFinanceWithdrawalsPage = lazy(() => import('@/app/pages/admin/finance/AdminFinanceWithdrawalsPage'));
    const AdminFinanceAdvancesPage = lazy(() => import('@/app/pages/admin/finance/AdminFinanceAdvancesPage'));
    const AdminFinanceBankAccountsPage = lazy(() => import('@/app/pages/admin/finance/AdminFinanceBankAccountsPage'));
    const AdminFinanceInvoicesPage = lazy(() => import('@/app/pages/admin/finance/AdminFinanceInvoicesPage'));
    const AdminFinanceStatementPage = lazy(() => import('@/app/pages/admin/finance/AdminFinanceStatementPage'));
    const AdminShippingSummaryPage = lazy(() => import('@/app/pages/admin/shipping/AdminShippingSummaryPage'));
    const AdminShippingZonesPage = lazy(() => import('@/app/pages/admin/shipping/AdminShippingZonesPage'));
    const AdminShippingMethodsRatesPage = lazy(() => import('@/app/pages/admin/shipping/AdminShippingMethodsRatesPage'));
    const AdminShippingLabelsPage = lazy(() => import('@/app/pages/admin/shipping/AdminShippingLabelsPage'));
    const AdminShippingPlpPage = lazy(() => import('@/app/pages/admin/shipping/AdminShippingPlpPage'));
    const AdminShippingQuotesPage = lazy(() => import('@/app/pages/admin/shipping/AdminShippingQuotesPage'));
    const AdminMarketingCouponsPage = lazy(() => import('@/app/pages/admin/marketing/AdminMarketingCouponsPage'));
    const AdminMarketingPromotionsPage = lazy(() => import('@/app/pages/admin/marketing/AdminMarketingPromotionsPage'));
    const AdminMarketingSeoPage = lazy(() => import('@/app/pages/admin/marketing/AdminMarketingSeoPage'));
    const AdminReportsSalesPage = lazy(() => import('@/app/pages/admin/reports/AdminReportsSalesPage'));
    const AdminReportsInventoryPage = lazy(() => import('@/app/pages/admin/reports/AdminReportsInventoryPage'));
    const AdminReportsCustomersPage = lazy(() => import('@/app/pages/admin/reports/AdminReportsCustomersPage'));
    const AdminReportsFinancePage = lazy(() => import('@/app/pages/admin/reports/AdminReportsFinancePage'));
    
    const AdminSettingsOverviewPage = lazy(() => import('@/app/pages/admin/settings/AdminSettingsOverviewPage'));
    const AdminSettingsProfilePage = lazy(() => import('@/app/pages/admin/settings/AdminSettingsProfilePage'));
    const AdminSettingsAdminAppearancePage = lazy(() => import('@/app/pages/admin/settings/AdminSettingsAdminAppearancePage'));
    const AdminSettingsPanelUsersPage = lazy(() => import('@/app/pages/admin/settings/AdminSettingsPanelUsersPage'));
    const AdminSettingsStoreGeneralFiscalPage = lazy(() => import('@/app/pages/admin/settings/store/AdminSettingsStoreGeneralFiscalPage'));
    const AdminSettingsStoreAppearancePage = lazy(() => import('@/app/pages/admin/settings/store/AdminSettingsStoreAppearancePage'));
    const AdminSettingsStoreTransactionalEmailsPage = lazy(() => import('@/app/pages/admin/settings/store/AdminSettingsStoreTransactionalEmailsPage'));
    const AdminSettingsStoreTransactionalSmsPage = lazy(() => import('@/app/pages/admin/settings/store/AdminSettingsStoreTransactionalSmsPage'));
    const AdminSettingsStoreCheckoutPage = lazy(() => import('@/app/pages/admin/settings/store/AdminSettingsStoreCheckoutPage'));
    const AdminSettingsStorePoliciesPage = lazy(() => import('@/app/pages/admin/settings/store/AdminSettingsStorePoliciesPage'));
    const AdminSettingsStoreLocalizationPage = lazy(() => import('@/app/pages/admin/settings/store/AdminSettingsStoreLocalizationPage'));
    const AdminSettingsIntegrationsSmsPage = lazy(() => import('@/app/pages/admin/settings/integrations/AdminSettingsIntegrationsSmsPage'));
    const AdminSettingsIntegrationsWhatsappVittachatPage = lazy(() => import('@/app/pages/admin/settings/integrations/whatsapp/AdminSettingsIntegrationsWhatsappVittachatPage'));
    const AdminSettingsIntegrationsWhatsappWabaPage = lazy(() => import('@/app/pages/admin/settings/integrations/whatsapp/AdminSettingsIntegrationsWhatsappWabaPage'));
    const AdminSettingsIntegrationsWhatsappBotPage = lazy(() => import('@/app/pages/admin/settings/integrations/whatsapp/AdminSettingsIntegrationsWhatsappBotPage'));
    const AdminSettingsIntegrationsWhatsappSmartNotificationsPage = lazy(() => import('@/app/pages/admin/settings/integrations/whatsapp/AdminSettingsIntegrationsWhatsappSmartNotificationsPage'));
    const AdminSettingsIntegrationsEmailActiveCampaignPage = lazy(() => import('@/app/pages/admin/settings/integrations/email/AdminSettingsIntegrationsEmailActiveCampaignPage'));
    const AdminSettingsIntegrationsEmailMauticPage = lazy(() => import('@/app/pages/admin/settings/integrations/email/AdminSettingsIntegrationsEmailMauticPage'));
    const AdminSettingsIntegrationsEmailBrevoPage = lazy(() => import('@/app/pages/admin/settings/integrations/email/AdminSettingsIntegrationsEmailBrevoPage'));
    const AdminSettingsIntegrationsPaymentVittapayPage = lazy(() => import('@/app/pages/admin/settings/integrations/payment/AdminSettingsIntegrationsPaymentVittapayPage'));
    const AdminSettingsIntegrationsPaymentPagarmePage = lazy(() => import('@/app/pages/admin/settings/integrations/payment/AdminSettingsIntegrationsPaymentPagarmePage'));
    const AdminSettingsIntegrationsPaymentAsaasPage = lazy(() => import('@/app/pages/admin/settings/integrations/payment/AdminSettingsIntegrationsPaymentAsaasPage'));
    const AdminSettingsIntegrationsPaymentMercadopagoPage = lazy(() => import('@/app/pages/admin/settings/integrations/payment/AdminSettingsIntegrationsPaymentMercadopagoPage'));
    const AdminSettingsIntegrationsInvoiceNotazzPage = lazy(() => import('@/app/pages/admin/settings/integrations/invoice/AdminSettingsIntegrationsInvoiceNotazzPage'));
    const AdminSettingsIntegrationsInvoiceBlingPage = lazy(() => import('@/app/pages/admin/settings/integrations/invoice/AdminSettingsIntegrationsInvoiceBlingPage'));
    const AdminSettingsIntegrationsInvoiceSpeedyPage = lazy(() => import('@/app/pages/admin/settings/integrations/invoice/AdminSettingsIntegrationsInvoiceSpeedyPage'));
    const AdminSettingsIntegrationsShippingCorreiosPage = lazy(() => import('@/app/pages/admin/settings/integrations/shipping/AdminSettingsIntegrationsShippingCorreiosPage'));
    const AdminSettingsIntegrationsShippingJadlogPage = lazy(() => import('@/app/pages/admin/settings/integrations/shipping/AdminSettingsIntegrationsShippingJadlogPage'));
    const AdminSettingsIntegrationsShippingMelhorenvioPage = lazy(() => import('@/app/pages/admin/settings/integrations/shipping/AdminSettingsIntegrationsShippingMelhorenvioPage'));
    const AdminSettingsIntegrationsDomainPage = lazy(() => import('@/app/pages/admin/settings/integrations/AdminSettingsIntegrationsDomainPage'));
    const AdminSettingsIntegrationsWebhookPage = lazy(() => import('@/app/pages/admin/settings/integrations/AdminSettingsIntegrationsWebhookPage'));
    const AdminSettingsIntegrationsApiPage = lazy(() => import('@/app/pages/admin/settings/integrations/AdminSettingsIntegrationsApiPage'));

    const AdminRoutes = () => {
      return (
        <Routes>
          <Route element={
            <ProtectedRoute allowedRoles={['admin', 'super_admin']}> {/* super_admin can also access tenant admin panel */}
              <MainLayoutAdmin />
            </ProtectedRoute>
          }>
            <Route path="dashboard" element={<AdminDashboardPage />} />
            
            {/* Placeholder routes for new top-level items */}
            <Route path="marketplace" element={<div>Vitrine de Lojas Page (Placeholder)</div>} />
            <Route path="referral-program" element={<div>Indique e Ganhe Page (Placeholder)</div>} />

            {/* Placeholder routes for new "Produtos & Papéis" sub-items */}
            <Route path="my-products" element={<AdminProductsPage />} /> {/* Reusing AdminProductsPage for now */}
            <Route path="roles/affiliate" element={<div>Como Afiliado Page (Placeholder)</div>} />
            <Route path="roles/coproducer" element={<div>Como Coprodutor Page (Placeholder)</div>} />
            <Route path="roles/affiliate-manager" element={<div>Como Gerente de Afiliados Page (Placeholder)</div>} />
            <Route path="roles/supplier" element={<div>Como Fornecedor Page (Placeholder)</div>} />
            <Route path="roles/logistics-operator" element={<div>Como Operador Logístico Page (Placeholder)</div>} />


            <Route path="sales/transactions" element={<AdminSalesTransactionsPage />} />
            <Route path="sales/orders" element={<AdminOrdersPage />} />
            <Route path="sales/customers-report" element={<AdminSalesCustomersReportPage />} />
            <Route path="sales/refunds" element={<AdminSalesRefundsPage />} />
            <Route path="sales/abandoned-carts" element={<AdminSalesAbandonedCartsPage />} />
            <Route path="customers" element={<AdminCustomersPage />} />
            <Route path="customers/new" element={<AdminCustomersNewPage />} />
            
            {/* Old product routes - to be reviewed if they are still directly accessible or part of "my-products" flow */}
            {/* <Route path="products" element={<AdminProductsPage />} /> */}
            <Route path="products/new" element={<AdminAddEditProductPage />} />
            <Route path="products/edit/:productId" element={<AdminAddEditProductPage />} />
            <Route path="products/categories" element={<AdminProductsCategoriesPage />} />
            <Route path="products/brands" element={<AdminProductsBrandsPage />} />
            <Route path="products/attributes" element={<AdminProductsAttributesPage />} />
            <Route path="products/reviews" element={<AdminProductsReviewsPage />} />
            <Route path="products/coupons" element={<AdminCouponsPage />} />

            <Route path="inventory/overview" element={<AdminInventoryOverviewPage />} />
            <Route path="inventory/adjustments" element={<AdminInventoryAdjustmentsPage />} />
            <Route path="inventory/history" element={<AdminInventoryHistoryPage />} />
            <Route path="finance/summary" element={<AdminFinanceSummaryPage />} />
            <Route path="finance/withdrawals" element={<AdminFinanceWithdrawalsPage />} />
            <Route path="finance/advances" element={<AdminFinanceAdvancesPage />} />
            <Route path="finance/bank-accounts" element={<AdminFinanceBankAccountsPage />} />
            <Route path="finance/invoices" element={<AdminFinanceInvoicesPage />} />
            <Route path="finance/statement" element={<AdminFinanceStatementPage />} />
            <Route path="shipping/summary" element={<AdminShippingSummaryPage />} />
            <Route path="shipping/zones" element={<AdminShippingZonesPage />} />
            <Route path="shipping/methods-rates" element={<AdminShippingMethodsRatesPage />} />
            <Route path="shipping/labels" element={<AdminShippingLabelsPage />} />
            <Route path="shipping/plp" element={<AdminShippingPlpPage />} />
            <Route path="shipping/quotes" element={<AdminShippingQuotesPage />} />
            <Route path="shipping" element={<Navigate to="summary" replace />} /> 
            <Route path="marketing/coupons" element={<AdminMarketingCouponsPage />} />
            <Route path="marketing/promotions" element={<AdminMarketingPromotionsPage />} />
            <Route path="marketing/seo" element={<AdminMarketingSeoPage />} />
            <Route path="reports/sales" element={<AdminReportsSalesPage />} />
            <Route path="reports/inventory" element={<AdminReportsInventoryPage />} />
            <Route path="reports/customers" element={<AdminReportsCustomersPage />} />
            <Route path="reports/finance" element={<AdminReportsFinancePage />} />
            
            {/* New Settings Overview Route */}
            <Route path="settings" element={<AdminSettingsOverviewPage />} />

            {/* Old Settings Sub-Routes - these will be accessed via cards from AdminSettingsOverviewPage */}
            <Route path="settings/profile" element={<AdminSettingsProfilePage />} />
            <Route path="settings/admin-appearance" element={<AdminSettingsAdminAppearancePage />} />
            <Route path="settings/panel-users" element={<AdminSettingsPanelUsersPage />} />
            <Route path="settings/store/general-fiscal" element={<AdminSettingsStoreGeneralFiscalPage />} />
            <Route path="settings/store/appearance" element={<AdminSettingsStoreAppearancePage />} />
            <Route path="settings/store/transactional-emails" element={<AdminSettingsStoreTransactionalEmailsPage />} />
            <Route path="settings/store/transactional-sms" element={<AdminSettingsStoreTransactionalSmsPage />} />
            <Route path="settings/store/checkout" element={<AdminSettingsStoreCheckoutPage />} />
            <Route path="settings/store/policies" element={<AdminSettingsStorePoliciesPage />} />
            <Route path="settings/store/localization" element={<AdminSettingsStoreLocalizationPage />} />
            <Route path="settings/integrations/sms" element={<AdminSettingsIntegrationsSmsPage />} />
            <Route path="settings/integrations/whatsapp/vittachat" element={<AdminSettingsIntegrationsWhatsappVittachatPage />} />
            <Route path="settings/integrations/whatsapp/waba" element={<AdminSettingsIntegrationsWhatsappWabaPage />} />
            <Route path="settings/integrations/whatsapp/bot" element={<AdminSettingsIntegrationsWhatsappBotPage />} />
            <Route path="settings/integrations/whatsapp/smart-notifications" element={<AdminSettingsIntegrationsWhatsappSmartNotificationsPage />} />
            <Route path="settings/integrations/email/active-campaign" element={<AdminSettingsIntegrationsEmailActiveCampaignPage />} />
            <Route path="settings/integrations/email/mautic" element={<AdminSettingsIntegrationsEmailMauticPage />} />
            <Route path="settings/integrations/email/brevo" element={<AdminSettingsIntegrationsEmailBrevoPage />} />
            <Route path="settings/integrations/payment/vittapay" element={<AdminSettingsIntegrationsPaymentVittapayPage />} />
            <Route path="settings/integrations/payment/pagarme" element={<AdminSettingsIntegrationsPaymentPagarmePage />} />
            <Route path="settings/integrations/payment/asaas" element={<AdminSettingsIntegrationsPaymentAsaasPage />} />
            <Route path="settings/integrations/payment/mercadopago" element={<AdminSettingsIntegrationsPaymentMercadopagoPage />} />
            <Route path="settings/integrations/invoice/notazz" element={<AdminSettingsIntegrationsInvoiceNotazzPage />} />
            <Route path="settings/integrations/invoice/bling" element={<AdminSettingsIntegrationsInvoiceBlingPage />} />
            <Route path="settings/integrations/invoice/speedy" element={<AdminSettingsIntegrationsInvoiceSpeedyPage />} />
            <Route path="settings/integrations/shipping/correios" element={<AdminSettingsIntegrationsShippingCorreiosPage />} />
            <Route path="settings/integrations/shipping/jadlog" element={<AdminSettingsIntegrationsShippingJadlogPage />} />
            <Route path="settings/integrations/shipping/melhorenvio" element={<AdminSettingsIntegrationsShippingMelhorenvioPage />} />
            <Route path="settings/integrations/domain" element={<AdminSettingsIntegrationsDomainPage />} />
            <Route path="settings/integrations/webhook" element={<AdminSettingsIntegrationsWebhookPage />} />
            <Route path="settings/integrations/api" element={<AdminSettingsIntegrationsApiPage />} />
            
            <Route index element={<Navigate to="dashboard" replace />} />
          </Route>
        </Routes>
      );
    };

    export default AdminRoutes;
  