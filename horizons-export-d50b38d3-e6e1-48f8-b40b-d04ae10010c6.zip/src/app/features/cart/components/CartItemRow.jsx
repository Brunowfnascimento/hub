
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Trash2 } from 'lucide-react';
import { useCart } from '@/app/contexts/CartContext';
import ProductQuantitySelectorStorefront from '@/app/features/products/components/ProductQuantitySelectorStorefront';
import { motion } from 'framer-motion';
import { formatCurrency } from '@/app/lib/formatters';
import { useTranslation } from 'react-i18next';
import { getOptimizedImageUrl } from '@/lib/imageUtils';

const CartItemRow = ({ item }) => {
  const { updateItemQuantity, removeItemFromCart } = useCart();
  const { t } = useTranslation();

  const handleQuantityChange = (newQuantity) => {
    updateItemQuantity(item.variantId || item.productId, newQuantity);
  };

  const handleRemoveItem = () => {
    removeItemFromCart(item.variantId || item.productId);
  };

  const formattedAttributes = item.attributes 
    ? Object.entries(item.attributes).map(([key, value]) => `${key}: ${value}`).join(', ')
    : '';

  const imageUrl = getOptimizedImageUrl(item.imageStoragePath, { width: 80, height: 80 });

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -50, transition: { duration: 0.3 } }}
      className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 border-b border-slate-200 dark:border-slate-700"
    >
      <div className="flex items-center gap-4 w-full sm:w-2/5">
        <Link to={`/product/${item.productSlug}`}>
          <img 
            className="w-20 h-20 object-cover rounded-md border dark:border-slate-700"
            alt={item.name}
            src={imageUrl} 
            loading="lazy"
          />
        </Link>
        <div>
          <Link to={`/product/${item.productSlug}`} className="hover:underline">
            <h3 className="font-semibold text-slate-800 dark:text-slate-100">{item.name}</h3>
          </Link>
          {formattedAttributes && (
            <p className="text-xs text-slate-500 dark:text-slate-400">{formattedAttributes}</p>
          )}
          <p className="text-sm text-slate-600 dark:text-slate-300 sm:hidden">
            {formatCurrency(item.price)}
          </p>
        </div>
      </div>

      <div className="hidden sm:block text-sm text-slate-600 dark:text-slate-300 w-1/5 text-center">
        {formatCurrency(item.price)}
      </div>

      <div className="w-full sm:w-1/5 flex justify-center">
        <ProductQuantitySelectorStorefront
          quantity={item.quantity}
          setQuantity={handleQuantityChange}
          maxQuantity={item.maxQuantityAvailable}
        />
      </div>

      <div className="hidden sm:block text-sm font-semibold text-slate-800 dark:text-slate-100 w-1/5 text-center">
        {formatCurrency(item.price * item.quantity)}
      </div>
      
      <div className="w-full sm:w-auto flex sm:flex-col items-center justify-between mt-2 sm:mt-0">
         <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 sm:hidden">
            {t('cartPage.total', 'Total')}: {formatCurrency(item.price * item.quantity)}
          </p>
        <Button variant="ghost" size="icon" onClick={handleRemoveItem} className="text-red-500 hover:text-red-700 dark:hover:text-red-400">
          <Trash2 className="h-5 w-5" />
          <span className="sr-only">Remover item</span>
        </Button>
      </div>
    </motion.div>
  );
};

export default CartItemRow;
