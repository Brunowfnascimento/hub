
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/app/contexts/CartContext';
import { ShoppingBag, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatCurrency } from '@/app/lib/formatters';
import { useTranslation } from 'react-i18next';

const CartSummary = () => {
  const { subtotalAmount, totalQuantity } = useCart();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const shippingCost = 0.00; 
  const discountAmount = 0.00; 
  const totalAmount = subtotalAmount + shippingCost - discountAmount;

  const handleCheckout = () => {
    navigate('/checkout');
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="shadow-lg bg-white dark:bg-slate-800 border dark:border-slate-700 rounded-xl">
        <CardHeader className="pb-4">
          <CardTitle className="text-2xl font-semibold text-slate-800 dark:text-slate-100 flex items-center">
            <ShoppingBag className="mr-3 h-7 w-7 text-sky-500" />
            {t('cartSummary.title', 'Resumo do Pedido')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-700 dark:text-slate-300">
          <div className="flex justify-between">
            <span>{t('cartSummary.subtotal', 'Subtotal')} ({totalQuantity} {totalQuantity === 1 ? t('cartSummary.item', 'item') : t('cartSummary.items', 'itens')})</span>
            <span className="font-medium">{formatCurrency(subtotalAmount)}</span>
          </div>
          <div className="flex justify-between">
            <span>{t('cartSummary.shipping', 'Frete')}</span>
            <span className="font-medium">{shippingCost > 0 ? formatCurrency(shippingCost) : t('cartSummary.shippingFree', 'Grátis (ou a calcular)')}</span>
          </div>
          <div className="flex justify-between">
            <span>{t('cartSummary.discounts', 'Descontos')}</span>
            <span className="font-medium text-green-600 dark:text-green-400">- {formatCurrency(discountAmount)}</span>
          </div>
          <Separator className="my-3 bg-slate-200 dark:bg-slate-700" />
          <div className="flex justify-between text-xl font-bold text-slate-900 dark:text-slate-50">
            <span>{t('cartSummary.totalEstimate', 'Total Estimado')}</span>
            <span>{formatCurrency(totalAmount)}</span>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-3 pt-6">
          <Button 
            size="lg" 
            className="w-full bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white text-lg font-semibold py-3 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
            onClick={handleCheckout}
          >
            {t('cartSummary.checkout', 'Finalizar Compra')} <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button variant="outline" size="lg" className="w-full dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700" asChild>
            <Link to="/products">{t('cartSummary.continueShopping', 'Continuar Comprando')}</Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default CartSummary;
