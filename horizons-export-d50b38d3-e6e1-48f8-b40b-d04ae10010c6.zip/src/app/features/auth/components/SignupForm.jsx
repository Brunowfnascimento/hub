
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/app/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

const SignupForm = () => {
  const navigate = useNavigate();
  const { signUpWithEmailPassword, isLoadingUser } = useAuth();
  const { toast } = useToast();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!fullName || !email || !password || !confirmPassword) {
      toast({
        variant: "destructive",
        title: "Erro de Validação",
        description: "Por favor, preencha todos os campos.",
      });
      return;
    }
    if (password !== confirmPassword) {
      toast({
        variant: "destructive",
        title: "Erro de Validação",
        description: "As senhas não coincidem.",
      });
      return;
    }

    const { error, data } = await signUpWithEmailPassword(email, password, fullName);

    if (error) {
      toast({
        variant: "destructive",
        title: "Erro no Registro",
        description: error.message || "Ocorreu um erro ao tentar se registrar.",
      });
    } else if (data && data.user && data.session) {
       toast({
        title: "Registro bem-sucedido!",
        description: "Você será redirecionado para fazer login.",
      });
      navigate('/'); 
    } else if (data && data.user && !data.session) {
      toast({
        title: "Registro quase completo!",
        description: "Por favor, verifique seu email para confirmar sua conta antes de fazer login.",
      });
      // Idealmente, redirecionar para uma página "verifique seu email" ou limpar formulário
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="fullName-signup">Nome Completo</Label>
        <Input
          id="fullName-signup"
          type="text"
          placeholder="Seu nome completo"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          disabled={isLoadingUser}
          className="bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="email-signup">Email</Label>
        <Input
          id="email-signup"
          type="email"
          placeholder="seu@email.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          disabled={isLoadingUser}
          className="bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password-signup">Senha</Label>
        <Input
          id="password-signup"
          type="password"
          placeholder="Crie uma senha"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          disabled={isLoadingUser}
          className="bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="confirmPassword-signup">Confirmar Senha</Label>
        <Input
          id="confirmPassword-signup"
          type="password"
          placeholder="Confirme sua senha"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          disabled={isLoadingUser}
          className="bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600"
        />
      </div>
      <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 dark:bg-emerald-500 dark:hover:bg-emerald-600 text-white" disabled={isLoadingUser}>
        {isLoadingUser ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Registrar"}
      </Button>
    </form>
  );
};

export default SignupForm;
  