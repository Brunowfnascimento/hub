
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/app/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

const LoginForm = () => {
  const navigate = useNavigate();
  const { loginWithEmailPassword, isLoadingUser } = useAuth();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        variant: "destructive",
        title: "Erro de Validação",
        description: "Por favor, preencha email e senha.",
      });
      return;
    }

    const { error } = await loginWithEmailPassword(email, password);

    if (error) {
      toast({
        variant: "destructive",
        title: "Erro no Login",
        description: error.message || "Ocorreu um erro ao tentar fazer login.",
      });
    } else {
      toast({
        title: "Login bem-sucedido!",
        description: "Você será redirecionado em breve.",
      });
      navigate('/'); 
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="email-login">Email</Label>
        <Input
          id="email-login"
          type="email"
          placeholder="seu@email.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          disabled={isLoadingUser}
          className="bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password-login">Senha</Label>
        <Input
          id="password-login"
          type="password"
          placeholder="Sua senha"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          disabled={isLoadingUser}
          className="bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600"
        />
      </div>
      <Button type="submit" className="w-full bg-sky-600 hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-600 text-white" disabled={isLoadingUser}>
        {isLoadingUser ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Entrar"}
      </Button>
    </form>
  );
};

export default LoginForm;
  