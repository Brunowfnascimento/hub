
import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider, useAuth } from '@/app/contexts/AuthContext';
import LoginForm from './LoginForm';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';

const mockLoginWithEmailPassword = jest.fn();
const mockNavigate = jest.fn();
const mockToast = jest.fn();

jest.mock('@/app/contexts/AuthContext', () => ({
  ...jest.requireActual('@/app/contexts/AuthContext'),
  useAuth: () => ({
    loginWithEmailPassword: mockLoginWithEmailPassword,
    isLoadingUser: false, 
  }),
}));

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));

jest.mock('@/components/ui/use-toast', () => ({
  useToast: () => ({
    toast: mockToast,
  }),
}));

const queryClient = new QueryClient();

const AllTheProviders = ({ children, authContextValue }) => {
  const actualAuthContext = jest.requireActual('@/app/contexts/AuthContext');
  const mockAuthHook = authContextValue 
    ? () => authContextValue 
    : () => ({ 
        loginWithEmailPassword: mockLoginWithEmailPassword, 
        isLoadingUser: false,
        ...actualAuthContext.useAuth() 
      });

  jest.spyOn(actualAuthContext, 'useAuth').mockImplementation(mockAuthHook);
  
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <MemoryRouter initialEntries={['/login']}>
          <Routes>
            <Route path="/login" element={children} />
            <Route path="/" element={<div>Home Page</div>} />
          </Routes>
          <Toaster />
        </MemoryRouter>
      </AuthProvider>
    </QueryClientProvider>
  );
};


describe('LoginForm Integration Test', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    queryClient.clear();
  });

  test('renders email and password fields, and login button', () => {
    render(<LoginForm />, { wrapper: AllTheProviders });
    expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/senha/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /entrar/i })).toBeInTheDocument();
  });

  test('calls loginWithEmailPassword with correct credentials on successful submission and navigates', async () => {
    mockLoginWithEmailPassword.mockResolvedValueOnce({ error: null });
    
    render(<LoginForm />, { wrapper: AllTheProviders });

    await userEvent.type(screen.getByLabelText(/email/i), 'test@example.com');
    await userEvent.type(screen.getByLabelText(/senha/i), 'password123');
    await userEvent.click(screen.getByRole('button', { name: /entrar/i }));

    await waitFor(() => {
      expect(mockLoginWithEmailPassword).toHaveBeenCalledWith('test@example.com', 'password123');
    });
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith(expect.objectContaining({
        title: "Login bem-sucedido!",
      }));
    });
    await waitFor(() => {
      expect(mockNavigate).toHaveBeenCalledWith('/');
    });
  });

  test('shows validation error toast if fields are empty', async () => {
    render(<LoginForm />, { wrapper: AllTheProviders });

    await userEvent.click(screen.getByRole('button', { name: /entrar/i }));

    await waitFor(() => {
      expect(mockLoginWithEmailPassword).not.toHaveBeenCalled();
    });
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith(expect.objectContaining({
        variant: "destructive",
        title: "Erro de Validação",
        description: "Por favor, preencha email e senha.",
      }));
    });
  });

  test('shows API error toast if login fails', async () => {
    const errorMessage = 'Invalid credentials';
    mockLoginWithEmailPassword.mockResolvedValueOnce({ error: { message: errorMessage } });

    render(<LoginForm />, { wrapper: AllTheProviders });

    await userEvent.type(screen.getByLabelText(/email/i), 'wrong@example.com');
    await userEvent.type(screen.getByLabelText(/senha/i), 'wrongpassword');
    await userEvent.click(screen.getByRole('button', { name: /entrar/i }));

    await waitFor(() => {
      expect(mockLoginWithEmailPassword).toHaveBeenCalledWith('wrong@example.com', 'wrongpassword');
    });
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith(expect.objectContaining({
        variant: "destructive",
        title: "Erro no Login",
        description: errorMessage,
      }));
    });
  });

  test('shows loading state on button when submitting', async () => {
    const actualAuthContext = jest.requireActual('@/app/contexts/AuthContext');
    const mockAuthHookLoading = () => ({ 
      loginWithEmailPassword: () => new Promise(resolve => setTimeout(() => resolve({ error: null }), 100)), 
      isLoadingUser: true, // Simulate loading state from context
      ...actualAuthContext.useAuth()
    });
    
    // Temporarily override useAuth for this specific test
    const originalUseAuth = actualAuthContext.useAuth;
    actualAuthContext.useAuth = mockAuthHookLoading;


    render(<LoginForm />, { wrapper: ({ children }) => (
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <MemoryRouter>
            {children}
            <Toaster />
          </MemoryRouter>
        </AuthProvider>
      </QueryClientProvider>
    ) });
    
    const loginButton = screen.getByRole('button', { name: /entrar/i });
    expect(loginButton).toBeDisabled();
    expect(screen.getByRole('button', { name: /entrar/i }).querySelector('.animate-spin')).toBeInTheDocument();

    // Restore original useAuth after test
    actualAuthContext.useAuth = originalUseAuth;

    // Wait for the mock login to complete to avoid state update issues after unmount
    await waitFor(() => expect(mockToast).toHaveBeenCalledWith(expect.objectContaining({
        title: "Login bem-sucedido!",
      })), { timeout: 500 }); 
  });


   test('inputs are disabled when isLoadingUser is true from context', () => {
    const actualAuthContext = jest.requireActual('@/app/contexts/AuthContext');
    const mockAuthHookLoading = () => ({ 
      loginWithEmailPassword: mockLoginWithEmailPassword, 
      isLoadingUser: true, 
      ...actualAuthContext.useAuth()
    });
    
    const originalUseAuth = actualAuthContext.useAuth;
    actualAuthContext.useAuth = mockAuthHookLoading;

    render(<LoginForm />, { wrapper: ({ children }) => (
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <MemoryRouter>
            {children}
          </MemoryRouter>
        </AuthProvider>
      </QueryClientProvider>
    ) });

    expect(screen.getByLabelText(/email/i)).toBeDisabled();
    expect(screen.getByLabelText(/senha/i)).toBeDisabled();
    expect(screen.getByRole('button', { name: /entrar/i })).toBeDisabled();
    
    actualAuthContext.useAuth = originalUseAuth;
  });

});
