
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { getOptimizedImageUrl } from '@/lib/imageUtils';
import { formatCurrency } from '@/app/lib/formatters';
import { useTranslation } from 'react-i18next';

const ProductCardStorefront = React.memo(({ product, isLoading }) => {
  const { t } = useTranslation();

  if (isLoading) {
    return (
      <Card className="overflow-hidden shadow-lg dark:bg-slate-800 border-slate-200 dark:border-slate-700 flex flex-col h-full">
        <div className="w-full h-48 bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
        <CardHeader className="p-4">
          <div className="h-6 w-3/4 bg-slate-200 dark:bg-slate-700 animate-pulse rounded"></div>
        </CardHeader>
        <CardContent className="p-4 flex-grow">
          <div className="h-4 w-1/2 bg-slate-200 dark:bg-slate-700 animate-pulse rounded mb-2"></div>
          <div className="h-4 w-1/4 bg-slate-200 dark:bg-slate-700 animate-pulse rounded"></div>
        </CardContent>
        <CardFooter className="p-4 flex justify-between">
          <div className="h-10 w-24 bg-slate-200 dark:bg-slate-700 animate-pulse rounded"></div>
          <div className="h-10 w-10 bg-slate-200 dark:bg-slate-700 animate-pulse rounded-full"></div>
        </CardFooter>
      </Card>
    );
  }

  if (!product) return null;

  const displayPrice = () => {
    if (product.has_variants && product.variants && product.variants.length > 0) {
      const prices = product.variants.map(v => v.price_override !== null && v.price_override !== undefined ? v.price_override : product.base_price).filter(p => p !== null && p !== undefined);
      if (prices.length === 0) return formatCurrency(product.base_price || 0);
      const minPrice = Math.min(...prices);
      return `${t('product.fromPrice', 'A partir de R$')} ${minPrice.toFixed(2)}`;
    }
    return formatCurrency(product.base_price || 0);
  };

  const hasNewTag = product.tags?.includes('novo') || (new Date(product.created_at) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)); 
  const hasPromoTag = product.compare_at_price && product.compare_at_price > product.base_price || product.variants?.some(v => v.compare_at_price_override && v.compare_at_price_override > (v.price_override ?? product.base_price));

  const imageUrl = getOptimizedImageUrl(product.main_image_storage_path || product.images?.[0]?.storage_path, { width: 400, height: 400 });


  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
      className="h-full"
    >
      <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 dark:bg-slate-800 border-slate-200 dark:border-slate-700 flex flex-col h-full group">
        <Link to={`/product/${product.slug}`} className="block">
          <div className="relative overflow-hidden aspect-square">
            <img 
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              data-optimized-src={imageUrl}
              loading="lazy"
             src="https://images.unsplash.com/photo-1635865165118-917ed9e20936" />
            <div className="absolute top-2 right-2 flex flex-col space-y-1">
              {hasNewTag && <Badge variant="secondary" className="bg-sky-500 text-white">NOVO</Badge>}
              {hasPromoTag && <Badge variant="destructive">PROMO</Badge>}
            </div>
          </div>
        </Link>
        <CardHeader className="p-4">
          <Link to={`/product/${product.slug}`}>
            <CardTitle className="text-lg font-semibold text-slate-800 dark:text-slate-100 hover:text-sky-600 dark:hover:text-sky-400 transition-colors truncate">
              {product.name}
            </CardTitle>
          </Link>
        </CardHeader>
        <CardContent className="p-4 pt-0 flex-grow">
          <p className="text-xl font-bold text-sky-600 dark:text-sky-400 mb-2">{displayPrice()}</p>
          {product.category && (
            <Link to={`/products?category=${product.category.slug}`}>
              <Badge variant="outline" className="text-xs dark:border-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
                {product.category.name}
              </Badge>
            </Link>
          )}
        </CardContent>
        <CardFooter className="p-4 border-t dark:border-slate-700/50 flex items-center justify-between gap-2">
          <Button asChild variant="outline" className="flex-1 group/button border-sky-500 text-sky-500 hover:bg-sky-500 hover:text-white dark:border-sky-400 dark:text-sky-400 dark:hover:bg-sky-400 dark:hover:text-slate-900 transition-all duration-300">
            <Link to={`/product/${product.slug}`} className="flex items-center justify-center">
              <Eye className="mr-2 h-4 w-4 transition-transform duration-300 group-hover/button:scale-110" /> {t('product.details', 'Ver Detalhes')}
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
});

export default ProductCardStorefront;
