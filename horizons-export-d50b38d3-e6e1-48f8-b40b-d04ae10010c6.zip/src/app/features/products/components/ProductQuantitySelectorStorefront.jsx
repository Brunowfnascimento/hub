
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Minus, Plus } from 'lucide-react';
import { motion } from 'framer-motion';

const ProductQuantitySelectorStorefront = ({ quantity, setQuantity, maxQuantity, disabled = false, productId }) => {
  const inputId = `quantity-${productId || Math.random().toString(36).substring(7)}`;

  const increment = () => {
    if (quantity < maxQuantity) {
      setQuantity(quantity + 1);
    }
  };

  const decrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleChange = (e) => {
    let value = parseInt(e.target.value, 10);
    if (isNaN(value) || value < 1) {
      value = 1;
    } else if (value > maxQuantity) {
      value = maxQuantity;
    }
    setQuantity(value);
  };

  return (
    <motion.div 
      className="flex items-center space-x-2"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3 }}
    >
      <Label htmlFor={inputId} className="sr-only">Quantidade do produto</Label>
      <Button
        variant="outline"
        size="icon"
        onClick={decrement}
        disabled={disabled || quantity <= 1}
        className="border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50"
        aria-label="Diminuir quantidade"
      >
        <Minus className="h-4 w-4" />
      </Button>
      <Input
        type="number"
        id={inputId}
        value={quantity}
        onChange={handleChange}
        min="1"
        max={maxQuantity}
        disabled={disabled}
        className="w-16 text-center dark:bg-slate-700 dark:border-slate-600 focus-visible:ring-sky-500"
        aria-describedby={`max-quantity-hint-${inputId}`}
      />
       <p id={`max-quantity-hint-${inputId}`} className="sr-only">Máximo de {maxQuantity} unidades.</p>
      <Button
        variant="outline"
        size="icon"
        onClick={increment}
        disabled={disabled || quantity >= maxQuantity}
        className="border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50"
        aria-label="Aumentar quantidade"
      >
        <Plus className="h-4 w-4" />
      </Button>
    </motion.div>
  );
};

export default ProductQuantitySelectorStorefront;
