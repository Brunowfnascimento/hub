
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getOptimizedImageUrl } from '@/lib/imageUtils';

const ProductImageGalleryStorefront = React.memo(({ images = [], productName = "Produto" }) => {
  const [mainImageStoragePath, setMainImageStoragePath] = useState(null);
  const [mainImageAltText, setMainImageAltText] = useState(productName);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomPosition, setZoomPosition] = useState({ x: 0, y: 0 });
  const [liveRegionMessage, setLiveRegionMessage] = useState('');

  const sortedImages = useMemo(() => {
    return images.length > 0 ? [...images].sort((a, b) => (a.display_order ?? Infinity) - (b.display_order ?? Infinity)) : [];
  }, [images]);

  useEffect(() => {
    if (sortedImages.length > 0) {
      const initialImage = sortedImages[0];
      setMainImageStoragePath(initialImage.storage_path);
      setMainImageAltText(initialImage.alt_text || `${productName} - Imagem 1`);
      setCurrentIndex(0);
      setLiveRegionMessage(`Exibindo ${initialImage.alt_text || `Imagem 1 de ${productName}`}`);
    } else {
      setMainImageStoragePath(null); 
      setMainImageAltText('Imagem indisponível');
      setCurrentIndex(0);
      setLiveRegionMessage('Nenhuma imagem disponível.');
    }
  }, [sortedImages, productName]);

  const handleThumbnailClick = (image, index) => {
    setMainImageStoragePath(image.storage_path);
    const altText = image.alt_text || `${productName} - Imagem ${index + 1}`;
    setMainImageAltText(altText);
    setCurrentIndex(index);
    setLiveRegionMessage(`Exibindo ${altText}`);
  };

  const handleMouseMove = (e) => {
    if (!isZoomed) return;
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.pageX - left) / width) * 100;
    const y = ((e.pageY - top) / height) * 100;
    setZoomPosition({ x, y });
  };
  
  const mainImageUrlOptimized = getOptimizedImageUrl(mainImageStoragePath, { width: 800, height: 800 });
  const mainImageUrlZoomed = getOptimizedImageUrl(mainImageStoragePath, { width: 1600, height: 1600, resize: 'fill' });


  if (sortedImages.length === 0 && !mainImageStoragePath) {
    return (
      <div className="w-full aspect-square bg-slate-200 dark:bg-slate-700 flex items-center justify-center rounded-lg" role="img" aria-label="Nenhuma imagem disponível para este produto.">
        <p className="text-slate-500 dark:text-slate-400">Sem imagem</p>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col gap-4">
      <div 
        className="relative aspect-square w-full overflow-hidden rounded-lg shadow-lg border dark:border-slate-700 cursor-zoom-in group"
        onMouseEnter={() => setIsZoomed(true)}
        onMouseLeave={() => setIsZoomed(false)}
        onMouseMove={handleMouseMove}
        role="figure"
        aria-label={`Imagem principal: ${mainImageAltText}`}
      >
        <AnimatePresence mode="wait">
          <motion.img
            key={mainImageStoragePath || 'placeholder'}
            src={isZoomed ? mainImageUrlZoomed : mainImageUrlOptimized}
            alt={mainImageAltText}
            className="w-full h-full object-contain transition-transform duration-300"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: isZoomed ? 1.5 : 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            style={{
              transformOrigin: isZoomed ? `${zoomPosition.x}% ${zoomPosition.y}%` : 'center center',
            }}
            loading="lazy"
          />
        </AnimatePresence>
         <div className="absolute top-2 right-2 p-2 bg-black/30 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity" aria-hidden="true">
          <ZoomIn size={20} />
        </div>
      </div>
      
      <div 
        className="sr-only" 
        aria-live="polite" 
        aria-atomic="true"
      >
        {liveRegionMessage}
      </div>

      {sortedImages.length > 1 && (
        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 gap-2" role="listbox" aria-label="Miniaturas das imagens do produto">
          {sortedImages.map((image, index) => {
            const thumbnailUrl = getOptimizedImageUrl(image.storage_path, { width: 100, height: 100 });
            const thumbnailAltText = image.alt_text || `Miniatura ${index + 1} de ${productName}`;
            return (
            <motion.button
              key={image.id || index}
              onClick={() => handleThumbnailClick(image, index)}
              className={cn(
                "aspect-square rounded-md overflow-hidden border-2 focus:outline-none focus:ring-2 focus:ring-sky-500 transition-all duration-200",
                mainImageStoragePath === image.storage_path ? "border-sky-500 shadow-md" : "border-transparent hover:border-slate-300 dark:hover:border-slate-600 opacity-70 hover:opacity-100"
              )}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              role="option"
              aria-selected={mainImageStoragePath === image.storage_path}
              aria-label={`Selecionar ${thumbnailAltText}`}
            >
              <img
                src={thumbnailUrl}
                alt={thumbnailAltText}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </motion.button>
          );
          })}
        </div>
      )}
    </div>
  );
});

export default ProductImageGalleryStorefront;
