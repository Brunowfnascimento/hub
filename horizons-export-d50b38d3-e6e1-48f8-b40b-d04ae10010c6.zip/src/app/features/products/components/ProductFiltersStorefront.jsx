
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { WorkspaceStorefrontCategories, WorkspaceStorefrontBrands } from '@/app/features/products/services/productStorefront.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, ListFilter, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { cn } from '@/lib/utils';

const ProductFiltersStorefront = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const [searchTerm, setSearchTerm] = useState(searchParams.get('searchTerm') || '');
  const [priceRange, setPriceRange] = useState([
    parseInt(searchParams.get('minPrice') || '0', 10),
    parseInt(searchParams.get('maxPrice') || '1000', 10) 
  ]);
  const [tempSearchTerm, setTempSearchTerm] = useState(searchParams.get('searchTerm') || '');

  const { data: categories, isLoading: isLoadingCategories } = useQuery({
    queryKey: ['storefrontCategories'],
    queryFn: WorkspaceStorefrontCategories,
  });

  const { data: brands, isLoading: isLoadingBrands } = useQuery({
    queryKey: ['storefrontBrands'],
    queryFn: WorkspaceStorefrontBrands,
  });

  const updateQueryParam = (key, value) => {
    const newSearchParams = new URLSearchParams(searchParams);
    if (value === null || value === '' || (Array.isArray(value) && value.length === 0)) {
      newSearchParams.delete(key);
    } else {
      newSearchParams.set(key, String(value));
    }
    newSearchParams.set('page', '1'); 
    setSearchParams(newSearchParams, { replace: true });
  };
  
  const handleDebouncedSearch = useCallback(
    (value) => {
      updateQueryParam('searchTerm', value);
    },
    [searchParams, setSearchParams]
  );

  useEffect(() => {
    const handler = setTimeout(() => {
      if (tempSearchTerm !== searchParams.get('searchTerm')) {
        handleDebouncedSearch(tempSearchTerm);
      }
    }, 500); 
    return () => clearTimeout(handler);
  }, [tempSearchTerm, handleDebouncedSearch, searchParams]);


  const handleCategoryChange = (slug) => updateQueryParam('category', slug);
  const handleBrandChange = (slug) => updateQueryParam('brand', slug);
  
  const handleSortChange = (value) => {
    const [sortBy, sortOrder] = value.split('_');
    const newSearchParams = new URLSearchParams(searchParams);
    newSearchParams.set('sortBy', sortBy);
    newSearchParams.set('sortOrder', sortOrder);
    newSearchParams.set('page', '1');
    setSearchParams(newSearchParams, { replace: true });
  };
  
  const handlePriceChange = (newRange) => {
    setPriceRange(newRange);
  };

  const applyPriceFilter = () => {
    const newSearchParams = new URLSearchParams(searchParams);
    newSearchParams.set('minPrice', String(priceRange[0]));
    newSearchParams.set('maxPrice', String(priceRange[1]));
    newSearchParams.set('page', '1');
    setSearchParams(newSearchParams, { replace: true });
  };

  const clearFilters = () => {
    setSearchTerm('');
    setTempSearchTerm('');
    setPriceRange([0, 1000]);
    const defaultSort = 'created_at_desc';
    const newSearchParams = new URLSearchParams({ sortBy: defaultSort.split('_')[0], sortOrder: defaultSort.split('_')[1], page: '1' });
    setSearchParams(newSearchParams, { replace: true });
  };

  const currentCategory = searchParams.get('category');
  const currentBrand = searchParams.get('brand');
  const currentSort = `${searchParams.get('sortBy') || 'created_at'}_${searchParams.get('sortOrder') || 'desc'}`;

  const sortOptions = [
    { value: 'created_at_desc', label: 'Mais Recentes' },
    { value: 'base_price_asc', label: 'Preço: Menor para Maior' },
    { value: 'base_price_desc', label: 'Preço: Maior para Menor' },
    { value: 'name_asc', label: 'Nome: A-Z' },
    { value: 'name_desc', label: 'Nome: Z-A' },
  ];

  return (
    <aside className="w-full lg:w-72 space-y-6 sticky top-24 self-start">
      <Card className="dark:bg-slate-800 border-slate-200 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="text-xl flex items-center text-slate-800 dark:text-slate-100">
            <ListFilter className="mr-2 h-5 w-5" /> Filtros
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="search-store" className="text-sm font-medium text-slate-700 dark:text-slate-300">Pesquisar</Label>
            <div className="relative mt-1">
              <Input
                id="search-store"
                type="text"
                placeholder="Nome do produto..."
                value={tempSearchTerm}
                onChange={(e) => setTempSearchTerm(e.target.value)}
                className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50 pr-10"
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400 dark:text-slate-500" />
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-700 dark:text-slate-300">Ordenar por</Label>
            <Select value={currentSort} onValueChange={handleSortChange}>
              <SelectTrigger className="w-full mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent className="dark:bg-slate-800 dark:border-slate-700 dark:text-slate-50">
                {sortOptions.map(option => (
                  <SelectItem key={option.value} value={option.value} className="dark:focus:bg-slate-700">
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-700 dark:text-slate-300">Categorias</Label>
            {isLoadingCategories ? <LoadingSpinner size="h-6 w-6" /> : (
              <ul className="mt-1 space-y-1 max-h-48 overflow-y-auto pr-1">
                <li>
                  <Button variant="link" onClick={() => handleCategoryChange(null)} className={cn("p-0 h-auto text-sm font-normal dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400", !currentCategory && "text-sky-600 dark:text-sky-400 font-semibold")}>Todas</Button>
                </li>
                {categories?.map(category => (
                  <li key={category.id}>
                    <Button variant="link" onClick={() => handleCategoryChange(category.slug)} className={cn("p-0 h-auto text-sm font-normal dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400", currentCategory === category.slug && "text-sky-600 dark:text-sky-400 font-semibold")}>
                      {category.name}
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-700 dark:text-slate-300">Marcas</Label>
             {isLoadingBrands ? <LoadingSpinner size="h-6 w-6" /> : (
              <ul className="mt-1 space-y-1 max-h-48 overflow-y-auto pr-1">
                 <li>
                  <Button variant="link" onClick={() => handleBrandChange(null)} className={cn("p-0 h-auto text-sm font-normal dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400", !currentBrand && "text-sky-600 dark:text-sky-400 font-semibold")}>Todas</Button>
                </li>
                {brands?.map(brand => (
                  <li key={brand.id}>
                    <Button variant="link" onClick={() => handleBrandChange(brand.slug)} className={cn("p-0 h-auto text-sm font-normal dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400", currentBrand === brand.slug && "text-sky-600 dark:text-sky-400 font-semibold")}>
                      {brand.name}
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          
          <div>
            <Label className="text-sm font-medium text-slate-700 dark:text-slate-300">Faixa de Preço</Label>
            <Slider
              min={0}
              max={1000} 
              step={10}
              value={priceRange}
              onValueChange={handlePriceChange}
              onValueCommit={applyPriceFilter} 
              className="mt-2"
            />
            <div className="flex justify-between text-xs mt-1 text-slate-500 dark:text-slate-400">
              <span>R$ {priceRange[0]}</span>
              <span>R$ {priceRange[1]}{priceRange[1] === 1000 ? '+' : ''}</span>
            </div>
             <Button onClick={applyPriceFilter} size="sm" variant="outline" className="w-full mt-2 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700">Aplicar Preço</Button>
          </div>

          <Button onClick={clearFilters} variant="outline" className="w-full dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700">
            <X className="mr-2 h-4 w-4" /> Limpar Filtros
          </Button>
        </CardContent>
      </Card>
    </aside>
  );
};

export default ProductFiltersStorefront;
