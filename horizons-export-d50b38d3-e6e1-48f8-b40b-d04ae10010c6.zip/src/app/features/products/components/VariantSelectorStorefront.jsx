
import React, { useState, useEffect } from 'react';
import { RadioGroup } from '@/components/ui/radio-group'; 
import * as RadioGroupPrimitive from "@radix-ui/react-radio-group";
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const VariantSelectorStorefront = ({ product, onVariantSelect, currentSelectedVariant }) => {
  const [selectedOptions, setSelectedOptions] = useState({});

  useEffect(() => {
    const initialOptions = {};
    if (product && product.variant_options) {
        if (currentSelectedVariant && currentSelectedVariant.attributes) {
            Object.keys(currentSelectedVariant.attributes).forEach(key => {
                initialOptions[key] = currentSelectedVariant.attributes[key];
            });
        } else {
            product.variant_options.forEach(option => {
                initialOptions[option.name] = null; 
            });
        }
    }
    setSelectedOptions(initialOptions);
  }, [product, currentSelectedVariant]);

  if (!product || !product.has_variants || !product.variant_options || product.variant_options.length === 0) {
    return null;
  }

  const handleOptionChange = (optionName, value) => {
    const newSelectedOptions = {
      ...selectedOptions,
      [optionName]: value,
    };
    setSelectedOptions(newSelectedOptions);

    const fullySelected = Object.values(newSelectedOptions).every(v => v !== null);
    if (fullySelected) {
      const matchedVariant = product.variants.find(variant => {
        if (!variant.attributes) return false;
        return Object.entries(newSelectedOptions).every(
          ([key, val]) => variant.attributes[key] === val
        );
      });
      onVariantSelect(matchedVariant || null);
    } else {
      onVariantSelect(null); 
    }
  };
  
  const isOptionValueDisabled = (optionName, value) => {
    const tempSelectedOptions = { ...selectedOptions, [optionName]: value };
    
    const matchedVariant = product.variants.find(variant => {
      if(!variant.attributes) return false;
      const matchesCurrentSelection = Object.entries(tempSelectedOptions)
        .filter(([_, val]) => val !== null) 
        .every(([key, val]) => variant.attributes[key] === val);
      
      if (!matchesCurrentSelection) return false;
      return variant.is_active && variant.inventory_quantity > 0;
    });

    const optionIndex = product.variant_options.findIndex(opt => opt.name === optionName);
    if (optionIndex < product.variant_options.length - 1) {
        const leadsToAvailable = product.variants.some(v => {
            if (!v.is_active || v.inventory_quantity <= 0) return false;
            if (!v.attributes) return false;
            
            let matches = true;
            for (const key in tempSelectedOptions) {
                if (tempSelectedOptions[key] !== null && v.attributes[key] !== tempSelectedOptions[key]) {
                    matches = false;
                    break;
                }
            }
            return matches;
        });
        return !leadsToAvailable;
    }

    return !matchedVariant || !matchedVariant.is_active || matchedVariant.inventory_quantity <= 0;
  };

  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2 }}
    >
      {product.variant_options.map((option, optionIndex) => {
        const groupLabelId = `variant-group-label-${option.name.replace(/\s+/g, '-').toLowerCase()}`;
        return (
          <div key={option.name}>
            <Label id={groupLabelId} className="text-md font-semibold text-slate-700 dark:text-slate-200">
              {option.name}: <span className="text-sm text-slate-500 dark:text-slate-400">{selectedOptions[option.name] || 'Selecione'}</span>
            </Label>
            <RadioGroup
              value={selectedOptions[option.name] || ""}
              onValueChange={(value) => handleOptionChange(option.name, value)}
              className="flex flex-wrap gap-2 mt-2"
              aria-labelledby={groupLabelId}
              role="radiogroup"
            >
              {option.values.map((value) => {
                const isDisabled = isOptionValueDisabled(option.name, value);
                const isSelected = selectedOptions[option.name] === value;
                const radioItemId = `variant-${option.name.replace(/\s+/g, '-')}-${value.replace(/\s+/g, '-')}`;

                if (option.name.toLowerCase() === 'cor') {
                  return (
                    <RadioGroupPrimitive.Item
                      key={value}
                      value={value}
                      id={radioItemId}
                      disabled={isDisabled}
                      className={cn(
                        "relative flex cursor-pointer items-center justify-center rounded-full w-8 h-8 border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500",
                        isSelected ? "border-sky-500 ring-2 ring-sky-500 ring-offset-1" : "border-slate-300 dark:border-slate-600",
                        isDisabled ? "opacity-50 cursor-not-allowed" : "hover:border-sky-400 dark:hover:border-sky-300"
                      )}
                      style={{ backgroundColor: value.toLowerCase() }} 
                      aria-label={value}
                    >
                      <RadioGroupPrimitive.Indicator className="flex items-center justify-center">
                         <span className="block w-3 h-3 rounded-full bg-white mix-blend-difference"></span>
                      </RadioGroupPrimitive.Indicator>
                    </RadioGroupPrimitive.Item>
                  );
                }

                return (
                  <RadioGroupPrimitive.Item
                    key={value}
                    value={value}
                    id={radioItemId}
                    disabled={isDisabled}
                    className={cn(
                      "flex items-center justify-center rounded-md border px-4 py-2 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500",
                      isSelected
                        ? "bg-sky-500 text-white border-sky-500"
                        : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-600",
                      isDisabled
                        ? "opacity-50 cursor-not-allowed bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500"
                        : "hover:bg-slate-50 dark:hover:bg-slate-700"
                    )}
                    aria-label={value}
                  >
                    {value}
                  </RadioGroupPrimitive.Item>
                );
              })}
            </RadioGroup>
          </div>
        );
      })}
    </motion.div>
  );
};

export default VariantSelectorStorefront;
