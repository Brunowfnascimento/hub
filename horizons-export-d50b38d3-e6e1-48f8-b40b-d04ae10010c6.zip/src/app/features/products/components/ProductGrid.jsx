
import React from 'react';
import ProductCardStorefront from './ProductCardStorefront';
import { AnimatePresence, motion } from 'framer-motion';

const ProductGrid = ({ products, isLoading, skeletons = 8 }) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {Array.from({ length: skeletons }).map((_, index) => (
          <ProductCardStorefront key={index} isLoading={true} />
        ))}
      </div>
    );
  }

  if (!products || products.length === 0) {
    return (
      <div className="text-center py-12">
        <img  alt="Nenhum produto encontrado" className="mx-auto mb-4 w-40 h-40 opacity-50" src="https://images.unsplash.com/photo-1647779118365-a1a071f4529e" />
        <h3 className="text-2xl font-semibold text-slate-700 dark:text-slate-300">Nenhum produto encontrado</h3>
        <p className="text-slate-500 dark:text-slate-400">Tente ajustar seus filtros ou pesquisar por algo diferente.</p>
      </div>
    );
  }

  return (
    <motion.div 
      layout 
      className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-8"
    >
      <AnimatePresence>
        {products.map((product) => (
          <ProductCardStorefront key={product.id} product={product} />
        ))}
      </AnimatePresence>
    </motion.div>
  );
};

export default ProductGrid;
