
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Star } from 'lucide-react'; 
import { motion } from 'framer-motion';
import { formatCurrency } from '@/app/lib/formatters';
import { useTranslation } from 'react-i18next';

const ProductInfoStorefront = ({ product, selectedVariant, onVariantChange, variants, attributesConfig }) => {
  const { t } = useTranslation();

  if (!product) return null;

  const getDisplayPrice = () => {
    const price = selectedVariant?.price_override ?? product.base_price;
    return formatCurrency(price);
  };

  const getCompareAtPrice = () => {
    const comparePriceValue = selectedVariant?.compare_at_price_override ?? product.compare_at_price;
    const currentPrice = selectedVariant?.price_override ?? product.base_price;
    return comparePriceValue && comparePriceValue > currentPrice
      ? formatCurrency(comparePriceValue)
      : null;
  };

  const displayPrice = getDisplayPrice();
  const compareAtPrice = getCompareAtPrice();
  const currentSku = selectedVariant?.sku || product.sku_base;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="space-y-4"
    >
      <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-slate-900 dark:text-slate-50">
        {product.name}
      </h1>
      
      <div className="flex items-baseline space-x-2">
        <p className="text-3xl font-semibold text-sky-600 dark:text-sky-400">
          {displayPrice}
        </p>
        {compareAtPrice && (
          <span className="text-lg text-slate-500 dark:text-slate-400 line-through">
            {compareAtPrice}
          </span>
        )}
      </div>

      
      <div className="flex items-center">
        <div className="flex text-yellow-400">
          {[...Array(5)].map((_, i) => <Star key={i} size={20} className={i < (product.average_rating || 4) ? "fill-current" : ""} />)}
        </div>
        <span className="ml-2 text-sm text-slate-600 dark:text-slate-400">({product.review_count || 0} {t('productInfo.reviewsPlaceholder', 'avaliações')})</span>
      </div>

      {currentSku && (
        <p className="text-sm text-slate-500 dark:text-slate-400">{t('productInfo.sku', 'SKU')}: {currentSku}</p>
      )}
      
      {product.category && (
         <Badge variant="secondary" className="dark:bg-slate-700 dark:text-slate-300">{product.category.name}</Badge>
      )}
      {product.brand && (
         <Badge variant="outline" className="ml-2 dark:border-slate-600 dark:text-slate-400">{product.brand.name}</Badge>
      )}

      {product.description_short && (
        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
          {product.description_short}
        </p>
      )}
    </motion.div>
  );
};

export default ProductInfoStorefront;
