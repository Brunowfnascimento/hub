
    import { supabase } from '@/app/api/supabase';
    import { mapProductsData } from './utils.jsx';
    
    const productStorefrontSelectFields = `
      id,
      name,
      slug,
      description_short,
      base_price,
      compare_at_price,
      is_active,
      is_featured,
      categories:category_id (id, name, slug),
      brands:brand_id (id, name, slug),
      product_variants!left (
        id,
        sku,
        price_override,
        attributes,
        is_active,
        inventory!left (quantity),
        product_images!left (id, storage_path, alt_text, display_order)
      ),
      product_images!left (id, storage_path, alt_text, display_order)
    `;
    
    export const WorkspaceFeaturedProducts = async (limit = 4) => {
      const { data, error } = await supabase
        .from('products')
        .select(productStorefrontSelectFields)
        .eq('is_featured', true)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(limit);
    
      if (error) {
        console.error('Error fetching featured products:', error);
        return [];
      }
      return mapProductsData(data);
    };
    
    export const WorkspaceRelatedProducts = async (productId, categoryId, limit = 4) => {
      if (!productId || !categoryId) {
        console.warn('Product ID or Category ID is missing for fetching related products.');
        return [];
      }
    
      const { data, error } = await supabase
        .from('products')
        .select(productStorefrontSelectFields)
        .eq('category_id', categoryId)
        .eq('is_active', true)
        .not('id', 'eq', productId)
        .limit(limit);
    
      if (error) {
        console.error('Error fetching related products:', error);
        return [];
      }
      return mapProductsData(data);
    };
  