
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    
    export const STOREFRONT_PAGE_SIZE = 12;
    
    export const mapProductData = (product) => {
      if (!product) return null;
    
      const activeVariants = product.product_variants?.filter(v => v.is_active) || [];
      
      let firstActiveVariant;
      if (activeVariants.length > 0) {
        firstActiveVariant = activeVariants[0];
      } else if (product.product_variants?.length > 0) {
        
        firstActiveVariant = product.product_variants[0];
      } else {
        
        return {
          ...product,
          display_price: product.base_price,
          compare_at_price: product.compare_at_price,
          category_name: product.categories?.name,
          brand_name: product.brands?.name,
          main_image_url: product.product_images?.[0]?.storage_path 
            ? supabase.storage.from('product-images').getPublicUrl(product.product_images[0].storage_path).data?.publicUrl
            : 'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
          images: product.product_images
            ?.map(img => ({
              ...img,
              url: img.storage_path ? supabase.storage.from('product-images').getPublicUrl(img.storage_path).data?.publicUrl : null,
            }))
            .sort((a, b) => a.display_order - b.display_order) || [],
          variants: [],
          total_stock: 0,
          has_variants_inferred: false,
          selected_variant: null,
        };
      }
    
      const mainImage = product.product_images?.find(img => img.display_order === 0 && !img.variant_id) ||
                        firstActiveVariant?.product_images?.find(img => img.display_order === 0) ||
                        product.product_images?.find(img => !img.variant_id) ||
                        firstActiveVariant?.product_images?.[0] ||
                        product.product_images?.[0];
    
      const mainImageUrl = mainImage?.storage_path
        ? supabase.storage.from('product-images').getPublicUrl(mainImage.storage_path).data?.publicUrl
        : 'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80'; 
    
      let displayPrice = firstActiveVariant?.price_override !== null && firstActiveVariant?.price_override !== undefined 
                         ? firstActiveVariant.price_override 
                         : product.base_price;
      
      let compareAtPrice = firstActiveVariant?.compare_at_price_override !== null && firstActiveVariant?.compare_at_price_override !== undefined
                           ? firstActiveVariant.compare_at_price_override
                           : product.compare_at_price;
    
      if (activeVariants.length > 1) {
        const prices = activeVariants.map(v => v.price_override !== null && v.price_override !== undefined ? v.price_override : product.base_price).filter(p => p !== null && p !== undefined);
        if (prices.length > 0) {
          const minPrice = Math.min(...prices);
          displayPrice = minPrice; 
        }
      }
    
      const totalStock = activeVariants.reduce((sum, v) => sum + (v.inventory?.quantity || 0), 0);
      
      const hasVariants = activeVariants.length > 1 || 
                          (product.product_variants && product.product_variants.length > 0 && 
                           product.product_variants.some(v => v.attributes && Object.keys(v.attributes).length > 0));
    
      return {
        ...product,
        display_price: displayPrice,
        compare_at_price: compareAtPrice,
        category_name: product.categories?.name,
        brand_name: product.brands?.name,
        main_image_url: mainImageUrl,
        images: product.product_images
          ?.map(img => ({
            ...img,
            url: img.storage_path ? supabase.storage.from('product-images').getPublicUrl(img.storage_path).data?.publicUrl : null,
          }))
          .sort((a, b) => a.display_order - b.display_order) || [],
        variants: activeVariants.map(v => ({
          ...v,
          inventory_quantity: v.inventory?.quantity || 0,
          images: product.product_images
            ?.filter(img => img.variant_id === v.id)
            .map(img => ({
              ...img,
              url: img.storage_path ? supabase.storage.from('product-images').getPublicUrl(img.storage_path).data?.publicUrl : null,
            }))
            .sort((a, b) => a.display_order - b.display_order) || [],
        })),
        total_stock: totalStock,
        has_variants_inferred: hasVariants, 
        selected_variant: activeVariants.length > 0 ? activeVariants[0] : null,
      };
    };
    
    export const mapProductsData = (products) => {
      if (!Array.isArray(products)) return [];
      return products.map(mapProductData).filter(p => p !== null);
    };
  