
import React from 'react';
import { supabase } from '@/app/api/supabase';

export const WorkspaceStorefrontBrands = async () => {
  const { data, error } = await supabase
    .from('brands')
    .select('id, name, slug, logo_url')
    .order('name', { ascending: true });

  if (error) {
    console.error("Error fetching storefront brands:", error);
    throw error;
  }
  return data.map(b => ({
    id: b.id,
    name: b.name,
    slug: b.slug,
    logoUrl: b.logo_url,
  }));
};
