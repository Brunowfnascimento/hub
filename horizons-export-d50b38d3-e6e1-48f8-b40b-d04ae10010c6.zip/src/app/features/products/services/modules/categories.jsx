
import React from 'react';
import { supabase } from '@/app/api/supabase';

export const WorkspaceStorefrontCategories = async ({ withProductCount = false } = {}) => {
  let query = supabase.from('categories').select('id, name, slug, description, image_url, parent_category_id');
  
  query = query.order('name', { ascending: true });
  const { data, error } = await query;

  if (error) {
    console.error("Error fetching storefront categories:", error);
    throw error;
  }
  return data.map(c => ({
    id: c.id,
    name: c.name,
    slug: c.slug,
    description: c.description,
    imageUrl: c.image_url,
    parentCategoryId: c.parent_category_id,
  }));
};
