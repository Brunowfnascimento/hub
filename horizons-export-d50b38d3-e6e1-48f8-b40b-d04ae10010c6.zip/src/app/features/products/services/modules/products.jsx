
    import { supabase } from '@/app/api/supabase';
    import { mapProductData, mapProductsData } from './utils.jsx';
    
    const productStorefrontSelectFields = `
      id,
      name,
      slug,
      description_short,
      description_long,
      base_price,
      compare_at_price,
      sku_base,
      is_active,
      is_featured,
      tags,
      categories:category_id (id, name, slug),
      brands:brand_id (id, name, slug),
      product_variants!left (
        id,
        sku,
        price_override,
        compare_at_price_override,
        attributes,
        is_active,
        inventory!left (quantity),
        product_images!left (id, storage_path, alt_text, display_order)
      ),
      product_images!left (id, storage_path, alt_text, display_order)
    `;
    
    
    export const WorkspaceStorefrontProducts = async (filters) => {
      let query = supabase
        .from('products')
        .select(productStorefrontSelectFields, { count: 'exact' })
        .eq('is_active', true);
    
      if (filters.searchTerm) {
        query = query.or(`name.ilike.%${filters.searchTerm}%,description_short.ilike.%${filters.searchTerm}%,tags.cs.{${filters.searchTerm}}`);
      }
    
      if (filters.categorySlug) {
        const { data: categoryData, error: categoryError } = await supabase
          .from('categories')
          .select('id')
          .eq('slug', filters.categorySlug)
          .single();
    
        if (categoryError) {
          console.warn('Error fetching category for filter:', categoryError.message);
        } else if (categoryData) {
          query = query.eq('category_id', categoryData.id);
        }
      }
    
      if (filters.brandSlug) {
         const { data: brandData, error: brandError } = await supabase
          .from('brands')
          .select('id')
          .eq('slug', filters.brandSlug)
          .single();
    
        if (brandError) {
          console.warn('Error fetching brand for filter:', brandError.message);
        } else if (brandData) {
          query = query.eq('brand_id', brandData.id);
        }
      }
    
      if (filters.minPrice !== undefined) {
        query = query.gte('base_price', filters.minPrice);
      }
      if (filters.maxPrice !== undefined) {
        query = query.lte('base_price', filters.maxPrice);
      }
      if (filters.tags && filters.tags.length > 0) {
        query = query.cs('tags', filters.tags); 
      }
      if (filters.isFeatured) {
        query = query.eq('is_featured', true);
      }
    
      const sortBy = filters.sortBy || 'created_at';
      const sortOrder = filters.sortOrder || 'desc';
      query = query.order(sortBy, { ascending: sortOrder === 'asc' });
    
      const page = filters.page || 1;
      const limit = filters.limit || 12;
      const from = (page - 1) * limit;
      const to = page * limit - 1;
      query = query.range(from, to);
    
      const { data, error, count } = await query;
    
      if (error) {
        console.error('Error fetching storefront products:', error);
        throw new Error('Error fetching products. Details: ' + error.message);
      }
    
      return {
        data: mapProductsData(data),
        count: count || 0,
        totalPages: Math.ceil((count || 0) / limit),
      };
    };
    
    export const WorkspaceStorefrontProductBySlug = async (slug) => {
      const { data, error } = await supabase
        .from('products')
        .select(productStorefrontSelectFields)
        .eq('slug', slug)
        .eq('is_active', true)
        .single();
    
      if (error) {
        if (error.code === 'PGRST116') {
          return null; 
        }
        console.error('Error fetching product by slug for storefront:', error);
        throw new Error('Error fetching product by slug. Details: ' + error.message);
      }
      return mapProductData(data);
    };
  