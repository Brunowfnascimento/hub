
import { WorkspaceStorefrontProducts, WorkspaceStorefrontProductBySlug } from './modules/products';
import { WorkspaceStorefrontCategories } from './modules/categories';
import { WorkspaceStorefrontBrands } from './modules/brands';
import { WorkspaceFeaturedProducts, WorkspaceRelatedProducts } from './modules/featuredAndRelated';

export {
  WorkspaceStorefrontProducts,
  WorkspaceStorefrontProductBySlug,
  WorkspaceStorefrontCategories,
  WorkspaceStorefrontBrands,
  WorkspaceFeaturedProducts,
  WorkspaceRelatedProducts,
};
