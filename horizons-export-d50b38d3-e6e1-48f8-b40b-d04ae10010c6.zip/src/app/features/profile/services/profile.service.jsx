
import React from 'react';
import { supabase } from '@/app/api/supabase';

const handleSupabaseError = (error, context) => {
  console.error(`Supabase error in ${context}:`, error);
  throw new Error(`Falha na operação de ${context}: ${error.message}`);
};

const PROFILES_TABLE = 'profiles';
const ADDRESSES_TABLE = 'addresses';
const ORDERS_TABLE = 'orders';
const AVATARS_BUCKET = 'avatars';

export const fetchUserProfile = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  const { data, error } = await supabase
    .from(PROFILES_TABLE)
    .select('*')
    .eq('id', user.id)
    .single();

  if (error && error.code !== 'PGRST116') { // PGRST116: no rows found, which is fine if profile not created yet
    handleSupabaseError(error, 'busca de perfil do usuário');
  }
  return data;
};

export const updateUserProfile = async (profileData) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  const updates = {
    ...profileData,
    id: user.id, // Ensure ID is set for upsert
    updated_at: new Date().toISOString(),
  };
  
  if (!profileData.created_at) { // If it's a new profile
    updates.created_at = new Date().toISOString();
    updates.role = updates.role || 'customer'; // Default role
  }


  const { data, error } = await supabase
    .from(PROFILES_TABLE)
    .upsert(updates, { onConflict: 'id' })
    .select()
    .single();
  
  if (error) handleSupabaseError(error, 'atualização de perfil do usuário');
  return data;
};

export const uploadProfileAvatar = async (file) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  const fileExt = file.name.split('.').pop();
  const fileName = `${user.id}-${Date.now()}.${fileExt}`;
  const filePath = `${fileName}`;

  const { error: uploadError } = await supabase.storage
    .from(AVATARS_BUCKET)
    .upload(filePath, file, { upsert: true });

  if (uploadError) {
    handleSupabaseError(uploadError, 'upload de avatar');
  }

  const { data: publicUrlData } = supabase.storage
    .from(AVATARS_BUCKET)
    .getPublicUrl(filePath);

  if (!publicUrlData || !publicUrlData.publicUrl) {
    throw new Error("Não foi possível obter a URL pública do avatar.");
  }
  
  return publicUrlData.publicUrl;
};


export const fetchUserAddresses = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  const { data, error } = await supabase
    .from(ADDRESSES_TABLE)
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });
  
  if (error) handleSupabaseError(error, 'busca de endereços do usuário');
  return data;
};

export const addUserAddress = async (addressData) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  const newAddress = {
    ...addressData,
    user_id: user.id,
  };

  const { data, error } = await supabase
    .from(ADDRESSES_TABLE)
    .insert([newAddress])
    .select()
    .single();

  if (error) handleSupabaseError(error, 'adição de endereço');
  return data;
};

export const updateUserAddress = async (addressId, addressData) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  const updates = {
    ...addressData,
    updated_at: new Date().toISOString(),
  };

  const { data, error } = await supabase
    .from(ADDRESSES_TABLE)
    .update(updates)
    .eq('id', addressId)
    .eq('user_id', user.id) // Ensure user owns the address
    .select()
    .single();

  if (error) handleSupabaseError(error, 'atualização de endereço');
  return data;
};

export const deleteUserAddress = async (addressId) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  const { error } = await supabase
    .from(ADDRESSES_TABLE)
    .delete()
    .eq('id', addressId)
    .eq('user_id', user.id); // Ensure user owns the address

  if (error) handleSupabaseError(error, 'deleção de endereço');
  return { message: "Endereço deletado com sucesso." };
};

const setDefaultAddress = async (addressId, type) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  // Reset all other addresses of this type for this user
  const resetField = type === 'shipping' ? 'is_default_shipping' : 'is_default_billing';
  const { error: resetError } = await supabase
    .from(ADDRESSES_TABLE)
    .update({ [resetField]: false })
    .eq('user_id', user.id);

  if (resetError) handleSupabaseError(resetError, `reset de endereço padrão ${type}`);

  // Set the new default address
  const { data, error: setError } = await supabase
    .from(ADDRESSES_TABLE)
    .update({ [resetField]: true })
    .eq('id', addressId)
    .eq('user_id', user.id)
    .select()
    .single();
  
  if (setError) handleSupabaseError(setError, `definição de endereço padrão ${type}`);
  return data;
};

export const setDefaultShippingAddress = (addressId) => setDefaultAddress(addressId, 'shipping');
export const setDefaultBillingAddress = (addressId) => setDefaultAddress(addressId, 'billing');


export const fetchUserOrders = async ({ page = 1, limit = 10 }) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Usuário não autenticado.");

  const from = (page - 1) * limit;
  const to = page * limit - 1;

  const { data, error, count } = await supabase
    .from(ORDERS_TABLE)
    .select('*', { count: 'exact' })
    .eq('user_id', user.id)
    .order('placed_at', { ascending: false })
    .range(from, to);

  if (error) handleSupabaseError(error, 'busca de pedidos do usuário');
  return { orders: data, totalCount: count };
};
