
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import { fetchUserOrders } from '@/app/features/profile/services/profile.service.jsx';
import { useAuth } from '@/app/contexts/AuthContext';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious, PaginationEllipsis } from '@/components/ui/pagination';
import OrderStatusBadge from '@/app/features/admin/order-management/components/OrderStatusBadge.jsx'; // Reusing admin badge
import { Eye, ShoppingBag } from 'lucide-react';
import { motion } from 'framer-motion';

const ProfileOrdersTab = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const ordersPerPage = 10;

  const { data: ordersData, isLoading, error } = useQuery({
    queryKey: ['userOrders', user?.id, currentPage, ordersPerPage],
    queryFn: () => fetchUserOrders({ page: currentPage, limit: ordersPerPage }),
    enabled: !!user,
    keepPreviousData: true,
  });

  const orders = ordersData?.orders || [];
  const totalCount = ordersData?.totalCount || 0;
  const totalPages = Math.ceil(totalCount / ordersPerPage);

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const renderPaginationItems = () => {
    const items = [];
    const maxPagesToShow = 5;
    const halfMaxPages = Math.floor(maxPagesToShow / 2);

    if (totalPages <= maxPagesToShow) {
      for (let i = 1; i <= totalPages; i++) {
        items.push(
          <PaginationItem key={i}>
            <PaginationLink isActive={currentPage === i} onClick={() => handlePageChange(i)}>
              {i}
            </PaginationLink>
          </PaginationItem>
        );
      }
    } else {
      items.push(
        <PaginationItem key="first">
          <PaginationLink onClick={() => handlePageChange(1)} disabled={currentPage === 1}>1</PaginationLink>
        </PaginationItem>
      );
      if (currentPage > halfMaxPages + 1) {
        items.push(<PaginationEllipsis key="ellipsis-start" />);
      }

      let startPage = Math.max(2, currentPage - halfMaxPages + (currentPage < totalPages - halfMaxPages +1 ? 0 : 1 ) );
      let endPage = Math.min(totalPages - 1, currentPage + halfMaxPages - (currentPage > halfMaxPages ? 0:1) );
      
      if (currentPage <= halfMaxPages) {
        startPage = 2;
        endPage = Math.min(totalPages -1, maxPagesToShow-1);
      } else if (currentPage >= totalPages - halfMaxPages ) {
        startPage = Math.max(2, totalPages - maxPagesToShow +2)
        endPage = totalPages -1;
      }


      for (let i = startPage; i <= endPage; i++) {
        items.push(
          <PaginationItem key={i}>
            <PaginationLink isActive={currentPage === i} onClick={() => handlePageChange(i)}>
              {i}
            </PaginationLink>
          </PaginationItem>
        );
      }

      if (currentPage < totalPages - halfMaxPages) {
        items.push(<PaginationEllipsis key="ellipsis-end" />);
      }
      items.push(
        <PaginationItem key="last">
          <PaginationLink onClick={() => handlePageChange(totalPages)} disabled={currentPage === totalPages}>{totalPages}</PaginationLink>
        </PaginationItem>
      );
    }
    return items;
  };


  if (isLoading) return <div className="flex justify-center items-center p-8"><LoadingSpinner size="h-10 w-10" /></div>;
  if (error) return <ErrorDisplay message={error.message} />;

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      transition={{ duration: 0.3 }}
      className="p-1 md:p-6 bg-white dark:bg-slate-800 rounded-lg shadow-xl"
    >
      <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200 mb-6">Meus Pedidos</h2>
      {orders.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingBag className="mx-auto h-16 w-16 text-slate-400 dark:text-slate-500 mb-4" />
          <p className="text-slate-600 dark:text-slate-400 text-lg">Você ainda não fez nenhum pedido.</p>
          <Button asChild className="mt-6 bg-sky-500 hover:bg-sky-600 text-white">
            <Link to="/products">Começar a Comprar</Link>
          </Button>
        </div>
      ) : (
        <>
          <div className="overflow-x-auto border rounded-md dark:border-slate-700">
            <Table>
              <TableHeader className="bg-slate-50 dark:bg-slate-700">
                <TableRow>
                  <TableHead className="dark:text-slate-300">Nº Pedido</TableHead>
                  <TableHead className="dark:text-slate-300">Data</TableHead>
                  <TableHead className="dark:text-slate-300">Status</TableHead>
                  <TableHead className="text-right dark:text-slate-300">Total</TableHead>
                  <TableHead className="text-center dark:text-slate-300">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow key={order.id} className="dark:hover:bg-slate-700/50">
                    <TableCell className="font-medium text-sky-600 dark:text-sky-400 hover:underline cursor-pointer" onClick={() => navigate(`/profile/orders/${order.id}`)}>
                      {order.order_number}
                    </TableCell>
                    <TableCell className="dark:text-slate-300">{new Date(order.placed_at).toLocaleDateString('pt-BR')}</TableCell>
                    <TableCell><OrderStatusBadge status={order.status} /></TableCell>
                    <TableCell className="text-right dark:text-slate-200">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(order.grand_total)}
                    </TableCell>
                    <TableCell className="text-center">
                      <Button variant="outline" size="sm" onClick={() => navigate(`/profile/orders/${order.id}`)} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                        <Eye className="mr-1 h-4 w-4" /> Ver Detalhes
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <Pagination className="mt-8">
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} />
                </PaginationItem>
                {renderPaginationItems()}
                <PaginationItem>
                  <PaginationNext onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages} />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}
    </motion.div>
  );
};

export default ProfileOrdersTab;
