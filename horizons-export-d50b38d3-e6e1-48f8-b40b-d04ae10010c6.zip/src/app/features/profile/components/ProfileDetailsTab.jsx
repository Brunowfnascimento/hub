
import React, { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/app/contexts/AuthContext';
import { fetchUserProfile, updateUserProfile, uploadProfileAvatar } from '@/app/features/profile/services/profile.service.jsx';
import ProfileDetailsForm from './ProfileDetailsForm';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/app/api/supabase'; // For password update
import { Edit3, Save, Camera, KeyRound } from 'lucide-react';
import { motion } from 'framer-motion';

const ProfileDetailsTab = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const avatarFileRef = useRef(null);

  const { data: profile, isLoading, error } = useQuery({
    queryKey: ['userProfile', user?.id],
    queryFn: fetchUserProfile,
    enabled: !!user,
  });

  const updateProfileMutation = useMutation({
    mutationFn: updateUserProfile,
    onSuccess: (data) => {
      queryClient.invalidateQueries(['userProfile', user?.id]);
      queryClient.setQueryData(['userProfile', user?.id], data); // Optimistic update
      toast({ title: "Sucesso!", description: "Perfil atualizado." });
      setIsEditingProfile(false);
    },
    onError: (err) => {
      toast({ title: "Erro ao atualizar perfil", description: err.message, variant: "destructive" });
    },
  });

  const uploadAvatarMutation = useMutation({
    mutationFn: uploadProfileAvatar,
    onSuccess: (avatarUrl) => {
      updateProfileMutation.mutate({ ...profile, avatar_url: avatarUrl });
      toast({ title: "Sucesso!", description: "Avatar atualizado." });
    },
    onError: (err) => {
      toast({ title: "Erro ao enviar avatar", description: err.message, variant: "destructive" });
    },
  });

  const handleAvatarChange = (event) => {
    const file = event.target.files?.[0];
    if (file) {
      uploadAvatarMutation.mutate(file);
    }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast({ title: "Erro", description: "As senhas não coincidem.", variant: "destructive" });
      return;
    }
    if (newPassword.length < 6) {
      toast({ title: "Erro", description: "A senha deve ter pelo menos 6 caracteres.", variant: "destructive" });
      return;
    }
    setIsChangingPassword(true);
    const { error: updateError } = await supabase.auth.updateUser({ password: newPassword });
    setIsChangingPassword(false);
    if (updateError) {
      toast({ title: "Erro ao alterar senha", description: updateError.message, variant: "destructive" });
    } else {
      toast({ title: "Sucesso!", description: "Senha alterada com sucesso." });
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  if (isLoading) return <div className="flex justify-center items-center p-8"><LoadingSpinner size="h-10 w-10" /></div>;
  if (error) return <ErrorDisplay message={error.message} />;

  const getInitials = (name) => {
    if (!name) return '?';
    const names = name.split(' ');
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return `${names[0].charAt(0)}${names[names.length - 1].charAt(0)}`.toUpperCase();
  };
  
  const currentAvatarUrl = profile?.avatar_url || user?.user_metadata?.avatar_url;


  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }} className="space-y-8">
      <Card className="overflow-hidden shadow-lg dark:bg-slate-800">
        <CardHeader className="bg-slate-50 dark:bg-slate-700/50 p-6">
          <div className="flex items-center space-x-6">
            <div className="relative group">
              <Avatar className="h-24 w-24 border-2 border-sky-500 dark:border-sky-400 shadow-md">
                <AvatarImage src={currentAvatarUrl} alt={profile?.full_name || user?.email} />
                <AvatarFallback className="text-3xl bg-slate-200 dark:bg-slate-600 text-slate-700 dark:text-slate-200">
                  {getInitials(profile?.full_name || user?.email)}
                </AvatarFallback>
              </Avatar>
              <Button
                variant="outline"
                size="icon"
                className="absolute bottom-0 right-0 rounded-full h-8 w-8 bg-white dark:bg-slate-700 group-hover:bg-slate-100 dark:group-hover:bg-slate-600 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => avatarFileRef.current?.click()}
                aria-label="Alterar avatar"
              >
                <Camera className="h-4 w-4 text-slate-600 dark:text-slate-300" />
              </Button>
              <input type="file" ref={avatarFileRef} onChange={handleAvatarChange} accept="image/*" className="hidden" />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-slate-800 dark:text-slate-100">{profile?.full_name || 'Usuário'}</CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-400">{user?.email}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {isEditingProfile ? (
            <ProfileDetailsForm
              profile={profile}
              onSubmit={(data) => updateProfileMutation.mutate(data)}
              isSubmitting={updateProfileMutation.isPending}
              onCancel={() => setIsEditingProfile(false)}
            />
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-slate-500 dark:text-slate-400">Nome Completo</Label>
                  <p className="text-lg text-slate-800 dark:text-slate-100">{profile?.full_name || '-'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-slate-500 dark:text-slate-400">CPF/CNPJ</Label>
                  <p className="text-lg text-slate-800 dark:text-slate-100">{profile?.cpf_cnpj || '-'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-slate-500 dark:text-slate-400">Telefone</Label>
                  <p className="text-lg text-slate-800 dark:text-slate-100">{profile?.phone || '-'}</p>
                </div>
              </div>
              <Button onClick={() => setIsEditingProfile(true)} className="mt-4 bg-sky-500 hover:bg-sky-600 text-white">
                <Edit3 className="mr-2 h-4 w-4" /> Editar Perfil
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="shadow-lg dark:bg-slate-800">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-slate-800 dark:text-slate-100 flex items-center">
            <KeyRound className="mr-2 h-5 w-5 text-amber-500" /> Alterar Senha
          </CardTitle>
          <CardDescription className="dark:text-slate-400">Use uma senha forte para maior segurança.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePasswordChange} className="space-y-4">
            <div>
              <Label htmlFor="newPassword">Nova Senha</Label>
              <Input
                id="newPassword"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="mt-1 dark:bg-slate-700"
                placeholder="Mínimo 6 caracteres"
              />
            </div>
            <div>
              <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1 dark:bg-slate-700"
              />
            </div>
            <Button type="submit" disabled={isChangingPassword || !newPassword || !confirmPassword} className="bg-amber-500 hover:bg-amber-600 text-white">
              {isChangingPassword ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : <Save className="mr-2 h-4 w-4" />}
              Alterar Senha
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProfileDetailsTab;
