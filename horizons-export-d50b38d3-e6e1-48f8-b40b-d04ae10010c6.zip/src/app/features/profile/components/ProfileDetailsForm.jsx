
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ProfileFormDataSchema } from '@/app/types/profile.types.jsx';
import { useToast } from '@/components/ui/use-toast';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';

const ProfileDetailsForm = ({ profile, onSubmit, isSubmitting, onCancel }) => {
  const [formData, setFormData] = useState(ProfileFormDataSchema);
  const { toast } = useToast();

  useEffect(() => {
    if (profile) {
      setFormData({
        full_name: profile.full_name || '',
        cpf_cnpj: profile.cpf_cnpj || '',
        phone: profile.phone || '',
      });
    } else {
      setFormData(ProfileFormDataSchema);
    }
  }, [profile]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.full_name.trim()) {
      toast({ title: "Erro de Validação", description: "O nome completo é obrigatório.", variant: "destructive" });
      return;
    }
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <Label htmlFor="full_name" className="text-slate-700 dark:text-slate-300">Nome Completo <span className="text-red-500">*</span></Label>
        <Input
          id="full_name"
          name="full_name"
          value={formData.full_name}
          onChange={handleChange}
          placeholder="Seu nome completo"
          className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
        />
      </div>
      <div>
        <Label htmlFor="cpf_cnpj" className="text-slate-700 dark:text-slate-300">CPF/CNPJ</Label>
        <Input
          id="cpf_cnpj"
          name="cpf_cnpj"
          value={formData.cpf_cnpj}
          onChange={handleChange}
          placeholder="Seu CPF ou CNPJ"
          className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
        />
      </div>
      <div>
        <Label htmlFor="phone" className="text-slate-700 dark:text-slate-300">Telefone</Label>
        <Input
          id="phone"
          name="phone"
          type="tel"
          value={formData.phone}
          onChange={handleChange}
          placeholder="(XX) XXXXX-XXXX"
          className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
        />
      </div>
      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting} className="bg-sky-500 hover:bg-sky-600 text-white">
          {isSubmitting ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : 'Salvar Alterações'}
        </Button>
      </div>
    </form>
  );
};

export default ProfileDetailsForm;
