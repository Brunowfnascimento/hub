
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/app/contexts/AuthContext';
import {
  fetchUserAddresses,
  addUserAddress,
  updateUserAddress,
  deleteUserAddress,
  setDefaultShippingAddress,
  setDefaultBillingAddress,
} from '@/app/features/profile/services/profile.service.jsx';
import AddressForm from './AddressForm';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { useToast } from '@/components/ui/use-toast';
import { PlusCircle, Edit2, Trash2, Star, Home } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ProfileAddressesTab = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState(null); // For editing
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [addressToDelete, setAddressToDelete] = useState(null);

  const { data: addresses, isLoading, error } = useQuery({
    queryKey: ['userAddresses', user?.id],
    queryFn: fetchUserAddresses,
    enabled: !!user,
  });

  const mutationOptions = (successMessage) => ({
    onSuccess: () => {
      queryClient.invalidateQueries(['userAddresses', user?.id]);
      toast({ title: "Sucesso!", description: successMessage });
      setIsFormOpen(false);
      setSelectedAddress(null);
      setIsDeleteDialogOpen(false);
      setAddressToDelete(null);
    },
    onError: (err) => {
      toast({ title: "Erro!", description: err.message, variant: "destructive" });
    },
  });

  const addAddressMutation = useMutation({
    mutationFn: addUserAddress,
    ...mutationOptions("Endereço adicionado com sucesso."),
  });

  const updateAddressMutation = useMutation({
    mutationFn: ({ addressId, data }) => updateUserAddress(addressId, data),
    ...mutationOptions("Endereço atualizado com sucesso."),
  });

  const deleteAddressMutation = useMutation({
    mutationFn: deleteUserAddress,
    ...mutationOptions("Endereço excluído com sucesso."),
  });

  const setDefaultShippingMutation = useMutation({
    mutationFn: setDefaultShippingAddress,
    ...mutationOptions("Endereço de entrega padrão atualizado."),
  });

  const setDefaultBillingMutation = useMutation({
    mutationFn: setDefaultBillingAddress,
    ...mutationOptions("Endereço de cobrança padrão atualizado."),
  });

  const handleFormSubmit = (data) => {
    if (selectedAddress) {
      updateAddressMutation.mutate({ addressId: selectedAddress.id, data });
    } else {
      addAddressMutation.mutate(data);
    }
  };

  const openEditForm = (address) => {
    setSelectedAddress(address);
    setIsFormOpen(true);
  };

  const openAddForm = () => {
    setSelectedAddress(null);
    setIsFormOpen(true);
  };
  
  const openDeleteDialog = (addressId) => {
    setAddressToDelete(addressId);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if(addressToDelete) {
      deleteAddressMutation.mutate(addressToDelete);
    }
  };

  if (isLoading) return <div className="flex justify-center items-center p-8"><LoadingSpinner size="h-10 w-10" /></div>;
  if (error) return <ErrorDisplay message={error.message} />;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200">Meus Endereços</h2>
        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogTrigger asChild>
            <Button onClick={openAddForm} className="bg-sky-500 hover:bg-sky-600 text-white">
              <PlusCircle className="mr-2 h-4 w-4" /> Adicionar Novo Endereço
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg dark:bg-slate-800 dark:border-slate-700">
            <DialogHeader>
              <DialogTitle className="dark:text-slate-100">{selectedAddress ? 'Editar Endereço' : 'Adicionar Novo Endereço'}</DialogTitle>
            </DialogHeader>
            <AddressForm
              address={selectedAddress}
              onSubmit={handleFormSubmit}
              isSubmitting={addAddressMutation.isPending || updateAddressMutation.isPending}
              onCancel={() => { setIsFormOpen(false); setSelectedAddress(null); }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {addresses?.length === 0 ? (
        <div className="text-center py-12">
          <Home className="mx-auto h-16 w-16 text-slate-400 dark:text-slate-500 mb-4" />
          <p className="text-slate-600 dark:text-slate-400 text-lg">Você ainda não cadastrou nenhum endereço.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <AnimatePresence>
            {addresses?.map((address) => (
              <motion.div
                key={address.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="shadow-lg dark:bg-slate-800 dark:border-slate-700 flex flex-col justify-between h-full">
                  <CardHeader>
                    <CardTitle className="text-lg text-slate-800 dark:text-slate-100">{address.full_name}</CardTitle>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {address.is_default_shipping && <Badge variant="default" className="bg-green-500 hover:bg-green-600 text-white">Padrão Entrega</Badge>}
                      {address.is_default_billing && <Badge variant="secondary" className="bg-blue-500 hover:bg-blue-600 text-white">Padrão Cobrança</Badge>}
                    </div>
                  </CardHeader>
                  <CardContent className="text-sm text-slate-600 dark:text-slate-300 space-y-1 pb-4">
                    <p>{address.address_line1}, {address.address_number || ''}</p>
                    {address.address_complement && <p>{address.address_complement}</p>}
                    <p>{address.address_district} - {address.city}, {address.state_province}</p>
                    <p>CEP: {address.postal_code}</p>
                    <p>País: {address.country}</p>
                    {address.phone_number && <p>Telefone: {address.phone_number}</p>}
                  </CardContent>
                  <CardFooter className="flex flex-col sm:flex-row sm:flex-wrap gap-2 pt-0 p-4 border-t dark:border-slate-600">
                    <Button variant="outline" size="sm" onClick={() => openEditForm(address)} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                      <Edit2 className="mr-1 h-3 w-3" /> Editar
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => openDeleteDialog(address.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-500">
                      <Trash2 className="mr-1 h-3 w-3" /> Excluir
                    </Button>
                    {!address.is_default_shipping && (
                      <Button variant="outline" size="sm" onClick={() => setDefaultShippingMutation.mutate(address.id)} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                        <Star className="mr-1 h-3 w-3" /> Padrão Entrega
                      </Button>
                    )}
                    {!address.is_default_billing && (
                      <Button variant="outline" size="sm" onClick={() => setDefaultBillingMutation.mutate(address.id)} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                        <Star className="mr-1 h-3 w-3" /> Padrão Cobrança
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="dark:bg-slate-800 dark:border-slate-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="dark:text-slate-100">Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription className="dark:text-slate-400">
              Tem certeza que deseja excluir este endereço? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setAddressToDelete(null)} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-500 hover:bg-red-600 text-white">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};

export default ProfileAddressesTab;
