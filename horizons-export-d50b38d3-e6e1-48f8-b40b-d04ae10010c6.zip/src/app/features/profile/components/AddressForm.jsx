
import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { addressSchema } from '@/app/types/checkout.types.jsx'; 
import AddressFormFields from '@/app/features/checkout/components/AddressFormFields';
import { Button } from '@/components/ui/button';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { useAuth } from '@/app/contexts/AuthContext';

const AddressForm = ({ address, onSubmit, isSubmitting, onCancel }) => {
  const { user } = useAuth();
  
  const defaultValues = {
    full_name: address?.full_name || user?.user_metadata?.full_name || '',
    email: address?.email || user?.email || '',
    cpf: address?.cpf || '',
    postal_code: address?.postal_code || '',
    address_line1: address?.address_line1 || '',
    address_number: address?.address_number || '',
    address_complement: address?.address_complement || '',
    address_district: address?.address_district || '',
    city: address?.city || '',
    state_province: address?.state_province || '',
    country: address?.country || 'Brasil',
    phone_number: address?.phone_number || user?.phone || '',
    // `save_address` checkbox is not needed here as these addresses are always saved.
    // Default shipping/billing flags will be handled by separate buttons.
  };

  const form = useForm({
    resolver: zodResolver(addressSchema),
    defaultValues,
  });

  useEffect(() => {
    form.reset(defaultValues);
  }, [address, user, form.reset]);

  const handleSubmit = (data) => {
    // Ensure fields not in AddressFormFields (like email) are part of submitted data.
    // For profile, email might not be directly editable in address form, but part of user.
    const submissionData = { ...data, email: user?.email }; 
    onSubmit(submissionData);
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
      <AddressFormFields form={form} showSaveAddressCheckbox={false} />
      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting} className="bg-sky-500 hover:bg-sky-600 text-white">
          {isSubmitting ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : 'Salvar Endereço'}
        </Button>
      </div>
    </form>
  );
};

export default AddressForm;
