
import React from 'react';
import { supabase } from '@/app/api/supabase';

export const fetchOrderByIdForCustomer = async (orderId, userId) => {
  if (!orderId) {
    throw new Error("ID do pedido não fornecido.");
  }

  let query = supabase
    .from('orders')
    .select(`
      *,
      order_items (
        id,
        product_snapshot,
        quantity,
        unit_price_at_purchase,
        total_price_at_purchase
      )
    `)
    .eq('id', orderId);

  if (userId) {
    query = query.eq('user_id', userId);
  }
  
  query = query.single();

  const { data: order, error } = await query;

  if (error) {
    if (error.code === 'PGRST116' && !userId) { 
      const { data: publicOrder, error: publicError } = await supabase
        .from('orders')
        .select(`
          *,
          order_items (
            id,
            product_snapshot,
            quantity,
            unit_price_at_purchase,
            total_price_at_purchase
          )
        `)
        .eq('id', orderId)
        .is('user_id', null) 
        .single();
      
      if (publicError) {
        console.error("Erro ao buscar pedido público:", publicError);
        throw new Error(publicError.message || "Pedido não encontrado ou acesso negado.");
      }
      if (!publicOrder) throw new Error("Pedido não encontrado.");
      return publicOrder;

    } else if (error.code === 'PGRST116') {
        throw new Error("Pedido não encontrado ou você não tem permissão para visualizá-lo.");
    }
    console.error("Erro ao buscar pedido:", error);
    throw new Error(error.message || "Não foi possível carregar os detalhes do pedido.");
  }

  if (!order) {
    throw new Error("Pedido não encontrado.");
  }

  return order;
};
