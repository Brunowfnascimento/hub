
import React from 'react';
import { Button } from '@/components/ui/button';
import { Copy, AlertTriangle, QrCode as QrCodeIcon, Landmark as BoletoIcon, CreditCard as CreditCardIcon, CheckCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const OrderPaymentDetailsDisplay = ({ paymentMethod, paymentStatus, paymentDetails = {} }) => {
  const { toast } = useToast();

  const handleCopyToClipboard = (text, type) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({ title: `${type} copiado!`, description: "Copiado para a área de transferência." });
    }).catch(err => {
      toast({ title: `Erro ao copiar ${type}`, description: err.message, variant: "destructive" });
    });
  };

  const getPaymentMethodLabel = (method) => {
    switch (method) {
      case 'credit_card': return 'Cartão de Crédito';
      case 'pix': return 'PIX';
      case 'boleto': return 'Boleto Bancário';
      default: return 'Não informado';
    }
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-2 text-slate-700 dark:text-slate-200">Detalhes do Pagamento</h3>
      <div className="p-4 bg-slate-100 dark:bg-slate-700/50 rounded-md text-sm">
        <p className="font-medium text-slate-700 dark:text-slate-200 mb-1">
          Método: {getPaymentMethodLabel(paymentMethod)}
        </p>
        
        {paymentMethod === 'credit_card' && (
          <div className="flex items-center text-green-600 dark:text-green-400">
            <CreditCardIcon className="h-5 w-5 mr-2" />
            <span>Pagamento Aprovado.</span>
          </div>
        )}

        {paymentMethod === 'pix' && paymentStatus === 'pending' && (
          <div className="space-y-3 mt-2">
            <div className="flex items-center text-amber-600 dark:text-amber-400">
               <AlertTriangle className="h-5 w-5 mr-2" />
               <span>Aguardando pagamento via PIX.</span>
            </div>
            {paymentDetails.pix_qr_code_image_base64 && (
              <div className="text-center">
                <p className="text-slate-600 dark:text-slate-300 mb-1">Escaneie o QR Code:</p>
                <img  class="mx-auto border rounded-md shadow-sm" alt="PIX QR Code" src="https://images.unsplash.com/photo-1626682561113-d1db402cc866" />
              </div>
            )}
            {paymentDetails.pix_copy_paste_code && (
              <div>
                <p className="text-slate-600 dark:text-slate-300 mb-1">Ou use o código Copia e Cola:</p>
                <div className="flex items-center gap-2 p-2 bg-slate-200 dark:bg-slate-600 rounded-md">
                  <QrCodeIcon className="h-5 w-5 text-slate-500 dark:text-slate-400 flex-shrink-0" />
                  <input 
                    type="text" 
                    readOnly 
                    value={paymentDetails.pix_copy_paste_code} 
                    className="w-full bg-transparent text-xs text-slate-700 dark:text-slate-200 focus:outline-none"
                  />
                  <Button variant="ghost" size="sm" onClick={() => handleCopyToClipboard(paymentDetails.pix_copy_paste_code, 'Código PIX')} className="p-1 h-auto">
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
            {!paymentDetails.pix_qr_code_image_base64 && !paymentDetails.pix_copy_paste_code && (
                <p className="text-slate-500 dark:text-slate-400 text-xs">Os detalhes para pagamento PIX (QR Code e Copia e Cola) foram enviados para o seu e-mail.</p>
            )}
            <p className="text-xs text-slate-500 dark:text-slate-400">Pague em até 1 hora para confirmar seu pedido.</p>
          </div>
        )}

        {paymentMethod === 'boleto' && paymentStatus === 'pending' && (
          <div className="space-y-3 mt-2">
             <div className="flex items-center text-amber-600 dark:text-amber-400">
               <AlertTriangle className="h-5 w-5 mr-2" />
               <span>Aguardando pagamento via Boleto.</span>
            </div>
            {paymentDetails.boleto_url && (
              <Button asChild variant="link" className="p-0 h-auto text-sky-600 dark:text-sky-400">
                <a href={paymentDetails.boleto_url} target="_blank" rel="noopener noreferrer">Visualizar Boleto</a>
              </Button>
            )}
            {paymentDetails.boleto_digitable_line && (
              <div>
                <p className="text-slate-600 dark:text-slate-300 mb-1">Linha Digitável:</p>
                 <div className="flex items-center gap-2 p-2 bg-slate-200 dark:bg-slate-600 rounded-md">
                  <BoletoIcon className="h-5 w-5 text-slate-500 dark:text-slate-400 flex-shrink-0" />
                  <input 
                    type="text" 
                    readOnly 
                    value={paymentDetails.boleto_digitable_line} 
                    className="w-full bg-transparent text-xs text-slate-700 dark:text-slate-200 focus:outline-none"
                  />
                  <Button variant="ghost" size="sm" onClick={() => handleCopyToClipboard(paymentDetails.boleto_digitable_line, 'Linha Digitável')} className="p-1 h-auto">
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
             {!paymentDetails.boleto_url && !paymentDetails.boleto_digitable_line && (
                <p className="text-slate-500 dark:text-slate-400 text-xs">Os detalhes para pagamento do Boleto (link e linha digitável) foram enviados para o seu e-mail.</p>
            )}
            <p className="text-xs text-slate-500 dark:text-slate-400">Pague até a data de vencimento para confirmar seu pedido.</p>
          </div>
        )}
        
        {(paymentMethod === 'pix' || paymentMethod === 'boleto') && paymentStatus === 'paid' && (
            <div className="flex items-center text-green-600 dark:text-green-400">
                <CheckCircle className="h-5 w-5 mr-2" />
                <span>Pagamento Confirmado!</span>
            </div>
        )}
      </div>
    </div>
  );
};

export default OrderPaymentDetailsDisplay;
