
import React from 'react';

const OrderAddressDisplay = ({ address, title = "Endereço" }) => {
  const formatAddressText = (addr) => {
    if (!addr) return "Não informado";
    return `${addr.address_line1}, ${addr.address_number || ''}${addr.address_complement ? `, ${addr.address_complement}` : ''} - ${addr.address_district || ''}, ${addr.city || ''} - ${addr.state_province || ''}, CEP: ${addr.postal_code || ''}`;
  };

  if (!address) {
    return (
      <div>
        <h3 className="text-lg font-semibold mb-2 text-slate-700 dark:text-slate-200">{title}</h3>
        <div className="p-4 bg-slate-100 dark:bg-slate-700/50 rounded-md text-sm text-slate-600 dark:text-slate-300">
          <p>Endereço não fornecido.</p>
        </div>
      </div>
    );
  }
  
  const currentAddress = typeof address === 'string' ? JSON.parse(address) : address;


  return (
    <div>
      <h3 className="text-lg font-semibold mb-2 text-slate-700 dark:text-slate-200">{title}</h3>
      <div className="p-4 bg-slate-100 dark:bg-slate-700/50 rounded-md text-sm text-slate-600 dark:text-slate-300 space-y-1">
        {currentAddress.full_name && <p>{currentAddress.full_name}</p>}
        <p>{formatAddressText(currentAddress)}</p>
        {currentAddress.phone_number && <p>Telefone: {currentAddress.phone_number}</p>}
      </div>
    </div>
  );
};

export default OrderAddressDisplay;
