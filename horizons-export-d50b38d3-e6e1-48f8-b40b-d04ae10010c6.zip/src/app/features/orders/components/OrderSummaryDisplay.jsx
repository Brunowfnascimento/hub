
import React from 'react';
import { Separator } from '@/components/ui/separator';
import { formatCurrency, formatDate } from '@/app/lib/formatters'; 
import { useTranslation } from 'react-i18next';

const OrderSummaryDisplay = ({ orderItems, totalItemsPrice, shippingCost, discountAmount, couponCode, grandTotal, shippingMethodName }) => {
  const { t, i18n } = useTranslation();
  
  const displayCurrency = (amount) => formatCurrency(amount, 'BRL', i18n.language);

  return (
    <div className="p-4 bg-slate-100 dark:bg-slate-700/50 rounded-md space-y-3 text-sm">
      {orderItems?.map(item => (
        <div key={item.id || item.product_snapshot?.id || Math.random()} className="flex justify-between items-start">
          <div>
            <p className="font-medium text-slate-700 dark:text-slate-200">{item.product_snapshot?.name}</p>
            {item.product_snapshot?.variant_attributes && (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {Object.entries(item.product_snapshot.variant_attributes).map(([key, value]) => `${key}: ${value}`).join(', ')}
              </p>
            )}
             {item.product_snapshot?.attributes && !item.product_snapshot?.variant_attributes && (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {Object.entries(item.product_snapshot.attributes).map(([key, value]) => `${key}: ${value}`).join(', ')}
              </p>
            )}
            <p className="text-xs text-slate-500 dark:text-slate-400">{t('cartPage.quantity', 'Qtd')}: {item.quantity}</p>
          </div>
          <p className="font-semibold text-slate-800 dark:text-slate-100">{displayCurrency(item.total_price_at_purchase)}</p>
        </div>
      ))}
      <Separator className="dark:bg-slate-600 print:bg-slate-300" />
      <div className="flex justify-between font-medium">
        <span className="text-slate-600 dark:text-slate-300">{t('cartSummary.subtotal', 'Subtotal')}:</span>
        <span className="text-slate-700 dark:text-slate-200">{displayCurrency(totalItemsPrice)}</span>
      </div>
      <div className="flex justify-between font-medium">
        <span className="text-slate-600 dark:text-slate-300">{t('cartSummary.shipping', 'Frete')} ({shippingMethodName || 'N/A'}):</span>
        <span className="text-slate-700 dark:text-slate-200">{displayCurrency(shippingCost)}</span>
      </div>
      {discountAmount > 0 && (
        <div className="flex justify-between font-medium text-green-600 dark:text-green-400">
          <span>{t('cartSummary.discounts', 'Desconto')} ({couponCode || t('Applied', 'Aplicado')}):</span>
          <span>- {displayCurrency(discountAmount)}</span>
        </div>
      )}
      <Separator className="dark:bg-slate-600 print:bg-slate-300" />
      <div className="flex justify-between text-lg font-bold text-slate-900 dark:text-slate-50">
        <span>{t('cartSummary.totalEstimate', 'Total')}:</span>
        <span>{displayCurrency(grandTotal)}</span>
      </div>
    </div>
  );
};

export default OrderSummaryDisplay;
