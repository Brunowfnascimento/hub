
import { supabase } from '@/app/api/supabase';

export const getUserAddresses = async (userId) => {
  if (!userId) {
    console.error("User ID is required to fetch addresses.");
    return { data: [], error: { message: "User ID is required." } };
  }
  const { data, error } = await supabase
    .from('addresses')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching user addresses:', error);
  }
  return { data, error };
};

export const saveUserAddress = async (addressData) => {
  if (!addressData.user_id) {
    return { data: null, error: { message: "User ID is required to save an address." } };
  }

  const addressToSave = { ...addressData };
  delete addressToSave.save_address; 
  delete addressToSave.id; 


  if (addressData.is_default_shipping) {
    await supabase
      .from('addresses')
      .update({ is_default_shipping: false })
      .eq('user_id', addressData.user_id)
      .neq('id', addressData.id || '00000000-0000-0000-0000-000000000000'); 
  }
  if (addressData.is_default_billing) {
     await supabase
      .from('addresses')
      .update({ is_default_billing: false })
      .eq('user_id', addressData.user_id)
      .neq('id', addressData.id || '00000000-0000-0000-0000-000000000000');
  }
  
  let response;
  if (addressData.id) { 
    response = await supabase
      .from('addresses')
      .update(addressToSave)
      .eq('id', addressData.id)
      .select()
      .single();
  } else {
    response = await supabase
      .from('addresses')
      .insert(addressToSave)
      .select()
      .single();
  }

  if (response.error) {
    console.error('Error saving user address:', response.error);
  }
  return response;
};

export const deleteUserAddress = async (addressId, userId) => {
   if (!addressId || !userId) {
    return { data: null, error: { message: "Address ID and User ID are required." } };
  }
  const { data, error } = await supabase
    .from('addresses')
    .delete()
    .eq('id', addressId)
    .eq('user_id', userId);

  if (error) {
    console.error('Error deleting user address:', error);
  }
  return { data, error };
};


export const fetchAddressFromViaCEP = async (postalCode) => {
  const cleanedPostalCode = postalCode.replace(/\D/g, '');
  if (cleanedPostalCode.length !== 8) {
    return { error: 'CEP inválido. Deve conter 8 dígitos.' };
  }
  try {
    const response = await fetch(`https://viacep.com.br/ws/${cleanedPostalCode}/json/`);
    if (!response.ok) {
      throw new Error(`Erro na API ViaCEP: ${response.status}`);
    }
    const data = await response.json();
    if (data.erro) {
      return { error: 'CEP não encontrado.' };
    }
    return {
      address_line1: data.logradouro || '',
      address_district: data.bairro || '',
      city: data.localidade || '',
      state_province: data.uf || '',
      postal_code: data.cep || postalCode, 
    };
  } catch (error) {
    console.error("Erro ao buscar CEP:", error);
    return { error: `Falha ao buscar CEP: ${error.message}` };
  }
};
