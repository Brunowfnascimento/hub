
import React, { useEffect } from 'react';
import { useCheckout } from '@/app/contexts/CheckoutContext';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';

const CheckoutShippingStep = () => {
  const {
    shippingAddress,
    availableShippingMethods,
    selectedShippingMethod,
    setSelectedShippingMethod,
    fetchAvailableShippingMethods,
    goToNextStep,
    goToPreviousStep,
    isFetchingShippingMethods,
    orderError, 
  } = useCheckout();

  useEffect(() => {
    if (shippingAddress?.postal_code) {
      fetchAvailableShippingMethods();
    }
  }, [shippingAddress, fetchAvailableShippingMethods]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedShippingMethod) {
      goToNextStep();
    }
  };

  if (isFetchingShippingMethods) {
    return (
      <div className="flex flex-col justify-center items-center py-10 min-h-[200px] bg-slate-50 dark:bg-slate-800 rounded-lg shadow">
        <LoadingSpinner size="h-12 w-12 text-sky-500" /> 
        <p className="mt-3 text-slate-600 dark:text-slate-300">Calculando opções de frete...</p>
      </div>
    );
  }
  
  if (orderError && availableShippingMethods.length === 0) {
    return (
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <ErrorDisplay 
            message="Erro ao Calcular Frete"
            details={orderError || "Não foi possível buscar as opções de frete. Verifique seu CEP ou tente novamente."} 
        />
        <div className="mt-6 flex justify-start">
             <Button type="button" variant="outline" onClick={goToPreviousStep}>
                Voltar para Endereço
            </Button>
        </div>
      </motion.div>
    )
  }


  return (
    <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 50 }}>
      <form onSubmit={handleSubmit}>
        <Card className="shadow-lg dark:bg-slate-800/70 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">Método de Envio</CardTitle>
          </CardHeader>
          <CardContent>
            {!shippingAddress?.postal_code ? (
                <div className="flex flex-col items-center text-center p-6 bg-amber-50 dark:bg-amber-900/30 border border-amber-300 dark:border-amber-700 rounded-lg">
                    <AlertTriangle className="h-10 w-10 text-amber-500 dark:text-amber-400 mb-3" />
                    <p className="text-amber-700 dark:text-amber-300 font-medium">
                        Por favor, informe um endereço de entrega na etapa anterior para ver as opções de frete.
                    </p>
                </div>
            ) : availableShippingMethods.length === 0 && !isFetchingShippingMethods ? (
              <div className="flex flex-col items-center text-center p-6 bg-slate-100 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-600 rounded-lg">
                <AlertTriangle className="h-10 w-10 text-slate-500 dark:text-slate-400 mb-3" />
                <p className="text-slate-600 dark:text-slate-300">
                  Nenhum método de envio disponível para o endereço e itens selecionados.
                </p>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                  Verifique se o CEP está correto ou tente remover/alterar itens do carrinho.
                </p>
              </div>
            ) : (
              <RadioGroup
                value={selectedShippingMethod?.id}
                onValueChange={(value) => {
                  const method = availableShippingMethods.find(m => m.id === value);
                  setSelectedShippingMethod(method);
                }}
                className="space-y-3"
              >
                {availableShippingMethods.map((method, index) => (
                  <motion.div 
                    key={method.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.3 }}
                  >
                    <Label 
                      htmlFor={method.id}
                      className={`flex items-center space-x-3 p-4 border rounded-lg cursor-pointer transition-all duration-200 ease-in-out hover:shadow-md hover:border-sky-400 dark:hover:border-sky-500
                        ${selectedShippingMethod?.id === method.id 
                          ? 'bg-sky-50 dark:bg-sky-700/40 border-sky-500 dark:border-sky-500 ring-2 ring-sky-500 dark:ring-sky-600 ring-offset-1 dark:ring-offset-slate-800' 
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60'
                        }`}
                    >
                      <RadioGroupItem value={method.id} id={method.id} className="border-slate-400 text-sky-600 focus:ring-sky-500" />
                      <div className="flex-1">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-slate-800 dark:text-slate-100">{method.name}</span>
                          <span className="font-semibold text-sky-600 dark:text-sky-400">
                            {method.cost === 0 ? 'Grátis' : `R$ ${parseFloat(method.cost).toFixed(2)}`}
                          </span>
                        </div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{method.estimated_delivery_time}</p>
                      </div>
                    </Label>
                  </motion.div>
                ))}
              </RadioGroup>
            )}
          </CardContent>
          <CardFooter className="flex justify-between mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
            <Button type="button" variant="outline" onClick={goToPreviousStep} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
              Voltar para Endereço
            </Button>
            <Button 
                type="submit" 
                disabled={!selectedShippingMethod || availableShippingMethods.length === 0 || !shippingAddress?.postal_code} 
                size="lg"
                className="bg-sky-600 hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-600 text-white shadow-md"
            >
              Continuar para Pagamento
            </Button>
          </CardFooter>
        </Card>
      </form>
    </motion.div>
  );
};

export default CheckoutShippingStep;
