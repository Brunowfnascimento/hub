
import React, { useState } from 'react';
import { useCheckout } from '@/app/contexts/CheckoutContext';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { motion, AnimatePresence } from 'framer-motion';
import { CreditCard, Landmark, QrCode, AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';

const CheckoutPaymentStep = () => {
  const {
    paymentMethod,
    setPaymentMethod,
    goToNextStep,
    goToPreviousStep,
    paymentProcessing,
  } = useCheckout();
  const { toast } = useToast();

  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');

  const paymentOptions = [
    { id: 'credit_card', label: 'Cartão de Crédito', icon: CreditCard },
    { id: 'pix', label: 'PIX', icon: QrCode },
    { id: 'boleto', label: 'Boleto Bancário', icon: Landmark },
  ];

  const handleCardNumberChange = (e) => {
    let value = e.target.value.replace(/\D/g, '');
    value = value.match(/.{1,4}/g)?.join(' ') || '';
    setCardNumber(value.slice(0, 19)); 
  };

  const handleCardExpiryChange = (e) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 2) {
      value = `${value.slice(0, 2)}/${value.slice(2)}`;
    }
    setCardExpiry(value.slice(0, 5)); 
  };

  const handleCardCvvChange = (e) => {
    setCardCvv(e.target.value.replace(/\D/g, '').slice(0, 4));
  };
  
  const validateAndProceed = () => {
    if (paymentMethod === 'credit_card') {
      if (!cardNumber || cardNumber.replace(/\s/g, '').length < 13 || cardNumber.replace(/\s/g, '').length > 19) {
        toast({ title: "Cartão Inválido", description: "Número do cartão inválido.", variant: "destructive" });
        return;
      }
      if (!cardName.trim()) {
        toast({ title: "Nome no Cartão", description: "Por favor, insira o nome no cartão.", variant: "destructive" });
        return;
      }
      if (!cardExpiry || !/^(0[1-9]|1[0-2])\/\d{2}$/.test(cardExpiry)) {
        toast({ title: "Validade Inválida", description: "Formato de validade MM/AA inválido.", variant: "destructive" });
        return;
      }
      if (!cardCvv || cardCvv.length < 3 || cardCvv.length > 4) {
        toast({ title: "CVV Inválido", description: "CVV do cartão inválido.", variant: "destructive" });
        return;
      }
      toast({ title: "Simulação de Cartão", description: "Dados do cartão (simulados) validados.", variant: "default", className: "bg-yellow-500 text-black dark:bg-yellow-600 dark:text-white" });
    }
    goToNextStep();
  };


  return (
    <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 50 }}>
      <Card className="shadow-lg dark:bg-slate-800/70 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">Forma de Pagamento</CardTitle>
          <CardDescription>Selecione como você gostaria de pagar.</CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="mb-6 space-y-3">
            {paymentOptions.map((option) => (
              <Label
                key={option.id}
                htmlFor={option.id}
                className={`flex items-center space-x-3 p-4 border rounded-lg cursor-pointer transition-all duration-200 ease-in-out hover:shadow-md hover:border-sky-400 dark:hover:border-sky-500
                  ${paymentMethod === option.id
                    ? 'bg-sky-50 dark:bg-sky-700/40 border-sky-500 dark:border-sky-500 ring-2 ring-sky-500 dark:ring-sky-600 ring-offset-1 dark:ring-offset-slate-800'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60'
                  }`}
              >
                <RadioGroupItem value={option.id} id={option.id} className="border-slate-400 text-sky-600 focus:ring-sky-500" />
                <option.icon className="h-6 w-6 text-slate-600 dark:text-slate-300" />
                <span className="font-medium text-slate-800 dark:text-slate-100">{option.label}</span>
              </Label>
            ))}
          </RadioGroup>

          <AnimatePresence mode="wait">
            {paymentMethod === 'credit_card' && (
              <motion.div
                key="credit_card_form"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-6 p-4 border border-yellow-400 bg-yellow-50 dark:bg-yellow-900/30 dark:border-yellow-700 rounded-lg space-y-4"
              >
                <div className="flex items-start space-x-2 text-yellow-700 dark:text-yellow-300">
                  <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
                  <p className="text-xs">
                    <strong>Modo de Simulação:</strong> Os campos abaixo são apenas para demonstração.
                    Não insira dados reais de cartão de crédito. Nenhum pagamento real será processado.
                  </p>
                </div>
                <div>
                  <Label htmlFor="cardNumber">Número do Cartão</Label>
                  <Input
                    id="cardNumber"
                    placeholder="0000 0000 0000 0000"
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    maxLength={19}
                    className="dark:bg-slate-700 dark:border-slate-600"
                  />
                </div>
                <div>
                  <Label htmlFor="cardName">Nome no Cartão</Label>
                  <Input
                    id="cardName"
                    placeholder="Como aparece no cartão"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    className="dark:bg-slate-700 dark:border-slate-600"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="cardExpiry">Validade (MM/AA)</Label>
                    <Input
                      id="cardExpiry"
                      placeholder="MM/AA"
                      value={cardExpiry}
                      onChange={handleCardExpiryChange}
                      maxLength={5}
                      className="dark:bg-slate-700 dark:border-slate-600"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cardCvv">CVV</Label>
                    <Input
                      id="cardCvv"
                      placeholder="123"
                      type="password"
                      value={cardCvv}
                      onChange={handleCardCvvChange}
                      maxLength={4}
                      className="dark:bg-slate-700 dark:border-slate-600"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {paymentMethod === 'pix' && (
              <motion.div
                key="pix_info"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-6 p-4 border border-sky-300 bg-sky-50 dark:bg-sky-900/30 dark:border-sky-700 rounded-lg text-center"
              >
                <QrCode className="h-10 w-10 mx-auto text-sky-600 dark:text-sky-400 mb-2" />
                <p className="text-slate-700 dark:text-slate-200">
                  O QR Code e o código "Copia e Cola" para pagamento via PIX serão exibidos na próxima tela, após a confirmação do seu pedido.
                </p>
              </motion.div>
            )}

            {paymentMethod === 'boleto' && (
              <motion.div
                key="boleto_info"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-6 p-4 border border-sky-300 bg-sky-50 dark:bg-sky-900/30 dark:border-sky-700 rounded-lg text-center"
              >
                <Landmark className="h-10 w-10 mx-auto text-sky-600 dark:text-sky-400 mb-2" />
                <p className="text-slate-700 dark:text-slate-200">
                  O boleto bancário para pagamento será gerado e disponibilizado na próxima tela, após a confirmação do seu pedido.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
        <CardFooter className="flex justify-between mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
          <Button type="button" variant="outline" onClick={goToPreviousStep} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
            Voltar para Frete
          </Button>
          <Button 
            onClick={validateAndProceed} 
            disabled={paymentProcessing}
            size="lg"
            className="bg-sky-600 hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-600 text-white shadow-md"
          >
            {paymentProcessing ? <LoadingSpinner size="h-5 w-5 mr-2" /> : null}
            Revisar Pedido
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default CheckoutPaymentStep;
