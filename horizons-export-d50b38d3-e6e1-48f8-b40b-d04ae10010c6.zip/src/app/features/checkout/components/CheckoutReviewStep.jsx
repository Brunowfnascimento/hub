
import React from 'react';
import { useCheckout } from '@/app/contexts/CheckoutContext';
import { useCart } from '@/app/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { AlertCircle, CheckCircle, CreditCard, Home, Landmark, Loader2, Package, QrCode, ShoppingCart, Truck } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/app/contexts/AuthContext';

const CheckoutReviewStep = () => {
  const {
    shippingAddress,
    billingAddress,
    useShippingAsBilling,
    selectedShippingMethod,
    paymentMethod,
    couponCode,
    discountApplied,
    paymentProcessing,
    orderError,
    placeOrder,
    goToPreviousStep,
    setPaymentProcessing, 
  } = useCheckout();

  const { items: cartItems, subtotalAmount, totalQuantity } = useCart();
  const { user } = useAuth();

  const shippingCost = selectedShippingMethod?.cost || 0;
  const totalAmount = subtotalAmount + shippingCost - discountApplied;

  const handlePlaceOrder = async () => {
    setPaymentProcessing(true); 
    await placeOrder();
  };

  const getPaymentMethodIcon = (method) => {
    switch (method) {
      case 'credit_card':
        return <CreditCard className="h-5 w-5 mr-2 text-sky-600 dark:text-sky-400" />;
      case 'pix':
        return <QrCode className="h-5 w-5 mr-2 text-sky-600 dark:text-sky-400" />;
      case 'boleto':
        return <Landmark className="h-5 w-5 mr-2 text-sky-600 dark:text-sky-400" />;
      default:
        return <CreditCard className="h-5 w-5 mr-2 text-slate-500" />;
    }
  };
  
  const formatAddress = (address) => {
    if (!address) return "Não informado";
    return `${address.address_line1}, ${address.address_number}${address.address_complement ? `, ${address.address_complement}` : ''} - ${address.address_district}, ${address.city} - ${address.state_province}, CEP: ${address.postal_code}`;
  };

  return (
    <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 50 }}>
      <Card className="shadow-xl dark:bg-slate-800/70 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center text-slate-800 dark:text-slate-100">
            <CheckCircle className="h-7 w-7 mr-3 text-green-500" />
            Revise seu Pedido
          </CardTitle>
          <CardDescription>Confirme os detalhes abaixo antes de finalizar a compra.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          
          <section>
            <h3 className="text-lg font-semibold mb-2 flex items-center text-slate-700 dark:text-slate-200">
              <Home className="h-5 w-5 mr-2 text-sky-600 dark:text-sky-400" /> Endereços
            </h3>
            <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-md space-y-2 text-sm">
              <div>
                <p className="font-medium text-slate-600 dark:text-slate-300">Entrega:</p>
                <p className="text-slate-500 dark:text-slate-400">{formatAddress(shippingAddress)}</p>
              </div>
              <div>
                <p className="font-medium text-slate-600 dark:text-slate-300">Cobrança:</p>
                <p className="text-slate-500 dark:text-slate-400">
                  {useShippingAsBilling ? "Mesmo da entrega" : formatAddress(billingAddress)}
                </p>
              </div>
            </div>
          </section>

          <Separator className="dark:bg-slate-700" />

          <section>
            <h3 className="text-lg font-semibold mb-2 flex items-center text-slate-700 dark:text-slate-200">
              <Truck className="h-5 w-5 mr-2 text-sky-600 dark:text-sky-400" /> Método de Envio
            </h3>
            <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-md text-sm">
              {selectedShippingMethod ? (
                <>
                  <p className="font-medium text-slate-600 dark:text-slate-300">{selectedShippingMethod.name}</p>
                  <p className="text-slate-500 dark:text-slate-400">Custo: R$ {selectedShippingMethod.cost.toFixed(2)}</p>
                  <p className="text-slate-500 dark:text-slate-400">Prazo: {selectedShippingMethod.estimated_delivery_time}</p>
                </>
              ) : (
                <p className="text-slate-500 dark:text-slate-400">Não selecionado</p>
              )}
            </div>
          </section>

          <Separator className="dark:bg-slate-700" />

          <section>
            <h3 className="text-lg font-semibold mb-2 flex items-center text-slate-700 dark:text-slate-200">
              {getPaymentMethodIcon(paymentMethod)} Método de Pagamento
            </h3>
            <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-md text-sm">
              <p className="font-medium text-slate-600 dark:text-slate-300">
                {paymentMethod === 'credit_card' ? 'Cartão de Crédito' : paymentMethod === 'pix' ? 'PIX' : 'Boleto Bancário'}
              </p>
              {paymentMethod === 'credit_card' && <p className="text-xs text-slate-500 dark:text-slate-400">(Detalhes do cartão não são exibidos por segurança)</p>}
            </div>
          </section>

          <Separator className="dark:bg-slate-700" />

          <section>
            <h3 className="text-lg font-semibold mb-2 flex items-center text-slate-700 dark:text-slate-200">
              <ShoppingCart className="h-5 w-5 mr-2 text-sky-600 dark:text-sky-400" /> Itens do Pedido ({totalQuantity})
            </h3>
            <div className="space-y-3 max-h-60 overflow-y-auto p-1">
              {cartItems.map(item => (
                <div key={item.variantId || item.productId} className="flex justify-between items-start p-3 bg-slate-50 dark:bg-slate-700/50 rounded-md text-sm">
                  <div className="flex-grow pr-2">
                    <p className="font-medium text-slate-700 dark:text-slate-200">{item.name}</p>
                    {item.attributes && (
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {Object.entries(item.attributes).map(([key, value]) => `${key}: ${value}`).join(', ')}
                      </p>
                    )}
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {item.quantity} x R$ {item.price.toFixed(2)}
                    </p>
                  </div>
                  <p className="font-semibold text-slate-800 dark:text-slate-100">R$ {(item.price * item.quantity).toFixed(2)}</p>
                </div>
              ))}
            </div>
          </section>

          <Separator className="dark:bg-slate-700" />

          <section className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600 dark:text-slate-300">Subtotal:</span>
              <span className="font-medium text-slate-700 dark:text-slate-200">R$ {subtotalAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600 dark:text-slate-300">Frete:</span>
              <span className="font-medium text-slate-700 dark:text-slate-200">R$ {shippingCost.toFixed(2)}</span>
            </div>
            {discountApplied > 0 && (
              <div className="flex justify-between text-green-600 dark:text-green-400">
                <span className="font-medium">Desconto ({couponCode}):</span>
                <span className="font-medium">- R$ {discountApplied.toFixed(2)}</span>
              </div>
            )}
            <Separator className="my-2 dark:bg-slate-700" />
            <div className="flex justify-between text-xl font-bold text-slate-900 dark:text-slate-50">
              <span>Total do Pedido:</span>
              <span>R$ {totalAmount.toFixed(2)}</span>
            </div>
          </section>

          {orderError && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-300 dark:border-red-600 rounded-md text-red-700 dark:text-red-300 text-sm flex items-center"
            >
              <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
              <span>{orderError}</span>
            </motion.div>
          )}

        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row justify-between mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
          <Button type="button" variant="outline" onClick={goToPreviousStep} disabled={paymentProcessing} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
            Voltar para Pagamento
          </Button>
          <Button 
            onClick={handlePlaceOrder} 
            disabled={paymentProcessing || !shippingAddress || !selectedShippingMethod}
            size="lg"
            className="bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white shadow-md min-w-[200px]"
          >
            {paymentProcessing ? (
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            ) : (
              <Package className="mr-2 h-5 w-5" />
            )}
            {paymentProcessing ? 'Processando...' : 'Finalizar Pedido e Pagar'}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default CheckoutReviewStep;
