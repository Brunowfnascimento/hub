
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Controller } from 'react-hook-form';
import { statesBrazil } from '@/app/types/checkout.types.jsx';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { useToast } from '@/components/ui/use-toast';
import { fetchAddressFromViaCEP } from '@/app/features/checkout/services/address.service';
import { useAuth } from '@/app/contexts/AuthContext';

const AddressFormFields = ({ form, typePrefix = '', onPostalCodeBlur: customOnPostalCodeBlur, showSaveAddressCheckbox = true }) => {
  const [isFetchingCep, setIsFetchingCep] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth(); // To conditionally render save address checkbox

  const handlePostalCodeBlurInternal = async (e, currentForm) => {
    const postalCode = e.target.value;
    if (postalCode && /^\d{5}-?\d{3}$/.test(postalCode)) {
      setIsFetchingCep(true);
      const result = await fetchAddressFromViaCEP(postalCode);
      setIsFetchingCep(false);
      if (result && !result.error) {
        currentForm.setValue(`${typePrefix}address_line1`, result.address_line1, { shouldValidate: true });
        currentForm.setValue(`${typePrefix}address_district`, result.address_district, { shouldValidate: true });
        currentForm.setValue(`${typePrefix}city`, result.city, { shouldValidate: true });
        currentForm.setValue(`${typePrefix}state_province`, result.state_province, { shouldValidate: true });
        currentForm.setValue(`${typePrefix}country`, 'Brasil', { shouldValidate: true });
        currentForm.setValue(`${typePrefix}postal_code`, result.postal_code, { shouldValidate: true });
      } else if (result.error) {
        toast({ title: "Erro ao buscar CEP", description: result.error, variant: "destructive" });
      }
    }
  };

  const onPostalCodeBlurHandler = customOnPostalCodeBlur || handlePostalCodeBlurInternal;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor={`${typePrefix}full_name`}>Nome Completo</Label>
          <Input {...form.register(`${typePrefix}full_name`)} id={`${typePrefix}full_name`} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
          {form.formState.errors[`${typePrefix}full_name`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}full_name`].message}</p>}
        </div>
        <div>
          <Label htmlFor={`${typePrefix}cpf`}>CPF</Label>
          <Input {...form.register(`${typePrefix}cpf`)} id={`${typePrefix}cpf`} placeholder="000.000.000-00" className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
          {form.formState.errors[`${typePrefix}cpf`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}cpf`].message}</p>}
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor={`${typePrefix}postal_code`}>CEP</Label>
          <div className="flex items-center">
            <Input 
              {...form.register(`${typePrefix}postal_code`)} 
              id={`${typePrefix}postal_code`} 
              placeholder="00000-000"
              onBlur={(e) => onPostalCodeBlurHandler(e, form)}
              className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
            />
            {isFetchingCep && <LoadingSpinner size="h-5 w-5 ml-2" />}
          </div>
          {form.formState.errors[`${typePrefix}postal_code`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}postal_code`].message}</p>}
        </div>
        <div>
          <Label htmlFor={`${typePrefix}address_line1`}>Endereço (Rua/Avenida)</Label>
          <Input {...form.register(`${typePrefix}address_line1`)} id={`${typePrefix}address_line1`} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
          {form.formState.errors[`${typePrefix}address_line1`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}address_line1`].message}</p>}
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor={`${typePrefix}address_number`}>Número</Label>
          <Input {...form.register(`${typePrefix}address_number`)} id={`${typePrefix}address_number`} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
          {form.formState.errors[`${typePrefix}address_number`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}address_number`].message}</p>}
        </div>
        <div>
          <Label htmlFor={`${typePrefix}address_complement`}>Complemento (Opcional)</Label>
          <Input {...form.register(`${typePrefix}address_complement`)} id={`${typePrefix}address_complement`} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor={`${typePrefix}address_district`}>Bairro</Label>
          <Input {...form.register(`${typePrefix}address_district`)} id={`${typePrefix}address_district`} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
          {form.formState.errors[`${typePrefix}address_district`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}address_district`].message}</p>}
        </div>
        <div>
          <Label htmlFor={`${typePrefix}city`}>Cidade</Label>
          <Input {...form.register(`${typePrefix}city`)} id={`${typePrefix}city`} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
          {form.formState.errors[`${typePrefix}city`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}city`].message}</p>}
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor={`${typePrefix}state_province`}>Estado</Label>
          <Controller
            name={`${typePrefix}state_province`}
            control={form.control}
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value} >
                <SelectTrigger id={`${typePrefix}state_province`} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
                  <SelectValue placeholder="Selecione o Estado" />
                </SelectTrigger>
                <SelectContent className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
                  {statesBrazil.map(state => (
                    <SelectItem key={state.value} value={state.value}>{state.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
          {form.formState.errors[`${typePrefix}state_province`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}state_province`].message}</p>}
        </div>
        <div>
          <Label htmlFor={`${typePrefix}phone_number`}>Telefone</Label>
          <Input {...form.register(`${typePrefix}phone_number`)} id={`${typePrefix}phone_number`} type="tel" placeholder="(00) 00000-0000" className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
          {form.formState.errors[`${typePrefix}phone_number`] && <p className="text-red-500 text-xs mt-1">{form.formState.errors[`${typePrefix}phone_number`].message}</p>}
        </div>
      </div>
      {user && showSaveAddressCheckbox && (
        <div className="flex items-center space-x-2 pt-2">
          <Controller
            name={`${typePrefix}save_address`}
            control={form.control}
            render={({ field }) => (
              <Checkbox
                id={`${typePrefix}save_address`}
                checked={field.value}
                onCheckedChange={field.onChange}
                className="dark:border-slate-600 data-[state=checked]:bg-sky-500 data-[state=checked]:text-white"
              />
            )}
          />
          <Label htmlFor={`${typePrefix}save_address`} className="dark:text-slate-300">Salvar este endereço para futuras compras</Label>
        </div>
      )}
    </div>
  );
};

export default AddressFormFields;
