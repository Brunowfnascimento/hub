
import React from 'react';
import { useCheckout } from '@/app/contexts/CheckoutContext';
import { useCart } from '@/app/contexts/CartContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ShoppingBag } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatCurrency } from '@/app/lib/formatters';
import { useTranslation } from 'react-i18next';

const CheckoutSummary = () => {
  const { selectedShippingMethod, discountApplied, couponCode } = useCheckout();
  const { items, subtotalAmount, totalQuantity } = useCart();
  const { t } = useTranslation();

  const shippingCost = selectedShippingMethod?.cost || 0;
  const totalAmount = subtotalAmount + shippingCost - discountApplied;

  if (items.length === 0) {
    return null; 
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="sticky top-24" 
    >
      <Card className="shadow-lg bg-white dark:bg-slate-800 border dark:border-slate-700 rounded-xl">
        <CardHeader className="pb-4">
          <CardTitle className="text-xl font-semibold text-slate-800 dark:text-slate-100 flex items-center">
            <ShoppingBag className="mr-2 h-6 w-6 text-sky-500" />
            {t('cartSummary.title', 'Resumo da Compra')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {items.map(item => (
            <div key={item.variantId || item.productId} className="flex justify-between items-center text-sm">
              <div className="flex-grow pr-2">
                <p className="text-slate-700 dark:text-slate-300 truncate" title={item.name}>
                  {item.name} <span className="text-slate-500 dark:text-slate-400">(x{item.quantity})</span>
                </p>
                {item.attributes && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {Object.values(item.attributes).join(', ')}
                  </p>
                )}
              </div>
              <p className="text-slate-600 dark:text-slate-300 font-medium">{formatCurrency(item.price * item.quantity)}</p>
            </div>
          ))}
          <Separator className="my-3 bg-slate-200 dark:bg-slate-700" />
          <div className="flex justify-between text-sm">
            <span className="text-slate-600 dark:text-slate-300">{t('cartSummary.subtotal', 'Subtotal')} ({totalQuantity} {totalQuantity === 1 ? t('cartSummary.item', 'item') : t('cartSummary.items', 'itens')}):</span>
            <span className="font-medium text-slate-700 dark:text-slate-200">{formatCurrency(subtotalAmount)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-slate-600 dark:text-slate-300">{t('cartSummary.shipping', 'Frete')}:</span>
            <span className="font-medium text-slate-700 dark:text-slate-200">
              {selectedShippingMethod ? formatCurrency(shippingCost) : t('cartSummary.shippingFree', 'A calcular')}
            </span>
          </div>
          {discountApplied > 0 && (
            <div className="flex justify-between text-sm text-green-600 dark:text-green-400">
              <span className="font-medium">{t('cartSummary.discounts', 'Desconto')} ({couponCode}):</span>
              <span className="font-medium">- {formatCurrency(discountApplied)}</span>
            </div>
          )}
          <Separator className="my-3 bg-slate-200 dark:bg-slate-700" />
          <div className="flex justify-between text-lg font-bold text-slate-900 dark:text-slate-50">
            <span>{t('cartSummary.totalEstimate', 'Total')}:</span>
            <span>{formatCurrency(totalAmount)}</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CheckoutSummary;
