
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, ArrowUpDown } from 'lucide-react';
import { motion } from 'framer-motion';

const ProductListTable = ({ 
  products, 
  onSort, 
  sortParams, 
  onDeleteProduct, 
  selectedProducts, 
  setSelectedProducts,
  isLoading
}) => {
  const navigate = useNavigate();

  const handleSelectAll = (checked) => {
    if (checked) {
      const allProductIds = products.map((product) => product.id);
      setSelectedProducts(allProductIds);
    } else {
      setSelectedProducts([]);
    }
  };

  const handleSelectOne = (productId, checked) => {
    if (checked) {
      setSelectedProducts([...selectedProducts, productId]);
    } else {
      setSelectedProducts(selectedProducts.filter((id) => id !== productId));
    }
  };

  const renderSortIcon = (columnKey) => {
    if (sortParams.sortBy === columnKey) {
      return sortParams.sortOrder === 'asc' ? ' ↑' : ' ↓';
    }
    return <ArrowUpDown className="ml-2 h-3 w-3 opacity-40 inline" />;
  };
  
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);
  };

  if (isLoading && (!products || products.length === 0)) {
    return (
      <div className="grid grid-cols-1 gap-4 mt-4">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="h-20 bg-slate-200 dark:bg-slate-700 rounded-md animate-pulse"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: i * 0.05 }}
          />
        ))}
      </div>
    );
  }


  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="rounded-lg border dark:border-slate-700 overflow-hidden shadow-lg bg-card"
    >
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
            <TableHead className="w-[50px]">
              <Checkbox
                checked={products.length > 0 && selectedProducts.length === products.length}
                onCheckedChange={(checkedState) => handleSelectAll(checkedState)}
                aria-label="Selecionar todos"
                disabled={products.length === 0}
              />
            </TableHead>
            <TableHead className="w-[80px]">Imagem</TableHead>
            <TableHead onClick={() => onSort('name')} className="cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
              Nome {renderSortIcon('name')}
            </TableHead>
            <TableHead>SKU</TableHead>
            <TableHead>Categoria</TableHead>
            <TableHead onClick={() => onSort('base_price')} className="cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
              Preço {renderSortIcon('base_price')}
            </TableHead>
            <TableHead onClick={() => onSort('total_stock')} className="cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
              Estoque {renderSortIcon('total_stock')}
            </TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {products.map((product) => (
            <TableRow key={product.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors data-[state=selected]:bg-slate-100 dark:data-[state=selected]:bg-slate-700">
              <TableCell>
                <Checkbox
                  checked={selectedProducts.includes(product.id)}
                  onCheckedChange={(checkedState) => handleSelectOne(product.id, checkedState)}
                  aria-label={`Selecionar produto ${product.name}`}
                />
              </TableCell>
              <TableCell>
                {product.main_image_url ? (
                  <img 
                    alt={product.name || 'Imagem do Produto'}
                    className="h-12 w-12 object-cover rounded-md shadow-sm" src="https://images.unsplash.com/photo-1646193186132-7976c1670e81" />
                ) : (
                  <div className="h-12 w-12 bg-slate-200 dark:bg-slate-700 rounded-md flex items-center justify-center text-xs text-muted-foreground">Sem Img</div>
                )}
              </TableCell>
              <TableCell className="font-medium text-primary dark:text-sky-400">{product.name}</TableCell>
              <TableCell>{product.display_sku}</TableCell>
              <TableCell>{product.categories?.name || 'N/A'}</TableCell>
              <TableCell>{formatCurrency(product.base_price)}</TableCell>
              <TableCell>{product.total_stock}</TableCell>
              <TableCell>
                <Badge variant={product.is_active ? 'default' : 'secondary'} 
                  className={product.is_active ? 'bg-green-500 hover:bg-green-600 text-white dark:bg-green-600 dark:hover:bg-green-700' : 'bg-slate-500 hover:bg-slate-600 text-white dark:bg-slate-600 dark:hover:bg-slate-700'}>
                  {product.is_active ? 'Ativo' : 'Inativo'}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Abrir menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => navigate(`/admin/products/edit/${product.id}`)}>
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => onDeleteProduct(product.id)} className="text-red-600 dark:text-red-400 focus:bg-red-100 dark:focus:bg-red-700 focus:text-red-700 dark:focus:text-red-300">
                      Deletar
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </motion.div>
  );
};

export default ProductListTable;
