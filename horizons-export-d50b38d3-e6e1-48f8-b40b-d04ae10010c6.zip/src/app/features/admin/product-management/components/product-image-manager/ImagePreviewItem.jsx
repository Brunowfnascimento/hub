
import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { AlertDialog, AlertDialogTrigger, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import { GripVertical, Star, CheckCircle, Trash2 } from 'lucide-react';
import { Controller } from 'react-hook-form';
import { cn } from '@/lib/utils';
import { getOptimizedImageUrl } from '@/lib/imageUtils';

const ImagePreviewItem = ({
  image,
  index,
  isMain,
  onSetMain,
  onMove,
  onRemove,
  control,
  fieldNamePrefix,
  deleteIsLoading
}) => {
  const imageUrl = image.url || (image.storage_path ? getOptimizedImageUrl(image.storage_path, {width: 200, height: 200}) : null);
  const previewUrl = image.file ? URL.createObjectURL(image.file) : null;
  const displayUrl = imageUrl || previewUrl;

  React.useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  return (
    <motion.div
      key={image.fieldId || image.id || index}
      layout
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="relative group aspect-square"
    >
      <Card className={cn("overflow-hidden h-full w-full shadow-md transition-all", isMain && "ring-2 ring-sky-500 border-sky-500")}>
        {displayUrl ? (
          <img
            src={displayUrl}
            alt={image.alt_text || `Prévia ${index + 1}`}
            className="object-cover w-full h-full"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-400">
            Sem prévia
          </div>
        )}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-opacity flex flex-col items-center justify-center p-2 space-y-1 opacity-0 group-hover:opacity-100">
          <div className="flex space-x-1">
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="h-8 w-8 bg-white/80 hover:bg-white dark:bg-slate-800/80 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
              onClick={() => onMove(index, index - 1)}
              disabled={index === 0}
              title="Mover para esquerda"
            >
              <GripVertical className="h-4 w-4 transform rotate-90" />
            </Button>
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="h-8 w-8 bg-white/80 hover:bg-white dark:bg-slate-800/80 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
              onClick={() => onMove(index, index + 1)}
              
              title="Mover para direita"
            >
              <GripVertical className="h-4 w-4 transform -rotate-90" />
            </Button>
          </div>
          <Button
            type="button"
            variant={isMain ? "default" : "outline"}
            size="sm"
            className={cn("h-8 text-xs w-full", isMain ? "bg-sky-500 hover:bg-sky-600 text-white" : "bg-white/80 hover:bg-white dark:bg-slate-800/80 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200")}
            onClick={() => onSetMain(index)}
            disabled={isMain}
          >
            {isMain ? <CheckCircle className="mr-1 h-4 w-4"/> : <Star className="mr-1 h-4 w-4" />}
            {isMain ? "Principal" : "Definir Principal"}
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button type="button" variant="destructive" size="sm" className="h-8 text-xs w-full">
                <Trash2 className="mr-1 h-4 w-4" /> Remover
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Confirmar Remoção</AlertDialogTitle>
                <AlertDialogDescription>
                  Tem certeza que deseja remover esta imagem?
                  {image.id && image.storage_path && " Esta ação removerá a imagem permanentemente do armazenamento."}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={() => onRemove(index)} disabled={deleteIsLoading}>
                  {deleteIsLoading ? "Removendo..." : "Remover"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
        {isMain && (
          <div className="absolute top-1 left-1 bg-sky-500 text-white text-xs px-1.5 py-0.5 rounded-full font-semibold">
            Principal
          </div>
        )}
      </Card>
      <Controller
        name={`${fieldNamePrefix}.${index}.alt_text`}
        control={control}
        defaultValue={image.alt_text || ''}
        render={({ field: controllerField }) => (
          <Input
            type="text"
            placeholder="Texto Alt (SEO)"
            className="mt-1 h-8 text-xs bg-white/90 dark:bg-slate-800/90 border-slate-300 dark:border-slate-600"
            value={controllerField.value}
            onChange={controllerField.onChange}
          />
        )}
      />
    </motion.div>
  );
};

export default ImagePreviewItem;
