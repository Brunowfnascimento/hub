
import React, { useState, useCallback } from 'react';
import { useFieldArray } from 'react-hook-form';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { deleteProductImage as deleteImageService } from '@/app/features/admin/product-management/services/image.service';
import { useToast } from '@/components/ui/use-toast';

const useImageUploadHandler = (control, setValue, watch, productId, fieldName = "images") => {
  const { fields, append, remove, move: moveFieldArray } = useFieldArray({
    control,
    name: fieldName,
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [localPreviewUrls, setLocalPreviewUrls] = useState({});


  const addLocalPreview = useCallback((fieldId, file) => {
    const url = URL.createObjectURL(file);
    setLocalPreviewUrls(prev => ({ ...prev, [fieldId]: url }));
    return url;
  }, []);

  const revokeLocalPreview = useCallback((fieldId) => {
    setLocalPreviewUrls(prev => {
      if (prev[fieldId]) {
        URL.revokeObjectURL(prev[fieldId]);
        const newPreviews = { ...prev };
        delete newPreviews[fieldId];
        return newPreviews;
      }
      return prev;
    });
  }, []);
  
  const watchedImages = watch(fieldName) || [];

  const deleteMutation = useMutation({
    mutationFn: ({ imageId, storagePath }) => deleteImageService(imageId, storagePath, !!imageId),
    onSuccess: (data, variables) => {
      toast({ title: "Imagem Removida", description: "A imagem foi removida com sucesso." });
      remove(variables.index);
      updateDisplayOrderAfterRemove(variables.index, fieldName, watch, setValue);
      queryClient.invalidateQueries(['adminProductById', productId]);
    },
    onError: (error) => {
      toast({ title: "Erro ao Remover Imagem", description: error.message, variant: "destructive" });
    },
  });

  const handleFileChange = useCallback((event) => {
    const files = Array.from(event.target.files);
    const currentFields = watch(fieldName) || [];
    files.forEach(file => {
      const newImage = {
        id: null, 
        fieldId: `temp-${Date.now()}-${Math.random()}`, 
        file: file,
        alt_text: file.name.replace(/\.[^/.]+$/, ""),
        display_order: currentFields.length,
        url: null,
        storage_path: null,
      };
      append(newImage, { shouldFocus: false });
      addLocalPreview(newImage.fieldId, file);
    });
    event.target.value = null;
  }, [append, fieldName, watch, addLocalPreview]);


  const handleRemoveImage = useCallback((index) => {
    const image = fields[index];
    if (image.id && image.storage_path) {
      deleteMutation.mutate({ imageId: image.id, storagePath: image.storage_path, index });
    } else {
      if (image.fieldId) {
         revokeLocalPreview(image.fieldId);
      }
      remove(index);
      updateDisplayOrderAfterRemove(index, fieldName, watch, setValue);
    }
  }, [fields, deleteMutation, remove, fieldName, watch, setValue, revokeLocalPreview]);

  const updateDisplayOrderAfterRemove = (removedIndex, fieldName, watch, setValue) => {
    const currentImages = watch(fieldName);
    if (!currentImages) return;
    currentImages.forEach((img, idx) => {
      if (idx >= removedIndex) {
        setValue(`${fieldName}.${idx}.display_order`, idx, { shouldDirty: true });
      }
    });
  };

  const setAsMainImage = useCallback((indexToSetAsMain) => {
    const currentImages = watch(fieldName) || [];
    if (currentImages.length === 0) return;

    const newOrderedImages = currentImages.map((img, idx) => ({
      ...img,
      display_order: idx === indexToSetAsMain ? 0 : (idx < indexToSetAsMain ? idx + 1 : idx)
    })).sort((a,b) => a.display_order - b.display_order);

    newOrderedImages.forEach((img, idx) => {
      setValue(`${fieldName}.${idx}`, img, { shouldDirty: true });
    });
    
    toast({ title: "Imagem Principal Definida", description: "A ordem das imagens foi atualizada." });
  }, [fieldName, watch, setValue, toast]);
  

  const moveImage = useCallback((fromIndex, toIndex) => {
    const currentImages = watch(fieldName) || [];
    if (toIndex < 0 || toIndex >= currentImages.length) return;
    
    moveFieldArray(fromIndex, toIndex);

    const reorderedImages = [...watch(fieldName)]; 
    reorderedImages.forEach((image, idx) => {
      setValue(`${fieldName}.${idx}.display_order`, idx, { shouldDirty: true });
    });
  }, [fieldName, watch, setValue, moveFieldArray]);

  return {
    fields,
    handleFileChange,
    handleRemoveImage,
    setAsMainImage,
    moveImage,
    deleteMutation,
    watchedImages,
    localPreviewUrls,
    revokeLocalPreview
  };
};

export default useImageUploadHandler;
