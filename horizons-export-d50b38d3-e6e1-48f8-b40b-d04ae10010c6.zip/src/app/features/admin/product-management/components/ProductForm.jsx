
import React, { useEffect, useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { productFormSchema, productDefaultValues } from '@/app/types/product.types.jsx';
import { getProductById, createProduct, updateProduct } from '@/app/features/admin/product-management/services/product.service';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';

import BasicInfoSection from './product-form-parts/BasicInfoSection';
import PricingSection from './product-form-parts/PricingSection';
import ShippingSection from './product-form-parts/ShippingSection';
import SeoSection from './product-form-parts/SeoSection';
import ImageSection from './product-form-parts/ImageSection';
import VariantSection from './product-form-parts/VariantSection';

import { ChevronLeft, Save, Image as ImageIcon, DollarSign, Truck, Search, Settings, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';


const ProductForm = () => {
  const { productId } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const isEditing = Boolean(productId);

  const [activeTab, setActiveTab] = useState("basic");

  const { data: productData, isLoading: isLoadingProduct, isError: isErrorProduct, error: productError } = useQuery({
    queryKey: ['adminProduct', productId],
    queryFn: () => getProductById(productId),
    enabled: isEditing,
    staleTime: 1000 * 60 * 5, 
  });

  const methods = useForm({
    resolver: zodResolver(productFormSchema),
    defaultValues: productDefaultValues,
  });

  const { handleSubmit, reset, control, formState: { isSubmitting, errors }, watch, setValue } = methods;
  const hasVariants = watch('has_variants');

  useEffect(() => {
    if (isEditing && productData) {
      const transformedData = {
        ...productData,
        category_id: productData.category?.id || '',
        brand_id: productData.brand?.id || '',
        tags: productData.tags || [],
        images: productData.images || [],
        variant_options: productData.variant_options || [],
        variants: productData.variants || [],
        base_price: productData.base_price !== null ? Number(productData.base_price) : undefined,
        compare_at_price: productData.compare_at_price !== null ? Number(productData.compare_at_price) : undefined,
        inventory_quantity_base: productData.inventory_quantity_base !== null && productData.inventory_quantity_base !== undefined ? Number(productData.inventory_quantity_base) : 0,
        weight_grams: productData.weight_grams !== null ? Number(productData.weight_grams) : undefined,
        length_cm: productData.length_cm !== null ? Number(productData.length_cm) : undefined,
        width_cm: productData.width_cm !== null ? Number(productData.width_cm) : undefined,
        height_cm: productData.height_cm !== null ? Number(productData.height_cm) : undefined,
      };
      reset(transformedData);
    } else if (!isEditing) {
      reset(productDefaultValues);
    }
  }, [isEditing, productData, reset]);


  const mutation = useMutation({
    mutationFn: isEditing ? (data) => updateProduct(productId, data) : createProduct,
    onSuccess: (data) => {
      toast({
        title: `Produto ${isEditing ? 'Atualizado' : 'Criado'}`,
        description: `O produto "${data.data.name}" foi ${isEditing ? 'atualizado' : 'criado'} com sucesso.`,
        className: "bg-green-600 text-white dark:bg-green-700 dark:text-slate-100"
      });
      queryClient.invalidateQueries({ queryKey: ['adminProducts'] });
      queryClient.invalidateQueries({ queryKey: ['adminProduct', data.data.id] });
      navigate('/admin/products');
    },
    onError: (error) => {
      toast({
        title: `Erro ao ${isEditing ? 'Atualizar' : 'Criar'} Produto`,
        description: error.message || `Não foi possível ${isEditing ? 'atualizar' : 'criar'} o produto.`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data) => {
    const dataToSubmit = { ...data };
    if (!dataToSubmit.has_variants) {
      dataToSubmit.variant_options = [];
      dataToSubmit.variants = [];
    }
    
    const numericFields = ['compare_at_price', 'weight_grams', 'length_cm', 'width_cm', 'height_cm'];
    numericFields.forEach(field => {
      if (dataToSubmit[field] === '' || dataToSubmit[field] === undefined) {
        dataToSubmit[field] = null;
      }
    });
    
    mutation.mutate(dataToSubmit);
  };

  if (isLoadingProduct && isEditing) {
    return (
      <div className="flex justify-center items-center h-screen">
        <LoadingSpinner size="h-20 w-20" />
      </div>
    );
  }

  if (isErrorProduct && isEditing) {
    return (
      <div className="container mx-auto p-4">
        <ErrorDisplay 
          message="Erro ao carregar dados do produto." 
          details={productError?.message || "Tente novamente mais tarde."}
        />
         <Button onClick={() => navigate('/admin/products')} variant="outline" className="mt-4">
            <ChevronLeft className="mr-2 h-4 w-4" /> Voltar para Produtos
        </Button>
      </div>
    );
  }
  
  const tabItems = [
    { value: "basic", label: "Informações Básicas", icon: Info, content: <BasicInfoSection control={control} errors={errors} /> },
    { value: "pricing", label: "Preços", icon: DollarSign, content: <PricingSection control={control} errors={errors} disabled={hasVariants} /> },
    { value: "images", label: "Imagens", icon: ImageIcon, content: <ImageSection control={control} errors={errors} productId={productId} existingImages={productData?.images || []} setValue={setValue} /> },
    { value: "shipping", label: "Frete", icon: Truck, content: <ShippingSection control={control} errors={errors} disabled={hasVariants} /> },
    { value: "variants", label: "Variantes", icon: Settings, content: <VariantSection control={control} errors={errors} watch={watch} setValue={setValue} productData={productData} /> },
    { value: "seo", label: "SEO", icon: Search, content: <SeoSection control={control} errors={errors} /> },
  ];

  return (
    <FormProvider {...methods}>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="container mx-auto p-2 sm:p-4 md:p-6 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950 min-h-screen"
      >
        <form onSubmit={handleSubmit(onSubmit)} aria-labelledby="product-form-title">
          <header className="flex flex-col sm:flex-row justify-between items-center mb-6 pb-4 border-b border-slate-300 dark:border-slate-700">
            <motion.h1 
              id="product-form-title"
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.1, type: "spring", stiffness: 120 }}
              className="text-2xl sm:text-3xl font-bold text-slate-800 dark:text-slate-100 tracking-tight"
            >
              {isEditing ? `Editar Produto: ${productData?.name || ''}` : 'Adicionar Novo Produto'}
            </motion.h1>
            <motion.div 
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 120 }}
              className="flex gap-2 mt-3 sm:mt-0"
            >
              <Button type="button" variant="outline" onClick={() => navigate('/admin/products')} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                <ChevronLeft className="mr-2 h-4 w-4" /> Voltar
              </Button>
              <Button type="submit" disabled={isSubmitting || mutation.isPending} className="bg-sky-600 hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-600 text-white shadow-md">
                {isSubmitting || mutation.isPending ? <LoadingSpinner size="h-5 w-5 mr-2" /> : <Save className="mr-2 h-4 w-4" />}
                {isEditing ? 'Salvar Alterações' : 'Criar Produto'}
              </Button>
            </motion.div>
          </header>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="overflow-x-auto pb-2 mb-2">
              <TabsList aria-label="Seções do formulário de produto" className="flex w-max sm:w-full bg-slate-200 dark:bg-slate-800 p-1 rounded-lg">
                {tabItems.map(tab => (
                  <TabsTrigger 
                    key={tab.value} 
                    value={tab.value}
                    className="flex-1 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-700 data-[state=active]:shadow-md data-[state=active]:text-sky-600 dark:data-[state=active]:text-sky-400 text-slate-600 dark:text-slate-300 px-3 py-2 text-sm font-medium rounded-md transition-all"
                    aria-controls={`tab-content-${tab.value}`}
                  >
                    <tab.icon className="mr-2 h-4 w-4" aria-hidden="true" /> {tab.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>
            
            <AnimatePresence mode="wait">
              {tabItems.map(tab => (
                activeTab === tab.value && (
                  <motion.div
                    key={tab.value}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                  >
                    <TabsContent value={tab.value} id={`tab-content-${tab.value}`} role="tabpanel" aria-labelledby={`tab-trigger-${tab.value}`}>
                      <Card className="shadow-lg dark:bg-slate-800/50 dark:border-slate-700">
                        <CardHeader>
                          <CardTitle>{tab.label}</CardTitle>
                          <CardDescription>
                            {tab.value === "basic" && "Detalhes essenciais do seu produto."}
                            {tab.value === "pricing" && "Defina os preços e SKUs para o produto base."}
                            {tab.value === "images" && "Gerencie as imagens do seu produto."}
                            {tab.value === "shipping" && "Informações para cálculo de frete do produto base."}
                            {tab.value === "variants" && "Configure as variações do seu produto, como cor e tamanho."}
                            {tab.value === "seo" && "Melhore a visibilidade do seu produto nos buscadores."}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          {tab.content}
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </motion.div>
                )
              ))}
            </AnimatePresence>
          </Tabs>
        </form>
      </motion.div>
    </FormProvider>
  );
};

export default ProductForm;
