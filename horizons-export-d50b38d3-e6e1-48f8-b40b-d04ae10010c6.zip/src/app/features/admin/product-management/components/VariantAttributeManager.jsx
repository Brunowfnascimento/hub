
import React, { useState } from 'react';
import { useFieldArray, Controller } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PlusCircle, Trash2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

const VariantAttributeManager = ({ control, register, errors, fieldName, setValue, getValues }) => {
  const { fields: optionFields, append: appendOption, remove: removeOption } = useFieldArray({
    control,
    name: fieldName,
  });

  const [newOptionValueInputs, setNewOptionValueInputs] = useState({});

  const handleAddOptionValue = (optionIndex) => {
    const valueToAdd = newOptionValueInputs[optionIndex]?.trim();
    if (!valueToAdd) return;

    const currentOptionValues = getValues(`${fieldName}.${optionIndex}.values`) || [];
    if (currentOptionValues.includes(valueToAdd)) {
      
      setNewOptionValueInputs(prev => ({ ...prev, [optionIndex]: '' }));
      return;
    }
    
    setValue(`${fieldName}.${optionIndex}.values`, [...currentOptionValues, valueToAdd], { shouldValidate: true, shouldDirty: true });
    setNewOptionValueInputs(prev => ({ ...prev, [optionIndex]: '' }));
  };

  const handleRemoveOptionValue = (optionIndex, valueIndex) => {
    const currentOptionValues = getValues(`${fieldName}.${optionIndex}.values`);
    const updatedValues = currentOptionValues.filter((_, idx) => idx !== valueIndex);
    setValue(`${fieldName}.${optionIndex}.values`, updatedValues, { shouldValidate: true, shouldDirty: true });
  };
  
  const optionNameError = (optionIndex) => {
    return errors[fieldName]?.[optionIndex]?.name?.message;
  }

  const optionValuesError = (optionIndex) => {
    const errorObj = errors[fieldName]?.[optionIndex]?.values;
    if (typeof errorObj?.message === 'string') return errorObj.message; // Error on the array itself
    if (Array.isArray(errorObj)) { // Error on a specific value
      const firstValueError = errorObj.find(e => e && e.message);
      return firstValueError?.message;
    }
    return null;
  }


  return (
    <div className="space-y-6">
      <AnimatePresence>
        {optionFields.map((optionField, optionIndex) => (
          <motion.div
            key={optionField.id}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10, transition: { duration: 0.2 } }}
            layout
          >
            <Card className="bg-slate-50 dark:bg-slate-700/50 border dark:border-slate-600 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-3 pt-4 px-4">
                <CardTitle className="text-lg text-slate-700 dark:text-slate-200">Opção {optionIndex + 1}</CardTitle>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeOption(optionIndex)}
                  className="text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 h-8 w-8"
                  title="Remover Opção"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-4">
                <div>
                  <Label htmlFor={`${fieldName}.${optionIndex}.name`} className="text-sm font-medium text-slate-600 dark:text-slate-300">
                    Nome da Opção (ex: Cor, Tamanho)
                  </Label>
                  <Input
                    id={`${fieldName}.${optionIndex}.name`}
                    {...register(`${fieldName}.${optionIndex}.name`)}
                    placeholder="Ex: Cor"
                    className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"
                  />
                  {optionNameError(optionIndex) && (
                    <p className="text-xs text-red-500 mt-1">{optionNameError(optionIndex)}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor={`new-value-${optionIndex}`} className="text-sm font-medium text-slate-600 dark:text-slate-300">
                    Valores da Opção (ex: Azul, Verde, P, M)
                  </Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Input
                      id={`new-value-${optionIndex}`}
                      value={newOptionValueInputs[optionIndex] || ''}
                      onChange={(e) => setNewOptionValueInputs(prev => ({ ...prev, [optionIndex]: e.target.value }))}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddOptionValue(optionIndex);
                        }
                      }}
                      placeholder="Adicionar valor e pressionar Enter"
                      className="bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => handleAddOptionValue(optionIndex)}
                      className="shrink-0 text-sky-600 border-sky-500 hover:bg-sky-50 dark:text-sky-400 dark:border-sky-600 dark:hover:bg-sky-900/50"
                    >
                      Adicionar
                    </Button>
                  </div>
                  {optionValuesError(optionIndex) && (
                    <p className="text-xs text-red-500 mt-1">{optionValuesError(optionIndex)}</p>
                  )}

                  <Controller
                    control={control}
                    name={`${fieldName}.${optionIndex}.values`}
                    render={({ field: { value: currentValues = [] } }) => (
                      <AnimatePresence>
                        {currentValues.length > 0 && (
                          <motion.div 
                            className="mt-3 flex flex-wrap gap-2"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                          >
                            {currentValues.map((val, valueIndex) => (
                              <motion.div
                                key={`${optionField.id}-value-${valueIndex}`}
                                initial={{ opacity: 0, scale: 0.8 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.8, transition: { duration: 0.15 } }}
                                layout
                              >
                                <Badge variant="secondary" className="text-sm py-1 px-2 bg-slate-200 dark:bg-slate-600 text-slate-700 dark:text-slate-200">
                                  {val}
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveOptionValue(optionIndex, valueIndex)}
                                    className="ml-1.5 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                                    title={`Remover valor "${val}"`}
                                  >
                                    <X className="h-3 w-3" />
                                  </button>
                                </Badge>
                              </motion.div>
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </AnimatePresence>

      <Button
        type="button"
        variant="outline"
        onClick={() => appendOption({ name: '', values: [] })}
        className="w-full border-dashed hover:border-solid border-sky-500 text-sky-600 hover:bg-sky-50 dark:border-sky-600 dark:text-sky-400 dark:hover:bg-sky-900/50"
      >
        <PlusCircle className="mr-2 h-4 w-4" /> Adicionar Nova Opção de Variante
      </Button>
    </div>
  );
};

export default VariantAttributeManager;
