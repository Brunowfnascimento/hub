
import React from 'react';
import { useFieldArray, Controller } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Trash2, ImagePlus, DollarSign } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from '@/components/ui/use-toast';

const VariantImageSelector = ({ control, name, productImages, currentVariantImageId }) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <Select
          onValueChange={(value) => field.onChange(value === "none" ? null : value)}
          value={field.value || "none"}
        >
          <SelectTrigger className="w-full bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600">
            <SelectValue placeholder="Selecionar imagem" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Nenhuma imagem específica</SelectItem>
            {productImages.map((img, idx) => (
              <SelectItem key={img.id || `new-${idx}`} value={img.id || `new-${idx}`}>
                {img.alt_text || `Imagem ${idx + 1}`}{img.file ? " (Nova)" : ""}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    />
  );
};

const VariantListEditor = ({ control, register, errors, variantFields, removeVariantField, productImages, productId, watch, setValue }) => {
  const { toast } = useToast();

  const handleRemoveVariant = (index) => {
    removeVariantField(index);
    toast({ title: "Variante Removida", description: "A variante foi removida da lista." });
  };

  const renderAttributeString = (attributes) => {
    if (!attributes) return "N/A";
    return Object.entries(attributes)
      .map(([key, value]) => `${key}: ${value}`)
      .join(', ');
  };

  const InputWithAdornment = ({ id, label, adornment, error, ...props }) => (
    <div>
      <Label htmlFor={id} className="text-xs text-slate-600 dark:text-slate-400">{label}</Label>
      <div className="relative mt-1">
        <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
          <span className="text-gray-500 sm:text-sm dark:text-slate-400">{adornment}</span>
        </div>
        <Input id={id} type="number" step="0.01" {...props} className="pl-9 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 h-9 text-sm" />
      </div>
      {error && <p className="text-xs text-red-500 mt-0.5">{error.message}</p>}
    </div>
  );

  const NumberInput = ({ id, label, unit, error, ...props }) => (
    <div>
      <Label htmlFor={id} className="text-xs text-slate-600 dark:text-slate-400">{label} {unit && `(${unit})`}</Label>
      <Input id={id} type="number" {...props} className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 h-9 text-sm" />
      {error && <p className="text-xs text-red-500 mt-0.5">{error.message}</p>}
    </div>
  );


  return (
    <div className="space-y-4">
      <AnimatePresence>
        {variantFields.map((field, index) => (
          <motion.div
            key={field.id}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10, transition: { duration: 0.2 } }}
            layout
          >
            <Card className="bg-slate-50 dark:bg-slate-700/50 border dark:border-slate-600 shadow-sm overflow-hidden">
              <CardHeader className="flex flex-row items-start justify-between p-3 bg-slate-100 dark:bg-slate-700 border-b dark:border-slate-200 dark:border-slate-600">
                <div>
                  <CardTitle className="text-md text-slate-800 dark:text-slate-100">
                    {renderAttributeString(field.attributes)}
                  </CardTitle>
                  <CardDescription className="text-xs text-slate-500 dark:text-slate-400">
                    SKU: {watch(`variants.${index}.sku`) || 'Não definido'}
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                   <Controller
                      name={`variants.${index}.is_active`}
                      control={control}
                      defaultValue={true}
                      render={({ field: switchField }) => (
                        <div className="flex items-center space-x-1.5">
                           <Switch
                            id={`variant-active-${index}`}
                            checked={switchField.value}
                            onCheckedChange={switchField.onChange}
                            className="data-[state=checked]:bg-green-500 data-[state=unchecked]:bg-slate-300 dark:data-[state=unchecked]:bg-slate-600"
                            style={{ transform: 'scale(0.8)' }}
                          />
                          <Label htmlFor={`variant-active-${index}`} className="text-xs text-slate-600 dark:text-slate-300">Ativa</Label>
                        </div>
                      )}
                    />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveVariant(index)}
                    className="text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 h-7 w-7"
                    title="Remover Variante"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-3 space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor={`variants.${index}.sku`} className="text-xs text-slate-600 dark:text-slate-400">SKU da Variante *</Label>
                    <Input
                      id={`variants.${index}.sku`}
                      {...register(`variants.${index}.sku`)}
                      placeholder="SKU único"
                      className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 h-9 text-sm"
                    />
                    {errors.variants?.[index]?.sku && <p className="text-xs text-red-500 mt-0.5">{errors.variants[index].sku.message}</p>}
                  </div>
                  <NumberInput
                    id={`variants.${index}.inventory_quantity`}
                    label="Estoque"
                    {...register(`variants.${index}.inventory_quantity`)}
                    error={errors.variants?.[index]?.inventory_quantity}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <InputWithAdornment
                    id={`variants.${index}.price_override`}
                    label="Preço (R$)"
                    adornment="R$"
                    {...register(`variants.${index}.price_override`)}
                    error={errors.variants?.[index]?.price_override}
                  />
                  <InputWithAdornment
                    id={`variants.${index}.compare_at_price_override`}
                    label="Preço Comparação (R$)"
                    adornment="R$"
                    {...register(`variants.${index}.compare_at_price_override`)}
                    error={errors.variants?.[index]?.compare_at_price_override}
                  />
                </div>
                
                <details className="text-xs">
                  <summary className="cursor-pointer text-sky-600 dark:text-sky-400 hover:underline">Dimensões e Peso Específicos (Opcional)</summary>
                  <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t dark:border-slate-600">
                    <NumberInput id={`variants.${index}.weight_grams_override`} label="Peso" unit="g" {...register(`variants.${index}.weight_grams_override`)} error={errors.variants?.[index]?.weight_grams_override} />
                    <NumberInput id={`variants.${index}.length_cm_override`} label="Compr." unit="cm" {...register(`variants.${index}.length_cm_override`)} error={errors.variants?.[index]?.length_cm_override} />
                    <NumberInput id={`variants.${index}.width_cm_override`} label="Larg." unit="cm" {...register(`variants.${index}.width_cm_override`)} error={errors.variants?.[index]?.width_cm_override} />
                    <NumberInput id={`variants.${index}.height_cm_override`} label="Alt." unit="cm" {...register(`variants.${index}.height_cm_override`)} error={errors.variants?.[index]?.height_cm_override} />
                  </div>
                </details>
                
                <div>
                  <Label className="text-xs text-slate-600 dark:text-slate-400">Imagem da Variante (Opcional)</Label>
                   <VariantImageSelector
                    control={control}
                    name={`variants.${index}.image_id`} 
                    productImages={productImages}
                    currentVariantImageId={watch(`variants.${index}.image_id`)}
                  />
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Associe uma imagem principal a esta variante ou deixe em branco para usar as imagens gerais do produto.</p>
                </div>

              </CardContent>
            </Card>
          </motion.div>
        ))}
      </AnimatePresence>
      {variantFields.length === 0 && (
        <p className="text-sm text-center text-slate-500 dark:text-slate-400 py-6">
          Nenhuma variante gerada. Defina opções e clique em "Gerar Variantes".
        </p>
      )}
    </div>
  );
};

export default VariantListEditor;
