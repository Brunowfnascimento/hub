
import React, { useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { UploadCloud } from 'lucide-react';
import { AnimatePresence } from 'framer-motion';
import useImageUploadHandler from './product-image-manager/useImageUploadHandler';
import ImagePreviewItem from './product-image-manager/ImagePreviewItem';

const ProductImageManager = ({ control, setValue, watch, productId, fieldName = "images" }) => {
  const {
    fields,
    handleFileChange,
    handleRemoveImage,
    setAsMainImage,
    moveImage,
    deleteMutation,
    watchedImages,
    localPreviewUrls,
    revokeLocalPreview
  } = useImageUploadHandler(control, setValue, watch, productId, fieldName);

  useEffect(() => {
    return () => {
      Object.keys(localPreviewUrls).forEach(fieldId => {
        revokeLocalPreview(fieldId);
      });
    };
  }, [localPreviewUrls, revokeLocalPreview]);


  return (
    <Card className="border-dashed border-slate-300 dark:border-slate-700 shadow-inner">
      <CardContent className="p-6">
        <div className="mb-6">
          <Label htmlFor="image-upload-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
            Adicionar Imagens (Recomendado: WebP, máx 1024x1024)
          </Label>
          <div className="flex items-center justify-center w-full">
            <label
              htmlFor="image-upload-input"
              className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-lg cursor-pointer bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            >
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <UploadCloud className="w-10 h-10 mb-3 text-slate-400 dark:text-slate-500" />
                <p className="mb-2 text-sm text-slate-500 dark:text-slate-400">
                  <span className="font-semibold">Clique para enviar</span> ou arraste e solte
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">WEBP, PNG, JPG (Max. 2MB por imagem)</p>
              </div>
              <Input id="image-upload-input" type="file" className="hidden" multiple onChange={handleFileChange} accept="image/webp,image/png,image/jpeg" />
            </label>
          </div>
        </div>

        {fields.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            <AnimatePresence>
              {fields.map((field, index) => {
                const imageToRender = {
                    ...field,
                    url: localPreviewUrls[field.fieldId] || field.url, 
                    fieldId: field.fieldId 
                };
                const isMain = watchedImages[index]?.display_order === 0;
                return (
                  <ImagePreviewItem
                    key={field.id || field.fieldId || index} 
                    image={imageToRender}
                    index={index}
                    isMain={isMain}
                    onSetMain={setAsMainImage}
                    onMove={moveImage}
                    onRemove={handleRemoveImage}
                    control={control}
                    fieldNamePrefix={fieldName}
                    deleteIsLoading={deleteMutation.isLoading}
                  />
                );
              })}
            </AnimatePresence>
          </div>
        )}
        {fields.length === 0 && (
          <p className="text-sm text-center text-slate-500 dark:text-slate-400 py-8">
            Nenhuma imagem adicionada. Use o botão acima para fazer upload.
          </p>
        )}
      </CardContent>
    </Card>
  );
};

export default ProductImageManager;
