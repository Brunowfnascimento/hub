
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const SeoSection = ({ register, errors }) => {
  return (
    <>
      <CardHeader className="px-0 pt-0 pb-4 mb-4 border-b dark:border-slate-600">
        <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">SEO (Otimização para Buscadores)</CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-400">Configure meta tags para melhorar a visibilidade do produto.</CardDescription>
      </CardHeader>
      <div className="space-y-6">
        <div>
          <Label htmlFor="meta_title" className="text-slate-700 dark:text-slate-300">Meta Título</Label>
          <Input id="meta_title" {...register("meta_title")} className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" />
          {errors.meta_title && <p className="text-sm text-red-500 mt-1">{errors.meta_title.message}</p>}
        </div>
        <div>
          <Label htmlFor="meta_description" className="text-slate-700 dark:text-slate-300">Meta Descrição</Label>
          <Textarea id="meta_description" {...register("meta_description")} rows={3} className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" />
          {errors.meta_description && <p className="text-sm text-red-500 mt-1">{errors.meta_description.message}</p>}
        </div>
      </div>
    </>
  );
};

export default SeoSection;
