
import React, { useState } from 'react';
import { Controller, useFieldArray } from 'react-hook-form';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import VariantAttributeManager from '@/app/features/admin/product-management/components/VariantAttributeManager';
import VariantListEditor from '@/app/features/admin/product-management/components/VariantListEditor';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const VariantSection = ({ control, register, errors, watch, setValue, getValues, productId }) => {
  const { toast } = useToast();
  const hasVariants = watch('has_variants');
  const variantOptions = watch('variant_options') || [];
  const existingVariants = watch('variants') || [];

  const { fields: variantFields, replace: replaceAllVariants, remove: removeVariantField } = useFieldArray({
    control,
    name: 'variants',
  });

  const [showGenerationConfirm, setShowGenerationConfirm] = useState(false);

  const generateVariantCombinations = () => {
    const options = getValues('variant_options');
    if (!options || options.length === 0 || options.some(opt => !opt.name || !opt.values || opt.values.length === 0)) {
      toast({
        title: "Opções Inválidas",
        description: "Por favor, defina nomes e pelo menos um valor para cada opção de variante antes de gerar.",
        variant: "destructive",
      });
      return [];
    }

    const combinations = options.reduce((acc, option) => {
      if (acc.length === 0) {
        return option.values.map(value => ({ [option.name]: value }));
      }
      return acc.flatMap(combo => 
        option.values.map(value => ({ ...combo, [option.name]: value }))
      );
    }, []);
    return combinations;
  };

  const handleGenerateVariants = () => {
    const newCombinations = generateVariantCombinations();
    if (newCombinations.length === 0 && variantOptions.length > 0) {
       toast({
        title: "Nenhuma Combinação Gerada",
        description: "Verifique se todas as opções de variante têm valores definidos.",
        variant: "warning",
      });
      return;
    }
    
    const baseSku = getValues('sku_base') || 'PROD';
    const basePrice = getValues('base_price');

    const newVariants = newCombinations.map((attrs, index) => {
      const skuSuffix = Object.values(attrs).join('-').toUpperCase().replace(/\s+/g, '');
      const existingMatch = existingVariants.find(ev => 
        JSON.stringify(ev.attributes) === JSON.stringify(attrs)
      );

      return {
        id: existingMatch?.id || null,
        attributes: attrs,
        sku: existingMatch?.sku || `${baseSku}-${skuSuffix}-${index + 1}`,
        price_override: existingMatch?.price_override !== undefined ? existingMatch.price_override : basePrice,
        compare_at_price_override: existingMatch?.compare_at_price_override,
        inventory_quantity: existingMatch?.inventory_quantity || 0,
        weight_grams_override: existingMatch?.weight_grams_override,
        length_cm_override: existingMatch?.length_cm_override,
        width_cm_override: existingMatch?.width_cm_override,
        height_cm_override: existingMatch?.height_cm_override,
        is_active: existingMatch?.is_active !== undefined ? existingMatch.is_active : true,
        images: existingMatch?.images || [], 
      };
    });

    replaceAllVariants(newVariants);
    setShowGenerationConfirm(false);
    toast({
      title: "Variantes Geradas",
      description: `${newVariants.length} combinações de variantes foram geradas/atualizadas.`,
    });
  };

  const confirmAndGenerate = () => {
    if (existingVariants.length > 0) {
      setShowGenerationConfirm(true);
    } else {
      handleGenerateVariants();
    }
  };
  
  const canGenerateVariants = variantOptions.length > 0 && variantOptions.every(opt => opt.name && opt.values?.length > 0);

  return (
    <>
      <CardHeader className="px-0 pt-0 pb-4 mb-4 border-b dark:border-slate-600">
        <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">Variantes do Produto</CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-400">
          Configure se este produto possui diferentes versões (ex: por cor, tamanho).
        </CardDescription>
      </CardHeader>

      <div className="space-y-6">
        <div className="flex items-center space-x-3 p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg border dark:border-slate-600">
          <Controller
            name="has_variants"
            control={control}
            render={({ field }) => (
              <Switch
                id="has_variants"
                checked={field.value}
                onCheckedChange={(checked) => {
                  field.onChange(checked);
                  if (!checked) {
                    replaceAllVariants([]); 
                    setValue('variant_options', []);
                  }
                }}
                aria-labelledby="has-variants-label"
              />
            )}
          />
          <Label htmlFor="has_variants" id="has-variants-label" className="text-md font-medium text-slate-700 dark:text-slate-200 cursor-pointer">
            Este produto possui variantes?
          </Label>
        </div>
        {errors.has_variants && <p className="text-sm text-red-500 mt-1">{errors.has_variants.message}</p>}

        <AnimatePresence>
          {hasVariants && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="overflow-hidden space-y-6"
            >
              <Card className="bg-white dark:bg-slate-800 border dark:border-slate-700 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-xl text-slate-700 dark:text-slate-200">1. Definir Opções de Variante</CardTitle>
                  <CardDescription className="text-slate-500 dark:text-slate-400">
                    Adicione opções como Cor, Tamanho, Material, etc., e seus respectivos valores.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <VariantAttributeManager 
                    control={control} 
                    register={register} 
                    errors={errors} 
                    setValue={setValue}
                    getValues={getValues}
                    fieldName="variant_options" 
                  />
                   {errors.variant_options && typeof errors.variant_options.message === 'string' && (
                    <p className="text-sm text-red-500 mt-2">{errors.variant_options.message}</p>
                  )}
                </CardContent>
              </Card>
              
              <div className="flex justify-center">
                <Button 
                  type="button" 
                  onClick={confirmAndGenerate}
                  disabled={!canGenerateVariants}
                  className="bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:transform-none disabled:shadow-none"
                >
                  <Sparkles className="mr-2 h-5 w-5" />
                  {existingVariants.length > 0 ? "Atualizar/Gerar Variantes" : "Gerar Variantes"}
                </Button>
              </div>
              {errors.variants && typeof errors.variants.message === 'string' && (
                <p className="text-sm text-red-500 mt-2 text-center">{errors.variants.message}</p>
              )}

              {variantFields.length > 0 && (
                <Card className="mt-6 bg-white dark:bg-slate-800 border dark:border-slate-700 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-xl text-slate-700 dark:text-slate-200">2. Editar Variantes Geradas</CardTitle>
                    <CardDescription className="text-slate-500 dark:text-slate-400">
                      Ajuste os detalhes de cada combinação de variante.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <VariantListEditor
                      control={control}
                      register={register}
                      errors={errors}
                      watch={watch}
                      setValue={setValue}
                      getValues={getValues}
                      removeVariantField={removeVariantField}
                      variantFields={variantFields}
                      productImages={watch('images') || []}
                      productId={productId}
                    />
                  </CardContent>
                </Card>
              )}
            </motion.div>
          )}
        </AnimatePresence>
        
        <AnimatePresence>
        {!hasVariants && (
           <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mt-4 p-4 bg-slate-100 dark:bg-slate-700/30 border border-slate-200 dark:border-slate-600 rounded-lg"
            >
              <p className="text-sm text-slate-600 dark:text-slate-300">
                Quando um produto não possui variantes, os campos de Preço Base, SKU Base, Estoque e Dimensões definidos nas outras seções serão aplicados diretamente ao produto.
              </p>
            </motion.div>
        )}
        </AnimatePresence>
      </div>
      <AlertDialog open={showGenerationConfirm} onOpenChange={setShowGenerationConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center">
              <AlertTriangle className="text-yellow-500 mr-2 h-6 w-6" />
              Confirmar Geração de Variantes
            </AlertDialogTitle>
            <AlertDialogDescription>
              Você já possui variantes definidas. Gerar novas combinações irá substituir a lista atual, tentando preservar dados de variantes com os mesmos atributos.
              Deseja continuar?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleGenerateVariants} className="bg-yellow-500 hover:bg-yellow-600">
              Sim, Gerar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default VariantSection;
