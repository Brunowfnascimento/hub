
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const ShippingField = ({ id, label, unit, error, disabled, ...props }) => (
 <div className={cn(disabled && "opacity-50")}>
    <Label htmlFor={id} className={cn("text-slate-700 dark:text-slate-300", disabled && "cursor-not-allowed")}>{label} <span className="text-xs text-slate-500 dark:text-slate-400">({unit})</span></Label>
    <Input 
      id={id} 
      type="number" 
      {...props} 
      disabled={disabled}
      className={cn("mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600", disabled && "cursor-not-allowed bg-slate-100 dark:bg-slate-800")} 
    />
    {error && <p className="text-sm text-red-500 mt-1">{error.message}</p>}
  </div>
);


const ShippingSection = ({ register, errors, disabled }) => {
  const fieldGroupClass = "mb-6 grid grid-cols-1 md:grid-cols-2 gap-6";

  return (
    <>
      <CardHeader className="px-0 pt-0 pb-4 mb-4 border-b dark:border-slate-600">
        <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">Dimensões e Peso para Frete (Produto Base)</CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-400">
           {disabled 
            ? "As dimensões e peso para frete serão definidos por variante."
            : "Informações de peso e dimensões para cálculo de frete do produto principal."
          }
        </CardDescription>
      </CardHeader>
      <div className={fieldGroupClass}>
        <ShippingField
          id="weight_grams"
          label="Peso"
          unit="gramas"
          {...register("weight_grams")}
          error={errors.weight_grams}
          disabled={disabled}
        />
        <ShippingField
          id="length_cm"
          label="Comprimento"
          unit="cm"
          {...register("length_cm")}
          error={errors.length_cm}
          disabled={disabled}
        />
        <ShippingField
          id="width_cm"
          label="Largura"
          unit="cm"
          {...register("width_cm")}
          error={errors.width_cm}
          disabled={disabled}
        />
        <ShippingField
          id="height_cm"
          label="Altura"
          unit="cm"
          {...register("height_cm")}
          error={errors.height_cm}
          disabled={disabled}
        />
      </div>
      {disabled && (
        <div className="mt-4 p-3 bg-sky-50 dark:bg-sky-900/30 border border-sky-200 dark:border-sky-700 rounded-md text-sm text-sky-700 dark:text-sky-300">
          Os campos de dimensões e peso estão desabilitados pois o produto possui variantes. Cada variante poderá ter suas próprias dimensões e peso.
        </div>
      )}
    </>
  );
};

export default ShippingSection;
