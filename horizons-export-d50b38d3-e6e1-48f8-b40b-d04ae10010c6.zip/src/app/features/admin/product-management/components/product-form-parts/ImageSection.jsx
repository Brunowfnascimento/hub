
import React from 'react';
import { CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import ProductImageManager from '@/app/features/admin/product-management/components/ProductImageManager'; 
import { Label } from '@/components/ui/label';

const ImageSection = ({ control, setValue, watch, productId, formErrors }) => {
  return (
    <>
      <CardHeader className="px-0 pt-0 pb-4 mb-4 border-b dark:border-slate-600">
        <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">Imagens do Produto</CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-400">
          Gerencie as imagens do seu produto. A primeira imagem será a principal.
        </CardDescription>
      </CardHeader>
      <div>
        <Label className="text-slate-700 dark:text-slate-300 mb-2 block">Upload e Gerenciamento de Imagens</Label>
        <ProductImageManager
          control={control}
          setValue={setValue}
          watch={watch}
          productId={productId}
          fieldName="images"
        />
        {formErrors.images && <p className="text-sm text-red-500 mt-1">{formErrors.images.message || (Array.isArray(formErrors.images) && formErrors.images[0]?.message)}</p>}
      </div>
    </>
  );
};

export default ImageSection;
