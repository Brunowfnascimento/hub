
import React from 'react';
import { Controller } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import TagInput from '@/app/components/common/TagInput';
import { slugify } from '@/lib/utils';
import { Sparkles } from 'lucide-react';

const BasicInfoSection = ({ control, register, errors, watch, setValue, categories, isLoadingCategories, brands, isLoadingBrands }) => {
  const fieldGroupClass = "mb-6 grid grid-cols-1 md:grid-cols-2 gap-6";
  const fullWidthFieldClass = "md:col-span-2";

  const generateSlugFromName = () => {
    const nameValue = watch('name');
    if (nameValue) {
      setValue('slug', slugify(nameValue), { shouldValidate: true });
    }
  };

  return (
    <>
      <CardHeader className="px-0 pt-0 pb-4 mb-4 border-b dark:border-slate-600">
        <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">Informações Básicas</CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-400">Detalhes essenciais do seu produto.</CardDescription>
      </CardHeader>
      <div className={fieldGroupClass}>
        <div className={fullWidthFieldClass}>
          <Label htmlFor="name" className="text-slate-700 dark:text-slate-300">Nome do Produto</Label>
          <Input id="name" {...register("name")} className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" />
          {errors.name && <p className="text-sm text-red-500 mt-1">{errors.name.message}</p>}
        </div>

        <div>
          <Label htmlFor="slug" className="text-slate-700 dark:text-slate-300">Slug</Label>
          <div className="flex items-center gap-2 mt-1">
            <Input id="slug" {...register("slug")} className="bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" />
            <Button type="button" variant="outline" onClick={generateSlugFromName} className="shrink-0 text-sky-600 border-sky-500 hover:bg-sky-50 dark:text-sky-400 dark:border-sky-600 dark:hover:bg-sky-900/50">
              <Sparkles className="mr-2 h-4 w-4"/> Gerar
            </Button>
          </div>
          {errors.slug && <p className="text-sm text-red-500 mt-1">{errors.slug.message}</p>}
        </div>

        <div>
          <Label htmlFor="category_id" className="text-slate-700 dark:text-slate-300">Categoria</Label>
          <Controller
            name="category_id"
            control={control}
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value} disabled={isLoadingCategories}>
                <SelectTrigger id="category_id" className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600">
                  <SelectValue placeholder={isLoadingCategories ? "Carregando..." : "Selecione uma categoria"} />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map(cat => <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          />
          {errors.category_id && <p className="text-sm text-red-500 mt-1">{errors.category_id.message}</p>}
        </div>

        <div>
          <Label htmlFor="brand_id" className="text-slate-700 dark:text-slate-300">Marca</Label>
          <Controller
            name="brand_id"
            control={control}
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value || ""} disabled={isLoadingBrands}>
                <SelectTrigger id="brand_id" className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600">
                  <SelectValue placeholder={isLoadingBrands ? "Carregando..." : "Selecione uma marca (opcional)"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Nenhuma marca</SelectItem>
                  {brands?.map(brand => <SelectItem key={brand.id} value={brand.id}>{brand.name}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          />
          {errors.brand_id && <p className="text-sm text-red-500 mt-1">{errors.brand_id.message}</p>}
        </div>
        
        <div className={fullWidthFieldClass}>
          <Label htmlFor="description_short" className="text-slate-700 dark:text-slate-300">Descrição Curta</Label>
          <Textarea id="description_short" {...register("description_short")} rows={3} className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" />
          {errors.description_short && <p className="text-sm text-red-500 mt-1">{errors.description_short.message}</p>}
        </div>

        <div className={fullWidthFieldClass}>
          <Label htmlFor="description_long" className="text-slate-700 dark:text-slate-300">Descrição Longa</Label>
          <Textarea id="description_long" {...register("description_long")} rows={6} className="mt-1 bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600" />
          {errors.description_long && <p className="text-sm text-red-500 mt-1">{errors.description_long.message}</p>}
        </div>

        <div className={fullWidthFieldClass}>
          <Label htmlFor="tags" className="text-slate-700 dark:text-slate-300">Tags</Label>
          <Controller
            name="tags"
            control={control}
            render={({ field }) => (
              <TagInput 
                value={field.value} 
                onChange={field.onChange} 
                placeholder="Adicionar tag e pressionar Enter"
              />
            )}
          />
          {errors.tags && <p className="text-sm text-red-500 mt-1">{errors.tags.message}</p>}
        </div>

        <div className="flex items-center space-x-4 pt-2">
          <div className="flex items-center space-x-2">
            <Controller name="is_active" control={control} render={({ field }) => <Switch id="is_active" checked={field.value} onCheckedChange={field.onChange} />} />
            <Label htmlFor="is_active" className="text-slate-700 dark:text-slate-300">Ativo</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Controller name="is_featured" control={control} render={({ field }) => <Switch id="is_featured" checked={field.value} onCheckedChange={field.onChange} />} />
            <Label htmlFor="is_featured" className="text-slate-700 dark:text-slate-300">Destaque</Label>
          </div>
        </div>
      </div>
    </>
  );
};

export default BasicInfoSection;
