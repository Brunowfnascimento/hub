
import React, { useState, useEffect, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import { WorkspaceCategories } from '@/app/features/admin/product-management/services';
import { motion } from 'framer-motion';

const ProductFiltersAdmin = ({ onApplyFilters, initialFilters }) => {
  const [searchTerm, setSearchTerm] = useState(initialFilters.searchTerm || '');
  const [selectedCategory, setSelectedCategory] = useState(initialFilters.categoryId || 'all');
  const [selectedStatus, setSelectedStatus] = useState(initialFilters.status || 'all');

  const { data: categories, isLoading: isLoadingCategories } = useQuery({
    queryKey: ['workspaceCategories'],
    queryFn: WorkspaceCategories,
  });

  const debounce = (func, delay) => {
    let timeoutId;
    return (...args) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        func.apply(this, args);
      }, delay);
    };
  };

  const debouncedApplyFilters = useCallback(
    debounce((filtersToApply) => {
      onApplyFilters(filtersToApply);
    }, 500),
    [onApplyFilters]
  );

  useEffect(() => {
    const currentFilters = { searchTerm, categoryId: selectedCategory, status: selectedStatus };
    if (searchTerm !== initialFilters.searchTerm) {
      debouncedApplyFilters(currentFilters);
    }
  }, [searchTerm, initialFilters.searchTerm, selectedCategory, selectedStatus, debouncedApplyFilters]);


  const handleApply = () => {
    onApplyFilters({ searchTerm, categoryId: selectedCategory, status: selectedStatus });
  };

  const handleClear = () => {
    setSearchTerm('');
    setSelectedCategory('all');
    setSelectedStatus('all');
    onApplyFilters({ searchTerm: '', categoryId: 'all', status: 'all' });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-4 mb-6 bg-card border dark:border-slate-700 rounded-lg shadow-lg space-y-4 md:space-y-0 md:flex md:items-end md:space-x-4"
    >
      <div className="flex-grow">
        <label htmlFor="searchTerm" className="block text-sm font-medium text-muted-foreground mb-1">
          Buscar Produto/SKU
        </label>
        <Input
          id="searchTerm"
          placeholder="Nome do produto ou SKU..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-background dark:bg-slate-800"
        />
      </div>

      <div className="min-w-[180px]">
        <label htmlFor="category" className="block text-sm font-medium text-muted-foreground mb-1">
          Categoria
        </label>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger id="category" className="bg-background dark:bg-slate-800">
            <SelectValue placeholder="Todas as Categorias" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as Categorias</SelectItem>
            {isLoadingCategories ? (
              <SelectItem value="loading" disabled>Carregando...</SelectItem>
            ) : (
              categories?.map((category) => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
      </div>

      <div className="min-w-[150px]">
        <label htmlFor="status" className="block text-sm font-medium text-muted-foreground mb-1">
          Status
        </label>
        <Select value={selectedStatus} onValueChange={setSelectedStatus}>
          <SelectTrigger id="status" className="bg-background dark:bg-slate-800">
            <SelectValue placeholder="Todos os Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="active">Ativo</SelectItem>
            <SelectItem value="inactive">Inativo</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="flex space-x-2 pt-4 md:pt-0">
        <Button onClick={handleApply} className="w-full md:w-auto bg-sky-600 hover:bg-sky-700 text-white">
          Aplicar Filtros
        </Button>
        <Button onClick={handleClear} variant="outline" className="w-full md:w-auto">
          Limpar
        </Button>
      </div>
    </motion.div>
  );
};

export default ProductFiltersAdmin;
