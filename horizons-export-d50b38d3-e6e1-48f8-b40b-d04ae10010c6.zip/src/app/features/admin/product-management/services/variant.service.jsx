
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    import { upsertVariantInventory } from './inventory.service'; // Changed from updateVariantInventoryBatch for individual calls if needed
    
    export const createDefaultVariant = async (productId, variantDetails) => {
      const payload = {
        product_id: productId,
        sku: variantDetails.sku || `DEFAULT-${productId}`,
        price_override: variantDetails.price_override,
        compare_at_price_override: variantDetails.compare_at_price_override,
        attributes: variantDetails.attributes || { default: "default" },
        is_active: variantDetails.is_active !== undefined ? variantDetails.is_active : true,
        // Default weight/dimensions can be inherited or set to 0/null
        weight_grams_override: variantDetails.weight_grams_override || null,
        length_cm_override: variantDetails.length_cm_override || null,
        width_cm_override: variantDetails.width_cm_override || null,
        height_cm_override: variantDetails.height_cm_override || null,
      };
    
      const { data: defaultVariant, error } = await supabase
        .from('product_variants')
        .insert(payload)
        .select()
        .single();
    
      if (error) {
        console.error("Error creating default variant:", error);
        throw error;
      }
      return defaultVariant;
    };

    export const processProductVariantsAdmin = async (productId, variantsData, userId) => {
      if (!productId) throw new Error("Product ID is required to process variants.");
    
      const { data: existingVariantsDb, error: fetchError } = await supabase
        .from('product_variants')
        .select('id, inventory(quantity)') // fetch inventory quantity to use as old_quantity
        .eq('product_id', productId);
    
      if (fetchError) {
        console.error("Error fetching existing variants:", fetchError);
        throw fetchError;
      }
    
      const existingVariantIds = existingVariantsDb.map(v => v.id);
      const incomingVariantIds = variantsData.filter(v => v.id).map(v => v.id);
      
      const variantsToDelete = existingVariantIds.filter(id => !incomingVariantIds.includes(id));
      if (variantsToDelete.length > 0) {
        // Inventory and images for these variants will be deleted by CASCADE constraint from product_variants table
        const { error: deleteError } = await supabase.from('product_variants').delete().in('id', variantsToDelete);
        if (deleteError) {
          console.error("Error deleting old variants:", deleteError);
        }
      }
    
      if (!variantsData || variantsData.length === 0) {
        // If variantsData is empty, it means all variants should be removed (handled above)
        // or it's a simple product being switched from multi-variant (handled in product.service)
        return []; 
      }
      
      const processedVariants = [];
    
      for (const variant of variantsData) {
        const { inventory_quantity, image_id, id: variantId, images, ...variantDetails } = variant;
        let savedVariant;
        const variantPayload = { ...variantDetails, product_id: productId };
    
        if (variantId) { 
          const { data, error } = await supabase
            .from('product_variants')
            .update(variantPayload)
            .eq('id', variantId)
            .select()
            .single();
          if (error) throw error;
          savedVariant = data;
        } else { 
          const { data, error } = await supabase
            .from('product_variants')
            .insert(variantPayload)
            .select()
            .single();
          if (error) throw error;
          savedVariant = data;
        }
        processedVariants.push(savedVariant);
    
        const existingVariantRecord = existingVariantsDb.find(v => v.id === savedVariant.id);
        const oldQty = existingVariantRecord?.inventory?.[0]?.quantity ?? 0;
        const newQty = Number(inventory_quantity) || 0;

        if (newQty !== oldQty || !variantId) { // Update inventory if quantity changed or it's a new variant
            await upsertVariantInventory(
                productId,
                savedVariant.id,
                newQty,
                oldQty,
                variantId ? 'admin_adjustment' : 'initial_stock',
                userId
            );
        }
        
        // Image association logic (simplified, assuming images are handled via product_images table with variant_id)
        // If variant-specific images are uploaded, their variant_id should be set during image processing.
        // This part could be enhanced if a single main image per variant is designated via image_id.
        if (image_id) { // if an image from product's main images is assigned to this variant
          await supabase.from('product_images').update({ variant_id: savedVariant.id }).eq('id', image_id);
          // Ensure other images for this product that might have been previously linked to this variant are unlinked
          await supabase.from('product_images')
            .update({ variant_id: null })
            .eq('product_id', productId)
            .eq('variant_id', savedVariant.id)
            .not('id', 'eq', image_id);
        }
      }
          
      return processedVariants;
    };
  