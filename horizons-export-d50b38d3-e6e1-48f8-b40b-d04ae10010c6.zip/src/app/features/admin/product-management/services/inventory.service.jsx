
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    
    export const upsertVariantInventory = async (productId, variantId, newQuantity, oldQuantity, reasonType, userIdResponsible = null, reasonNotes = null) => {
      if (!variantId) {
        console.error("Cannot update inventory without a variant ID.");
        throw new Error("Variant ID is required to update inventory.");
      }

      const { data: inventoryRecord, error: upsertError } = await supabase
        .from('inventory')
        .upsert({
          variant_id: variantId,
          quantity: newQuantity,
         })
        .select()
        .single();

      if (upsertError) {
        console.error("Error upserting inventory:", upsertError);
        throw upsertError;
      }

      const quantityChange = newQuantity - oldQuantity;

      if (quantityChange !== 0) {
          const movementData = {
            variant_id: variantId,
            quantity_change: quantityChange,
            new_quantity_on_hand: newQuantity,
            reason_type: reasonType,
            reason_notes: reasonNotes,
            user_id_responsible: userIdResponsible,
          };
        
          const { error: movementError } = await supabase
            .from('inventory_movements')
            .insert([movementData]);
        
          if (movementError) {
            console.error("Error inserting inventory movement:", movementError);
            // Not throwing here, as inventory was updated, but logging is important.
          }
      }
      return inventoryRecord;
    };
    

    // This batch function might be useful for bulk updates, but individual upsertVariantInventory ensures movements.
    // For now, individual updates are preferred for clarity with movements.
    export const updateVariantInventoryBatch = async (inventoryUpdates) => {
      if (!inventoryUpdates || inventoryUpdates.length === 0) {
        return { data: [], error: null };
      }
    
      const inventoryRecordsToUpsert = inventoryUpdates.map(update => {
        if (!update.variant_id) {
            console.warn("Skipping inventory update due to missing variant_id for product_id:", update.product_id);
            return null; 
        }
        return {
            variant_id: update.variant_id, // PK
            quantity: update.quantity,
        };
      }).filter(Boolean); // Remove nulls if any variant_id was missing


      if (inventoryRecordsToUpsert.length === 0) {
        return { inventory: [], movements: [], error: { message: "No valid inventory records to upsert."} };
      }
    
      const { data: upsertedInventory, error: upsertError } = await supabase
        .from('inventory')
        .upsert(inventoryRecordsToUpsert)
        .select();
    
      if (upsertError) {
        console.error("Error upserting inventory records in batch:", upsertError);
        throw upsertError;
      }
    
      const movementsToInsert = inventoryUpdates.map((update, index) => {
        if (!update.variant_id) return null; // Skip if no variant_id

        const correspondingUpsertedRecord = upsertedInventory?.find(inv => 
          inv.variant_id === update.variant_id
        );
        const quantityChange = update.quantity - (update.old_quantity !== undefined ? update.old_quantity : (correspondingUpsertedRecord?.quantity || update.quantity) - (update.quantity_change_for_movement_if_no_old_qty || 0));
        
        if (quantityChange === 0 && update.reason_type !== 'initial_stock') return null; // No actual change, not initial stock

        return {
          variant_id: update.variant_id,
          quantity_change: quantityChange,
          new_quantity_on_hand: update.quantity,
          reason_type: update.reason_type || 'admin_adjustment',
          reason_notes: update.reason_notes || null,
          user_id_responsible: update.user_id_responsible || null,
        };
      }).filter(Boolean); 
    
      if (movementsToInsert.length > 0) {
        const { data: insertedMovements, error: movementError } = await supabase
          .from('inventory_movements')
          .insert(movementsToInsert)
          .select();
    
        if (movementError) {
          console.error("Error inserting inventory movements in batch:", movementError);
          // Decide if this should throw; inventory is updated, but movements failed.
        }
        return { inventory: upsertedInventory, movements: insertedMovements, error: null };
      }
    
      return { inventory: upsertedInventory, movements: [], error: null };
    };
    
    export const mapInventoryToBaseOrVariants = (product) => {
      // This function's logic now assumes all stock is via product_variants.
      // The concept of 'inventory_base_product' direct from product is removed.
      let totalStock = 0;
      const inventoryQuantityBase = 0; // No longer applicable directly from product.
    
      const variantsWithInventory = product.product_variants?.map(v => {
        const variantStock = v.inventory?.quantity || 0;
        totalStock += variantStock;
        return {
          ...v,
          inventory_quantity: variantStock,
          old_inventory_quantity: variantStock, // For form editing, might need separate fetch for true old qty
          image_id: v.product_images?.[0]?.id || null,
          images: product.product_images
            ?.filter(img => img.variant_id === v.id)
            .map(img => ({
              ...img,
              url: img.storage_path ? supabase.storage.from('product-images').getPublicUrl(img.storage_path).data?.publicUrl : null
            }))
            .sort((a, b) => a.display_order - b.display_order) || [],
        };
      }).sort((a, b) => new Date(a.created_at) - new Date(b.created_at)) || [];
    
      return { totalStock, inventoryQuantityBase, variantsWithInventory };
    };
  