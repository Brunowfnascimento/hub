
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    import { v4 as uuidv4 } from 'uuid'; 
    import { resizeImageFrontend } from '@/lib/imageUtils';
    
    const PRODUCT_IMAGES_BUCKET = 'product-images';
    
    export const uploadProductImage = async (file, productId, variantId = null, displayOrder = 0) => {
      if (!file) throw new Error("File is required for upload.");
      if (!productId) throw new Error("Product ID is required for upload.");
    
      let processedFile = file;
      try {
        processedFile = await resizeImageFrontend(file, 1024, 1024, 0.85, 'image/webp');
      } catch (resizeError) {
        
        
      }
    
      const fileExt = processedFile.name.split('.').pop();
      const fileName = `${uuidv4()}.${fileExt}`;
      const filePath = `${productId}/${fileName}`;
    
      const { error: uploadError } = await supabase.storage
        .from(PRODUCT_IMAGES_BUCKET)
        .upload(filePath, processedFile);
    
      if (uploadError) {
        
        throw uploadError;
      }
    
      const { data: dbRecord, error: dbError } = await supabase
        .from('product_images')
        .insert([{
          product_id: productId,
          variant_id: variantId,
          storage_path: filePath, 
          alt_text: processedFile.name.replace(/\.[^/.]+$/, ""), 
          display_order: displayOrder
        }])
        .select()
        .single();
    
      if (dbError) {
        
        await supabase.storage.from(PRODUCT_IMAGES_BUCKET).remove([filePath]);
        throw dbError;
      }
      
      return { ...dbRecord, storage_path: filePath }; 
    };
    
    export const deleteProductImage = async (imageId, storagePath, deleteFromDb = true) => {
      if (!storagePath && imageId) {
        const {data: imgData, error: fetchError} = await supabase.from('product_images').select('storage_path').eq('id', imageId).single();
        if(fetchError || !imgData) {
          
          throw new Error('Storage path not found for image deletion and could not be fetched.');
        }
        storagePath = imgData.storage_path;
      } else if (!storagePath && !imageId) {
        throw new Error('Either imageId or storagePath is required to delete an image.');
      }
    
    
      if (storagePath) {
        const { error: storageError } = await supabase.storage
          .from(PRODUCT_IMAGES_BUCKET)
          .remove([storagePath]);
    
        if (storageError && storageError.statusCode !== '404') { 
          
        }
      }
      
    
      if(deleteFromDb && imageId){
        const { error: dbError } = await supabase
          .from('product_images')
          .delete()
          .eq('id', imageId);
    
        if (dbError) {
          
          throw dbError;
        }
      }
      
      return { success: true };
    };
    
    export const processImageUpdates = async (productId, newImageFilesData = [], existingImagesData = []) => {
      const uploadedImages = [];
      const imagesToDelete = [];
      
      // Determine images to delete
      const newImageIds = newImageFilesData.filter(img => img.id && !img.file).map(img => img.id);
      existingImagesData.forEach(existingImg => {
        if (!newImageIds.includes(existingImg.id)) {
          imagesToDelete.push(existingImg);
        }
      });
    
      for (const image of imagesToDelete) {
        await deleteProductImage(image.id, image.storage_path);
      }
    
      // Process new or updated images
      let currentDisplayOrder = 0;
      for (const imageData of newImageFilesData) {
        if (imageData.file) { // New image to upload
          try {
            const uploadedImage = await uploadProductImage(imageData.file, productId, imageData.variant_id || null, currentDisplayOrder);
            uploadedImages.push({ ...uploadedImage, url: supabase.storage.from(PRODUCT_IMAGES_BUCKET).getPublicUrl(uploadedImage.storage_path).data.publicUrl });
          } catch (error) {
            console.error("Error uploading new image:", error);
            // Optionally, collect errors and return them
          }
        } else if (imageData.id) { // Existing image, potentially update display order or variant_id
          const { data: updatedImage, error: updateError } = await supabase
            .from('product_images')
            .update({ 
              display_order: currentDisplayOrder,
              variant_id: imageData.variant_id || null,
              alt_text: imageData.alt_text 
            })
            .eq('id', imageData.id)
            .select()
            .single();
            
          if (updateError) {
            console.error(`Error updating image ${imageData.id}:`, updateError);
          } else if (updatedImage) {
            uploadedImages.push({ ...updatedImage, url: supabase.storage.from(PRODUCT_IMAGES_BUCKET).getPublicUrl(updatedImage.storage_path).data.publicUrl });
          }
        }
        currentDisplayOrder++;
      }
      
      // Re-fetch all images for the product to ensure correct order and full list
      const { data: finalImages, error: fetchFinalError } = await supabase
          .from('product_images')
          .select('*')
          .eq('product_id', productId)
          .order('display_order', { ascending: true });
    
      if (fetchFinalError) {
          console.error("Error fetching final images after update:", fetchFinalError);
          return uploadedImages; // return what we have
      }
    
      return finalImages.map(img => ({
        ...img,
        url: supabase.storage.from(PRODUCT_IMAGES_BUCKET).getPublicUrl(img.storage_path).data.publicUrl
      }));
    };
  