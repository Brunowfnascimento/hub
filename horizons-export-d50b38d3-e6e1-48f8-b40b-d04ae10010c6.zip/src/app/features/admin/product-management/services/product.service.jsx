
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    import { processImageUpdates } from './image.service';
    import { processProductVariantsAdmin, createDefaultVariant } from './variant.service';
    import { upsertVariantInventory } from './inventory.service';
    import { mapProductDataAdmin as mapProductFromDb } from './productMapper.service';
    import { getProductById as fetchProductById } from './productQueries.service';
    
    const PRODUCT_PAGE_SIZE = 10;
    
    const baseProductSelectFields = `
      id, name, slug, base_price, sku_base, is_active, is_featured, created_at, 
      description_short, description_long, tags,
      weight_grams, length_cm, width_cm, height_cm, meta_title, meta_description, compare_at_price,
      categories!left(id, name),
      brands!left(id, name),
      variant_options
    `;
    
    const productRelationsSelectFieldsAdmin = `
      product_images(id, storage_path, alt_text, display_order, variant_id),
      product_variants!left( 
        *,
        inventory!left(quantity), 
        product_images!left(id, storage_path, alt_text, display_order, variant_id)
      )
    `;
        
    export const getAdminProducts = async ({ 
      page = 1, 
      limit = PRODUCT_PAGE_SIZE, 
      searchTerm = '', 
      categoryId = null, 
      brandId = null, 
      status = null, 
      sortBy = 'created_at', 
      sortOrder = 'desc' 
    }) => {
      let query = supabase
        .from('products')
        .select(`
          ${baseProductSelectFields},
          ${productRelationsSelectFieldsAdmin}
        `, { count: 'exact' });
    
      if (searchTerm) {
        query = query.or(`name.ilike.%${searchTerm}%,sku_base.ilike.%${searchTerm}%,product_variants.sku.ilike.%${searchTerm}%`);
      }
      if (categoryId && categoryId !== 'all') query = query.eq('category_id', categoryId);
      if (brandId && brandId !== 'all') query = query.eq('brand_id', brandId);
      if (status !== null && status !== undefined && status !== 'all') query = query.eq('is_active', status === 'active');
    
      const sortOptions = {};
      if (sortBy === 'category_name') {
        query = query.order('name', { foreignTable: 'categories', ascending: sortOrder === 'asc' });
      } else if (sortBy === 'brand_name') {
         query = query.order('name', { foreignTable: 'brands', ascending: sortOrder === 'asc' });
      } else {
        sortOptions.ascending = sortOrder === 'asc';
        query = query.order(sortBy, sortOptions);
      }
      
      const from = (page - 1) * limit;
      const to = page * limit - 1;
      query = query.range(from, to);
    
      const { data, error, count } = await query;
    
      if (error) {
        console.error("Error fetching admin products:", error);
        throw error;
      }
      
      return { 
        data: data.map(p => mapProductFromDb(p)), 
        count: count || 0,
        page,
        limit,
        totalPages: Math.ceil((count || 0) / limit)
      };
    };
    
    export const getProductById = async (productId) => {
      if (!productId) return null;
      const { data, error } = await supabase
        .from('products')
        .select(`
          ${baseProductSelectFields},
          ${productRelationsSelectFieldsAdmin}
        `)
        .eq('id', productId)
        .single();
    
      if (error) {
        if (error.code === 'PGRST116') return null; 
        console.error("Error fetching product by ID:", error);
        throw error;
      }
      return mapProductFromDb(data);
    };
    
    
    export const createProduct = async (productData) => {
      const { images: imageFilesData, variants: variantsData, variant_options, inventory_quantity_base, category_id, brand_id, has_variants, ...baseProductData } = productData;
      const user = (await supabase.auth.getUser()).data.user;
    
      const productInsertPayload = {
        ...baseProductData,
        category_id: category_id || null,
        brand_id: brand_id || null,
        variant_options: has_variants ? variant_options : null,
      };

      const { data: newProduct, error: productError } = await supabase
        .from('products')
        .insert(productInsertPayload)
        .select(`*, categories!left(*), brands!left(*)`) 
        .single();
    
      if (productError) throw productError;
    
      const existingImages = []; 
      await processImageUpdates(newProduct.id, imageFilesData || [], existingImages);
      
      if (has_variants && variantsData && variantsData.length > 0) {
        await processProductVariantsAdmin(newProduct.id, variantsData, user?.id);
      } else if (!has_variants) {
        const defaultVariant = await createDefaultVariant(newProduct.id, {
            sku: newProduct.sku_base,
            price_override: newProduct.base_price,
            compare_at_price_override: newProduct.compare_at_price,
            is_active: true,
            attributes: { default: "default" } 
        });
        if (defaultVariant) {
            await upsertVariantInventory(
                defaultVariant.id, 
                Number(inventory_quantity_base) || 0, 
                0, 
                'initial_stock', 
                user?.id
            );
        }
      }
      
      const finalProduct = await fetchProductById(newProduct.id);
      return { data: finalProduct };
    };
    
    
    export const updateProduct = async (productId, productData) => {
      const { images: newImageFiles, variants: variantsData, variant_options, inventory_quantity_base, category_id, brand_id, has_variants, ...baseProductData } = productData;
      const user = (await supabase.auth.getUser()).data.user;
    
      const productUpdatePayload = {
        ...baseProductData,
        category_id: category_id || null,
        brand_id: brand_id || null,
        variant_options: has_variants ? variant_options : null,
      };

      const { data: updatedProduct, error: productError } = await supabase
        .from('products')
        .update(productUpdatePayload)
        .eq('id', productId)
        .select(`*, categories!left(*), brands!left(*)`) 
        .single();
    
      if (productError) throw productError;
    
      const { data: existingImages } = await supabase.from('product_images').select('*').eq('product_id', productId);
      await processImageUpdates(productId, newImageFiles || [], existingImages || []);
      
      const { data: existingVariantsDb } = await supabase.from('product_variants').select('id, attributes, inventory(quantity)').eq('product_id', productId);
      
      if (has_variants && variantsData) {
        await processProductVariantsAdmin(productId, variantsData, user?.id);
      } else if (!has_variants) {
        await processProductVariantsAdmin(productId, [], user?.id); 
        
        let defaultVariant;
        const defaultVariantInDb = existingVariantsDb?.find(v => v.attributes?.default === "default");

        if (defaultVariantInDb) {
            const { data: updatedDefaultVariant, error: updateDefVarError } = await supabase
                .from('product_variants')
                .update({
                    sku: updatedProduct.sku_base,
                    price_override: updatedProduct.base_price,
                    compare_at_price_override: updatedProduct.compare_at_price,
                    is_active: true,
                    attributes: { default: "default" }
                })
                .eq('id', defaultVariantInDb.id)
                .select()
                .single();
            if(updateDefVarError) throw updateDefVarError;
            defaultVariant = updatedDefaultVariant;
        } else {
             defaultVariant = await createDefaultVariant(productId, {
                sku: updatedProduct.sku_base,
                price_override: updatedProduct.base_price,
                compare_at_price_override: updatedProduct.compare_at_price,
                is_active: true,
                attributes: { default: "default" }
            });
        }

        if (defaultVariant) {
            const oldQty = defaultVariantInDb?.inventory?.[0]?.quantity ?? 0;
            await upsertVariantInventory(
                defaultVariant.id,
                Number(inventory_quantity_base) || 0,
                oldQty,
                'admin_adjustment',
                user?.id
            );
        }
      }
      
      const finalProductData = await fetchProductById(productId);
      return { data: finalProductData };
    };
    
    
    export const deleteProduct = async (productId) => {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);
      
      if (error) throw error;
      return { success: true, productId };
    };
  