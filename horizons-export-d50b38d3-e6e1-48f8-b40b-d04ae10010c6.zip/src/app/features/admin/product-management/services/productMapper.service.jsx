
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    import { mapInventoryToBaseOrVariants } from './inventory.service';
    
    export const mapProductDataAdmin = (product) => {
      if (!product) return null;
    
      const mainImage = product.product_images?.find(img => img.display_order === 0 && !img.variant_id) 
                      || product.product_images?.filter(img => !img.variant_id)[0];
      const mainImageUrl = mainImage?.storage_path 
        ? supabase.storage.from('product-images').getPublicUrl(mainImage.storage_path).data?.publicUrl 
        : null;
    
      const { totalStock, variantsWithInventory } = mapInventoryToBaseOrVariants(product);
    
      let displayPrice = product.base_price;
      if (variantsWithInventory && variantsWithInventory.length > 0) {
        const firstVariant = variantsWithInventory[0];
        displayPrice = firstVariant.price_override !== null && firstVariant.price_override !== undefined 
                       ? firstVariant.price_override 
                       : product.base_price;
      }
    
      return {
        ...product,
        display_price: displayPrice,
        category_name: product.categories?.name,
        brand_name: product.brands?.name,
        main_image_url: mainImageUrl,
        images: product.product_images
          ?.filter(img => !img.variant_id) 
          .map(img => ({
            ...img,
            url: img.storage_path ? supabase.storage.from('product-images').getPublicUrl(img.storage_path).data?.publicUrl : null
          }))
          .sort((a, b) => a.display_order - b.display_order) || [],
        variants: variantsWithInventory,
        total_stock: totalStock,
        inventory_quantity_base: (product.has_variants === false && variantsWithInventory.length > 0)
                                   ? variantsWithInventory[0].inventory_quantity
                                   : 0,
        variant_options: product.variant_options || [],
        category: product.categories, 
        brand: product.brands,
      };
    };
    
    export const mapProductsDataAdmin = (products) => {
      if (!Array.isArray(products)) return [];
      return products.map(mapProductDataAdmin).filter(p => p !== null);
    };
    
    
    export const mapProductToPayload = (formData) => {
      const payload = {
        name: formData.name,
        slug: formData.slug,
        description_short: formData.description_short || null,
        description_long: formData.description_long || null,
        base_price: parseFloat(formData.base_price) || 0,
        compare_at_price: formData.compare_at_price ? parseFloat(formData.compare_at_price) : null,
        sku_base: formData.sku_base || null,
        is_active: formData.is_active,
        is_featured: formData.is_featured,
        category_id: formData.category_id || null,
        brand_id: formData.brand_id || null,
        tags: formData.tags || [],
        weight_grams: formData.weight_grams ? parseInt(formData.weight_grams, 10) : null,
        length_cm: formData.length_cm ? parseInt(formData.length_cm, 10) : null,
        width_cm: formData.width_cm ? parseInt(formData.width_cm, 10) : null,
        height_cm: formData.height_cm ? parseInt(formData.height_cm, 10) : null,
        meta_title: formData.meta_title || null,
        meta_description: formData.meta_description || null,
      };
      return payload;
    };
    
    export const mapVariantToPayload = (variantData, productId) => {
      const payload = {
        product_id: productId,
        sku: variantData.sku,
        price_override: variantData.price_override ? parseFloat(variantData.price_override) : null,
        compare_at_price_override: variantData.compare_at_price_override ? parseFloat(variantData.compare_at_price_override) : null,
        attributes: variantData.attributes || {},
        is_active: variantData.is_active,
        weight_grams_override: variantData.weight_grams_override ? parseInt(variantData.weight_grams_override, 10) : null,
        length_cm_override: variantData.length_cm_override ? parseInt(variantData.length_cm_override, 10) : null,
        width_cm_override: variantData.width_cm_override ? parseInt(variantData.width_cm_override, 10) : null,
        height_cm_override: variantData.height_cm_override ? parseInt(variantData.height_cm_override, 10) : null,
      };
      if (variantData.id && variantData.id.startsWith && !variantData.id.startsWith('temp-')) {
        payload.id = variantData.id;
      }
      return payload;
    };
    
    export const mapImageToPayload = (imageData, productId, variantId = null) => {
      const payload = {
        product_id: productId,
        variant_id: variantId,
        storage_path: imageData.storage_path,
        alt_text: imageData.alt_text || null,
        display_order: imageData.display_order,
      };
      if (imageData.id && !String(imageData.id).startsWith('temp-')) {
        payload.id = imageData.id;
      }
      return payload;
    };
    
    export const mapAttributeToPayload = (attributeData) => {
      return {
        name: attributeData.name,
        value: attributeData.value,
      };
    };
  