
    import { supabase } from '@/app/api/supabase';
    import { 
      mapProductDataAdmin, 
      mapProductsDataAdmin,
    } from './productMapper.service.jsx';
    
    const productFieldsBase = `
      id,
      name,
      slug,
      description_short,
      description_long,
      base_price,
      compare_at_price,
      sku_base,
      is_active,
      is_featured,
      tags,
      weight_grams,
      length_cm,
      width_cm,
      height_cm,
      meta_title,
      meta_description,
      created_at,
      updated_at,
      variant_options
    `;
    
    const productRelations = `
      categories:category_id (id, name, slug),
      brands:brand_id (id, name, slug),
      product_variants!left (
        id,
        sku,
        price_override,
        compare_at_price_override,
        attributes,
        is_active,
        weight_grams_override,
        length_cm_override,
        width_cm_override,
        height_cm_override,
        inventory!left (quantity),
        product_images!left (id, storage_path, alt_text, display_order)
      ),
      product_images!left (id, storage_path, alt_text, display_order)
    `;
    
    const productRelationsSelectFieldsAdmin = `
      ${productFieldsBase},
      ${productRelations}
    `;
    
    const productRelationsSelectFieldsStorefront = `
      ${productFieldsBase},
      ${productRelations}
    `;
    
    
    export const getAdminProducts = async (filters) => {
      let query = supabase
        .from('products')
        .select(productRelationsSelectFieldsAdmin, { count: 'exact' });
    
      if (filters.searchTerm) {
        query = query.or(`name.ilike.%${filters.searchTerm}%,description_short.ilike.%${filters.searchTerm}%,sku_base.ilike.%${filters.searchTerm}%`);
      }
      if (filters.categoryId && filters.categoryId !== 'all') {
        query = query.eq('category_id', filters.categoryId);
      }
      if (filters.brandId && filters.brandId !== 'all') {
        query = query.eq('brand_id', filters.brandId);
      }
      if (filters.status && filters.status !== 'all') {
        query = query.eq('is_active', filters.status === 'active');
      }
    
      query = query.order(filters.sortBy, { ascending: filters.sortOrder === 'asc' });
    
      const from = (filters.page - 1) * filters.limit;
      const to = filters.page * filters.limit - 1;
      query = query.range(from, to);
    
      const { data, error, count } = await query;
    
      if (error) {
        console.error('Error fetching admin products:', error);
        throw new Error('Error fetching products for admin. Details: ' + error.message);
      }
    
      return {
        data: mapProductsDataAdmin(data),
        count: count || 0,
        totalPages: Math.ceil((count || 0) / filters.limit),
      };
    };
    
    
    export const getProductById = async (productId) => {
      const { data, error } = await supabase
        .from('products')
        .select(productRelationsSelectFieldsAdmin)
        .eq('id', productId)
        .single();
    
      if (error) {
        if (error.code === 'PGRST116') { 
          throw new Error('Product not found.');
        }
        console.error('Error fetching product by ID for admin:', error);
        throw new Error('Error fetching product by ID for admin. Details: ' + error.message);
      }
      return mapProductDataAdmin(data);
    };
    
    
    export const getProductBySlug = async (slug) => {
      const { data, error } = await supabase
        .from('products')
        .select(productRelationsSelectFieldsStorefront)
        .eq('slug', slug)
        .eq('is_active', true)
        .single();
    
      if (error) {
        if (error.code === 'PGRST116') {
          return null; 
        }
        console.error('Error fetching product by slug for storefront:', error);
        throw new Error('Error fetching product by slug. Details: ' + error.message);
      }
      return mapProductDataAdmin(data); 
    };
    
    export const getStorefrontProducts = async (filters) => {
      let query = supabase
        .from('products')
        .select(productRelationsSelectFieldsStorefront, { count: 'exact' })
        .eq('is_active', true);
    
      if (filters.searchTerm) {
        query = query.or(`name.ilike.%${filters.searchTerm}%,description_short.ilike.%${filters.searchTerm}%,tags.cs.{${filters.searchTerm}}`);
      }
      if (filters.categorySlug) {
        const { data: categoryData, error: categoryError } = await supabase
          .from('categories')
          .select('id')
          .eq('slug', filters.categorySlug)
          .single();
    
        if (categoryError) {
          console.error('Error fetching category for filter:', categoryError);
        } else if (categoryData) {
          query = query.eq('category_id', categoryData.id);
        }
      }
      if (filters.brandSlug) {
         const { data: brandData, error: brandError } = await supabase
          .from('brands')
          .select('id')
          .eq('slug', filters.brandSlug)
          .single();
    
        if (brandError) {
          console.error('Error fetching brand for filter:', brandError);
        } else if (brandData) {
          query = query.eq('brand_id', brandData.id);
        }
      }
    
      if (filters.minPrice) {
        query = query.gte('base_price', filters.minPrice);
      }
      if (filters.maxPrice) {
        query = query.lte('base_price', filters.maxPrice);
      }
      if (filters.tags && filters.tags.length > 0) {
        query = query.overlaps('tags', filters.tags);
      }
      if (filters.isFeatured) {
        query = query.eq('is_featured', true);
      }
    
      const sortBy = filters.sortBy || 'created_at';
      const sortOrder = filters.sortOrder || 'desc';
      query = query.order(sortBy, { ascending: sortOrder === 'asc' });
    
      const page = filters.page || 1;
      const limit = filters.limit || 12;
      const from = (page - 1) * limit;
      const to = page * limit - 1;
      query = query.range(from, to);
    
      const { data, error, count } = await query;
    
      if (error) {
        console.error('Error fetching storefront products:', error);
        throw new Error('Error fetching products. Details: ' + error.message);
      }
    
      return {
        data: mapProductsDataAdmin(data), 
        count: count || 0,
        totalPages: Math.ceil((count || 0) / limit),
      };
    };
    
    export const getStorefrontProductBySlugDetailed = async (slug) => {
        const { data, error } = await supabase
        .from('products')
        .select(productRelationsSelectFieldsStorefront)
        .eq('slug', slug)
        .eq('is_active', true)
        .single();
    
      if (error) {
        if (error.code === 'PGRST116') {
          return null; 
        }
        console.error('Error fetching product by slug for storefront:', error);
        throw new Error('Error fetching product by slug. Details: ' + error.message);
      }
      return mapProductDataAdmin(data); 
    };
    
    export const getStorefrontRelatedProducts = async (productId, categoryId, limit = 4) => {
      if (!productId || !categoryId) return [];
    
      const { data, error } = await supabase
        .from('products')
        .select(productRelationsSelectFieldsStorefront)
        .eq('category_id', categoryId)
        .eq('is_active', true)
        .not('id', 'eq', productId) 
        .limit(limit);
    
      if (error) {
        console.error('Error fetching related products:', error);
        return [];
      }
      return mapProductsDataAdmin(data); 
    };
    
    export const getStorefrontFeaturedProducts = async (limit = 8) => {
      const { data, error } = await supabase
        .from('products')
        .select(productRelationsSelectFieldsStorefront)
        .eq('is_featured', true)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(limit);
    
      if (error) {
        console.error('Error fetching featured products:', error);
        return [];
      }
      return mapProductsDataAdmin(data);
    };
  