
import React from 'react';
import { supabase } from '@/app/api/supabase';

export const WorkspaceCategories = async () => {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('name', { ascending: true });
  if (error) {
    
    throw error;
  }
  return data;
};

export const createCategory = async (categoryData) => {
  const { data, error } = await supabase
    .from('categories')
    .insert([categoryData])
    .select()
    .single();
  if (error) {
    
    throw error;
  }
  return data;
};

export const updateCategory = async (categoryId, categoryData) => {
  const { data, error } = await supabase
    .from('categories')
    .update(categoryData)
    .eq('id', categoryId)
    .select()
    .single();
  if (error) {
    
    throw error;
  }
  return data;
};

export const deleteCategory = async (categoryId) => {
  const { error } = await supabase
    .from('categories')
    .delete()
    .eq('id', categoryId);
  if (error) {
    
    throw error;
  }
  return { success: true };
};
