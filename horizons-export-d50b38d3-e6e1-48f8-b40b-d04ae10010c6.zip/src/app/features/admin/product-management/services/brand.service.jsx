
import React from 'react';
import { supabase } from '@/app/api/supabase';

export const WorkspaceBrands = async () => {
  const { data, error } = await supabase
    .from('brands')
    .select('*')
    .order('name', { ascending: true });
  if (error) {
    
    throw error;
  }
  return data;
};

export const createBrand = async (brandData) => {
  const { data, error } = await supabase
    .from('brands')
    .insert([brandData])
    .select()
    .single();
  if (error) {
    
    throw error;
  }
  return data;
};

export const updateBrand = async (brandId, brandData) => {
  const { data, error } = await supabase
    .from('brands')
    .update(brandData)
    .eq('id', brandId)
    .select()
    .single();
  if (error) {
    
    throw error;
  }
  return data;
};

export const deleteBrand = async (brandId) => {
  const { error } = await supabase
    .from('brands')
    .delete()
    .eq('id', brandId);
  if (error) {
    
    throw error;
  }
  return { success: true };
};
