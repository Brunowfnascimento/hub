
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    import { processImageUpdates } from './image.service';
    import { processProductVariantsAdmin, createDefaultVariant } from './variant.service';
    import { upsertVariantInventory } from './inventory.service';
    import { getProductById } from './productQueries.service';
    
    export const createProductAction = async (productData) => {
      const { images: imageFilesData, variants: variantsData, variant_options, inventory_quantity_base, category_id, brand_id, ...baseProductData } = productData;
      const user = (await supabase.auth.getUser()).data.user;
    
      const productInsertPayload = {
        ...baseProductData,
        category_id: category_id || null,
        brand_id: brand_id || null,
        variant_options: baseProductData.has_variants ? variant_options : null,
      };
    
      const { data: newProduct, error: productError } = await supabase
        .from('products')
        .insert(productInsertPayload)
        .select(`*, categories!left(*), brands!left(*)`)
        .single();
    
      if (productError) throw productError;
    
      const existingImages = []; 
      await processImageUpdates(newProduct.id, imageFilesData || [], existingImages);
      
      if (baseProductData.has_variants && variantsData && variantsData.length > 0) {
        await processProductVariantsAdmin(newProduct.id, variantsData, user?.id);
      } else if (!baseProductData.has_variants) {
        const defaultVariant = await createDefaultVariant(newProduct.id, {
            sku: newProduct.sku_base,
            price_override: newProduct.base_price,
            compare_at_price_override: newProduct.compare_at_price,
            is_active: true,
            attributes: { default: "default" } 
        });
        if (defaultVariant) {
            await upsertVariantInventory(
                defaultVariant.id,
                Number(inventory_quantity_base) || 0,
                0, 
                'initial_stock',
                user?.id
            );
        }
      }
      
      const finalProduct = await getProductById(newProduct.id);
      return { data: finalProduct };
    };
    
    export const updateProductAction = async (productId, productData) => {
      const { images: newImageFiles, variants: variantsData, variant_options, inventory_quantity_base, category_id, brand_id, ...baseProductData } = productData;
      const user = (await supabase.auth.getUser()).data.user;
    
      const productUpdatePayload = {
        ...baseProductData,
        category_id: category_id || null,
        brand_id: brand_id || null,
        variant_options: baseProductData.has_variants ? variant_options : null,
      };
    
      const { data: updatedProduct, error: productError } = await supabase
        .from('products')
        .update(productUpdatePayload)
        .eq('id', productId)
        .select(`*, categories!left(*), brands!left(*)`)
        .single();
    
      if (productError) throw productError;
    
      const { data: existingImages } = await supabase.from('product_images').select('*').eq('product_id', productId);
      await processImageUpdates(productId, newImageFiles || [], existingImages || []);
      
      const { data: existingVariantsDb } = await supabase.from('product_variants').select('id, attributes, inventory(quantity)').eq('product_id', productId);
      
      if (baseProductData.has_variants && variantsData) {
        await processProductVariantsAdmin(productId, variantsData, user?.id);
      } else if (!baseProductData.has_variants) {
        await processProductVariantsAdmin(productId, [], user?.id); 
        
        let defaultVariant;
        const defaultVariantInDb = existingVariantsDb?.find(v => v.attributes?.default === "default");
    
        if (defaultVariantInDb) {
            const { data: updatedDefaultVariant, error: updateDefVarError } = await supabase
                .from('product_variants')
                .update({
                    sku: updatedProduct.sku_base,
                    price_override: updatedProduct.base_price,
                    compare_at_price_override: updatedProduct.compare_at_price,
                    is_active: true,
                    attributes: { default: "default" }
                })
                .eq('id', defaultVariantInDb.id)
                .select()
                .single();
            if(updateDefVarError) throw updateDefVarError;
            defaultVariant = updatedDefaultVariant;
        } else {
             defaultVariant = await createDefaultVariant(productId, {
                sku: updatedProduct.sku_base,
                price_override: updatedProduct.base_price,
                compare_at_price_override: updatedProduct.compare_at_price,
                is_active: true,
                attributes: { default: "default" }
            });
        }
    
        if (defaultVariant) {
            const oldQty = defaultVariantInDb?.inventory?.[0]?.quantity ?? 0;
            await upsertVariantInventory(
                defaultVariant.id,
                Number(inventory_quantity_base) || 0,
                oldQty,
                'admin_adjustment',
                user?.id
            );
        }
      }
      
      const finalProductData = await getProductById(productId);
      return { data: finalProductData };
    };
    
    export const deleteProductAction = async (productId) => {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);
      
      if (error) throw error;
      return { success: true, productId };
    };
  