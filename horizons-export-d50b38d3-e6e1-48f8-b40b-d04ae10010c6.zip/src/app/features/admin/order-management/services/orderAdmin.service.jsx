
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    import { fetchAdminOrdersList, fetchAdminOrderDetailsById } from './modules/orderQueries.admin.jsx';
    import { updateExistingOrderStatus, addNewTrackingToOrder, markExistingOrderAsPaid, processOrderRefund } from './modules/orderMutations.admin.jsx';
    
    export const fetchAdminOrders = async (params) => {
      return fetchAdminOrdersList(params);
    };
    
    export const fetchAdminOrderById = async (orderId) => {
      return fetchAdminOrderDetailsById(orderId);
    };
    
    export const updateOrderStatus = async (orderId, newStatus, notes = null, changedByUserId = null) => {
      return updateExistingOrderStatus(orderId, newStatus, notes, changedByUserId);
    };
    
    export const addTrackingToOrder = async (orderId, trackingCode, trackingUrl = null, changedByUserId = null) => {
      return addNewTrackingToOrder(orderId, trackingCode, trackingUrl, changedByUserId);
    };
    
    export const markOrderAsPaid = async (orderId, transactionId = null, paymentMethod = null, changedByUserId = null) => {
      return markExistingOrderAsPaid(orderId, transactionId, paymentMethod, changedByUserId);
    };
    
    export const processRefund = async (orderId, amount, reason, refundedByUserId = null) => {
      return processOrderRefund(orderId, amount, reason, refundedByUserId);
    };
  