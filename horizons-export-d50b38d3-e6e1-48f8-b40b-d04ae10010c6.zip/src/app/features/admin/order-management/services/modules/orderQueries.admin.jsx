
    import { supabase } from '@/app/api/supabase';
    
    const ORDER_PAGE_SIZE = 10;
    
    const baseOrderSelectFields = `
      id, 
      order_number, 
      user_id, 
      customer_email, 
      customer_name, 
      status, 
      total_items_price, 
      shipping_cost, 
      discount_amount, 
      coupon_code, 
      grand_total, 
      payment_method, 
      payment_gateway_transaction_id, 
      payment_status, 
      tracking_code, 
      tracking_url, 
      notes_customer, 
      notes_internal, 
      placed_at, 
      updated_at,
      shipping_address_snapshot,
      billing_address_snapshot,
      shipping_method_details
    `;
    
    const orderRelationsSelectFields = `
      order_items (
        id,
        variant_id,
        product_snapshot,
        quantity,
        unit_price_at_purchase,
        total_price_at_purchase
      ),
      order_status_history (
        id,
        status_from,
        status_to,
        changed_at,
        notes,
        changed_by_user_id
      ),
      profiles:user_id!inner ( 
        full_name, 
        role,
        phone
      )
    `;
    
    const mapOrderData = (order) => {
      if (!order) return null;
      return {
        ...order,
        customer_profile: order.profiles || null, 
      };
    };
    
    export const fetchAdminOrdersList = async ({
      page = 1,
      limit = ORDER_PAGE_SIZE,
      searchTerm = '',
      status = null,
      paymentStatus = null,
      sortBy = 'placed_at',
      sortOrder = 'desc',
      dateFrom = null,
      dateTo = null,
    }) => {
      let query = supabase
        .from('orders')
        .select(`
          ${baseOrderSelectFields},
          ${orderRelationsSelectFields}
        `, { count: 'exact' });
    
      if (searchTerm) {
        query = query.or(
          `order_number.ilike.%${searchTerm}%,customer_email.ilike.%${searchTerm}%,customer_name.ilike.%${searchTerm}%,profiles.full_name.ilike.%${searchTerm}%`
        );
      }
      if (status && status !== 'all') query = query.eq('status', status);
      if (paymentStatus && paymentStatus !== 'all') query = query.eq('payment_status', paymentStatus);
      if (dateFrom) query = query.gte('placed_at', dateFrom);
      if (dateTo) query = query.lte('placed_at', dateTo);
    
      query = query.order(sortBy, { ascending: sortOrder === 'asc' });
    
      const from = (page - 1) * limit;
      const to = page * limit - 1;
      query = query.range(from, to);
    
      const { data, error, count } = await query;
    
      if (error) {
        console.error("Error fetching admin orders:", error);
        throw error;
      }
    
      return {
        data: data.map(mapOrderData),
        count: count || 0,
        page,
        limit,
        totalPages: Math.ceil((count || 0) / limit),
      };
    };
    
    export const fetchAdminOrderDetailsById = async (orderId) => {
      if (!orderId) return null;
    
      const { data, error } = await supabase
        .from('orders')
        .select(`
          ${baseOrderSelectFields},
          ${orderRelationsSelectFields}
        `)
        .eq('id', orderId)
        .single();
    
      if (error) {
        if (error.code === 'PGRST116') return null; 
        console.error("Error fetching order details by ID:", error);
        throw error;
      }
      return mapOrderData(data);
    };
  