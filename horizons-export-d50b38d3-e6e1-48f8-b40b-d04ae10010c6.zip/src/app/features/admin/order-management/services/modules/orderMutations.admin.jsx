
    import { supabase } from '@/app/api/supabase';

    const logOrderStatusChange = async (orderId, statusFrom, statusTo, notes, changedByUserId) => {
      const { error: historyError } = await supabase
        .from('order_status_history')
        .insert({
          order_id: orderId,
          status_from: statusFrom,
          status_to: statusTo,
          notes: notes,
          changed_by_user_id: changedByUserId,
          changed_at: new Date().toISOString(),
        });
    
      if (historyError) {
        console.error('Error inserting order status history:', historyError.message);
      }
    };
    
    export const updateExistingOrderStatus = async (orderId, newStatus, notes = null, changedByUserId = null) => {
      if (!orderId || !newStatus) throw new Error('ID do pedido ou novo status não fornecidos.');
    
      const { data: currentOrder, error: fetchError } = await supabase
        .from('orders')
        .select('status')
        .eq('id', orderId)
        .single();
    
      if (fetchError || !currentOrder) {
        console.error('Error fetching current order status:', fetchError?.message);
        throw new Error('Não foi possível obter o status atual do pedido.');
      }
    
      const { error: updateError } = await supabase
        .from('orders')
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq('id', orderId);
    
      if (updateError) {
        console.error('Error updating order status:', updateError.message);
        throw new Error('Não foi possível atualizar o status do pedido.');
      }
    
      await logOrderStatusChange(orderId, currentOrder.status, newStatus, notes, changedByUserId);
    
      return { success: true, message: 'Status do pedido atualizado com sucesso.' };
    };
    
    export const addNewTrackingToOrder = async (orderId, trackingCode, trackingUrl = null, changedByUserId = null) => {
      if (!orderId || !trackingCode) throw new Error('ID do pedido ou código de rastreio não fornecidos.');
    
      const { error } = await supabase
        .from('orders')
        .update({ 
          tracking_code: trackingCode, 
          tracking_url: trackingUrl,
          updated_at: new Date().toISOString() 
        })
        .eq('id', orderId);
    
      if (error) {
        console.error('Error adding tracking to order:', error.message);
        throw new Error('Não foi possível adicionar as informações de rastreio.');
      }
      
      const { data: currentOrder, error: fetchError } = await supabase
        .from('orders').select('status').eq('id', orderId).single();
      
      await logOrderStatusChange(orderId, currentOrder?.status || 'unknown', 'shipped', `Rastreio adicionado: ${trackingCode}`, changedByUserId);
      
      if (currentOrder?.status !== 'shipped') {
         await supabase.from('orders').update({ status: 'shipped', updated_at: new Date().toISOString() }).eq('id', orderId);
      }
    
      return { success: true, message: 'Informações de rastreio adicionadas com sucesso.' };
    };
    
    export const markExistingOrderAsPaid = async (orderId, transactionId = null, paymentMethod = null, changedByUserId = null) => {
      if (!orderId) throw new Error('ID do pedido não fornecido.');
    
      const updatePayload = {
        payment_status: 'paid',
        status: 'processing', 
        updated_at: new Date().toISOString(),
      };
      if (transactionId) updatePayload.payment_gateway_transaction_id = transactionId;
      if (paymentMethod) updatePayload.payment_method = paymentMethod;
    
      const { data: currentOrder, error: fetchError } = await supabase
        .from('orders')
        .select('status, payment_status')
        .eq('id', orderId)
        .single();
    
      if (fetchError || !currentOrder) {
        console.error('Error fetching current order for marking as paid:', fetchError?.message);
        throw new Error('Não foi possível obter o pedido atual.');
      }
    
      const { error } = await supabase
        .from('orders')
        .update(updatePayload)
        .eq('id', orderId);
    
      if (error) {
        console.error('Error marking order as paid:', error.message);
        throw new Error('Não foi possível marcar o pedido como pago.');
      }
      
      await logOrderStatusChange(orderId, currentOrder.status, 'processing', `Pedido marcado como pago. Transação: ${transactionId || 'N/A'}`, changedByUserId);
    
      return { success: true, message: 'Pedido marcado como pago com sucesso.' };
    };
    
    export const processOrderRefund = async (orderId, amount, reason, refundedByUserId = null) => {
      if (!orderId || amount == null || !reason) throw new Error('Dados incompletos para processar reembolso.');
      
      const newStatus = 'refunded'; 
      const notesForHistory = `Reembolso de R$ ${parseFloat(amount).toFixed(2)} processado. Motivo: ${reason}`;
      const notesForInternal = `Reembolso processado. Valor: R$ ${parseFloat(amount).toFixed(2)}. Motivo: ${reason}.`;
    
      const { data: currentOrder, error: fetchError } = await supabase
        .from('orders')
        .select('status, notes_internal')
        .eq('id', orderId)
        .single();
    
      if (fetchError || !currentOrder) {
        console.error('Error fetching current order for refund:', fetchError?.message);
        throw new Error('Não foi possível obter o pedido atual para reembolso.');
      }
    
      const updatedInternalNotes = currentOrder.notes_internal 
        ? `${currentOrder.notes_internal}\n${notesForInternal}` 
        : notesForInternal;
    
      const { error } = await supabase
        .from('orders')
        .update({ 
          status: newStatus, 
          notes_internal: updatedInternalNotes, 
          payment_status: 'refunded', // ou 'partially_refunded' se aplicável
          updated_at: new Date().toISOString() 
        })
        .eq('id', orderId);
    
      if (error) {
        console.error('Error processing refund (updating order):', error.message);
        throw new Error('Não foi possível atualizar o status do pedido para reembolsado.');
      }
    
      await logOrderStatusChange(orderId, currentOrder.status, newStatus, notesForHistory, refundedByUserId);
    
      return { success: true, message: 'Reembolso processado com sucesso.' };
    };
  