
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const OrderStatusBadge = ({ status }) => {
  let variant = 'default';
  let className = '';
  let text = status;

  switch (status?.toLowerCase()) {
    case 'pending_payment':
      variant = 'outline';
      className = 'bg-amber-100 text-amber-700 border-amber-300 dark:bg-amber-700/30 dark:text-amber-300 dark:border-amber-600';
      text = 'Pag. Pendente';
      break;
    case 'processing':
      variant = 'outline';
      className = 'bg-sky-100 text-sky-700 border-sky-300 dark:bg-sky-700/30 dark:text-sky-300 dark:border-sky-600';
      text = 'Processando';
      break;
    case 'awaiting_shipment':
      variant = 'outline';
      className = 'bg-cyan-100 text-cyan-700 border-cyan-300 dark:bg-cyan-700/30 dark:text-cyan-300 dark:border-cyan-600';
      text = 'Aguard. Envio';
      break;
    case 'shipped':
      variant = 'outline';
      className = 'bg-blue-100 text-blue-700 border-blue-300 dark:bg-blue-700/30 dark:text-blue-300 dark:border-blue-600';
      text = 'Enviado';
      break;
    case 'delivered':
      variant = 'outline';
      className = 'bg-emerald-100 text-emerald-700 border-emerald-300 dark:bg-emerald-700/30 dark:text-emerald-300 dark:border-emerald-600';
      text = 'Entregue';
      break;
    case 'completed':
      variant = 'outline';
      className = 'bg-green-100 text-green-700 border-green-300 dark:bg-green-700/30 dark:text-green-300 dark:border-green-600';
      text = 'Concluído';
      break;
    case 'cancelled':
      variant = 'outline';
      className = 'bg-red-100 text-red-700 border-red-300 dark:bg-red-700/30 dark:text-red-300 dark:border-red-600';
      text = 'Cancelado';
      break;
    case 'refunded':
      variant = 'outline';
      className = 'bg-purple-100 text-purple-700 border-purple-300 dark:bg-purple-700/30 dark:text-purple-300 dark:border-purple-600';
      text = 'Reembolsado';
      break;
    case 'failed':
      variant = 'destructive';
      className = 'bg-rose-100 text-rose-700 border-rose-300 dark:bg-rose-700/30 dark:text-rose-300 dark:border-rose-600';
      text = 'Falhou';
      break;
    default:
      variant = 'secondary';
      className = 'bg-slate-100 text-slate-700 border-slate-300 dark:bg-slate-700/30 dark:text-slate-300 dark:border-slate-600';
      text = status || 'Desconhecido';
  }

  return (
    <Badge variant={variant} className={cn("font-semibold", className)}>
      {text}
    </Badge>
  );
};

export default OrderStatusBadge;
