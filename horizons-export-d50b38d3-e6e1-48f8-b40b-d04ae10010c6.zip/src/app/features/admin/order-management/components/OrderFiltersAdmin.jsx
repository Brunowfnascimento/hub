
import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ORDER_STATUS_OPTIONS, PAYMENT_STATUS_OPTIONS } from '@/app/types/admin.types.jsx';
import { X, Search } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

const OrderFiltersAdmin = ({ filters, onFiltersChange, onApplyFilters, onClearFilters }) => {
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    onFiltersChange({ ...filters, [name]: value });
  };

  const handleSelectChange = (name, value) => {
    onFiltersChange({ ...filters, [name]: value });
  };

  return (
    <Card className="mb-6 shadow-lg bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-800/90">
      <CardHeader>
        <CardTitle className="text-xl text-slate-800 dark:text-slate-100">Filtrar Pedidos</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="space-y-1.5">
          <Label htmlFor="customerQuery" className="text-slate-700 dark:text-slate-300">Cliente/Pedido</Label>
          <Input
            id="customerQuery"
            name="customerQuery"
            placeholder="Nome, email ou Nº do pedido"
            value={filters.customerQuery}
            onChange={handleInputChange}
            className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
          />
        </div>
        
        <div className="space-y-1.5">
          <Label htmlFor="status" className="text-slate-700 dark:text-slate-300">Status do Pedido</Label>
          <Select
            name="status"
            value={filters.status}
            onValueChange={(value) => handleSelectChange('status', value)}
          >
            <SelectTrigger id="status" className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
              <SelectValue placeholder="Todos os status" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
              <SelectItem value="">Todos os status</SelectItem>
              {ORDER_STATUS_OPTIONS.map(option => (
                <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="paymentStatus" className="text-slate-700 dark:text-slate-300">Status do Pagamento</Label>
          <Select
            name="paymentStatus"
            value={filters.paymentStatus}
            onValueChange={(value) => handleSelectChange('paymentStatus', value)}
          >
            <SelectTrigger id="paymentStatus" className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
              <SelectValue placeholder="Todos os status" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
              <SelectItem value="">Todos os status</SelectItem>
              {PAYMENT_STATUS_OPTIONS.map(option => (
                <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="dateFrom" className="text-slate-700 dark:text-slate-300">Data De</Label>
          <Input
            id="dateFrom"
            name="dateFrom"
            type="date"
            value={filters.dateFrom || ''}
            onChange={handleInputChange}
            className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="dateTo" className="text-slate-700 dark:text-slate-300">Data Até</Label>
          <Input
            id="dateTo"
            name="dateTo"
            type="date"
            value={filters.dateTo || ''}
            onChange={handleInputChange}
            className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
          />
        </div>
      </CardContent>
      <CardFooter className="flex justify-end gap-3 pt-4">
        <Button variant="outline" onClick={onClearFilters} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
          <X className="mr-2 h-4 w-4" /> Limpar
        </Button>
        <Button onClick={onApplyFilters} className="bg-sky-500 hover:bg-sky-600 text-white">
          <Search className="mr-2 h-4 w-4" /> Aplicar Filtros
        </Button>
      </CardFooter>
    </Card>
  );
};

export default OrderFiltersAdmin;
