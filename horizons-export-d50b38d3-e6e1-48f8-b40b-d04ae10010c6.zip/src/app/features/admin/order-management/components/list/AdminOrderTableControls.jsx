
    import React from 'react';
    import { Button } from '@/components/ui/button';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuTrigger,
    } from '@/components/ui/dropdown-menu';
    import { MoreHorizontal, Edit3, Receipt, DownloadCloud } from 'lucide-react';
    
    const AdminOrderTableControls = ({
      selectedOrdersCount,
      onBulkAction,
    }) => {
      return (
        <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200">Lista de Pedidos</h2>
            {selectedOrdersCount > 0 && (
              <span className="text-sm text-slate-500 dark:text-slate-400">({selectedOrdersCount} selecionado(s))</span>
            )}
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" disabled={selectedOrdersCount === 0} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                Ações em Lote <MoreHorizontal className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="dark:bg-slate-700 dark:border-slate-600">
              <DropdownMenuItem onClick={() => onBulkAction('Atualizar Status')} className="dark:hover:bg-slate-600">
                <Edit3 className="mr-2 h-4 w-4" /> Atualizar Status
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onBulkAction('Imprimir Faturas')} className="dark:hover:bg-slate-600">
                <Receipt className="mr-2 h-4 w-4" /> Imprimir Faturas
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onBulkAction('Exportar Pedidos')} className="dark:hover:bg-slate-600">
                <DownloadCloud className="mr-2 h-4 w-4" /> Exportar Pedidos
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      );
    };
    
    export default AdminOrderTableControls;
  