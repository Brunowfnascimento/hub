
    import React from 'react';
    import {
      Pagination,
      PaginationContent,
      PaginationItem,
      PaginationLink,
      PaginationNext,
      PaginationPrevious,
      PaginationEllipsis
    } from '@/components/ui/pagination';
    
    const AdminOrderPaginationControls = ({
      pagination,
      totalPages,
      totalCount,
      onPageChange,
    }) => {
    
      const renderPaginationItems = () => {
        const items = [];
        const maxPagesToShow = 3;
        const pageBuffer = 1;
    
        if (totalPages <= 1) return null;
    
        items.push(
          <PaginationItem key="prev">
            <PaginationPrevious 
              href="#" 
              onClick={(e) => { e.preventDefault(); onPageChange(pagination.page - 1); }}
              disabled={pagination.page === 1}
              className={pagination.page === 1 ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
            />
          </PaginationItem>
        );
    
        if (totalPages <= maxPagesToShow + (pageBuffer * 2)) {
          for (let i = 1; i <= totalPages; i++) {
            items.push(
              <PaginationItem key={i}>
                <PaginationLink
                  href="#"
                  isActive={pagination.page === i}
                  onClick={(e) => { e.preventDefault(); onPageChange(i); }}
                  className={pagination.page === i ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
                >
                  {i}
                </PaginationLink>
              </PaginationItem>
            );
          }
        } else {
          items.push(
            <PaginationItem key={1}>
              <PaginationLink href="#" onClick={(e) => { e.preventDefault(); onPageChange(1); }} className={pagination.page === 1 ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>1</PaginationLink>
            </PaginationItem>
          );
    
          if (pagination.page > pageBuffer + 2) {
            items.push(<PaginationItem key="start-ellipsis"><PaginationEllipsis /></PaginationItem>);
          }
    
          const startRange = Math.max(2, pagination.page - pageBuffer);
          const endRange = Math.min(totalPages - 1, pagination.page + pageBuffer);
    
          for (let i = startRange; i <= endRange; i++) {
            items.push(
              <PaginationItem key={i}>
                <PaginationLink
                  href="#"
                  isActive={pagination.page === i}
                  onClick={(e) => { e.preventDefault(); onPageChange(i); }}
                  className={pagination.page === i ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
                >
                  {i}
                </PaginationLink>
              </PaginationItem>
            );
          }
    
          if (pagination.page < totalPages - pageBuffer - 1) {
            items.push(<PaginationItem key="end-ellipsis"><PaginationEllipsis /></PaginationItem>);
          }
    
          items.push(
            <PaginationItem key={totalPages}>
              <PaginationLink href="#" onClick={(e) => { e.preventDefault(); onPageChange(totalPages);}} className={pagination.page === totalPages ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>{totalPages}</PaginationLink>
            </PaginationItem>
          );
        }
    
        items.push(
          <PaginationItem key="next">
            <PaginationNext 
              href="#" 
              onClick={(e) => { e.preventDefault(); onPageChange(pagination.page + 1); }}
              disabled={pagination.page === totalPages}
              className={pagination.page === totalPages ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
            />
          </PaginationItem>
        );
        return items;
      };
    
      if (totalPages <= 0) return null;
    
      return (
        <div className="p-4 border-t border-slate-200 dark:border-slate-700">
          <Pagination>
            <PaginationContent>
              {renderPaginationItems()}
            </PaginationContent>
          </Pagination>
          <p className="text-center text-sm text-slate-600 dark:text-slate-400 mt-2">
            Página {pagination.page} de {totalPages}. Total de {totalCount} pedidos.
          </p>
        </div>
      );
    };
    
    export default AdminOrderPaginationControls;
  