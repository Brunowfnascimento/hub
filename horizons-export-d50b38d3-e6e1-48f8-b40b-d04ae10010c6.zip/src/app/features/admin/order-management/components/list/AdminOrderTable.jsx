
    import React from 'react';
    import {
      Table,
      TableHeader,
      TableBody,
      TableRow,
      TableHead,
      TableCell,
    } from '@/components/ui/table';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Button } from '@/components/ui/button';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuTrigger,
      DropdownMenuSeparator
    } from '@/components/ui/dropdown-menu';
    import { MoreHorizontal, Eye, Edit3, Truck, DollarSign, RotateCcw, Receipt } from 'lucide-react';
    import OrderStatusBadge from '../OrderStatusBadge';
    import { motion, AnimatePresence } from 'framer-motion';
    
    const AdminOrderTable = ({
      orders,
      selectedOrders,
      onSelectOrder,
      onSelectAllOrders,
      onSort,
      onOpenDetailModal,
      toast
    }) => {
    
      const formatCurrency = (amount) => {
        return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount);
      };
    
      const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString('pt-BR', {
          day: '2-digit', month: '2-digit', year: 'numeric',
          hour: '2-digit', minute: '2-digit'
        });
      };
    
      const handleActionInDropdown = (action, orderId) => {
        if (action === 'Ver Detalhes') {
          onOpenDetailModal(orderId);
        } else {
          toast({
            title: `Ação: ${action}`,
            description: `Pedido ID: ${orderId}. Ação será tratada no modal de detalhes.`,
          });
          onOpenDetailModal(orderId); 
        }
      };
    
      const isAllSelected = orders.length > 0 && selectedOrders.length === orders.length;
    
      return (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-slate-50 dark:bg-slate-700">
              <TableRow>
                <TableHead className="w-[50px] px-4">
                  <Checkbox 
                    checked={isAllSelected}
                    onCheckedChange={onSelectAllOrders}
                    aria-label="Selecionar todos os pedidos"
                    className="border-slate-400 data-[state=checked]:bg-sky-500 data-[state=checked]:border-sky-500"
                  />
                </TableHead>
                <TableHead onClick={() => onSort('order_number')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Nº Pedido</TableHead>
                <TableHead onClick={() => onSort('placed_at')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Data</TableHead>
                <TableHead className="px-4 text-slate-600 dark:text-slate-300">Cliente</TableHead>
                <TableHead onClick={() => onSort('grand_total')} className="text-right cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Total</TableHead>
                <TableHead onClick={() => onSort('payment_status')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Pagamento</TableHead>
                <TableHead onClick={() => onSort('status')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Status Pedido</TableHead>
                <TableHead className="text-center px-4 text-slate-600 dark:text-slate-300">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <AnimatePresence>
                {orders.length > 0 ? orders.map((order) => (
                  <motion.tr 
                    key={order.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
                  >
                    <TableCell className="px-4">
                      <Checkbox 
                        checked={selectedOrders.includes(order.id)}
                        onCheckedChange={() => onSelectOrder(order.id)}
                        aria-label={`Selecionar pedido ${order.order_number}`}
                        className="border-slate-400 data-[state=checked]:bg-sky-500 data-[state=checked]:border-sky-500"
                      />
                    </TableCell>
                    <TableCell className="px-4">
                      <Button variant="link" className="p-0 h-auto text-sky-600 dark:text-sky-400 hover:underline" onClick={() => onOpenDetailModal(order.id)}>
                        {order.order_number}
                      </Button>
                    </TableCell>
                    <TableCell className="text-slate-600 dark:text-slate-300 px-4">{formatDate(order.placed_at)}</TableCell>
                    <TableCell className="text-slate-700 dark:text-slate-200 px-4">
                      {order.customer_details?.full_name || order.customer_name || 'N/A'}
                      <div className="text-xs text-slate-500 dark:text-slate-400">{order.customer_details?.email || order.customer_email}</div>
                    </TableCell>
                    <TableCell className="text-right font-medium text-slate-800 dark:text-slate-100 px-4">{formatCurrency(order.grand_total)}</TableCell>
                    <TableCell className="px-4"><OrderStatusBadge status={order.payment_status} /></TableCell>
                    <TableCell className="px-4"><OrderStatusBadge status={order.status} /></TableCell>
                    <TableCell className="text-center px-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
                            <span className="sr-only">Abrir menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="dark:bg-slate-700 dark:border-slate-600">
                          <DropdownMenuItem onClick={() => handleActionInDropdown('Ver Detalhes', order.id)} className="dark:hover:bg-slate-600">
                            <Eye className="mr-2 h-4 w-4" /> Ver Detalhes
                          </DropdownMenuItem>
                          <DropdownMenuSeparator className="dark:bg-slate-600" />
                          <DropdownMenuItem onClick={() => handleActionInDropdown('Atualizar Status', order.id)} className="dark:hover:bg-slate-600">
                            <Edit3 className="mr-2 h-4 w-4" /> Atualizar Status
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleActionInDropdown('Adicionar Rastreio', order.id)} className="dark:hover:bg-slate-600">
                            <Truck className="mr-2 h-4 w-4" /> Adicionar Rastreio
                          </DropdownMenuItem>
                           <DropdownMenuItem onClick={() => handleActionInDropdown('Marcar como Pago', order.id)} className="dark:hover:bg-slate-600">
                            <DollarSign className="mr-2 h-4 w-4" /> Marcar como Pago
                          </DropdownMenuItem>
                           <DropdownMenuItem onClick={() => handleActionInDropdown('Processar Reembolso', order.id)} className="dark:hover:bg-slate-600">
                            <RotateCcw className="mr-2 h-4 w-4" /> Processar Reembolso
                          </DropdownMenuItem>
                          <DropdownMenuSeparator className="dark:bg-slate-600" />
                           <DropdownMenuItem onClick={() => handleActionInDropdown('Ver Fatura (Em breve)', order.id)} className="dark:hover:bg-slate-600" disabled>
                            <Receipt className="mr-2 h-4 w-4" /> Ver Fatura
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </motion.tr>
                )) : (
                  <TableRow>
                    <TableCell colSpan={8} className="h-24 text-center text-slate-500 dark:text-slate-400">
                      Nenhum pedido encontrado com os filtros atuais.
                    </TableCell>
                  </TableRow>
                )}
              </AnimatePresence>
            </TableBody>
          </Table>
        </div>
      );
    };
    
    export default AdminOrderTable;
  