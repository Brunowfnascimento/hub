
    import React, { useState, useEffect } from 'react';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { fetchAdminOrderById, updateOrderStatus, addTrackingToOrder, markOrderAsPaid, processRefund } from '@/app/features/admin/order-management/services/orderAdmin.service.jsx';
    import LoadingSpinner from '@/app/components/common/LoadingSpinner';
    import ErrorDisplay from '@/app/components/common/ErrorDisplay';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Edit, Info, Package, UserCircle, Wallet, DollarSign, RotateCcw, ShieldCheck, Send } from 'lucide-react';
    import { useAuth } from '@/app/contexts/AuthContext';
    
    import OrderCustomerInfoSection from './detail-modal-parts/OrderCustomerInfoSection';
    import OrderItemsSection from './detail-modal-parts/OrderItemsSection';
    import OrderPaymentShippingSection from './detail-modal-parts/OrderPaymentShippingSection';
    import OrderActionsSection from './detail-modal-parts/OrderActionsSection';
    import OrderStatusHistorySection from './detail-modal-parts/OrderStatusHistorySection';
    import OrderStatusBadge from './OrderStatusBadge'; 
    import ModalSection from './detail-modal-parts/ModalSection';
    
    const AdminOrderDetailModal = ({ orderId, isOpen, onClose }) => {
      const { toast } = useToast();
      const queryClient = useQueryClient();
      const { currentUser } = useAuth();
    
      const [newStatus, setNewStatus] = useState('');
      const [statusNotes, setStatusNotes] = useState('');
      const [trackingCode, setTrackingCode] = useState('');
      const [trackingUrl, setTrackingUrl] = useState('');
      const [refundAmount, setRefundAmount] = useState(0);
      const [refundReason, setRefundReason] = useState('');
    
      const { data: order, isLoading, error, isSuccess } = useQuery({
        queryKey: ['adminOrderById', orderId],
        queryFn: () => fetchAdminOrderById(orderId),
        enabled: !!orderId && isOpen, 
        staleTime: 1 * 60 * 1000, // 1 minute stale time
        refetchOnWindowFocus: true,
      });
    
      useEffect(() => {
        if (isSuccess && order) {
          setNewStatus(order.status);
          setTrackingCode(order.tracking_code || '');
          setTrackingUrl(order.tracking_url || '');
          setRefundAmount(order.grand_total); 
          setRefundReason('');
          setStatusNotes('');
        }
      }, [isSuccess, order, orderId]);
    
      const mutationOptions = (actionMessage) => ({
        onSuccess: (data) => {
          toast({ title: "Sucesso!", description: data.message || `${actionMessage} com sucesso.`, variant: 'success' });
          queryClient.invalidateQueries(['adminOrderById', orderId]);
          queryClient.invalidateQueries(['adminOrders']);
        },
        onError: (err) => {
          toast({ title: "Erro!", description: err.message || `Falha ao ${actionMessage.toLowerCase()}.`, variant: 'destructive' });
        },
      });
    
      const updateStatusMutation = useMutation({
        mutationFn: ({ status, notes }) => updateOrderStatus(orderId, status, notes, currentUser?.id),
        ...mutationOptions('Atualizar status'),
      });
    
      const addTrackingMutation = useMutation({
        mutationFn: ({ code, url }) => addTrackingToOrder(orderId, code, url, currentUser?.id),
        ...mutationOptions('Adicionar rastreio'),
      });
    
      const markAsPaidMutation = useMutation({
        mutationFn: () => markOrderAsPaid(orderId, order?.payment_gateway_transaction_id, order?.payment_method, currentUser?.id),
        ...mutationOptions('Marcar como pago'),
      });
    
      const processRefundMutation = useMutation({
        mutationFn: ({ amount, reason }) => processRefund(orderId, amount, reason, currentUser?.id),
        ...mutationOptions('Processar reembolso'),
      });
    
      const handleUpdateStatus = () => {
        if (!newStatus) {
          toast({ title: "Atenção", description: "Selecione um novo status.", variant: 'warning' });
          return;
        }
        updateStatusMutation.mutate({ status: newStatus, notes: statusNotes });
      };
    
      const handleAddTracking = () => {
        if (!trackingCode) {
          toast({ title: "Atenção", description: "Insira o código de rastreio.", variant: 'warning' });
          return;
        }
        addTrackingMutation.mutate({ code: trackingCode, url: trackingUrl });
      };
    
      const handleMarkAsPaid = () => {
        markAsPaidMutation.mutate();
      };
    
      const handleProcessRefund = () => {
        if (refundAmount <= 0 || !refundReason) {
          toast({ title: "Atenção", description: "Insira um valor de reembolso válido e um motivo.", variant: 'warning' });
          return;
        }
        if (refundAmount > order?.grand_total) {
          toast({ title: "Atenção", description: "Valor do reembolso não pode ser maior que o total do pedido.", variant: 'warning' });
          return;
        }
        processRefundMutation.mutate({ amount: refundAmount, reason: refundReason });
      };
      
      const formatDate = (dateString) => dateString ? new Date(dateString).toLocaleString('pt-BR') : 'N/A';
    
      if (!isOpen) return null;
    
      return (
        <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
          <DialogContent className="max-w-4xl w-[95vw] h-[90vh] flex flex-col p-0 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800/90">
            <DialogHeader className="px-6 py-4 border-b border-slate-200 dark:border-slate-700">
              <DialogTitle className="text-2xl font-bold text-slate-800 dark:text-slate-100">
                Detalhes do Pedido: <span className="text-sky-600 dark:text-sky-400">#{order?.order_number || orderId}</span>
              </DialogTitle>
              {order && (
                <div className="flex items-center space-x-4 mt-1">
                  <OrderStatusBadge status={order.status} />
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    Realizado em: {formatDate(order.placed_at)}
                  </p>
                </div>
              )}
            </DialogHeader>
    
            <ScrollArea className="flex-grow overflow-y-auto px-6 py-4">
              {isLoading && <div className="flex justify-center items-center h-full"><LoadingSpinner size="h-16 w-16" /></div>}
              {error && <ErrorDisplay message={error.message} />}
              {isSuccess && order && (
                <div className="space-y-6">
                  <ModalSection title="Informações do Cliente" icon={UserCircle} defaultOpen={true}>
                    <OrderCustomerInfoSection order={order} />
                  </ModalSection>
    
                  <ModalSection title="Itens do Pedido" icon={Package} defaultOpen={true}>
                    <OrderItemsSection 
                      orderItems={order.order_items}
                      totalItemsPrice={order.total_items_price}
                      shippingCost={order.shipping_cost}
                      discountAmount={order.discount_amount}
                      couponCode={order.coupon_code}
                      grandTotal={order.grand_total}
                    />
                  </ModalSection>
                  
                  <ModalSection title="Pagamento e Envio" icon={Wallet}>
                     <OrderPaymentShippingSection order={order} />
                  </ModalSection>
    
                  <ModalSection title="Ações no Pedido" icon={Edit}>
                    <OrderActionsSection 
                      orderStatus={order.status}
                      paymentStatus={order.payment_status}
                      newStatus={newStatus}
                      setNewStatus={setNewStatus}
                      statusNotes={statusNotes}
                      setStatusNotes={setStatusNotes}
                      handleUpdateStatus={handleUpdateStatus}
                      isUpdatingStatus={updateStatusMutation.isPending}
                      trackingCode={trackingCode}
                      setTrackingCode={setTrackingCode}
                      trackingUrl={trackingUrl}
                      setTrackingUrl={setTrackingUrl}
                      handleAddTracking={handleAddTracking}
                      isAddingTracking={addTrackingMutation.isPending}
                      handleMarkAsPaid={handleMarkAsPaid}
                      isMarkingAsPaid={markAsPaidMutation.isPending}
                      refundAmount={refundAmount}
                      setRefundAmount={setRefundAmount}
                      refundReason={refundReason}
                      setRefundReason={setRefundReason}
                      handleProcessRefund={handleProcessRefund}
                      isProcessingRefund={processRefundMutation.isPending}
                      orderTotal={order.grand_total}
                    />
                  </ModalSection>
    
                  <ModalSection title="Histórico de Status" icon={Info}>
                    <OrderStatusHistorySection history={order.order_status_history} />
                  </ModalSection>
                </div>
              )}
            </ScrollArea>
    
            <DialogFooter className="px-6 py-3 border-t border-slate-200 dark:border-slate-700">
              <DialogClose asChild>
                <Button variant="outline" onClick={onClose} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">Fechar</Button>
              </DialogClose>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };
    
    export default AdminOrderDetailModal;
  