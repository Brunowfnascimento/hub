
    import React, { useState } from 'react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { ChevronDown } from 'lucide-react';
    import { motion } from 'framer-motion';
    import { cn } from '@/lib/utils';

    const ModalSection = ({ title, icon, children, defaultOpen = false }) => {
      const [isOpen, setIsOpen] = useState(defaultOpen);
      const IconComponent = icon;

      return (
        <Card className="bg-white dark:bg-slate-800 shadow-lg">
          <CardHeader 
            className="flex flex-row items-center justify-between py-3 px-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors rounded-t-lg"
            onClick={() => setIsOpen(!isOpen)}
          >
            <div className="flex items-center">
              {IconComponent && <IconComponent className="h-5 w-5 mr-3 text-sky-600 dark:text-sky-400" />}
              <CardTitle className="text-lg font-semibold text-slate-700 dark:text-slate-200">{title}</CardTitle>
            </div>
            <ChevronDown 
                className={cn("h-5 w-5 text-slate-500 dark:text-slate-400 transform transition-transform duration-200", isOpen && "rotate-180")}
            />
          </CardHeader>
          <motion.div
            initial={false}
            animate={isOpen ? "open" : "closed"}
            variants={{
              open: { opacity: 1, height: "auto", marginTop: "0px" },
              closed: { opacity: 0, height: 0, marginTop: "0px" },
            }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <CardContent className="p-4 border-t border-slate-200 dark:border-slate-700">
              {children}
            </CardContent>
          </motion.div>
        </Card>
      );
    };

    export default ModalSection;
  