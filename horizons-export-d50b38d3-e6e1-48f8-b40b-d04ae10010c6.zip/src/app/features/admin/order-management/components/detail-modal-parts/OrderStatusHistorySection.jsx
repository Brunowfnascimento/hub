
import React from 'react';
import { ORDER_STATUS_OPTIONS } from '@/app/types/admin.types.jsx';

const OrderStatusHistorySection = ({ history }) => {
  const formatDate = (dateString) => dateString ? new Date(dateString).toLocaleString('pt-BR') : 'N/A';

  return (
    <>
      {history?.length > 0 ? (
        <ul className="space-y-3 max-h-60 overflow-y-auto pr-2">
          {history.sort((a, b) => new Date(b.changed_at) - new Date(a.changed_at)).map(entry => (
            <li key={entry.id} className="text-sm p-3 bg-slate-100 dark:bg-slate-700/50 rounded-md shadow-sm">
              <div className="flex justify-between items-center mb-1">
                 <span className="font-semibold text-slate-700 dark:text-slate-200">
                  {ORDER_STATUS_OPTIONS.find(opt => opt.value === entry.status_to)?.label || entry.status_to}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">{formatDate(entry.changed_at)}</span>
              </div>
              {entry.status_from && <p className="text-xs text-slate-500 dark:text-slate-400">De: {ORDER_STATUS_OPTIONS.find(opt => opt.value === entry.status_from)?.label || entry.status_from}</p>}
              {entry.notes && <p className="text-xs mt-1 text-slate-600 dark:text-slate-300">Nota: {entry.notes}</p>}
              {entry.changed_by_user_id && <p className="text-xs text-slate-500 dark:text-slate-400">Por: Admin (ID: ...{entry.changed_by_user_id.slice(-4)})</p>}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-slate-500 dark:text-slate-400">Nenhum histórico de status disponível.</p>
      )}
    </>
  );
};

export default OrderStatusHistorySection;
