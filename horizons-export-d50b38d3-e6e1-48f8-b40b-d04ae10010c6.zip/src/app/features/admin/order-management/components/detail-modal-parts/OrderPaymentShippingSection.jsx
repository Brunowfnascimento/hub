
import React from 'react';
import OrderStatusBadge from '@/app/features/admin/order-management/components/OrderStatusBadge.jsx';
import { ExternalLink } from 'lucide-react';

const OrderPaymentShippingSection = ({ order }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div>
        <h4 className="font-semibold text-md mb-2 text-slate-700 dark:text-slate-300">Informações de Pagamento</h4>
        <p className="text-sm text-slate-600 dark:text-slate-400">Método: <span className="font-medium text-slate-800 dark:text-slate-200">{order.payment_method?.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'N/A'}</span></p>
        <p className="text-sm text-slate-600 dark:text-slate-400">Status: <OrderStatusBadge status={order.payment_status} /></p>
        <p className="text-sm text-slate-600 dark:text-slate-400">ID Transação: <span className="font-medium text-slate-800 dark:text-slate-200">{order.payment_gateway_transaction_id || 'N/A'}</span></p>
      </div>
      <div>
        <h4 className="font-semibold text-md mb-2 text-slate-700 dark:text-slate-300">Informações de Envio</h4>
        <p className="text-sm text-slate-600 dark:text-slate-400">Método: <span className="font-medium text-slate-800 dark:text-slate-200">{order.shipping_method_details?.name || 'N/A'}</span></p>
        <p className="text-sm text-slate-600 dark:text-slate-400">Prazo Estimado: <span className="font-medium text-slate-800 dark:text-slate-200">{order.shipping_method_details?.estimated_delivery_time_template || 'N/A'}</span></p>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Rastreio: 
          {order.tracking_code ? (
            order.tracking_url ? 
            <a href={order.tracking_url} target="_blank" rel="noopener noreferrer" className="font-medium text-sky-600 hover:underline dark:text-sky-400">
              {order.tracking_code} <ExternalLink className="inline h-3 w-3 ml-1" />
            </a> : 
            <span className="font-medium text-slate-800 dark:text-slate-200">{order.tracking_code}</span>
          ) : 'N/A'}
        </p>
      </div>
    </div>
  );
};

export default OrderPaymentShippingSection;
