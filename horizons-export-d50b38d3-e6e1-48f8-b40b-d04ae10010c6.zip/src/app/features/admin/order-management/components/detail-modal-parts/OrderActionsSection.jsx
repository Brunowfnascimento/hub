
    import React from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { ORDER_STATUS_OPTIONS } from '@/app/types/admin.types.jsx';
    import LoadingSpinner from '@/app/components/common/LoadingSpinner';
    import { ShieldCheck, Send, DollarSign, RotateCcw } from 'lucide-react';
    import { Label } from '@/components/ui/label';
    
    const OrderActionsSection = ({ 
      orderStatus, 
      paymentStatus,
      newStatus, 
      setNewStatus, 
      statusNotes, 
      setStatusNotes, 
      handleUpdateStatus, 
      isUpdatingStatus,
      trackingCode, 
      setTrackingCode, 
      trackingUrl, 
      setTrackingUrl, 
      handleAddTracking, 
      isAddingTracking,
      handleMarkAsPaid,
      isMarkingAsPaid,
      refundAmount,
      setRefundAmount,
      refundReason,
      setRefundReason,
      handleProcessRefund,
      isProcessingRefund,
      orderTotal
    }) => {
      const formatCurrencyInput = (value) => {
        const onlyDigits = String(value).replace(/\D/g, '');
        if (!onlyDigits) return '';
        const number = parseFloat(onlyDigits) / 100;
        return number.toFixed(2);
      };
    
      const handleRefundAmountChange = (e) => {
        const formattedValue = formatCurrencyInput(e.target.value);
        setRefundAmount(parseFloat(formattedValue) || 0);
      };

      const displayRefundAmount = () => {
        return typeof refundAmount === 'number' ? refundAmount.toFixed(2).replace('.', ',') : '0,00';
      };

      const canMarkAsPaid = paymentStatus !== 'paid';
      const canRefund = paymentStatus === 'paid' || paymentStatus === 'partially_refunded';
    
      return (
        <div className="space-y-6">
          {/* Atualizar Status */}
          <div>
            <h4 className="font-semibold text-md mb-2 text-slate-700 dark:text-slate-300">Atualizar Status do Pedido</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="newOrderStatus" className="text-xs text-slate-600 dark:text-slate-400">Novo Status</Label>
                <Select value={newStatus} onValueChange={setNewStatus}>
                  <SelectTrigger id="newOrderStatus" className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
                    <SelectValue placeholder="Selecione um status" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
                    {ORDER_STATUS_OPTIONS.map(opt => (
                      <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                 <Label htmlFor="statusNotes" className="text-xs text-slate-600 dark:text-slate-400">Notas (Opcional)</Label>
                <Textarea 
                  id="statusNotes"
                  placeholder="Notas sobre a atualização..." 
                  value={statusNotes} 
                  onChange={(e) => setStatusNotes(e.target.value)}
                  className="min-h-[40px] dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
                  rows={2}
                />
              </div>
            </div>
            <Button onClick={handleUpdateStatus} disabled={isUpdatingStatus || newStatus === orderStatus} className="mt-2 w-full sm:w-auto bg-sky-500 hover:bg-sky-600 text-white">
              {isUpdatingStatus ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : <ShieldCheck className="h-4 w-4 mr-2" />}
              Atualizar Status
            </Button>
          </div>
    
          {/* Adicionar Rastreio */}
          <div>
            <h4 className="font-semibold text-md mb-2 text-slate-700 dark:text-slate-300">Informações de Rastreio</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="trackingCode" className="text-xs text-slate-600 dark:text-slate-400">Código de Rastreio</Label>
                <Input 
                  id="trackingCode"
                  placeholder="Ex: AB123456789BR" 
                  value={trackingCode} 
                  onChange={(e) => setTrackingCode(e.target.value)}
                  className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
                />
              </div>
              <div>
                <Label htmlFor="trackingUrl" className="text-xs text-slate-600 dark:text-slate-400">URL de Rastreio (Opcional)</Label>
                <Input 
                  id="trackingUrl"
                  placeholder="Ex: https://rastreio.correios.com.br/..." 
                  value={trackingUrl} 
                  onChange={(e) => setTrackingUrl(e.target.value)}
                  className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
                />
              </div>
            </div>
            <Button onClick={handleAddTracking} disabled={isAddingTracking || !trackingCode} className="mt-2 w-full sm:w-auto bg-blue-500 hover:bg-blue-600 text-white">
              {isAddingTracking ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : <Send className="h-4 w-4 mr-2" />}
              Salvar Rastreio
            </Button>
          </div>
    
          {/* Marcar como Pago */}
          {canMarkAsPaid && (
            <div>
              <h4 className="font-semibold text-md mb-2 text-slate-700 dark:text-slate-300">Confirmar Pagamento</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">Marcar este pedido como pago e iniciar processamento.</p>
              <Button onClick={handleMarkAsPaid} disabled={isMarkingAsPaid} className="w-full sm:w-auto bg-green-500 hover:bg-green-600 text-white">
                {isMarkingAsPaid ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : <DollarSign className="h-4 w-4 mr-2" />}
                Marcar como Pago
              </Button>
            </div>
          )}
    
          {/* Processar Reembolso */}
          {canRefund && (
            <div>
              <h4 className="font-semibold text-md mb-2 text-slate-700 dark:text-slate-300">Processar Reembolso</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="refundAmount" className="text-xs text-slate-600 dark:text-slate-400">Valor a Reembolsar (R$)</Label>
                    <Input 
                        id="refundAmount"
                        type="text"
                        placeholder="0,00" 
                        value={displayRefundAmount()} 
                        onChange={handleRefundAmountChange}
                        className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
                        max={orderTotal}
                    />
                </div>
                <div>
                    <Label htmlFor="refundReason" className="text-xs text-slate-600 dark:text-slate-400">Motivo do Reembolso</Label>
                    <Input 
                        id="refundReason"
                        placeholder="Ex: Produto devolvido" 
                        value={refundReason} 
                        onChange={(e) => setRefundReason(e.target.value)}
                        className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
                    />
                </div>
              </div>
              <Button onClick={handleProcessRefund} disabled={isProcessingRefund || refundAmount <= 0 || !refundReason} className="mt-2 w-full sm:w-auto bg-purple-500 hover:bg-purple-600 text-white">
                {isProcessingRefund ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : <RotateCcw className="h-4 w-4 mr-2" />}
                Processar Reembolso
              </Button>
            </div>
          )}
        </div>
      );
    };
    
    export default OrderActionsSection;
  