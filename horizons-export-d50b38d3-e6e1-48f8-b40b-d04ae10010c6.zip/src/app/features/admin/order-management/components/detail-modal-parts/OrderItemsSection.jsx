
import React from 'react';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';

const OrderItemsSection = ({ orderItems, totalItemsPrice, shippingCost, discountAmount, couponCode, grandTotal }) => {
  const formatCurrency = (amount) => amount != null ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount) : 'N/A';

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent dark:hover:bg-transparent">
            <TableHead className="text-slate-600 dark:text-slate-300">Produto</TableHead>
            <TableHead className="text-slate-600 dark:text-slate-300">SKU</TableHead>
            <TableHead className="text-center text-slate-600 dark:text-slate-300">Qtd.</TableHead>
            <TableHead className="text-right text-slate-600 dark:text-slate-300">Preço Unit.</TableHead>
            <TableHead className="text-right text-slate-600 dark:text-slate-300">Total Item</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orderItems?.map(item => (
            <TableRow key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
              <TableCell className="font-medium text-slate-800 dark:text-slate-100">
                {item.product_snapshot?.name || 'Produto Desconhecido'}
                {item.product_snapshot?.variant_attributes && 
                  <span className="block text-xs text-slate-500 dark:text-slate-400">
                    {Object.entries(item.product_snapshot.variant_attributes).map(([key, value]) => `${key}: ${value}`).join(', ')}
                  </span>}
              </TableCell>
              <TableCell className="text-slate-600 dark:text-slate-300">{item.product_snapshot?.sku || 'N/A'}</TableCell>
              <TableCell className="text-center text-slate-600 dark:text-slate-300">{item.quantity}</TableCell>
              <TableCell className="text-right text-slate-600 dark:text-slate-300">{formatCurrency(item.unit_price_at_purchase)}</TableCell>
              <TableCell className="text-right text-slate-600 dark:text-slate-300">{formatCurrency(item.total_price_at_purchase)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <div className="mt-4 space-y-1 text-right pr-2">
        <p className="text-sm text-slate-600 dark:text-slate-300">Subtotal: <span className="font-semibold text-slate-800 dark:text-slate-100">{formatCurrency(totalItemsPrice)}</span></p>
        <p className="text-sm text-slate-600 dark:text-slate-300">Frete: <span className="font-semibold text-slate-800 dark:text-slate-100">{formatCurrency(shippingCost)}</span></p>
        {discountAmount > 0 && (
          <p className="text-sm text-green-600 dark:text-green-400">Desconto ({couponCode || 'Aplicado'}): <span className="font-semibold">{formatCurrency(-discountAmount)}</span></p>
        )}
        <p className="text-lg font-bold text-slate-800 dark:text-slate-100">Total Geral: <span className="text-sky-600 dark:text-sky-400">{formatCurrency(grandTotal)}</span></p>
      </div>
    </>
  );
};

export default OrderItemsSection;
