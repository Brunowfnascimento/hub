
import React from 'react';
import { Separator } from '@/components/ui/separator';

const OrderCustomerInfoSection = ({ order }) => {
  const renderAddress = (addressSnapshot, title) => {
    if (!addressSnapshot) return <p className="text-sm text-slate-500 dark:text-slate-400">Endereço não fornecido.</p>;
    const addr = typeof addressSnapshot === 'string' ? JSON.parse(addressSnapshot) : addressSnapshot;
    return (
      <div>
        <h4 className="font-semibold text-md mb-1 text-slate-700 dark:text-slate-300">{title}</h4>
        <p className="text-sm text-slate-600 dark:text-slate-400">{addr.full_name}</p>
        <p className="text-sm text-slate-600 dark:text-slate-400">{addr.address_line1}{addr.address_number ? `, ${addr.address_number}` : ''}{addr.address_complement ? ` - ${addr.address_complement}` : ''}</p>
        <p className="text-sm text-slate-600 dark:text-slate-400">{addr.address_district}, {addr.city} - {addr.state_province}</p>
        <p className="text-sm text-slate-600 dark:text-slate-400">CEP: {addr.postal_code}</p>
        {addr.phone_number && <p className="text-sm text-slate-600 dark:text-slate-400">Telefone: {addr.phone_number}</p>}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <p className="text-sm text-slate-500 dark:text-slate-400">Nome: <span className="font-medium text-slate-700 dark:text-slate-300">{order.customer_details?.full_name || order.customer_name || 'N/A'}</span></p>
        <p className="text-sm text-slate-500 dark:text-slate-400">Email: <span className="font-medium text-slate-700 dark:text-slate-300">{order.customer_details?.email || order.customer_email || 'N/A'}</span></p>
        <p className="text-sm text-slate-500 dark:text-slate-400">Telefone: <span className="font-medium text-slate-700 dark:text-slate-300">{order.customer_details?.phone || 'N/A'}</span></p>
      </div>
      <div>
        {renderAddress(order.shipping_address_snapshot, 'Endereço de Entrega')}
        <Separator className="my-3 dark:bg-slate-600" />
        {renderAddress(order.billing_address_snapshot || order.shipping_address_snapshot, 'Endereço de Cobrança')}
      </div>
    </div>
  );
};

export default OrderCustomerInfoSection;
