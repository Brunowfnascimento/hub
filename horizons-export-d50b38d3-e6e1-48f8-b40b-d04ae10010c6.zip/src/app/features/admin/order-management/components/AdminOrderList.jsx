
    import React from 'react';
    import AdminOrderTable from './list/AdminOrderTable';
    import AdminOrderTableControls from './list/AdminOrderTableControls';
    import AdminOrderPaginationControls from './list/AdminOrderPaginationControls';
    import { motion } from 'framer-motion';
    
    const AdminOrderList = ({
      orders,
      selectedOrders,
      onSelectOrder,
      onSelectAllOrders,
      onSort,
      onOpenDetailModal,
      pagination,
      totalPages,
      totalCount,
      onPageChange,
      onBulkAction,
      toast
    }) => {
      return (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white dark:bg-slate-800 shadow-xl rounded-lg overflow-hidden"
        >
          <AdminOrderTableControls
            selectedOrdersCount={selectedOrders.length}
            onBulkAction={onBulkAction}
          />
          <AdminOrderTable
            orders={orders}
            selectedOrders={selectedOrders}
            onSelectOrder={onSelectOrder}
            onSelectAllOrders={onSelectAllOrders}
            onSort={onSort}
            onOpenDetailModal={onOpenDetailModal}
            toast={toast}
          />
          <AdminOrderPaginationControls
            pagination={pagination}
            totalPages={totalPages}
            totalCount={totalCount}
            onPageChange={onPageChange}
          />
        </motion.div>
      );
    };
    
    export default AdminOrderList;
  