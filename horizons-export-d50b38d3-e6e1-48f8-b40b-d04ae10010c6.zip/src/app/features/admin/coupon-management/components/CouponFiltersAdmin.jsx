
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Search } from 'lucide-react';

const CouponFiltersAdmin = ({ onFiltersChange, initialFilters }) => {
  const [code, setCode] = useState(initialFilters.code || '');
  const [isActive, setIsActive] = useState(initialFilters.isActive === null || initialFilters.isActive === undefined ? '' : String(initialFilters.isActive));


  const handleApplyFilters = () => {
    onFiltersChange({ 
      code, 
      isActive: isActive === '' ? null : isActive === 'true' 
    });
  };

  const handleClearFilters = () => {
    setCode('');
    setIsActive('');
    onFiltersChange({ code: '', isActive: null });
  };

  const statusOptions = [
    { value: 'true', label: 'Ativo' },
    { value: 'false', label: 'Inativo' },
  ];

  return (
    <div className="p-4 mb-6 bg-slate-50 dark:bg-slate-800 rounded-lg shadow">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 items-end">
        <div>
          <label htmlFor="code" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            Buscar por Código
          </label>
          <Input
            id="code"
            type="text"
            placeholder="Digite o código do cupom..."
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
          />
        </div>
        <div>
          <label htmlFor="isActive" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            Filtrar por Status
          </label>
          <Select value={isActive} onValueChange={setIsActive}>
            <SelectTrigger id="isActive" className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
              <SelectValue placeholder="Todos os Status" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
              <SelectItem value="">Todos os Status</SelectItem>
              {statusOptions.map(opt => (
                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex space-x-2">
          <Button onClick={handleApplyFilters} className="w-full sm:w-auto bg-sky-500 hover:bg-sky-600 text-white">
            <Search className="mr-2 h-4 w-4" /> Aplicar
          </Button>
          <Button onClick={handleClearFilters} variant="outline" className="w-full sm:w-auto dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
            <X className="mr-2 h-4 w-4" /> Limpar
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CouponFiltersAdmin;
