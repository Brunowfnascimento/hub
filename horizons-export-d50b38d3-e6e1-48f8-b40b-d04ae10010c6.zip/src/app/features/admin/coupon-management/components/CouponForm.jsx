
import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DatePicker } from '@/components/ui/date-picker'; 
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { DiscountTypeOptions, CouponFormDataSchema } from '@/app/types/coupon.types.jsx';
import { Sparkles } from 'lucide-react';

const generateRandomCode = (length = 8) => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
};

const CouponForm = ({ coupon, onSubmit, isSubmitting, onCancel }) => {
  const [formData, setFormData] = useState(CouponFormDataSchema);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (coupon) {
      setFormData({
        code: coupon.code || '',
        description: coupon.description || '',
        discount_type: coupon.discount_type || 'percentage',
        discount_value: coupon.discount_value?.toString() || '',
        max_uses_total: coupon.max_uses_total?.toString() || '',
        max_uses_per_user: coupon.max_uses_per_user?.toString() || '',
        min_purchase_amount: coupon.min_purchase_amount?.toString() || '',
        valid_from: coupon.valid_from ? new Date(coupon.valid_from) : null,
        valid_until: coupon.valid_until ? new Date(coupon.valid_until) : null,
        is_active: coupon.is_active !== undefined ? coupon.is_active : true,
      });
    } else {
       setFormData({...CouponFormDataSchema, code: generateRandomCode()}); // Pre-generate code for new coupons
    }
  }, [coupon]);

  const validateField = (name, value) => {
    let errorMsg = '';
    if (name === 'code' && !value) errorMsg = 'Código é obrigatório.';
    if (name === 'discount_value') {
      if (!value) errorMsg = 'Valor do desconto é obrigatório.';
      else if (isNaN(parseFloat(value)) || parseFloat(value) <= 0) errorMsg = 'Valor do desconto deve ser um número positivo.';
      else if (formData.discount_type === 'percentage' && (parseFloat(value) < 0 || parseFloat(value) > 100)) {
        errorMsg = 'Porcentagem deve ser entre 0 e 100.';
      }
    }
    if (['max_uses_total', 'max_uses_per_user', 'min_purchase_amount'].includes(name) && value && (isNaN(parseFloat(value)) || parseFloat(value) < 0)) {
      errorMsg = 'Valor deve ser um número não negativo.';
    }
    if (name === 'valid_until' && value && formData.valid_from && new Date(value) < new Date(formData.valid_from)) {
      errorMsg = 'Data "Válido Até" deve ser após "Válido De".';
    }
    
    setErrors(prev => ({ ...prev, [name]: errorMsg }));
    return !errorMsg;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const val = type === 'checkbox' ? checked : value;
    setFormData(prev => ({ ...prev, [name]: val }));
    validateField(name, val);
  };

  const handleDateChange = (name, date) => {
    setFormData(prev => ({ ...prev, [name]: date }));
    validateField(name, date);
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    validateField(name, value);
  };
  
  const handleGenerateCode = () => {
    const newCode = generateRandomCode();
    setFormData(prev => ({ ...prev, code: newCode }));
    validateField('code', newCode);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let formIsValid = true;
    const currentErrors = {};
    Object.keys(formData).forEach(key => {
      if (!validateField(key, formData[key])) {
        formIsValid = false;
        // Preserve existing error if validateField didn't set one (e.g. for initially empty required fields)
        if (!errors[key] && (key === 'code' && !formData.code) ) currentErrors[key] = 'Código é obrigatório.';
        if (!errors[key] && (key === 'discount_value' && !formData.discount_value) ) currentErrors[key] = 'Valor do desconto é obrigatório.';

      }
    });
    setErrors(prev => ({...prev, ...currentErrors}));


    if (!formIsValid || Object.values(errors).some(err => err) || Object.values(currentErrors).some(err => err)) {
      console.log("Validation failed", errors, currentErrors);
      return;
    }

    const processedData = {
      ...formData,
      discount_value: parseFloat(formData.discount_value),
      max_uses_total: formData.max_uses_total ? parseInt(formData.max_uses_total, 10) : null,
      max_uses_per_user: formData.max_uses_per_user ? parseInt(formData.max_uses_per_user, 10) : null,
      min_purchase_amount: formData.min_purchase_amount ? parseFloat(formData.min_purchase_amount) : null,
      valid_from: formData.valid_from ? formData.valid_from.toISOString() : null,
      valid_until: formData.valid_until ? formData.valid_until.toISOString() : null,
    };
    onSubmit(processedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="code" className="dark:text-slate-300">Código do Cupom <span className="text-red-500">*</span></Label>
          <div className="flex items-center gap-2">
            <Input id="code" name="code" value={formData.code} onChange={handleChange} className={`dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50 ${errors.code ? 'border-red-500' : ''}`} />
            <Button type="button" variant="outline" onClick={handleGenerateCode} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
              <Sparkles className="h-4 w-4 mr-2" /> Gerar
            </Button>
          </div>
          {errors.code && <p className="text-xs text-red-500 mt-1">{errors.code}</p>}
        </div>

        <div>
          <Label htmlFor="discount_type" className="dark:text-slate-300">Tipo de Desconto <span className="text-red-500">*</span></Label>
          <Select value={formData.discount_type} onValueChange={(val) => handleSelectChange('discount_type', val)}>
            <SelectTrigger id="discount_type" className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
              <SelectValue placeholder="Selecione o Tipo" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
              {DiscountTypeOptions.map(opt => (
                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label htmlFor="discount_value" className="dark:text-slate-300">Valor do Desconto <span className="text-red-500">*</span></Label>
        <Input id="discount_value" name="discount_value" type="number" step="0.01" value={formData.discount_value} onChange={handleChange} className={`dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50 ${errors.discount_value ? 'border-red-500' : ''}`} />
        {errors.discount_value && <p className="text-xs text-red-500 mt-1">{errors.discount_value}</p>}
      </div>
      
      <div>
        <Label htmlFor="description" className="dark:text-slate-300">Descrição</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="max_uses_total" className="dark:text-slate-300">Usos Máximos (Total)</Label>
          <Input id="max_uses_total" name="max_uses_total" type="number" value={formData.max_uses_total} onChange={handleChange} className={`dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50 ${errors.max_uses_total ? 'border-red-500' : ''}`} placeholder="Ex: 100 (deixe em branco para ilimitado)" />
          {errors.max_uses_total && <p className="text-xs text-red-500 mt-1">{errors.max_uses_total}</p>}
        </div>
        <div>
          <Label htmlFor="max_uses_per_user" className="dark:text-slate-300">Usos Máximos (por Usuário)</Label>
          <Input id="max_uses_per_user" name="max_uses_per_user" type="number" value={formData.max_uses_per_user} onChange={handleChange} className={`dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50 ${errors.max_uses_per_user ? 'border-red-500' : ''}`} placeholder="Ex: 1 (deixe em branco para ilimitado)" />
          {errors.max_uses_per_user && <p className="text-xs text-red-500 mt-1">{errors.max_uses_per_user}</p>}
        </div>
      </div>

      <div>
        <Label htmlFor="min_purchase_amount" className="dark:text-slate-300">Valor Mínimo da Compra (R$)</Label>
        <Input id="min_purchase_amount" name="min_purchase_amount" type="number" step="0.01" value={formData.min_purchase_amount} onChange={handleChange} className={`dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50 ${errors.min_purchase_amount ? 'border-red-500' : ''}`} placeholder="Ex: 50.00" />
         {errors.min_purchase_amount && <p className="text-xs text-red-500 mt-1">{errors.min_purchase_amount}</p>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="valid_from" className="dark:text-slate-300">Válido De</Label>
          <DatePicker date={formData.valid_from} onDateChange={(date) => handleDateChange('valid_from', date)} className={`dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50 ${errors.valid_from ? 'border-red-500' : ''}`} />
          {errors.valid_from && <p className="text-xs text-red-500 mt-1">{errors.valid_from}</p>}
        </div>
        <div>
          <Label htmlFor="valid_until" className="dark:text-slate-300">Válido Até</Label>
          <DatePicker date={formData.valid_until} onDateChange={(date) => handleDateChange('valid_until', date)} className={`dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50 ${errors.valid_until ? 'border-red-500' : ''}`} />
          {errors.valid_until && <p className="text-xs text-red-500 mt-1">{errors.valid_until}</p>}
        </div>
      </div>

      <div className="flex items-center space-x-2 pt-2">
        <Switch id="is_active" name="is_active" checked={formData.is_active} onCheckedChange={(checked) => handleSelectChange('is_active', checked)} />
        <Label htmlFor="is_active" className="dark:text-slate-300">Cupom Ativo</Label>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting} className="bg-sky-500 hover:bg-sky-600 text-white">
          {isSubmitting ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : (coupon ? 'Salvar Alterações' : 'Criar Cupom')}
        </Button>
      </div>
    </form>
  );
};

export default CouponForm;
