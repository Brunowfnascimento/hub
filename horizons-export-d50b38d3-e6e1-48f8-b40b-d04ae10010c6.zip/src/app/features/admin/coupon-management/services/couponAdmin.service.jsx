
import React from 'react';
import { supabase } from '@/app/api/supabase';

export const fetchAdminCoupons = async ({
  page = 1,
  limit = 10,
  code = null,
  isActive = null,
  sortBy = 'created_at',
  sortOrder = 'desc',
}) => {
  const offset = (page - 1) * limit;

  let query = supabase
    .from('coupons')
    .select('*', { count: 'exact' });

  if (code) {
    query = query.ilike('code', `%${code}%`);
  }

  if (isActive !== null && typeof isActive === 'boolean') {
    query = query.eq('is_active', isActive);
  }

  query = query.order(sortBy, { ascending: sortOrder === 'asc' });
  query = query.range(offset, offset + limit - 1);

  const { data, error, count } = await query;

  if (error) {
    console.error('Error fetching coupons:', error);
    throw new Error(`Erro ao buscar cupons: ${error.message}`);
  }
  
  // Fetch usage counts - this could be very inefficient for many coupons.
  // Ideally, this count should be a denormalized field on the coupons table updated by triggers
  // or a separate, efficient query. For now, fetching all relevant orders.
  // This part is removed for performance reasons on a list view.
  // We will only show max_uses_total for now.
  /*
  const couponIds = data.map(c => c.id);
  const { data: orderData, error: orderError } = await supabase
    .from('orders')
    .select('coupon_code')
    .in('coupon_code', data.map(c => c.code)) // Assuming coupon_code in orders matches coupon.code
    .not('status', 'in', '("cancelled", "failed")');

  if (orderError) {
    console.warn('Could not fetch order usage for coupons:', orderError.message);
  }

  const usageMap = orderData?.reduce((acc, order) => {
    if (order.coupon_code) {
      acc[order.coupon_code] = (acc[order.coupon_code] || 0) + 1;
    }
    return acc;
  }, {}) || {};

  const couponsWithUsage = data.map(coupon => ({
    ...coupon,
    current_uses: usageMap[coupon.code] || 0,
  }));
  */


  return { coupons: data, totalCount: count };
};

export const fetchAdminCouponById = async (couponId) => {
  const { data, error } = await supabase
    .from('coupons')
    .select('*')
    .eq('id', couponId)
    .single();

  if (error) {
    console.error('Error fetching coupon by ID:', error);
    throw new Error(`Erro ao buscar cupom: ${error.message}`);
  }
  return data;
};

export const createAdminCoupon = async (couponData) => {
  const { data, error } = await supabase
    .from('coupons')
    .insert([couponData])
    .select()
    .single();

  if (error) {
    console.error('Error creating coupon:', error);
    throw new Error(`Erro ao criar cupom: ${error.message}`);
  }
  return data;
};

export const updateAdminCoupon = async (couponId, couponData) => {
  const { data, error } = await supabase
    .from('coupons')
    .update(couponData)
    .eq('id', couponId)
    .select()
    .single();

  if (error) {
    console.error('Error updating coupon:', error);
    throw new Error(`Erro ao atualizar cupom: ${error.message}`);
  }
  return data;
};

export const deleteAdminCoupon = async (couponId) => {
  const { error } = await supabase
    .from('coupons')
    .delete()
    .eq('id', couponId);

  if (error) {
    console.error('Error deleting coupon:', error);
    throw new Error(`Erro ao deletar cupom: ${error.message}`);
  }
  return true; 
};
