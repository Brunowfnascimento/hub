
    import React, { useState, useEffect } from 'react';
    import { useNavigate } from 'react-router-dom';
    import { useAuth } from '@/app/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { Loader2 } from 'lucide-react';
    
    const AdminLoginForm = () => {
      const navigate = useNavigate();
      const { loginWithEmailPassword, isLoadingUser, user, userProfile, fetchUserProfile } = useAuth();
      const { toast } = useToast();
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
    
      useEffect(() => {
        if (user && userProfile) {
          if (userProfile.role === 'admin' || userProfile.role === 'super_admin') {
            navigate('/admin/dashboard');
          }
        }
      }, [user, userProfile, navigate]);
    
      const handleSubmit = async (e) => {
        e.preventDefault();
        if (!email || !password) {
          toast({
            variant: "destructive",
            title: "Erro de Validação",
            description: "Por favor, preencha email e senha.",
          });
          return;
        }
    
        const { data, error } = await loginWithEmailPassword(email, password);
    
        if (error) {
          toast({
            variant: "destructive",
            title: "Erro no Login",
            description: error.message || "Credenciais inválidas ou erro no servidor.",
          });
        } else if (data.user) {
          
          const fetchedProfile = await fetchUserProfile(data.user.id); 

          if (!fetchedProfile) {
             toast({
              variant: "destructive",
              title: "Erro de Permissão",
              description: "Perfil de usuário não encontrado ou erro ao buscar.",
            });
            
            return;
          }

          if (fetchedProfile.role === 'admin' || fetchedProfile.role === 'super_admin') {
            toast({
              title: "Login de Admin bem-sucedido!",
              description: "Redirecionando para o painel...",
            });
            navigate('/admin/dashboard');
          } else {
            toast({
              variant: "destructive",
              title: "Acesso Negado",
              description: "Você não tem permissão para acessar o painel de administração.",
            });
            
          }
        }
      };
    
      return (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="admin-email-login" className="text-slate-700 dark:text-slate-300">Email</Label>
            <Input
              id="admin-email-login"
              type="email"
              placeholder="admin@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoadingUser}
              className="bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 focus:ring-sky-500 dark:focus:ring-sky-400"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="admin-password-login" className="text-slate-700 dark:text-slate-300">Senha</Label>
            <Input
              id="admin-password-login"
              type="password"
              placeholder="Sua senha de administrador"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoadingUser}
              className="bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 focus:ring-sky-500 dark:focus:ring-sky-400"
            />
          </div>
          <Button type="submit" className="w-full bg-sky-600 hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-600 text-white py-3 text-base" disabled={isLoadingUser}>
            {isLoadingUser ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : "Entrar no Painel"}
          </Button>
        </form>
      );
    };
    
    export default AdminLoginForm;
  