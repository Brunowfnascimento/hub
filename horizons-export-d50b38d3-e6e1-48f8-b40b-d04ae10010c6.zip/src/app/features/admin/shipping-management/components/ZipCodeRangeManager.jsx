
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { X, PlusCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ZipCodeRangeManager = ({ ranges = [], onChange }) => {
  const [newRange, setNewRange] = useState({ from: '', to: '' });

  const formatZipCode = (value) => {
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length <= 5) return cleaned;
    return `${cleaned.slice(0, 5)}-${cleaned.slice(5, 8)}`;
  };

  const handleNewRangeChange = (e) => {
    const { name, value } = e.target;
    setNewRange(prev => ({ ...prev, [name]: formatZipCode(value) }));
  };

  const handleAddRange = () => {
    if (newRange.from.match(/^\d{5}-\d{3}$/) && newRange.to.match(/^\d{5}-\d{3}$/)) {
      onChange([...ranges, { ...newRange }]);
      setNewRange({ from: '', to: '' });
    } else {
      // Idealmente, usar toast para feedback
      alert("Formato de CEP inválido. Use XXXXX-XXX.");
    }
  };

  const handleRemoveRange = (indexToRemove) => {
    onChange(ranges.filter((_, index) => index !== indexToRemove));
  };

  return (
    <div className="space-y-4">
      <Label className="text-slate-700 dark:text-slate-300">Faixas de CEP</Label>
      <AnimatePresence>
        {ranges.map((range, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="flex items-center space-x-2 p-2 bg-slate-100 dark:bg-slate-700/50 rounded-md"
          >
            <Input
              type="text"
              value={range.from}
              readOnly
              className="w-full dark:bg-slate-600 dark:border-slate-500 dark:text-slate-200"
              aria-label={`Faixa de CEP De ${index + 1}`}
            />
            <span className="text-slate-500 dark:text-slate-400">-</span>
            <Input
              type="text"
              value={range.to}
              readOnly
              className="w-full dark:bg-slate-600 dark:border-slate-500 dark:text-slate-200"
              aria-label={`Faixa de CEP Para ${index + 1}`}
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => handleRemoveRange(index)}
              className="text-red-500 hover:bg-red-100 dark:hover:bg-red-700/30"
              aria-label={`Remover faixa ${index + 1}`}
            >
              <X className="h-4 w-4" />
            </Button>
          </motion.div>
        ))}
      </AnimatePresence>

      <div className="flex items-end space-x-2 pt-2 border-t border-slate-200 dark:border-slate-700 mt-4">
        <div className="flex-grow">
          <Label htmlFor="newRangeFrom" className="text-xs text-slate-600 dark:text-slate-400">De (CEP)</Label>
          <Input
            id="newRangeFrom"
            name="from"
            value={newRange.from}
            onChange={handleNewRangeChange}
            placeholder="XXXXX-XXX"
            maxLength={9}
            className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
          />
        </div>
        <div className="flex-grow">
          <Label htmlFor="newRangeTo" className="text-xs text-slate-600 dark:text-slate-400">Para (CEP)</Label>
          <Input
            id="newRangeTo"
            name="to"
            value={newRange.to}
            onChange={handleNewRangeChange}
            placeholder="XXXXX-XXX"
            maxLength={9}
            className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
          />
        </div>
        <Button
          type="button"
          variant="outline"
          onClick={handleAddRange}
          className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
          aria-label="Adicionar nova faixa de CEP"
        >
          <PlusCircle className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default ZipCodeRangeManager;
