
import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ShippingMethodSchema, CalculationTypeOptions, ShippingMethodCalculationType } from '@/app/types/shipping.types.jsx';
import { fetchShippingZones, fetchShippingCarriers } from '@/app/features/admin/shipping-management/services/shippingAdmin.service.jsx';
import { useToast } from '@/components/ui/use-toast';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';

const ShippingMethodForm = ({ method, onSubmit, isSubmitting, onCancel }) => {
  const [formData, setFormData] = useState(ShippingMethodSchema);
  const { toast } = useToast();

  const { data: zones, isLoading: isLoadingZones } = useQuery({
    queryKey: ['shippingZonesForForm'],
    queryFn: fetchShippingZones,
  });
  const { data: carriers, isLoading: isLoadingCarriers } = useQuery({
    queryKey: ['shippingCarriersForForm'],
    queryFn: fetchShippingCarriers,
  });

  useEffect(() => {
    if (method) {
      setFormData({
        ...ShippingMethodSchema, // Ensure all fields are present
        ...method,
        carrier_id: method.carrier_id || null, // Ensure null if not set
        base_cost: method.base_cost ?? 0,
      });
    } else {
      setFormData(ShippingMethodSchema);
    }
  }, [method]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleNumberChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value === '' ? '' : parseFloat(value) }));
  };

  const handleSwitchChange = (checked) => {
    setFormData(prev => ({ ...prev, is_active: checked }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.shipping_zone_id) {
      toast({ title: "Erro de Validação", description: "Nome e Zona de Entrega são obrigatórios.", variant: "destructive" });
      return;
    }
    const dataToSubmit = {
        ...formData,
        base_cost: formData.base_cost === '' || formData.base_cost === null ? 0 : parseFloat(formData.base_cost),
        carrier_id: formData.carrier_id === '' ? null : formData.carrier_id,
    };
    onSubmit(dataToSubmit);
  };

  const showBaseCost = [
    ShippingMethodCalculationType.FLAT_RATE_PER_ITEM,
    ShippingMethodCalculationType.FLAT_RATE_PER_ORDER,
    ShippingMethodCalculationType.FREE_SHIPPING
  ].includes(formData.calculation_type);

  if (isLoadingZones || isLoadingCarriers) {
    return <div className="flex justify-center items-center p-8"><LoadingSpinner /></div>;
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <Label htmlFor="name">Nome do Método <span className="text-red-500">*</span></Label>
        <Input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="Ex: Entrega Expressa, PAC" className="mt-1 dark:bg-slate-700" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="shipping_zone_id">Zona de Entrega <span className="text-red-500">*</span></Label>
          <Select name="shipping_zone_id" value={formData.shipping_zone_id} onValueChange={(value) => handleSelectChange('shipping_zone_id', value)}>
            <SelectTrigger className="mt-1 dark:bg-slate-700">
              <SelectValue placeholder="Selecione uma zona" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-700">
              {zones?.map(zone => <SelectItem key={zone.id} value={zone.id}>{zone.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="carrier_id">Transportadora (Opcional)</Label>
          <Select name="carrier_id" value={formData.carrier_id || ''} onValueChange={(value) => handleSelectChange('carrier_id', value || null)}>
            <SelectTrigger className="mt-1 dark:bg-slate-700">
              <SelectValue placeholder="Selecione uma transportadora" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-700">
              <SelectItem value={null}>Nenhuma</SelectItem>
              {carriers?.map(carrier => <SelectItem key={carrier.id} value={carrier.id}>{carrier.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="service_code">Código do Serviço (Opcional)</Label>
        <Input id="service_code" name="service_code" value={formData.service_code} onChange={handleChange} placeholder="Ex: 04510 (SEDEX), 04669 (PAC)" className="mt-1 dark:bg-slate-700" />
      </div>
      <div>
        <Label htmlFor="description">Descrição (Opcional)</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} rows={3} className="mt-1 dark:bg-slate-700" />
      </div>
      <div>
        <Label htmlFor="estimated_delivery_time_template">Modelo de Prazo de Entrega</Label>
        <Input id="estimated_delivery_time_template" name="estimated_delivery_time_template" value={formData.estimated_delivery_time_template} onChange={handleChange} placeholder="Ex: 3-5 dias úteis" className="mt-1 dark:bg-slate-700" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="calculation_type">Tipo de Cálculo</Label>
          <Select name="calculation_type" value={formData.calculation_type} onValueChange={(value) => handleSelectChange('calculation_type', value)}>
            <SelectTrigger className="mt-1 dark:bg-slate-700">
              <SelectValue placeholder="Selecione o tipo" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-700">
              {CalculationTypeOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        {showBaseCost && (
          <div>
            <Label htmlFor="base_cost">Custo Base (R$)</Label>
            <Input id="base_cost" name="base_cost" type="number" step="0.01" value={formData.base_cost} onChange={handleNumberChange} className="mt-1 dark:bg-slate-700" />
          </div>
        )}
      </div>
      <div className="flex items-center space-x-2 pt-2">
        <Switch id="is_active" checked={formData.is_active} onCheckedChange={handleSwitchChange} />
        <Label htmlFor="is_active">Ativo</Label>
      </div>
      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">Cancelar</Button>
        <Button type="submit" disabled={isSubmitting} className="bg-sky-500 hover:bg-sky-600 text-white">
          {isSubmitting ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : (method ? 'Atualizar Método' : 'Adicionar Método')}
        </Button>
      </div>
    </form>
  );
};

export default ShippingMethodForm;
