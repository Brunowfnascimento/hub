
import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  fetchShippingMethods,
  createShippingMethod,
  updateShippingMethod,
  deleteShippingMethod,
  fetchShippingZones, // To populate filter
} from '@/app/features/admin/shipping-management/services/shippingAdmin.service.jsx';
import ShippingMethodForm from './ShippingMethodForm';
import RateManager from './RateManager';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { Button } from '@/components/ui/button';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { MoreHorizontal, PlusCircle, Edit, Trash2, Settings2, DollarSign } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { CalculationTypeOptions, ShippingMethodCalculationType } from '@/app/types/shipping.types.jsx';

const ShippingMethodsTab = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [methodToDelete, setMethodToDelete] = useState(null);
  const [isRateManagerOpen, setIsRateManagerOpen] = useState(false);
  const [methodForRates, setMethodForRates] = useState(null);
  const [zoneFilter, setZoneFilter] = useState('');

  const { data: zones, isLoading: isLoadingZones } = useQuery({
    queryKey: ['shippingZonesForFilter'],
    queryFn: fetchShippingZones,
  });

  const { data: methods, isLoading, error } = useQuery({
    queryKey: ['shippingMethods', { shipping_zone_id: zoneFilter }],
    queryFn: () => fetchShippingMethods({ shipping_zone_id: zoneFilter || undefined }),
  });

  const getCalculationTypeLabel = (value) => {
    const option = CalculationTypeOptions.find(opt => opt.value === value);
    return option ? option.label : value;
  };

  const mutationOptions = {
    onSuccess: () => {
      queryClient.invalidateQueries(['shippingMethods', { shipping_zone_id: zoneFilter }]);
      setIsFormModalOpen(false);
      setSelectedMethod(null);
      setIsEditing(false);
    },
    onError: (err) => { toast({ title: "Erro", description: err.message, variant: "destructive" }); },
  };

  const createMutation = useMutation({
    mutationFn: createShippingMethod, ...mutationOptions,
    onSuccess: (...args) => { mutationOptions.onSuccess(...args); toast({ title: "Sucesso!", description: "Método de envio adicionado." }); }
  });
  const updateMutation = useMutation({
    mutationFn: (methodData) => updateShippingMethod(selectedMethod.id, methodData), ...mutationOptions,
    onSuccess: (...args) => { mutationOptions.onSuccess(...args); toast({ title: "Sucesso!", description: "Método de envio atualizado." }); }
  });
  const deleteMutation = useMutation({
    mutationFn: deleteShippingMethod,
    onSuccess: () => {
      queryClient.invalidateQueries(['shippingMethods', { shipping_zone_id: zoneFilter }]);
      setIsDeleteDialogOpen(false); setMethodToDelete(null);
      toast({ title: "Sucesso!", description: "Método de envio deletado." });
    },
    onError: (err) => { toast({ title: "Erro ao deletar", description: err.message, variant: "destructive" }); setIsDeleteDialogOpen(false); },
  });

  const handleOpenAddModal = () => { setIsEditing(false); setSelectedMethod(null); setIsFormModalOpen(true); };
  const handleOpenEditModal = (method) => { setIsEditing(true); setSelectedMethod(method); setIsFormModalOpen(true); };
  const handleOpenDeleteDialog = (method) => { setMethodToDelete(method); setIsDeleteDialogOpen(true); };
  const handleSubmitForm = (formData) => {
    if (isEditing && selectedMethod) { updateMutation.mutate(formData); } else { createMutation.mutate(formData); }
  };
  const confirmDelete = () => { if (methodToDelete) { deleteMutation.mutate(methodToDelete.id); } };
  const handleOpenRateManager = (method) => { setMethodForRates(method); setIsRateManagerOpen(true); };

  if (isLoading || isLoadingZones) return <div className="flex justify-center items-center h-64"><LoadingSpinner size="h-12 w-12" /></div>;
  if (error) return <ErrorDisplay message={error.message} />;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <div className="w-full sm:w-auto">
          <Label htmlFor="zoneFilter" className="text-sm font-medium text-slate-700 dark:text-slate-300">Filtrar por Zona:</Label>
          <Select value={zoneFilter} onValueChange={setZoneFilter}>
            <SelectTrigger className="w-full sm:w-[250px] mt-1 dark:bg-slate-700">
              <SelectValue placeholder="Todas as Zonas" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-700">
              <SelectItem value="">Todas as Zonas</SelectItem>
              {zones?.map(zone => <SelectItem key={zone.id} value={zone.id}>{zone.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <Button onClick={handleOpenAddModal} className="w-full sm:w-auto bg-indigo-500 hover:bg-indigo-600 text-white shadow-md">
          <PlusCircle className="mr-2 h-5 w-5" /> Adicionar Método
        </Button>
      </div>

      <motion.div className="bg-white dark:bg-slate-800 shadow-xl rounded-lg overflow-hidden" initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }}>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-slate-50 dark:bg-slate-700">
              <TableRow>
                <TableHead className="dark:text-slate-300">Nome</TableHead>
                <TableHead className="dark:text-slate-300">Zona</TableHead>
                <TableHead className="dark:text-slate-300">Transportadora</TableHead>
                <TableHead className="dark:text-slate-300">Tipo Cálculo</TableHead>
                <TableHead className="dark:text-slate-300">Status</TableHead>
                <TableHead className="text-center dark:text-slate-300">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <AnimatePresence>
                {methods?.length > 0 ? methods.map((method) => (
                  <motion.tr key={method.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="dark:hover:bg-slate-700/50">
                    <TableCell className="font-medium dark:text-slate-100">{method.name}</TableCell>
                    <TableCell className="dark:text-slate-300">{method.shipping_zones?.name || 'N/A'}</TableCell>
                    <TableCell className="dark:text-slate-300">{method.shipping_carriers?.name || 'N/A'}</TableCell>
                    <TableCell className="dark:text-slate-300">{getCalculationTypeLabel(method.calculation_type)}</TableCell>
                    <TableCell>
                      <Badge variant={method.is_active ? 'success' : 'destructive'} className={`${method.is_active ? 'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300' : 'bg-red-100 text-red-700 dark:bg-red-700/30 dark:text-red-300'}`}>
                        {method.is_active ? 'Ativo' : 'Inativo'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" className="h-8 w-8 p-0"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="dark:bg-slate-700 dark:border-slate-600">
                          <DropdownMenuItem onClick={() => handleOpenEditModal(method)} className="dark:hover:bg-slate-600"><Edit className="mr-2 h-4 w-4" /> Editar</DropdownMenuItem>
                          {method.calculation_type === ShippingMethodCalculationType.TABLE_RATE && (
                            <DropdownMenuItem onClick={() => handleOpenRateManager(method)} className="dark:hover:bg-slate-600"><DollarSign className="mr-2 h-4 w-4" /> Gerenciar Taxas</DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator className="dark:bg-slate-600" />
                          <DropdownMenuItem onClick={() => handleOpenDeleteDialog(method)} className="text-red-600 dark:text-red-400 dark:hover:bg-red-700/20 focus:text-red-600 focus:bg-red-50 dark:focus:bg-red-700/20"><Trash2 className="mr-2 h-4 w-4" /> Deletar</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </motion.tr>
                )) : (
                  <TableRow><TableCell colSpan={6} className="h-24 text-center dark:text-slate-400">Nenhum método de envio encontrado.</TableCell></TableRow>
                )}
              </AnimatePresence>
            </TableBody>
          </Table>
        </div>
      </motion.div>

      <Dialog open={isFormModalOpen} onOpenChange={(open) => { if (!open) { setIsFormModalOpen(false); setSelectedMethod(null); setIsEditing(false); } else { setIsFormModalOpen(true); } }}>
        <DialogContent className="sm:max-w-lg dark:bg-slate-800">
          <DialogHeader>
            <DialogTitle className="text-xl dark:text-slate-100">{isEditing ? 'Editar Método de Envio' : 'Adicionar Novo Método'}</DialogTitle>
            <DialogDescription className="dark:text-slate-400">{isEditing ? 'Modifique os detalhes.' : 'Preencha os detalhes.'}</DialogDescription>
          </DialogHeader>
          <ShippingMethodForm method={selectedMethod} onSubmit={handleSubmitForm} isSubmitting={createMutation.isPending || updateMutation.isPending} onCancel={() => setIsFormModalOpen(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={isRateManagerOpen} onOpenChange={setIsRateManagerOpen}>
        <DialogContent className="sm:max-w-4xl dark:bg-slate-800"> {/* Larger modal for rate manager */}
          {methodForRates && <RateManager shippingMethodId={methodForRates.id} methodName={methodForRates.name} />}
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="dark:bg-slate-800">
          <AlertDialogHeader><AlertDialogTitle className="dark:text-slate-100">Confirmar Exclusão</AlertDialogTitle><AlertDialogDescription className="dark:text-slate-400">Tem certeza que deseja deletar "{methodToDelete?.name}"?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isPending} className="bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600">
              {deleteMutation.isPending ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : "Deletar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};

export default ShippingMethodsTab;
