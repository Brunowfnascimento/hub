
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  fetchShippingRates,
  createShippingRate,
  updateShippingRate,
  deleteShippingRate,
} from '@/app/features/admin/shipping-management/services/shippingAdmin.service.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { MoreHorizontal, PlusCircle, Edit, Trash2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { ShippingRateSchema } from '@/app/types/shipping.types.jsx';
import { motion, AnimatePresence } from 'framer-motion';

const RateForm = ({ rate, shippingMethodId, onSubmit, isSubmitting, onCancel }) => {
  const [formData, setFormData] = useState(ShippingRateSchema);

  useEffect(() => {
    if (rate) {
      setFormData({
        ...ShippingRateSchema, // Ensure all fields are present
        ...rate,
        shipping_method_id: shippingMethodId,
        // Ensure numeric fields are numbers or empty strings for input control
        condition_min_weight_grams: rate.condition_min_weight_grams ?? '',
        condition_max_weight_grams: rate.condition_max_weight_grams ?? '',
        condition_min_subtotal: rate.condition_min_subtotal ?? '',
        condition_max_subtotal: rate.condition_max_subtotal ?? '',
        cost: rate.cost ?? 0,
        priority: rate.priority ?? 0,
      });
    } else {
      setFormData({ ...ShippingRateSchema, shipping_method_id: shippingMethodId });
    }
  }, [rate, shippingMethodId]);

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? (value === '' ? '' : parseFloat(value)) : value,
    }));
  };
  
  const handleNullableNumberChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value === '' ? null : parseFloat(value),
    }));
  };


  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.cost === '' || formData.cost === null || isNaN(parseFloat(formData.cost))) {
      alert("O custo é obrigatório."); // Idealmente, usar toast
      return;
    }
    const dataToSubmit = {
        ...formData,
        condition_min_weight_grams: formData.condition_min_weight_grams === '' ? null : parseFloat(formData.condition_min_weight_grams),
        condition_max_weight_grams: formData.condition_max_weight_grams === '' ? null : parseFloat(formData.condition_max_weight_grams),
        condition_min_subtotal: formData.condition_min_subtotal === '' ? null : parseFloat(formData.condition_min_subtotal),
        condition_max_subtotal: formData.condition_max_subtotal === '' ? null : parseFloat(formData.condition_max_subtotal),
        cost: parseFloat(formData.cost),
        priority: formData.priority === '' ? 0 : parseInt(formData.priority, 10),
    };
    onSubmit(dataToSubmit);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-1">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="cost">Custo (R$) <span className="text-red-500">*</span></Label>
          <Input id="cost" name="cost" type="number" step="0.01" value={formData.cost} onChange={handleChange} className="mt-1 dark:bg-slate-700" />
        </div>
        <div>
          <Label htmlFor="priority">Prioridade</Label>
          <Input id="priority" name="priority" type="number" value={formData.priority} onChange={handleChange} className="mt-1 dark:bg-slate-700" />
        </div>
      </div>
      <h4 className="text-sm font-medium text-slate-700 dark:text-slate-300 pt-2 border-t mt-4">Condições (Opcional)</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="condition_min_weight_grams">Peso Mín. (g)</Label>
          <Input id="condition_min_weight_grams" name="condition_min_weight_grams" type="number" value={formData.condition_min_weight_grams ?? ''} onChange={handleNullableNumberChange} className="mt-1 dark:bg-slate-700" />
        </div>
        <div>
          <Label htmlFor="condition_max_weight_grams">Peso Máx. (g)</Label>
          <Input id="condition_max_weight_grams" name="condition_max_weight_grams" type="number" value={formData.condition_max_weight_grams ?? ''} onChange={handleNullableNumberChange} className="mt-1 dark:bg-slate-700" />
        </div>
        <div>
          <Label htmlFor="condition_min_subtotal">Subtotal Mín. (R$)</Label>
          <Input id="condition_min_subtotal" name="condition_min_subtotal" type="number" step="0.01" value={formData.condition_min_subtotal ?? ''} onChange={handleNullableNumberChange} className="mt-1 dark:bg-slate-700" />
        </div>
        <div>
          <Label htmlFor="condition_max_subtotal">Subtotal Máx. (R$)</Label>
          <Input id="condition_max_subtotal" name="condition_max_subtotal" type="number" step="0.01" value={formData.condition_max_subtotal ?? ''} onChange={handleNullableNumberChange} className="mt-1 dark:bg-slate-700" />
        </div>
        <div>
          <Label htmlFor="zip_code_start">CEP Início</Label>
          <Input id="zip_code_start" name="zip_code_start" value={formData.zip_code_start} onChange={handleChange} placeholder="XXXXX-XXX" className="mt-1 dark:bg-slate-700" />
        </div>
        <div>
          <Label htmlFor="zip_code_end">CEP Fim</Label>
          <Input id="zip_code_end" name="zip_code_end" value={formData.zip_code_end} onChange={handleChange} placeholder="XXXXX-XXX" className="mt-1 dark:bg-slate-700" />
        </div>
      </div>
      <DialogFooter className="pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">Cancelar</Button>
        <Button type="submit" disabled={isSubmitting} className="bg-sky-500 hover:bg-sky-600 text-white">
          {isSubmitting ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : (rate ? 'Atualizar Taxa' : 'Adicionar Taxa')}
        </Button>
      </DialogFooter>
    </form>
  );
};


const RateManager = ({ shippingMethodId, methodName }) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRate, setSelectedRate] = useState(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [rateToDelete, setRateToDelete] = useState(null);

  const { data: rates, isLoading, error } = useQuery({
    queryKey: ['shippingRates', shippingMethodId],
    queryFn: () => fetchShippingRates(shippingMethodId),
    enabled: !!shippingMethodId,
  });

  const mutationOptions = {
    onSuccess: () => {
      queryClient.invalidateQueries(['shippingRates', shippingMethodId]);
      setIsFormModalOpen(false);
      setSelectedRate(null);
      setIsEditing(false);
    },
    onError: (err) => {
      toast({ title: "Erro", description: err.message, variant: "destructive" });
    },
  };

  const createMutation = useMutation({
    mutationFn: createShippingRate,
    ...mutationOptions,
    onSuccess: (...args) => { mutationOptions.onSuccess(...args); toast({ title: "Sucesso!", description: "Taxa adicionada." }); }
  });

  const updateMutation = useMutation({
    mutationFn: (rateData) => updateShippingRate(selectedRate.id, rateData),
    ...mutationOptions,
    onSuccess: (...args) => { mutationOptions.onSuccess(...args); toast({ title: "Sucesso!", description: "Taxa atualizada." }); }
  });

  const deleteMutation = useMutation({
    mutationFn: deleteShippingRate,
    onSuccess: () => {
      queryClient.invalidateQueries(['shippingRates', shippingMethodId]);
      setIsDeleteDialogOpen(false);
      setRateToDelete(null);
      toast({ title: "Sucesso!", description: "Taxa deletada." });
    },
    onError: (err) => { toast({ title: "Erro ao deletar", description: err.message, variant: "destructive" }); setIsDeleteDialogOpen(false); },
  });

  const handleOpenAddModal = () => { setIsEditing(false); setSelectedRate(null); setIsFormModalOpen(true); };
  const handleOpenEditModal = (rate) => { setIsEditing(true); setSelectedRate(rate); setIsFormModalOpen(true); };
  const handleOpenDeleteDialog = (rate) => { setRateToDelete(rate); setIsDeleteDialogOpen(true); };
  const handleSubmitForm = (formData) => {
    if (isEditing && selectedRate) { updateMutation.mutate(formData); } 
    else { createMutation.mutate(formData); }
  };
  const confirmDelete = () => { if (rateToDelete) { deleteMutation.mutate(rateToDelete.id); } };

  if (isLoading) return <div className="flex justify-center items-center h-40"><LoadingSpinner /></div>;
  if (error) return <ErrorDisplay message={error.message} />;

  return (
    <div className="p-1">
      <DialogHeader className="mb-4">
        <DialogTitle className="text-xl dark:text-slate-100">Gerenciar Taxas para: {methodName}</DialogTitle>
        <DialogDescription className="dark:text-slate-400">Adicione, edite ou remova taxas para este método de envio.</DialogDescription>
      </DialogHeader>
      <div className="flex justify-end mb-4">
        <Button onClick={handleOpenAddModal} className="bg-green-500 hover:bg-green-600 text-white">
          <PlusCircle className="mr-2 h-4 w-4" /> Adicionar Taxa
        </Button>
      </div>
      <div className="overflow-x-auto border rounded-md dark:border-slate-700">
        <Table>
          <TableHeader className="bg-slate-50 dark:bg-slate-700">
            <TableRow>
              <TableHead className="dark:text-slate-300">Custo (R$)</TableHead>
              <TableHead className="dark:text-slate-300">Peso (g)</TableHead>
              <TableHead className="dark:text-slate-300">Subtotal (R$)</TableHead>
              <TableHead className="dark:text-slate-300">CEP</TableHead>
              <TableHead className="dark:text-slate-300">Prioridade</TableHead>
              <TableHead className="text-center dark:text-slate-300">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <AnimatePresence>
              {rates?.length > 0 ? rates.map((rate) => (
                <motion.tr key={rate.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="dark:hover:bg-slate-700/50">
                  <TableCell className="dark:text-slate-200">{rate.cost.toFixed(2)}</TableCell>
                  <TableCell className="dark:text-slate-200">
                    {rate.condition_min_weight_grams ?? '-'} à {rate.condition_max_weight_grams ?? '-'}
                  </TableCell>
                  <TableCell className="dark:text-slate-200">
                    {rate.condition_min_subtotal?.toFixed(2) ?? '-'} à {rate.condition_max_subtotal?.toFixed(2) ?? '-'}
                  </TableCell>
                  <TableCell className="dark:text-slate-200">
                    {rate.zip_code_start || '-'} à {rate.zip_code_end || '-'}
                  </TableCell>
                  <TableCell className="dark:text-slate-200">{rate.priority}</TableCell>
                  <TableCell className="text-center">
                     <Button variant="ghost" size="icon" onClick={() => handleOpenEditModal(rate)} className="mr-1 hover:text-sky-500 dark:hover:text-sky-400"><Edit className="h-4 w-4" /></Button>
                     <Button variant="ghost" size="icon" onClick={() => handleOpenDeleteDialog(rate)} className="hover:text-red-500 dark:hover:text-red-400"><Trash2 className="h-4 w-4" /></Button>
                  </TableCell>
                </motion.tr>
              )) : (
                <TableRow><TableCell colSpan={6} className="h-24 text-center dark:text-slate-400">Nenhuma taxa configurada.</TableCell></TableRow>
              )}
            </AnimatePresence>
          </TableBody>
        </Table>
      </div>

      <Dialog open={isFormModalOpen} onOpenChange={(open) => {
          if (!open) { setIsFormModalOpen(false); setSelectedRate(null); setIsEditing(false); } 
          else { setIsFormModalOpen(true); }
      }}>
        <DialogContent className="sm:max-w-2xl dark:bg-slate-800">
          <DialogHeader>
            <DialogTitle className="dark:text-slate-100">{isEditing ? 'Editar Taxa' : 'Adicionar Nova Taxa'}</DialogTitle>
          </DialogHeader>
          <RateForm
            rate={selectedRate}
            shippingMethodId={shippingMethodId}
            onSubmit={handleSubmitForm}
            isSubmitting={createMutation.isPending || updateMutation.isPending}
            onCancel={() => setIsFormModalOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="dark:bg-slate-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="dark:text-slate-100">Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription className="dark:text-slate-400">Tem certeza que deseja deletar esta taxa? Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isPending} className="bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600">
              {deleteMutation.isPending ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : "Deletar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default RateManager;
