
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { ShippingCarrierSchema } from '@/app/types/shipping.types.jsx';
import { useToast } from '@/components/ui/use-toast';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';

const CarrierForm = ({ carrier, onSubmit, isSubmitting, onCancel }) => {
  const [formData, setFormData] = useState(ShippingCarrierSchema);
  const { toast } = useToast();

  useEffect(() => {
    if (carrier) {
      setFormData({
        name: carrier.name || '',
        code: carrier.code || '',
        is_active: carrier.is_active !== undefined ? carrier.is_active : true,
        tracking_url_template: carrier.tracking_url_template || '',
        api_integration_details: carrier.api_integration_details ? JSON.stringify(carrier.api_integration_details, null, 2) : '',
      });
    } else {
      setFormData(ShippingCarrierSchema);
    }
  }, [carrier]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSwitchChange = (checked) => {
    setFormData(prev => ({ ...prev, is_active: checked }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({ title: "Erro de Validação", description: "O nome da transportadora é obrigatório.", variant: "destructive" });
      return;
    }

    let apiDetails = null;
    if (formData.api_integration_details) {
      try {
        apiDetails = JSON.parse(formData.api_integration_details);
      } catch (error) {
        toast({ title: "Erro de Validação", description: "Detalhes da Integração API não é um JSON válido.", variant: "destructive" });
        return;
      }
    }
    
    onSubmit({
      ...formData,
      api_integration_details: apiDetails,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <Label htmlFor="name" className="text-slate-700 dark:text-slate-300">Nome da Transportadora <span className="text-red-500">*</span></Label>
        <Input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Ex: Correios, Jadlog"
          className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
        />
      </div>
      <div>
        <Label htmlFor="code" className="text-slate-700 dark:text-slate-300">Código (Opcional)</Label>
        <Input
          id="code"
          name="code"
          value={formData.code}
          onChange={handleChange}
          placeholder="Ex: CORREIOS_SEDEX"
          className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
        />
      </div>
      <div className="flex items-center space-x-2">
        <Switch
          id="is_active"
          checked={formData.is_active}
          onCheckedChange={handleSwitchChange}
        />
        <Label htmlFor="is_active" className="text-slate-700 dark:text-slate-300">Ativa</Label>
      </div>
      <div>
        <Label htmlFor="tracking_url_template" className="text-slate-700 dark:text-slate-300">Modelo de URL de Rastreio (Opcional)</Label>
        <Input
          id="tracking_url_template"
          name="tracking_url_template"
          value={formData.tracking_url_template}
          onChange={handleChange}
          placeholder="https://rastreio.examplo.com?codigo={tracking_code}"
          className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
        />
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Use {'{tracking_code}'} como placeholder para o código.</p>
      </div>
      <div>
        <Label htmlFor="api_integration_details" className="text-slate-700 dark:text-slate-300">Detalhes da Integração API (JSON, Opcional)</Label>
        <Textarea
          id="api_integration_details"
          name="api_integration_details"
          value={formData.api_integration_details}
          onChange={handleChange}
          placeholder='{ "apiKey": "seu_api_key", "secret": "seu_secret" }'
          rows={4}
          className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50"
        />
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting} className="bg-sky-500 hover:bg-sky-600 text-white">
          {isSubmitting ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white"/> : null}
          {carrier ? 'Atualizar Transportadora' : 'Adicionar Transportadora'}
        </Button>
      </div>
    </form>
  );
};

export default CarrierForm;
