
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  fetchShippingCarriers,
  createShippingCarrier,
  updateShippingCarrier,
  deleteShippingCarrier,
} from '@/app/features/admin/shipping-management/services/shippingAdmin.service.jsx';
import CarrierForm from './CarrierForm';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { MoreHorizontal, PlusCircle, Edit, Trash2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { motion, AnimatePresence } from 'framer-motion';

const CarriersTab = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedCarrier, setSelectedCarrier] = useState(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [carrierToDelete, setCarrierToDelete] = useState(null);

  const { data: carriers, isLoading, error } = useQuery({
    queryKey: ['shippingCarriers'],
    queryFn: fetchShippingCarriers,
  });

  const mutationOptions = {
    onSuccess: () => {
      queryClient.invalidateQueries(['shippingCarriers']);
      setIsFormModalOpen(false);
      setSelectedCarrier(null);
      setIsEditing(false);
    },
    onError: (err) => {
      toast({ title: "Erro", description: err.message, variant: "destructive" });
    },
  };

  const createMutation = useMutation({
    mutationFn: createShippingCarrier,
    ...mutationOptions,
    onSuccess: (...args) => {
      mutationOptions.onSuccess(...args);
      toast({ title: "Sucesso!", description: "Transportadora adicionada." });
    }
  });

  const updateMutation = useMutation({
    mutationFn: (carrierData) => updateShippingCarrier(selectedCarrier.id, carrierData),
    ...mutationOptions,
    onSuccess: (...args) => {
      mutationOptions.onSuccess(...args);
      toast({ title: "Sucesso!", description: "Transportadora atualizada." });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: deleteShippingCarrier,
    onSuccess: () => {
      queryClient.invalidateQueries(['shippingCarriers']);
      setIsDeleteDialogOpen(false);
      setCarrierToDelete(null);
      toast({ title: "Sucesso!", description: "Transportadora deletada." });
    },
    onError: (err) => {
      toast({ title: "Erro ao deletar", description: err.message, variant: "destructive" });
      setIsDeleteDialogOpen(false);
    },
  });

  const handleOpenAddModal = () => {
    setIsEditing(false);
    setSelectedCarrier(null);
    setIsFormModalOpen(true);
  };

  const handleOpenEditModal = (carrier) => {
    setIsEditing(true);
    setSelectedCarrier(carrier);
    setIsFormModalOpen(true);
  };

  const handleOpenDeleteDialog = (carrier) => {
    setCarrierToDelete(carrier);
    setIsDeleteDialogOpen(true);
  };

  const handleSubmitForm = (formData) => {
    if (isEditing && selectedCarrier) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };

  const confirmDelete = () => {
    if (carrierToDelete) {
      deleteMutation.mutate(carrierToDelete.id);
    }
  };

  if (isLoading) return <div className="flex justify-center items-center h-64"><LoadingSpinner size="h-12 w-12" /></div>;
  if (error) return <ErrorDisplay message={error.message} />;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
      <div className="flex justify-end mb-6">
        <Button onClick={handleOpenAddModal} className="bg-sky-500 hover:bg-sky-600 text-white shadow-md">
          <PlusCircle className="mr-2 h-5 w-5" /> Adicionar Transportadora
        </Button>
      </div>

      <motion.div 
        className="bg-white dark:bg-slate-800 shadow-xl rounded-lg overflow-hidden"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-slate-50 dark:bg-slate-700">
              <TableRow>
                <TableHead className="text-slate-600 dark:text-slate-300">Nome</TableHead>
                <TableHead className="text-slate-600 dark:text-slate-300">Código</TableHead>
                <TableHead className="text-slate-600 dark:text-slate-300">Status</TableHead>
                <TableHead className="text-center text-slate-600 dark:text-slate-300">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <AnimatePresence>
                {carriers?.length > 0 ? carriers.map((carrier) => (
                  <motion.tr 
                    key={carrier.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
                  >
                    <TableCell className="font-medium text-slate-800 dark:text-slate-100">{carrier.name}</TableCell>
                    <TableCell className="text-slate-600 dark:text-slate-300">{carrier.code || 'N/A'}</TableCell>
                    <TableCell>
                      <Badge variant={carrier.is_active ? 'success' : 'destructive'} className={`${carrier.is_active ? 'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300' : 'bg-red-100 text-red-700 dark:bg-red-700/30 dark:text-red-300'}`}>
                        {carrier.is_active ? 'Ativa' : 'Inativa'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="dark:bg-slate-700 dark:border-slate-600">
                          <DropdownMenuItem onClick={() => handleOpenEditModal(carrier)} className="dark:hover:bg-slate-600">
                            <Edit className="mr-2 h-4 w-4" /> Editar
                          </DropdownMenuItem>
                          <DropdownMenuSeparator className="dark:bg-slate-600" />
                          <DropdownMenuItem onClick={() => handleOpenDeleteDialog(carrier)} className="text-red-600 dark:text-red-400 dark:hover:bg-red-700/20 focus:text-red-600 focus:bg-red-50 dark:focus:bg-red-700/20">
                            <Trash2 className="mr-2 h-4 w-4" /> Deletar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </motion.tr>
                )) : (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center text-slate-500 dark:text-slate-400">
                      Nenhuma transportadora encontrada.
                    </TableCell>
                  </TableRow>
                )}
              </AnimatePresence>
            </TableBody>
          </Table>
        </div>
      </motion.div>

      <Dialog open={isFormModalOpen} onOpenChange={(open) => {
          if (!open) {
            setIsFormModalOpen(false);
            setSelectedCarrier(null);
            setIsEditing(false);
          } else {
            setIsFormModalOpen(true);
          }
      }}>
        <DialogContent className="sm:max-w-lg dark:bg-slate-800">
          <DialogHeader>
            <DialogTitle className="text-xl dark:text-slate-100">{isEditing ? 'Editar Transportadora' : 'Adicionar Nova Transportadora'}</DialogTitle>
            <DialogDescription className="dark:text-slate-400">
              {isEditing ? 'Modifique os detalhes da transportadora.' : 'Preencha os detalhes da nova transportadora.'}
            </DialogDescription>
          </DialogHeader>
          <CarrierForm
            carrier={selectedCarrier}
            onSubmit={handleSubmitForm}
            isSubmitting={createMutation.isPending || updateMutation.isPending}
            onCancel={() => setIsFormModalOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="dark:bg-slate-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="dark:text-slate-100">Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription className="dark:text-slate-400">
              Tem certeza que deseja deletar a transportadora "{carrierToDelete?.name}"? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isPending} className="bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600">
              {deleteMutation.isPending ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : "Deletar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};

export default CarriersTab;
