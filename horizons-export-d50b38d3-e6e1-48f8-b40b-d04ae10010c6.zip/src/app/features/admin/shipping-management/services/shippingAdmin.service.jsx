
import { supabase } from '@/app/api/supabase';

const handleSupabaseError = (error, context) => {
  console.error(`Supabase error in ${context}:`, error);
  throw new Error(`Falha na operação de ${context}: ${error.message}`);
};

const SHIPPING_CARRIERS_TABLE = 'shipping_carriers';
const SHIPPING_ZONES_TABLE = 'shipping_zones';
const SHIPPING_METHODS_TABLE = 'shipping_methods';
const SHIPPING_RATES_TABLE = 'shipping_rates';


export const fetchShippingCarriers = async () => {
  const { data, error } = await supabase
    .from(SHIPPING_CARRIERS_TABLE)
    .select('*')
    .order('name', { ascending: true });
  if (error) handleSupabaseError(error, 'busca de transportadoras');
  return data;
};

export const fetchShippingCarrierById = async (carrierId) => {
  const { data, error } = await supabase
    .from(SHIPPING_CARRIERS_TABLE)
    .select('*')
    .eq('id', carrierId)
    .single();
  if (error) handleSupabaseError(error, `busca da transportadora ID ${carrierId}`);
  return data;
};

export const createShippingCarrier = async (carrierData) => {
  const { data, error } = await supabase
    .from(SHIPPING_CARRIERS_TABLE)
    .insert([carrierData])
    .select()
    .single();
  if (error) handleSupabaseError(error, 'criação de transportadora');
  return data;
};

export const updateShippingCarrier = async (carrierId, carrierData) => {
  const { data, error } = await supabase
    .from(SHIPPING_CARRIERS_TABLE)
    .update(carrierData)
    .eq('id', carrierId)
    .select()
    .single();
  if (error) handleSupabaseError(error, `atualização da transportadora ID ${carrierId}`);
  return data;
};

export const deleteShippingCarrier = async (carrierId) => {
  const { error } = await supabase
    .from(SHIPPING_CARRIERS_TABLE)
    .delete()
    .eq('id', carrierId);
  if (error) handleSupabaseError(error, `deleção da transportadora ID ${carrierId}`);
  return { message: "Transportadora deletada com sucesso." };
};


export const fetchShippingZones = async () => {
  const { data, error } = await supabase
    .from(SHIPPING_ZONES_TABLE)
    .select('*')
    .order('name', { ascending: true });
  if (error) handleSupabaseError(error, 'busca de zonas de entrega');
  return data;
};

export const fetchShippingZoneById = async (zoneId) => {
  const { data, error } = await supabase
    .from(SHIPPING_ZONES_TABLE)
    .select('*')
    .eq('id', zoneId)
    .single();
  if (error) handleSupabaseError(error, `busca da zona de entrega ID ${zoneId}`);
  return data;
};

export const createShippingZone = async (zoneData) => {
  const { data, error } = await supabase
    .from(SHIPPING_ZONES_TABLE)
    .insert([zoneData])
    .select()
    .single();
  if (error) handleSupabaseError(error, 'criação de zona de entrega');
  return data;
};

export const updateShippingZone = async (zoneId, zoneData) => {
  const { data, error } = await supabase
    .from(SHIPPING_ZONES_TABLE)
    .update(zoneData)
    .eq('id', zoneId)
    .select()
    .single();
  if (error) handleSupabaseError(error, `atualização da zona de entrega ID ${zoneId}`);
  return data;
};

export const deleteShippingZone = async (zoneId) => {
  const { error } = await supabase
    .from(SHIPPING_ZONES_TABLE)
    .delete()
    .eq('id', zoneId);
  if (error) handleSupabaseError(error, `deleção da zona de entrega ID ${zoneId}`);
  return { message: "Zona de entrega deletada com sucesso." };
};


export const fetchShippingMethods = async (filters = {}) => {
  let query = supabase
    .from(SHIPPING_METHODS_TABLE)
    .select(`
      *,
      shipping_zones (id, name),
      shipping_carriers (id, name)
    `)
    .order('name', { ascending: true });

  if (filters.shipping_zone_id) {
    query = query.eq('shipping_zone_id', filters.shipping_zone_id);
  }
  
  const { data, error } = await query;
  if (error) handleSupabaseError(error, 'busca de métodos de envio');
  return data;
};

export const fetchShippingMethodById = async (methodId) => {
  const { data, error } = await supabase
    .from(SHIPPING_METHODS_TABLE)
    .select(`
      *,
      shipping_zones (id, name),
      shipping_carriers (id, name)
    `)
    .eq('id', methodId)
    .single();
  if (error) handleSupabaseError(error, `busca do método de envio ID ${methodId}`);
  return data;
};

export const createShippingMethod = async (methodData) => {
  const { data, error } = await supabase
    .from(SHIPPING_METHODS_TABLE)
    .insert([methodData])
    .select()
    .single();
  if (error) handleSupabaseError(error, 'criação de método de envio');
  return data;
};

export const updateShippingMethod = async (methodId, methodData) => {
  const { data, error } = await supabase
    .from(SHIPPING_METHODS_TABLE)
    .update(methodData)
    .eq('id', methodId)
    .select()
    .single();
  if (error) handleSupabaseError(error, `atualização do método de envio ID ${methodId}`);
  return data;
};

export const deleteShippingMethod = async (methodId) => {
  const { error } = await supabase
    .from(SHIPPING_METHODS_TABLE)
    .delete()
    .eq('id', methodId);
  if (error) handleSupabaseError(error, `deleção do método de envio ID ${methodId}`);
  return { message: "Método de envio deletado com sucesso." };
};


export const fetchShippingRates = async (shippingMethodId) => {
  const { data, error } = await supabase
    .from(SHIPPING_RATES_TABLE)
    .select('*')
    .eq('shipping_method_id', shippingMethodId)
    .order('priority', { ascending: true })
    .order('cost', { ascending: true });
  if (error) handleSupabaseError(error, `busca de taxas para o método ID ${shippingMethodId}`);
  return data;
};

export const createShippingRate = async (rateData) => {
  const { data, error } = await supabase
    .from(SHIPPING_RATES_TABLE)
    .insert([rateData])
    .select()
    .single();
  if (error) handleSupabaseError(error, 'criação de taxa de envio');
  return data;
};

export const updateShippingRate = async (rateId, rateData) => {
  const { data, error } = await supabase
    .from(SHIPPING_RATES_TABLE)
    .update(rateData)
    .eq('id', rateId)
    .select()
    .single();
  if (error) handleSupabaseError(error, `atualização da taxa de envio ID ${rateId}`);
  return data;
};

export const deleteShippingRate = async (rateId) => {
  const { error } = await supabase
    .from(SHIPPING_RATES_TABLE)
    .delete()
    .eq('id', rateId);
  if (error) handleSupabaseError(error, `deleção da taxa de envio ID ${rateId}`);
  return { message: "Taxa de envio deletada com sucesso." };
};
