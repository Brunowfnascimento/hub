
import React from 'react';
import { supabase } from '@/app/api/supabase';

const MAIN_SETTINGS_KEY = 'main_settings';
const STORE_ASSETS_BUCKET = 'store-assets';

export const fetchStoreSettings = async () => {
  const { data, error } = await supabase
    .from('store_settings')
    .select('*')
    .eq('settings_key', MAIN_SETTINGS_KEY)
    .maybeSingle(); // Use maybeSingle to return null if not found, instead of erroring

  if (error && error.code !== 'PGRST116') { // PGRST116: "Searched item was not found"
    console.error('Error fetching store settings:', error);
    throw new Error(`Erro ao buscar configurações da loja: ${error.message}`);
  }
  
  if (!data) {
    // Return default/empty settings if no record found
    return {
        settings_key: MAIN_SETTINGS_KEY,
        store_name: 'Minha Loja',
        store_email_contact: '',
        store_phone_contact: '',
        store_address: '',
        store_cnpj: '',
        default_currency: 'BRL',
        logo_url: '',
        favicon_url: '',
    };
  }
  return data;
};

export const updateStoreSettings = async (settingsData) => {
  // Ensure settings_key is always 'main_settings' for upsert
  const dataToUpsert = { ...settingsData, settings_key: MAIN_SETTINGS_KEY, updated_at: new Date().toISOString() };
  
  // Remove id if it's an empty string or not part of the data model for upsert based on settings_key
  if (dataToUpsert.id === '' || dataToUpsert.id === undefined) {
    delete dataToUpsert.id;
  }


  const { data, error } = await supabase
    .from('store_settings')
    .upsert(dataToUpsert, { onConflict: 'settings_key' })
    .select()
    .single();

  if (error) {
    console.error('Error updating store settings:', error);
    throw new Error(`Erro ao atualizar configurações da loja: ${error.message}`);
  }
  return data;
};


export const uploadStoreAsset = async (file, assetType) => {
  if (!file) throw new Error("Nenhum arquivo fornecido para upload.");

  const fileName = `${assetType}-${Date.now()}.${file.name.split('.').pop()}`;
  const filePath = `${fileName}`; // Store assets at the root of the bucket for simplicity

  const { data, error } = await supabase.storage
    .from(STORE_ASSETS_BUCKET)
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: true, 
    });

  if (error) {
    console.error(`Error uploading ${assetType}:`, error);
    throw new Error(`Erro ao fazer upload do ${assetType}: ${error.message}`);
  }

  const { data: publicUrlData } = supabase.storage
    .from(STORE_ASSETS_BUCKET)
    .getPublicUrl(data.path);
  
  if (!publicUrlData || !publicUrlData.publicUrl) {
     throw new Error(`Não foi possível obter URL pública para ${assetType}.`);
  }

  return publicUrlData.publicUrl;
};
