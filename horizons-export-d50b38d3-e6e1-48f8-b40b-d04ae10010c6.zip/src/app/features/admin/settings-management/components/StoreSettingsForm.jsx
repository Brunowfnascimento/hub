
import React, { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { StoreSettingsFormDataSchema } from '@/app/types/settings.types.jsx';
import { UploadCloud, Image as ImageIcon } from 'lucide-react';

const StoreSettingsForm = ({ 
  settings, 
  onSubmit, 
  isSubmitting,
  onLogoUpload,
  onFaviconUpload,
  isUploadingLogo,
  isUploadingFavicon
}) => {
  const [formData, setFormData] = useState(StoreSettingsFormDataSchema);
  const [logoPreview, setLogoPreview] = useState(null);
  const [faviconPreview, setFaviconPreview] = useState(null);
  const logoInputRef = useRef(null);
  const faviconInputRef = useRef(null);

  useEffect(() => {
    if (settings) {
      setFormData({
        store_name: settings.store_name || '',
        store_email_contact: settings.store_email_contact || '',
        store_phone_contact: settings.store_phone_contact || '',
        store_address: settings.store_address || '',
        store_cnpj: settings.store_cnpj || '',
        default_currency: settings.default_currency || 'BRL',
        logo_url: settings.logo_url || '',
        favicon_url: settings.favicon_url || '',
      });
      if (settings.logo_url) setLogoPreview(settings.logo_url);
      if (settings.favicon_url) setFaviconPreview(settings.favicon_url);
    }
  }, [settings]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e, fileType) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      if (fileType === 'logo') {
        setLogoPreview(reader.result);
        onLogoUpload(file);
      } else if (fileType === 'favicon') {
        setFaviconPreview(reader.result);
        onFaviconUpload(file);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // onSubmit will receive formData which includes the latest logo_url and favicon_url
    // that should have been updated by the parent tab component after successful uploads.
    onSubmit(formData); 
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="store_name" className="dark:text-slate-300">Nome da Loja</Label>
          <Input id="store_name" name="store_name" value={formData.store_name} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
        </div>
        <div>
          <Label htmlFor="store_email_contact" className="dark:text-slate-300">Email de Contato</Label>
          <Input id="store_email_contact" name="store_email_contact" type="email" value={formData.store_email_contact} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="store_phone_contact" className="dark:text-slate-300">Telefone de Contato</Label>
          <Input id="store_phone_contact" name="store_phone_contact" value={formData.store_phone_contact} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
        </div>
        <div>
          <Label htmlFor="store_cnpj" className="dark:text-slate-300">CNPJ</Label>
          <Input id="store_cnpj" name="store_cnpj" value={formData.store_cnpj} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
        </div>
      </div>
      
      <div>
        <Label htmlFor="store_address" className="dark:text-slate-300">Endereço da Loja</Label>
        <Textarea id="store_address" name="store_address" value={formData.store_address} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
      </div>

      <div>
        <Label htmlFor="default_currency" className="dark:text-slate-300">Moeda Padrão</Label>
        <Input id="default_currency" name="default_currency" value={formData.default_currency} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        <div>
          <Label htmlFor="logo" className="block mb-2 dark:text-slate-300">Logo da Loja</Label>
          <div className="flex items-center gap-4">
            {logoPreview ? (
              <img-replace src={logoPreview} alt="Pré-visualização do Logo" className="h-20 w-auto object-contain border rounded dark:border-slate-600" />
            ) : (
              <div className="h-20 w-20 flex items-center justify-center border rounded bg-slate-100 dark:bg-slate-700 dark:border-slate-600">
                <ImageIcon className="h-10 w-10 text-slate-400 dark:text-slate-500" />
              </div>
            )}
            <Button type="button" variant="outline" onClick={() => logoInputRef.current?.click()} disabled={isUploadingLogo} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
              {isUploadingLogo ? <LoadingSpinner size="h-4 w-4 mr-2"/> : <UploadCloud className="h-4 w-4 mr-2"/>}
              {isUploadingLogo ? 'Enviando...' : 'Alterar Logo'}
            </Button>
            <input type="file" ref={logoInputRef} onChange={(e) => handleFileChange(e, 'logo')} accept="image/*" className="hidden" />
          </div>
           {formData.logo_url && <p className="text-xs text-slate-500 mt-2 dark:text-slate-400">URL atual: {formData.logo_url}</p>}
        </div>

        <div>
          <Label htmlFor="favicon" className="block mb-2 dark:text-slate-300">Favicon</Label>
           <div className="flex items-center gap-4">
            {faviconPreview ? (
              <img-replace src={faviconPreview} alt="Pré-visualização do Favicon" className="h-10 w-10 object-contain border rounded dark:border-slate-600" />
            ) : (
               <div className="h-10 w-10 flex items-center justify-center border rounded bg-slate-100 dark:bg-slate-700 dark:border-slate-600">
                <ImageIcon className="h-5 w-5 text-slate-400 dark:text-slate-500" />
              </div>
            )}
            <Button type="button" variant="outline" onClick={() => faviconInputRef.current?.click()} disabled={isUploadingFavicon} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
              {isUploadingFavicon ? <LoadingSpinner size="h-4 w-4 mr-2"/> : <UploadCloud className="h-4 w-4 mr-2"/>}
              {isUploadingFavicon ? 'Enviando...' : 'Alterar Favicon'}
            </Button>
            <input type="file" ref={faviconInputRef} onChange={(e) => handleFileChange(e, 'favicon')} accept="image/png, image/x-icon, image/svg+xml" className="hidden" />
          </div>
          {formData.favicon_url && <p className="text-xs text-slate-500 mt-2 dark:text-slate-400">URL atual: {formData.favicon_url}</p>}
        </div>
      </div>

      <div className="flex justify-end pt-4">
        <Button type="submit" disabled={isSubmitting || isUploadingLogo || isUploadingFavicon} className="bg-sky-500 hover:bg-sky-600 text-white">
          {isSubmitting ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : 'Salvar Configurações'}
        </Button>
      </div>
    </form>
  );
};

export default StoreSettingsForm;
