
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  fetchStoreSettings, 
  updateStoreSettings,
  uploadStoreAsset 
} from '@/app/features/admin/settings-management/services/settingsAdmin.service.jsx';
import StoreSettingsForm from './StoreSettingsForm';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const StoreSettingsTab = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const [isUploadingFavicon, setIsUploadingFavicon] = useState(false);

  const { data: settings, isLoading, error } = useQuery({
    queryKey: ['storeSettings'],
    queryFn: fetchStoreSettings,
  });

  const updateSettingsMutation = useMutation({
    mutationFn: updateStoreSettings,
    onSuccess: (updatedData) => {
      queryClient.setQueryData(['storeSettings'], updatedData); // Optimistically update
      queryClient.invalidateQueries({ queryKey: ['storeSettings'] });
      toast({
        title: "Sucesso!",
        description: "Configurações da loja atualizadas.",
        className: "bg-green-500 text-white dark:bg-green-700",
      });
    },
    onError: (err) => {
      toast({
        title: "Erro ao atualizar",
        description: err.message,
        variant: "destructive",
      });
    },
  });
  
  const handleFileUpload = async (file, assetType, setIsUploading, fieldToUpdate) => {
    if (!file) return;
    setIsUploading(true);
    try {
      const assetUrl = await uploadStoreAsset(file, assetType);
      // Get current settings to merge
      const currentSettings = queryClient.getQueryData(['storeSettings']) || {};
      const updatedSettingsPayload = { ...currentSettings, [fieldToUpdate]: assetUrl };
      // Remove id if it was part of currentSettings but should not be in payload for upsert
      // if (updatedSettingsPayload.id === undefined && currentSettings.id) delete updatedSettingsPayload.id;
      
      updateSettingsMutation.mutate(updatedSettingsPayload); // This will save the URL

    } catch (uploadError) {
      toast({
        title: `Erro no Upload do ${assetType === 'logo' ? 'Logo' : 'Favicon'}`,
        description: uploadError.message,
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleLogoUpload = (file) => {
    handleFileUpload(file, 'logo', setIsUploadingLogo, 'logo_url');
  };

  const handleFaviconUpload = (file) => {
    handleFileUpload(file, 'favicon', setIsUploadingFavicon, 'favicon_url');
  };

  const handleSubmit = (formData) => {
    // FormData contains text fields; logo_url and favicon_url should be updated
    // if uploads were successful. The settings from useQuery (or queryClient.getQueryData)
    // should have the most recent URLs.
    const currentSettings = queryClient.getQueryData(['storeSettings']) || {};
    const payload = {
        ...currentSettings, // Start with current settings (which include latest URLs)
        ...formData, // Override with form text data
    };
    updateSettingsMutation.mutate(payload);
  };

  if (isLoading) return <div className="flex justify-center items-center h-64"><LoadingSpinner size="h-12 w-12" /></div>;
  if (error) return <ErrorDisplay message={error.message} />;

  return (
    <Card className="dark:bg-slate-800 dark:border-slate-700">
      <CardHeader>
        <CardTitle className="dark:text-slate-100">Configurações da Loja</CardTitle>
        <CardDescription className="dark:text-slate-400">
          Gerencie as informações básicas, contatos e identidade visual da sua loja.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <StoreSettingsForm
          settings={settings}
          onSubmit={handleSubmit}
          isSubmitting={updateSettingsMutation.isPending}
          onLogoUpload={handleLogoUpload}
          onFaviconUpload={handleFaviconUpload}
          isUploadingLogo={isUploadingLogo}
          isUploadingFavicon={isUploadingFavicon}
        />
      </CardContent>
    </Card>
  );
};

export default StoreSettingsTab;
