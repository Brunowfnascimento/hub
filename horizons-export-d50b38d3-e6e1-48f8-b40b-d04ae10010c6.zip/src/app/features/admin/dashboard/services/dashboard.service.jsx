
import React from 'react';
import { supabase } from '@/app/api/supabase';

const thirtyDaysAgo = () => {
  const date = new Date();
  date.setDate(date.getDate() - 30);
  return date.toISOString();
};

export const fetchDashboardMetrics = async () => {
  const metrics = {
    totalSales: 0,
    totalOrders: 0,
    averageOrderValue: 0,
    newCustomers: 0,
    activeProducts: 0,
    lowStockProductsCount: 0,
  };

  const salesAndOrdersPromise = supabase
    .from('orders')
    .select('grand_total, user_id', { count: 'exact' })
    .gte('placed_at', thirtyDaysAgo())
    .not('status', 'in', '("cancelled", "failed")');

  const newCustomersPromise = supabase
    .from('profiles')
    .select('id', { count: 'exact' })
    .gte('created_at', thirtyDaysAgo());

  const activeProductsPromise = supabase
    .from('products')
    .select('id', { count: 'exact' })
    .eq('is_active', true);
  
  const lowStockProductsPromise = supabase
    .from('inventory')
    .select('variant_id, quantity', { count: 'exact' })
    .lt('quantity', 5);


  const [
    { data: ordersData, count: totalOrdersCount, error: ordersError },
    { count: newCustomersCount, error: customersError },
    { count: activeProductsCount, error: productsError },
    { data: lowStockData, count: lowStockCount, error: lowStockError }
  ] = await Promise.all([
    salesAndOrdersPromise,
    newCustomersPromise,
    activeProductsPromise,
    lowStockProductsPromise
  ]);

  if (ordersError) throw new Error(`Erro ao buscar pedidos: ${ordersError.message}`);
  if (customersError) throw new Error(`Erro ao buscar clientes: ${customersError.message}`);
  if (productsError) throw new Error(`Erro ao buscar produtos: ${productsError.message}`);
  if (lowStockError) throw new Error(`Erro ao buscar produtos com baixo estoque: ${lowStockError.message}`);

  metrics.totalOrders = totalOrdersCount || 0;
  metrics.totalSales = ordersData?.reduce((sum, order) => sum + order.grand_total, 0) || 0;
  metrics.averageOrderValue = metrics.totalOrders > 0 ? metrics.totalSales / metrics.totalOrders : 0;
  metrics.newCustomers = newCustomersCount || 0;
  metrics.activeProducts = activeProductsCount || 0;
  
  const uniqueLowStockVariants = new Set(lowStockData?.map(item => item.variant_id));
  metrics.lowStockProductsCount = uniqueLowStockVariants.size;


  return metrics;
};

export const fetchSalesOverTime = async (period = 'last_30_days') => {
  let dateFilter = thirtyDaysAgo();
  if (period === 'last_7_days') {
    const date = new Date();
    date.setDate(date.getDate() - 7);
    dateFilter = date.toISOString();
  }

  const { data, error } = await supabase
    .from('orders')
    .select('placed_at, grand_total')
    .gte('placed_at', dateFilter)
    .not('status', 'in', '("cancelled", "failed")')
    .order('placed_at', { ascending: true });

  if (error) throw new Error(`Erro ao buscar vendas ao longo do tempo: ${error.message}`);

  const salesByDate = data.reduce((acc, order) => {
    const date = new Date(order.placed_at).toISOString().split('T')[0];
    acc[date] = (acc[date] || 0) + order.grand_total;
    return acc;
  }, {});

  return Object.entries(salesByDate).map(([date, sales]) => ({ date, sales }));
};

export const fetchRecentOrders = async (limit = 5) => {
  const { data, error } = await supabase
    .from('orders')
    .select('id, order_number, customer_name, grand_total, status, placed_at')
    .order('placed_at', { ascending: false })
    .limit(limit);

  if (error) throw new Error(`Erro ao buscar pedidos recentes: ${error.message}`);
  return data;
};

export const fetchTopSellingProducts = async (limit = 5, period = 'last_30_days') => {
  let dateFilter = thirtyDaysAgo();
  
  const { data: orderItems, error: orderItemsError } = await supabase
    .from('order_items')
    .select(`
      quantity,
      variant_id,
      product_snapshot,
      orders ( placed_at )
    `)
    .gte('orders.placed_at', dateFilter);

  if (orderItemsError) throw new Error(`Erro ao buscar itens de pedido: ${orderItemsError.message}`);

  const productSales = orderItems.reduce((acc, item) => {
    const productId = item.product_snapshot?.product_id || item.variant_id; // Fallback if product_id not in snapshot
    const variantId = item.variant_id;
    
    if (!acc[variantId]) {
      acc[variantId] = {
        product_id: productId,
        variant_id: variantId,
        product_name: item.product_snapshot?.name || 'Produto Desconhecido',
        variant_sku: item.product_snapshot?.sku || 'N/A',
        total_sold: 0,
        product_slug: item.product_snapshot?.slug || ''
      };
    }
    acc[variantId].total_sold += item.quantity;
    return acc;
  }, {});

  const sortedProducts = Object.values(productSales)
    .sort((a, b) => b.total_sold - a.total_sold)
    .slice(0, limit);
  
  return sortedProducts;
};


export const fetchLowStockProducts = async (limit = 5, threshold = 5) => {
  const { data, error } = await supabase
    .from('inventory')
    .select(`
      quantity,
      product_variants (
        id,
        sku,
        products (
          id,
          name,
          slug
        )
      )
    `)
    .lt('quantity', threshold)
    .order('quantity', { ascending: true })
    .limit(limit);

  if (error) throw new Error(`Erro ao buscar produtos com baixo estoque: ${error.message}`);

  return data.map(item => ({
    product_id: item.product_variants?.products?.id,
    variant_id: item.product_variants?.id,
    product_name: item.product_variants?.products?.name || 'Produto Desconhecido',
    variant_sku: item.product_variants?.sku || 'N/A',
    quantity: item.quantity,
    product_slug: item.product_variants?.products?.slug || ''
  }));
};
