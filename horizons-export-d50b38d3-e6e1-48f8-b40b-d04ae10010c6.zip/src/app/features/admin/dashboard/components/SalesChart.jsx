
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { BarChart } from 'lucide-react'; // Placeholder icon

const SalesChart = ({ data, isLoading }) => {
  // Placeholder for chart implementation
  // In a real scenario, you would use a library like Recharts or Chart.js here
  // and map `data` (which would be [{ date: 'YYYY-MM-DD', sales: 123.45 }, ...])
  // to the chart's data format.

  return (
    <Card className="shadow-lg col-span-1 lg:col-span-2 dark:bg-slate-800">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-slate-700 dark:text-slate-200">Vendas ao Longo do Tempo</CardTitle>
      </CardHeader>
      <CardContent className="h-[350px] flex items-center justify-center">
        {isLoading ? (
          <LoadingSpinner size="h-10 w-10" />
        ) : (
          <div className="text-center text-slate-500 dark:text-slate-400">
            <BarChart className="h-12 w-12 mx-auto mb-2" />
            <p>Gráfico de vendas será exibido aqui.</p>
            {data && data.length > 0 ? (
              <p className="text-xs mt-1">Dados recebidos: {data.length} pontos.</p>
            ) : (
              <p className="text-xs mt-1">Nenhum dado de vendas para exibir no período.</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SalesChart;
