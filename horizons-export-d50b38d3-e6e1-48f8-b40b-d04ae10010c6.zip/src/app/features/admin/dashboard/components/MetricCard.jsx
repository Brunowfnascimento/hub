
    import React from 'react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { motion } from 'framer-motion';
    import { Skeleton } from '@/components/ui/skeleton.jsx';
    
    const MetricCard = ({ title, value, icon, previousValue, isLoading, formatFn }) => {
      const IconComponent = icon;
      const formattedValue = formatFn ? formatFn(value) : value;
      let percentageChange = null;
      let changeType = 'neutral';
    
      if (previousValue !== undefined && previousValue !== null && typeof value === 'number' && typeof previousValue === 'number') {
        if (previousValue !== 0) {
          percentageChange = ((value - previousValue) / previousValue) * 100;
        } else if (value > 0) {
          percentageChange = 100;
        }
        if (percentageChange > 0) changeType = 'positive';
        if (percentageChange < 0) changeType = 'negative';
      }
    
      if (isLoading) {
        return (
          <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 dark:bg-slate-800">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-8 w-8 rounded-full" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-10 w-1/2 mb-2" />
              <Skeleton className="h-4 w-full" />
            </CardContent>
          </Card>
        );
      }
    
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 dark:bg-slate-800 dark:border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">{title}</CardTitle>
              {IconComponent && <IconComponent className="h-6 w-6 text-sky-500 dark:text-sky-400" />}
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-800 dark:text-slate-100">{formattedValue}</div>
              {percentageChange !== null && (
                <p className={`text-xs mt-1 ${
                  changeType === 'positive' ? 'text-green-600 dark:text-green-400' : 
                  changeType === 'negative' ? 'text-red-600 dark:text-red-400' :
                  'text-slate-500 dark:text-slate-400'
                }`}>
                  {percentageChange >= 0 ? '+' : ''}{percentageChange.toFixed(1)}% em relação ao período anterior
                </p>
              )}
               {percentageChange === null && (
                 <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Dados dos últimos 30 dias</p>
               )}
            </CardContent>
          </Card>
        </motion.div>
      );
    };
    
    export default MetricCard;
  