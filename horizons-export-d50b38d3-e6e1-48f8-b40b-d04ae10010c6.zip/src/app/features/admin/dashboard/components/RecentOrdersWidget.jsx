
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import OrderStatusBadge from '@/app/features/admin/order-management/components/OrderStatusBadge';
import { Eye } from 'lucide-react';

const RecentOrdersWidget = ({ orders, isLoading }) => {
  const formatCurrency = (amount) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount);
  const formatDate = (dateString) => new Date(dateString).toLocaleDateString('pt-BR');

  return (
    <Card className="shadow-lg dark:bg-slate-800">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-slate-700 dark:text-slate-200">Pedidos Recentes</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-40 flex items-center justify-center">
            <LoadingSpinner size="h-8 w-8" />
          </div>
        ) : !orders || orders.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">Nenhum pedido recente encontrado.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent dark:hover:bg-transparent">
                  <TableHead className="dark:text-slate-300">Pedido</TableHead>
                  <TableHead className="dark:text-slate-300">Cliente</TableHead>
                  <TableHead className="text-right dark:text-slate-300">Total</TableHead>
                  <TableHead className="dark:text-slate-300">Status</TableHead>
                  <TableHead className="text-center dark:text-slate-300">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map(order => (
                  <TableRow key={order.id} className="dark:hover:bg-slate-700/50">
                    <TableCell className="font-medium text-sky-600 dark:text-sky-400">{order.order_number}</TableCell>
                    <TableCell className="dark:text-slate-300">{order.customer_name || 'N/A'}</TableCell>
                    <TableCell className="text-right dark:text-slate-200">{formatCurrency(order.grand_total)}</TableCell>
                    <TableCell><OrderStatusBadge status={order.status} /></TableCell>
                    <TableCell className="text-center">
                      <Button variant="outline" size="sm" asChild className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                        <Link to={`/admin/orders?orderId=${order.id}`}>
                          <Eye className="h-4 w-4" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentOrdersWidget;
