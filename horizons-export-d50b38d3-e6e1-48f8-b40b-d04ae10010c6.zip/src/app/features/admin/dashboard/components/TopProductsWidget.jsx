
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { Button } from '@/components/ui/button';
import { Edit2 } from 'lucide-react';

const TopProductsWidget = ({ products, isLoading }) => {
  return (
    <Card className="shadow-lg dark:bg-slate-800">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-slate-700 dark:text-slate-200">Produtos Mais Vendidos</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-40 flex items-center justify-center">
            <LoadingSpinner size="h-8 w-8" />
          </div>
        ) : !products || products.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">Nenhum produto vendido recentemente.</p>
        ) : (
          <ul className="space-y-3">
            {products.map(product => (
              <li key={product.variant_id || product.product_id} className="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-700 last:border-b-0">
                <div>
                  <Link to={`/admin/products/edit/${product.product_id}`} className="font-medium text-sky-600 hover:underline dark:text-sky-400">
                    {product.product_name}
                  </Link>
                  {product.variant_sku && <p className="text-xs text-slate-500 dark:text-slate-400">SKU: {product.variant_sku}</p>}
                </div>
                <div className="text-right">
                  <span className="font-semibold text-slate-800 dark:text-slate-100">{product.total_sold} un.</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
};

export default TopProductsWidget;
