
    import React from 'react';
    import { supabase } from '@/app/api/supabase';
    
    const BAN_DURATION_YEARS = 100; 
    
    export const fetchAdminCustomers = async ({
      page = 1,
      limit = 10,
      searchTerm = '',
      role = null,
      sortBy = 'created_at',
      sortOrder = 'desc',
    }) => {
      const offset = (page - 1) * limit;
    
      let query = supabase
        .from('profiles')
        .select(`
          id,
          full_name,
          cpf_cnpj,
          phone,
          role,
          auth_user:id!inner ( 
            email,
            created_at,
            last_sign_in_at,
            banned_until
          ),
          orders (
            id,
            grand_total
          )
        `, { count: 'exact' });
    
      if (searchTerm) {
        query = query.or(`full_name.ilike.%${searchTerm}%,auth_user.email.ilike.%${searchTerm}%`);
      }
    
      if (role && role !== 'all') {
        query = query.eq('role', role);
      }
      
      let actualSortBy = sortBy;
      let foreignTable;
      if (sortBy === 'email') {
        actualSortBy = 'email';
        foreignTable = 'auth_user';
      } else if (sortBy === 'created_at' && !['full_name', 'cpf_cnpj', 'phone', 'role'].includes(sortBy)) {
        actualSortBy = 'created_at';
        foreignTable = 'auth_user';
      } else if (sortBy === 'last_sign_in_at') {
        actualSortBy = 'last_sign_in_at';
        foreignTable = 'auth_user';
      } else {
        actualSortBy = sortBy;
      }
    
      if (foreignTable) {
        query = query.order(actualSortBy, { ascending: sortOrder === 'asc', foreignTable: foreignTable });
      } else {
        query = query.order(actualSortBy, { ascending: sortOrder === 'asc' });
      }
    
      query = query.range(offset, offset + limit - 1);
    
      const { data, error, count } = await query;
    
      if (error) {
        console.error("Error fetching customers:", error);
        throw new Error(`Erro ao buscar clientes: ${error.message}`);
      }
    
      const customers = data.map(profile => {
        const user = profile.auth_user; 
        const orders = profile.orders || [];
        return {
          id: profile.id,
          email: user?.email || 'N/A',
          full_name: profile.full_name || 'N/A',
          cpf_cnpj: profile.cpf_cnpj || '',
          phone: profile.phone || '',
          role: profile.role || 'customer',
          created_at: user?.created_at,
          last_sign_in_at: user?.last_sign_in_at,
          banned_until: user?.banned_until,
          total_spent: orders.reduce((sum, o) => sum + o.grand_total, 0),
          order_count: orders.length,
        };
      });
      
      return { customers, totalCount: count };
    };
    
    export const fetchAdminCustomerById = async (userId) => {
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select(`
          id,
          full_name,
          cpf_cnpj,
          phone,
          role,
          avatar_url,
          auth_user:id!inner (
            email,
            created_at,
            last_sign_in_at,
            banned_until
          )
        `)
        .eq('id', userId)
        .single();
    
      if (profileError) throw new Error(`Erro ao buscar perfil do cliente: ${profileError.message}`);
      if (!profileData) throw new Error('Cliente não encontrado.');
    
      const { data: addresses, error: addressesError } = await supabase
        .from('addresses')
        .select('*')
        .eq('user_id', userId);
    
      if (addressesError) throw new Error(`Erro ao buscar endereços: ${addressesError.message}`);
    
      const { data: recentOrders, error: ordersError } = await supabase
        .from('orders')
        .select('id, order_number, placed_at, grand_total, status')
        .eq('user_id', userId)
        .order('placed_at', { ascending: false })
        .limit(5);
    
      if (ordersError) throw new Error(`Erro ao buscar pedidos: ${ordersError.message}`);
      
      const user = profileData.auth_user;
      const customerProfile = {
        id: profileData.id,
        email: user?.email,
        full_name: profileData.full_name,
        cpf_cnpj: profileData.cpf_cnpj,
        phone: profileData.phone,
        role: profileData.role,
        avatar_url: profileData.avatar_url,
        created_at: user?.created_at,
        last_sign_in_at: user?.last_sign_in_at,
        banned_until: user?.banned_until,
      };
    
      return {
        profile: customerProfile,
        addresses: addresses || [],
        recent_orders: recentOrders || [],
      };
    };
    
    export const updateCustomerProfileAdmin = async (userId, profileData) => {
      const { data, error } = await supabase
        .from('profiles')
        .update({
          full_name: profileData.full_name,
          cpf_cnpj: profileData.cpf_cnpj,
          phone: profileData.phone,
          role: profileData.role,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userId)
        .select()
        .single();
    
      if (error) throw new Error(`Erro ao atualizar perfil do cliente: ${error.message}`);
      return data;
    };
    
    export const toggleCustomerBanStatus = async (userId, currentBannedUntil) => {
      let newBannedUntil = null;
      if (!currentBannedUntil || new Date(currentBannedUntil) < new Date()) {
        const banDate = new Date();
        banDate.setFullYear(banDate.getFullYear() + BAN_DURATION_YEARS);
        newBannedUntil = banDate.toISOString();
      } else {
        newBannedUntil = null;
      }
    
      const { data, error } = await supabase.rpc('admin_update_user_ban', {
        user_id_to_update: userId,
        banned_until_value: newBannedUntil
      });
    
      if (error) {
        console.error("Error toggling ban status (RPC):", error);
        throw new Error(`Erro ao alterar status de banimento: ${error.message}. Verifique se a função 'admin_update_user_ban' existe e tem as permissões corretas.`);
      }
      
      const { data: updatedProfile, error: fetchError } = await supabase
        .from('profiles')
        .select('id, auth_user:id(banned_until)')
        .eq('id', userId)
        .single();
    
      if (fetchError) throw new Error(`Erro ao buscar usuário após atualização do ban: ${fetchError.message}`);
      
      return { ...updatedProfile, banned_until: updatedProfile.auth_user.banned_until };
    };
    
    export const deleteCustomerAdmin = async (userId) => {
      const { data, error } = await supabase.rpc('admin_delete_user', { user_id_to_delete: userId });
    
      if (error) {
        console.error("Error deleting customer (RPC):", error);
        throw new Error(`Erro ao deletar cliente: ${error.message}. Verifique se a função 'admin_delete_user' existe e tem as permissões corretas.`);
      }
      return data; 
    };
  