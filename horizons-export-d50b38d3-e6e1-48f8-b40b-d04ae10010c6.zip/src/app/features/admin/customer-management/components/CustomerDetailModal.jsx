
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchAdminCustomerById } from '@/app/features/admin/customer-management/services/customerAdmin.service.jsx';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Link } from 'react-router-dom';
import { ScrollArea } from '@/components/ui/scroll-area';
import OrderStatusBadge from '@/app/features/admin/order-management/components/OrderStatusBadge';

const CustomerDetailModal = ({ userId, isOpen, onClose }) => {
  const { data: customerDetails, isLoading, error, isFetching } = useQuery({
    queryKey: ['adminCustomerDetail', userId],
    queryFn: () => fetchAdminCustomerById(userId),
    enabled: !!userId && isOpen, // Only fetch when modal is open and userId is provided
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const profile = customerDetails?.profile;
  const addresses = customerDetails?.addresses;
  const recentOrders = customerDetails?.recent_orders;

  const formatCurrency = (amount) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount);
  const formatDate = (dateString) => dateString ? new Date(dateString).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A';
  const isBanned = profile?.banned_until && new Date(profile.banned_until) > new Date();

  const renderContent = () => {
    if (isLoading || isFetching) return <div className="h-96 flex items-center justify-center"><LoadingSpinner size="h-12 w-12" /></div>;
    if (error) return <ErrorDisplay message={error.message} />;
    if (!profile) return <p className="text-center py-8 dark:text-slate-300">Cliente não encontrado.</p>;

    return (
      <ScrollArea className="max-h-[70vh] pr-4">
        <div className="space-y-6">
          <section>
            <DialogTitle className="text-2xl mb-4 dark:text-slate-100">Detalhes do Cliente</DialogTitle>
            <div className="flex items-center space-x-4 mb-6">
              <Avatar className="h-20 w-20">
                <AvatarImage src={profile.avatar_url || undefined} alt={profile.full_name} />
                <AvatarFallback className="text-2xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                  {profile.full_name ? profile.full_name.charAt(0).toUpperCase() : 'U'}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-xl font-semibold dark:text-slate-100">{profile.full_name || 'Nome não informado'}</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">{profile.email}</p>
                <Badge variant={isBanned ? "destructive" : "default"} className={`mt-1 ${isBanned ? 'bg-red-500' : 'bg-green-500'} text-white`}>
                  {isBanned ? `Banido até ${formatDate(profile.banned_until)}` : 'Ativo'}
                </Badge>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 text-sm">
              <p><strong className="dark:text-slate-300">ID:</strong> <span className="dark:text-slate-400">{profile.id}</span></p>
              <p><strong className="dark:text-slate-300">CPF/CNPJ:</strong> <span className="dark:text-slate-400">{profile.cpf_cnpj || 'N/A'}</span></p>
              <p><strong className="dark:text-slate-300">Telefone:</strong> <span className="dark:text-slate-400">{profile.phone || 'N/A'}</span></p>
              <p><strong className="dark:text-slate-300">Papel:</strong> <span className="dark:text-slate-400">{profile.role || 'customer'}</span></p>
              <p><strong className="dark:text-slate-300">Cadastro:</strong> <span className="dark:text-slate-400">{formatDate(profile.created_at)}</span></p>
              <p><strong className="dark:text-slate-300">Último Login:</strong> <span className="dark:text-slate-400">{formatDate(profile.last_sign_in_at)}</span></p>
            </div>
          </section>

          <section>
            <h4 className="text-lg font-semibold mb-2 dark:text-slate-200">Endereços Salvos ({addresses?.length || 0})</h4>
            {addresses && addresses.length > 0 ? (
              <div className="space-y-3">
                {addresses.map(addr => (
                  <div key={addr.id} className="p-3 border rounded-md bg-slate-50 dark:bg-slate-700/50 dark:border-slate-600 text-xs">
                    <p className="font-medium dark:text-slate-200">{addr.address_line1}, {addr.address_number}</p>
                    {addr.address_line2 && <p className="dark:text-slate-300">{addr.address_line2}</p>}
                    <p className="dark:text-slate-300">{addr.address_district} - {addr.city}, {addr.state_province}</p>
                    <p className="dark:text-slate-300">CEP: {addr.postal_code} {addr.country && `(${addr.country})`}</p>
                    <div className="mt-1">
                      {addr.is_default_shipping && <Badge variant="outline" className="mr-1 text-green-700 border-green-500 bg-green-100 dark:text-green-300 dark:border-green-600 dark:bg-green-900/50">Entrega Padrão</Badge>}
                      {addr.is_default_billing && <Badge variant="outline" className="text-blue-700 border-blue-500 bg-blue-100 dark:text-blue-300 dark:border-blue-600 dark:bg-blue-900/50">Cobrança Padrão</Badge>}
                    </div>
                  </div>
                ))}
              </div>
            ) : <p className="text-sm text-slate-500 dark:text-slate-400">Nenhum endereço cadastrado.</p>}
          </section>

          <section>
            <h4 className="text-lg font-semibold mb-2 dark:text-slate-200">Pedidos Recentes ({recentOrders?.length || 0})</h4>
            {recentOrders && recentOrders.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent dark:hover:bg-transparent">
                    <TableHead className="dark:text-slate-300">Nº Pedido</TableHead>
                    <TableHead className="dark:text-slate-300">Data</TableHead>
                    <TableHead className="text-right dark:text-slate-300">Total</TableHead>
                    <TableHead className="dark:text-slate-300">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentOrders.map(order => (
                    <TableRow key={order.id} className="dark:hover:bg-slate-700/50">
                      <TableCell>
                        <Link to={`/admin/orders?orderId=${order.id}`} className="text-sky-600 hover:underline dark:text-sky-400">
                          {order.order_number}
                        </Link>
                      </TableCell>
                      <TableCell className="dark:text-slate-300">{formatDate(order.placed_at)}</TableCell>
                      <TableCell className="text-right dark:text-slate-200">{formatCurrency(order.grand_total)}</TableCell>
                      <TableCell><OrderStatusBadge status={order.status} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : <p className="text-sm text-slate-500 dark:text-slate-400">Nenhum pedido recente.</p>}
          </section>
        </div>
      </ScrollArea>
    );
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl md:max-w-3xl dark:bg-slate-800 dark:border-slate-700">
        <DialogHeader>
          {/* Title is inside renderContent for better layout control with Avatar */}
        </DialogHeader>
        {renderContent()}
      </DialogContent>
    </Dialog>
  );
};

export default CustomerDetailModal;
