
import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';

const CustomerProfileEditForm = ({ profile, onSubmit, isSubmitting, onCancel }) => {
  const [formData, setFormData] = useState({
    full_name: '',
    cpf_cnpj: '',
    phone: '',
    role: 'customer',
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        full_name: profile.full_name || '',
        cpf_cnpj: profile.cpf_cnpj || '',
        phone: profile.phone || '',
        role: profile.role || 'customer',
      });
    }
  }, [profile]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleRoleChange = (value) => {
    setFormData(prev => ({ ...prev, role: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  const customerRoles = [
    { value: 'customer', label: 'Cliente' },
    { value: 'admin', label: 'Administrador' },
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <Label htmlFor="full_name" className="dark:text-slate-300">Nome Completo</Label>
        <Input id="full_name" name="full_name" value={formData.full_name} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
      </div>
      <div>
        <Label htmlFor="cpf_cnpj" className="dark:text-slate-300">CPF/CNPJ</Label>
        <Input id="cpf_cnpj" name="cpf_cnpj" value={formData.cpf_cnpj} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
      </div>
      <div>
        <Label htmlFor="phone" className="dark:text-slate-300">Telefone</Label>
        <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50" />
      </div>
      <div>
        <Label htmlFor="role" className="dark:text-slate-300">Papel (Role)</Label>
        <Select value={formData.role} onValueChange={handleRoleChange}>
          <SelectTrigger id="role" className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
            <SelectValue placeholder="Selecione o Papel" />
          </SelectTrigger>
          <SelectContent className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-50">
            {customerRoles.map(r => (
              <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting} className="bg-sky-500 hover:bg-sky-600 text-white">
          {isSubmitting ? <LoadingSpinner size="h-4 w-4 mr-2" color="text-white" /> : 'Salvar Alterações'}
        </Button>
      </div>
    </form>
  );
};

export default CustomerProfileEditForm;
