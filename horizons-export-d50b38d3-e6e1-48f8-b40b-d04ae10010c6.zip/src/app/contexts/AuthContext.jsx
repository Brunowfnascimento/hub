
    import React, { createContext, useState, useEffect, useContext, useRef, useCallback } from 'react';
    import { supabase } from '@/app/api/supabase';
    
    const AuthContext = createContext();
    
    const initialAuthState = {
      session: null,
      user: null,
      userProfile: null,
      isLoadingUser: true,
    };
    
    // Hook para lógica de autenticação
    const useAuthLogic = () => {
      const [authState, setAuthState] = useState(initialAuthState);
      const initialSessionCheckDone = useRef(false);
      const initialAuthStateChangeProcessed = useRef(false);
    
      const setLoadingState = useCallback((isLoading) => {
        setAuthState(prev => ({ ...prev, isLoadingUser: isLoading }));
      }, []);
    
      const attemptFinishInitialLoading = useCallback(() => {
        if (initialSessionCheckDone.current && initialAuthStateChangeProcessed.current) {
          console.log('[AuthContext] attemptFinishInitialLoading: Both initial checks complete. Setting isLoadingUser to false.');
          setLoadingState(false);
        } else {
          console.log(
            '[AuthContext] attemptFinishInitialLoading: Conditions not met. SessionCheckDone:',
            initialSessionCheckDone.current,
            'AuthStateChangeProcessed:',
            initialAuthStateChangeProcessed.current
          );
        }
      }, [setLoadingState]);
    
      const fetchUserProfile = useCallback(async (userId) => {
        console.log('[AuthContext] fetchUserProfile: UserId recebido:', userId);
        if (!userId) {
          console.warn('[AuthContext] fetchUserProfile: userId é nulo ou indefinido. Definindo userProfile como null.');
          setAuthState(prev => ({ ...prev, userProfile: null }));
          return null;
        }
    
        console.log('[AuthContext] fetchUserProfile: Consultando Supabase para o perfil com userId:', userId);
        try {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('*, role') 
            .eq('id', userId)
            .single();
    
          console.log('[AuthContext] fetchUserProfile: Resposta do Supabase - Data:', profileData, 'Error:', profileError);
    
          if (profileError) {
            console.error('[AuthContext] fetchUserProfile: Erro ao buscar perfil do Supabase:', profileError.message);
            setAuthState(prev => ({ ...prev, userProfile: null }));
            return null; 
          } else {
            console.log('[AuthContext] fetchUserProfile: Perfil encontrado:', profileData);
            setAuthState(prev => ({ ...prev, userProfile: profileData }));
            return profileData; 
          }
        } catch (error) {
          console.error('[AuthContext] fetchUserProfile: Exceção inesperada ao buscar perfil:', error);
          setAuthState(prev => ({ ...prev, userProfile: null }));
          return null; 
        }
      }, []);
    
      useEffect(() => {
        console.log('[AuthContext DEBUG STATE] isLoadingUser:', authState.isLoadingUser);
        console.log('[AuthContext DEBUG STATE] userProfile:', authState.userProfile);
        console.log('[AuthContext DEBUG STATE] user:', authState.user);
        console.log('[AuthContext DEBUG STATE] session:', authState.session);
      }, [authState.isLoadingUser, authState.userProfile, authState.user, authState.session]);
    
      useEffect(() => {
        console.log('[AuthContext] Main useEffect: Initializing auth logic. Setting isLoadingUser to true.');
        setLoadingState(true);
    
        const initializeSession = async () => {
          console.log('[AuthContext] initializeSession: Attempting to get current session.');
          try {
            const { data: { session: currentSession }, error: sessionError } = await supabase.auth.getSession();
            
            if (sessionError) {
              console.error('[AuthContext] initializeSession: Error getting session:', sessionError.message);
            }
            console.log('[AuthContext] initializeSession: currentSession from getSession():', currentSession);
            
            const currentUser = currentSession?.user ?? null;
            
            setAuthState(prev => ({
              ...prev,
              session: currentSession,
              user: currentUser,
            }));
    
            if (currentUser) {
              console.log('[AuthContext] initializeSession: User found in session. Fetching profile for user ID:', currentUser.id);
              await fetchUserProfile(currentUser.id);
            } else {
              console.log('[AuthContext] initializeSession: No user in session. Setting userProfile to null.');
              setAuthState(prev => ({ ...prev, userProfile: null }));
            }
          } catch (error) {
            console.error('[AuthContext] initializeSession: Catch block error:', error);
            setAuthState(prev => ({
              ...prev,
              session: null,
              user: null,
              userProfile: null,
            }));
          } finally {
            initialSessionCheckDone.current = true;
            console.log('[AuthContext] initializeSession: Finished. initialSessionCheckDone.current = true.');
            attemptFinishInitialLoading();
          }
        };
    
        initializeSession();
    
        const { data: authListener } = supabase.auth.onAuthStateChange(
          async (_event, newSession) => {
            console.log('[AuthContext] onAuthStateChange: Event received.', _event, 'New session:', newSession);
            const newUser = newSession?.user ?? null;
            
            setAuthState(prev => ({
              ...prev,
              session: newSession,
              user: newUser,
            }));
    
            if (newUser) {
              console.log('[AuthContext] onAuthStateChange: New user detected. Fetching profile for user ID:', newUser.id);
              await fetchUserProfile(newUser.id);
            } else {
              console.log('[AuthContext] onAuthStateChange: No new user (e.g., logout). Setting userProfile to null.');
              setAuthState(prev => ({ ...prev, userProfile: null }));
            }
    
            if (!initialAuthStateChangeProcessed.current) {
              initialAuthStateChangeProcessed.current = true;
              console.log('[AuthContext] onAuthStateChange: First event processed. initialAuthStateChangeProcessed.current = true.');
            }
            attemptFinishInitialLoading();
          }
        );
    
        return () => {
          console.log('[AuthContext] Main useEffect: Cleaning up auth listener.');
          authListener.subscription.unsubscribe();
        };
      }, [fetchUserProfile, setLoadingState, attemptFinishInitialLoading]); // Adicionado setLoadingState e attemptFinishInitialLoading
    
      const loginWithEmailPassword = async (email, password) => {
        console.log('[AuthContext] loginWithEmailPassword: Attempting for email:', email);
        setLoadingState(true);
        try {
          const { data, error } = await supabase.auth.signInWithPassword({ email, password });
          if (error) {
            console.error('[AuthContext] loginWithEmailPassword: Error signing in:', error.message);
            // Não defina isLoadingUser como false aqui diretamente, onAuthStateChange e attemptFinishInitialLoading cuidarão disso
            setAuthState(prev => ({ ...prev, userProfile: null})); 
            return { data: null, error };
          }
          console.log('[AuthContext] loginWithEmailPassword: signInWithPassword successful. User data:', data.user);
          if (data.user) {
            await fetchUserProfile(data.user.id);
          }
           // onAuthStateChange será chamado e, eventualmente, attemptFinishInitialLoading.
          return { data, error: null };
        } catch (error) {
          console.error('[AuthContext] loginWithEmailPassword: Catch block error:', error);
          setAuthState(prev => ({ ...prev, userProfile: null})); 
          setLoadingState(false); // Em caso de exceção não prevista, garantir que o loading pare
          return { data: null, error };
        }
      };
    
      const signUpWithEmailPassword = async (email, password, fullName) => {
        console.log('[AuthContext] signUpWithEmailPassword: Attempting for email:', email);
        setLoadingState(true); 
        try {
          const { data, error } = await supabase.auth.signUp({
            email,
            password,
            options: { data: { full_name: fullName } },
          });
          if (error) {
            console.error('[AuthContext] signUpWithEmailPassword: Error signing up:', error.message);
            setLoadingState(false);
            return { data: null, error };
          }
          console.log('[AuthContext] signUpWithEmailPassword: SignUp successful. User data:', data.user);
          // onAuthStateChange irá lidar com a busca do perfil e o estado de loading.
          return { data, error: null };
        } catch (error) {
          console.error('[AuthContext] signUpWithEmailPassword: Catch block error:', error);
          setLoadingState(false);
          return { data: null, error };
        }
      };
    
      const logout = async () => {
        console.log('[AuthContext] logout: Attempting sign out.');
        setLoadingState(true);
        try {
          const { error } = await supabase.auth.signOut();
          if (error) {
            console.error('[AuthContext] logout: Error signing out:', error.message);
            setLoadingState(false); 
            return { error };
          }
          console.log('[AuthContext] logout: SignOut successful.');
          // onAuthStateChange cuidará de limpar user, session, userProfile e o estado de loading.
          // A definição explícita aqui é mais para uma resposta imediata da UI, se necessário.
          setAuthState(prev => ({ 
            ...prev,
            session: null,
            user: null,
            userProfile: null,
          }));
          return { error: null };
        } catch (error) {
          console.error('[AuthContext] logout: Catch block error:', error);
          setLoadingState(false);
          return { error };
        }
      };
    
      const loginWithGoogle = async () => {
        console.log('[AuthContext] loginWithGoogle: Attempting Google OAuth.');
        // setLoadingState(true); // onAuthStateChange gerenciará
        try {
          const { data, error } = await supabase.auth.signInWithOAuth({ provider: 'google' });
          if (error) {
            console.error('[AuthContext] loginWithGoogle: Error initiating OAuth:', error.message);
            // setLoadingState(false);
            return { data: null, error };
          }
          console.log('[AuthContext] loginWithGoogle: OAuth initiated.');
          return { data, error: null };
        } catch (error) {
          console.error('[AuthContext] loginWithGoogle: Catch block error:', error);
          // setLoadingState(false);
          return { data: null, error };
        }
      };
    
      return {
        authState,
        loginWithEmailPassword,
        signUpWithEmailPassword,
        logout,
        loginWithGoogle,
        fetchUserProfile, // Exposto caso seja necessário chamar externamente
      };
    };
    
    export const AuthProvider = ({ children }) => {
      const authLogic = useAuthLogic();
      return <AuthContext.Provider value={authLogic.authState}>{children}</AuthContext.Provider>;
    };
    
    export const useAuth = () => {
      const context = useContext(AuthContext);
      if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider. Certifique-se de que AuthProvider está acima na árvore de componentes.');
      }
      // Retorna apenas os estados, as funções de manipulação não são diretamente parte do valor do contexto visível aos consumidores
      // mas são usadas internamente pelo useAuthLogic. Se precisar expô-las, ajuste o value no AuthProvider.
      // Por ora, vamos manter a estrutura original onde `value` em `AuthProviderInternal` continha tudo.
      // Para isso, precisamos reestruturar um pouco.
      return context; 
    };

    // Re-ajuste para expor as funções de manipulação também
    // Isso requer que o AuthProvider use o AuthContext.Provider diretamente com o valor completo
    // e useAuth consuma isso.

    // AuthProvider principal que usa o hook e provê o valor completo.
    export const AuthProviderFinal = ({ children }) => {
        const auth = useAuthLogic(); // Este hook agora retorna tudo { authState, loginWithEmailPassword, ... }
        const value = {
            session: auth.authState.session,
            user: auth.authState.user,
            userProfile: auth.authState.userProfile,
            isLoadingUser: auth.authState.isLoadingUser,
            loginWithEmailPassword: auth.loginWithEmailPassword,
            signUpWithEmailPassword: auth.signUpWithEmailPassword,
            logout: auth.logout,
            loginWithGoogle: auth.loginWithGoogle,
            fetchUserProfile: auth.fetchUserProfile, // Expondo a função diretamente
        };
        return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
    };
    
    // useAuth continua o mesmo, mas consumirá o valor completo fornecido por AuthProviderFinal
    // Certifique-se de que em App.jsx você está usando <AuthProviderFinal> e não <AuthProvider>
  