
import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { useToast } from '@/components/ui/use-toast';

const CartContext = createContext({
  items: [],
  totalItems: 0,
  totalQuantity: 0,
  subtotalAmount: 0,
  isCartLoading: false,
  addItemToCart: () => {},
  updateItemQuantity: () => {},
  removeItemFromCart: () => {},
  clearCart: () => {},
  getCartItem: () => undefined,
});

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [items, setItems] = useState([]);
  const [isCartLoading, setIsCartLoading] = useState(true); // True initially until loaded from localStorage
  const { toast } = useToast();

  useEffect(() => {
    try {
      const storedCart = localStorage.getItem('vittaHubCart');
      if (storedCart) {
        setItems(JSON.parse(storedCart));
      }
    } catch (error) {
      console.error("Failed to parse cart from localStorage", error);
      localStorage.removeItem('vittaHubCart'); // Clear corrupted cart
    }
    setIsCartLoading(false);
  }, []);

  useEffect(() => {
    if (!isCartLoading) { // Only save to localStorage after initial load
      localStorage.setItem('vittaHubCart', JSON.stringify(items));
    }
  }, [items, isCartLoading]);

  const addItemToCart = (product, variant, quantity) => {
    if (!product || quantity <= 0) {
      toast({ title: "Erro", description: "Produto ou quantidade inválida.", variant: "destructive" });
      return;
    }

    const stockAvailable = variant ? variant.inventory_quantity : product.inventory_quantity_base;
    if (stockAvailable === undefined || stockAvailable === null) {
        toast({ title: "Erro", description: "Informação de estoque indisponível.", variant: "destructive" });
        return;
    }

    const cartItemId = variant ? variant.id : product.id;
    const existingItem = items.find(item => (item.variantId || item.productId) === cartItemId);

    if (existingItem) {
      const newQuantity = existingItem.quantity + quantity;
      if (newQuantity > existingItem.maxQuantityAvailable) {
        toast({
          title: "Estoque Insuficiente",
          description: `Não é possível adicionar ${quantity} unidade(s). Apenas ${existingItem.maxQuantityAvailable - existingItem.quantity} restante(s) em estoque. Você já tem ${existingItem.quantity}.`,
          variant: "destructive",
        });
        return;
      }
      setItems(prevItems =>
        prevItems.map(item =>
          (item.variantId || item.productId) === cartItemId
            ? { ...item, quantity: newQuantity }
            : item
        )
      );
    } else {
      if (quantity > stockAvailable) {
        toast({
          title: "Estoque Insuficiente",
          description: `A quantidade solicitada (${quantity}) excede o estoque disponível (${stockAvailable}).`,
          variant: "destructive",
        });
        return;
      }
      const newItem = {
        productId: product.id,
        variantId: variant ? variant.id : null,
        name: product.name,
        sku: variant ? variant.sku : product.sku_base,
        imageUrl: variant?.image_url || product.main_image_url,
        price: variant ? (variant.price_override ?? product.base_price) : product.base_price,
        quantity,
        attributes: variant ? variant.attributes : null,
        maxQuantityAvailable: stockAvailable,
        productSlug: product.slug,
      };
      setItems(prevItems => [...prevItems, newItem]);
    }
    toast({
      title: "Produto Adicionado!",
      description: `${product.name}${variant ? ` (${Object.values(variant.attributes || {}).join('/')})` : ''} adicionado ao carrinho.`,
    });
  };

  const updateItemQuantity = (itemId, newQuantity) => {
    if (newQuantity <= 0) {
      removeItemFromCart(itemId);
      return;
    }

    setItems(prevItems =>
      prevItems.map(item => {
        if ((item.variantId || item.productId) === itemId) {
          if (newQuantity > item.maxQuantityAvailable) {
            toast({
              title: "Estoque Insuficiente",
              description: `A quantidade solicitada (${newQuantity}) excede o estoque disponível (${item.maxQuantityAvailable}).`,
              variant: "destructive",
            });
            return { ...item, quantity: item.maxQuantityAvailable }; // Set to max available
          }
          return { ...item, quantity: newQuantity };
        }
        return item;
      })
    );
  };

  const removeItemFromCart = (itemId) => {
    setItems(prevItems => prevItems.filter(item => (item.variantId || item.productId) !== itemId));
    toast({
      title: "Produto Removido",
      description: "O item foi removido do seu carrinho.",
    });
  };

  const clearCart = () => {
    setItems([]);
    toast({
      title: "Carrinho Limpo",
      description: "Todos os itens foram removidos do seu carrinho.",
    });
  };

  const getCartItem = (itemId) => {
    return items.find(item => (item.variantId || item.productId) === itemId);
  };

  const totalItems = items.length;
  const totalQuantity = useMemo(() => items.reduce((sum, item) => sum + item.quantity, 0), [items]);
  const subtotalAmount = useMemo(() => items.reduce((sum, item) => sum + item.price * item.quantity, 0), [items]);

  const value = {
    items,
    totalItems,
    totalQuantity,
    subtotalAmount,
    isCartLoading,
    addItemToCart,
    updateItemQuantity,
    removeItemFromCart,
    clearCart,
    getCartItem,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};
