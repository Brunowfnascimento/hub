
import React from 'react';
import { supabase } from '@/app/api/supabase';

export const shippingActions = (setState, state, helpers) => ({
  fetchAvailableShippingMethods: async () => {
    const { shippingAddress, cartItems } = state;
    const { toast } = helpers;

    if (!shippingAddress?.postal_code || !cartItems || cartItems.length === 0) {
      setState(prev => ({ ...prev, availableShippingMethods: [], selectedShippingMethod: null }));
      return;
    }
    setState(prev => ({ ...prev, isFetchingShippingMethods: true, orderError: null }));
    try {
      const itemsForEdgeFunction = cartItems.map(item => ({
        variantId: item.variantId,
        productId: item.productId,
        quantity: item.quantity,
      }));

      const { data, error } = await supabase.functions.invoke('calculate-shipping', {
        body: JSON.stringify({
          destination_zip_code: shippingAddress.postal_code,
          items: itemsForEdgeFunction,
        }),
      });

      if (error) {
        throw error;
      }
      
      if (Array.isArray(data)) {
        setState(prev => ({ ...prev, availableShippingMethods: data }));
        if (data.length > 0 && !state.selectedShippingMethod) {
          setState(prev => ({ ...prev, selectedShippingMethod: data[0] }));
        } else if (data.length === 0) {
          setState(prev => ({ ...prev, selectedShippingMethod: null }));
          toast({ title: "Frete não disponível", description: "Nenhuma opção de frete encontrada para seu endereço e itens.", variant: "default" });
        }
      } else {
        console.error("Resposta inesperada da Edge Function:", data);
        setState(prev => ({ ...prev, availableShippingMethods: [], selectedShippingMethod: null }));
        toast({ title: "Erro ao buscar frete", description: "Formato de resposta inválido do servidor.", variant: "destructive" });
      }

    } catch (err) {
      console.error("Erro ao chamar Edge Function 'calculate-shipping':", err);
      const errorMessage = err.message || (err.details ? JSON.stringify(err.details) : "Não foi possível calcular o frete.");
      setState(prev => ({ ...prev, orderError: `Erro ao calcular frete: ${errorMessage}`, availableShippingMethods: [], selectedShippingMethod: null }));
      toast({ title: "Erro ao buscar frete", description: errorMessage, variant: "destructive" });
    } finally {
      setState(prev => ({ ...prev, isFetchingShippingMethods: false }));
    }
  },
  setSelectedShippingMethod: (method) => {
    setState(prev => ({ ...prev, selectedShippingMethod: method }));
  },
});
