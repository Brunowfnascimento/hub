
import React from 'react';
import { supabase } from '@/app/api/supabase';

export const paymentActions = (setState, state, helpers) => ({
  setPaymentMethod: (method) => {
    setState(prev => ({ ...prev, paymentMethod: method }));
  },
  applyCoupon: async (code) => {
    const { subtotalAmount } = state;
    const { toast } = helpers;

    if (!code) {
      setState(prev => ({ ...prev, discountApplied: 0, couponCode: '' }));
      toast({ title: "Cupom removido", variant: "default" });
      return;
    }
    setState(prev => ({ ...prev, paymentProcessing: true }));
    try {
        const { data: couponData, error } = await supabase
            .from('coupons')
            .select('*')
            .eq('code', code.toUpperCase())
            .eq('is_active', true)
            .single();

        if (error || !couponData) {
            toast({ title: "Cupom Inválido", description: "O código do cupom inserido não é válido ou expirou.", variant: "destructive" });
            setState(prev => ({ ...prev, discountApplied: 0 }));
            return;
        }
        
        const now = new Date();
        if (new Date(couponData.valid_until) < now || new Date(couponData.valid_from) > now) {
             toast({ title: "Cupom Expirado", description: "Este cupom não está mais válido.", variant: "destructive" });
             setState(prev => ({ ...prev, discountApplied: 0 }));
             return;
        }

        if (couponData.min_purchase_amount && subtotalAmount < couponData.min_purchase_amount) {
            toast({ title: "Valor Mínimo Não Atingido", description: `Este cupom requer um valor mínimo de R$ ${couponData.min_purchase_amount.toFixed(2)}.`, variant: "destructive" });
            setState(prev => ({ ...prev, discountApplied: 0 }));
            return;
        }
        
        let discount = 0;
        if (couponData.discount_type === 'percentage') {
            discount = subtotalAmount * (couponData.discount_value / 100);
        } else if (couponData.discount_type === 'fixed_amount') {
            discount = couponData.discount_value;
        }
        
        discount = Math.min(discount, subtotalAmount); 

        setState(prev => ({ ...prev, discountApplied: discount, couponCode: couponData.code }));
        toast({ title: "Cupom Aplicado!", description: `Desconto de R$ ${discount.toFixed(2)} aplicado.` });

    } catch (err) {
        toast({ title: "Erro ao aplicar cupom", description: err.message, variant: "destructive" });
        setState(prev => ({ ...prev, discountApplied: 0 }));
    } finally {
        setState(prev => ({ ...prev, paymentProcessing: false }));
    }
  },
});
