
import React from 'react';

export const navigationActions = (setState, state, CHECKOUT_STEPS) => ({
  goToNextStep: () => {
    const currentIndex = CHECKOUT_STEPS.indexOf(state.currentStep);
    if (currentIndex < CHECKOUT_STEPS.length - 1) {
      setState(prev => ({ ...prev, currentStep: CHECKOUT_STEPS[currentIndex + 1] }));
    }
  },
  goToPreviousStep: () => {
    const currentIndex = CHECKOUT_STEPS.indexOf(state.currentStep);
    if (currentIndex > 0) {
      setState(prev => ({ ...prev, currentStep: CHECKOUT_STEPS[currentIndex - 1] }));
    }
  },
  goToStep: (stepName) => {
    const stepIndex = CHECKOUT_STEPS.indexOf(stepName);
    const currentIndex = CHECKOUT_STEPS.indexOf(state.currentStep);
    if (stepIndex < currentIndex && CHECKOUT_STEPS.includes(stepName)) {
      setState(prev => ({ ...prev, currentStep: stepName }));
    }
  },
});
