
import React from 'react';

export const addressActions = (setState, state, helpers) => ({
  setShippingAddress: (address) => {
    setState(prev => ({ ...prev, shippingAddress: address }));
    if (state.useShippingAsBilling) {
      setState(prev => ({ ...prev, billingAddress: address }));
    }
    setState(prev => ({ ...prev, availableShippingMethods: [], selectedShippingMethod: null }));
  },
  setBillingAddress: (address) => {
    setState(prev => ({ ...prev, billingAddress: address }));
  },
  setUseShippingAsBilling: (value) => {
    setState(prev => ({ ...prev, useShippingAsBilling: value }));
    if (value && state.shippingAddress) {
      setState(prev => ({ ...prev, billingAddress: state.shippingAddress }));
    } else if (!value) {
      setState(prev => ({ ...prev, billingAddress: null }));
    }
  },
});
