
import React from 'react';
import { supabase } from '@/app/api/supabase';
import { initialCheckoutState } from '@/app/contexts/CheckoutContext'; // Importar o estado inicial

export const orderActions = (setState, state, helpers) => ({ // CHECKOUT_STEPS não é mais necessário aqui
  placeOrder: async () => {
    const { 
        shippingAddress, billingAddress, useShippingAsBilling, 
        selectedShippingMethod, paymentMethod, couponCode, 
        discountApplied, 
    } = state;
    const { toast, navigate, clearCart, cartItems, subtotalAmount } = helpers;

    if (!shippingAddress || !selectedShippingMethod || cartItems.length === 0) {
        toast({ title: "Erro no Pedido", description: "Informações de endereço, frete ou itens do carrinho estão faltando.", variant: "destructive" });
        setState(prev => ({ ...prev, paymentProcessing: false, orderError: "Dados incompletos para finalizar o pedido." }));
        return;
    }
    
    setState(prev => ({ ...prev, paymentProcessing: true, orderError: null }));
    
    const currentUser = (await supabase.auth.getUser()).data.user;
    const customerEmail = shippingAddress.email || currentUser?.email;

    if (!customerEmail) {
        toast({ title: "Erro no Pedido", description: "E-mail do cliente não encontrado.", variant: "destructive" });
        setState(prev => ({ ...prev, paymentProcessing: false, orderError: "E-mail do cliente é obrigatório." }));
        return;
    }

    const orderPayload = {
        user_id: currentUser?.id || null,
        customer_email: customerEmail, 
        customer_name: shippingAddress.full_name,
        status: 'pending_payment', 
        total_items_price: subtotalAmount,
        shipping_cost: selectedShippingMethod?.cost || 0,
        discount_amount: discountApplied || 0,
        coupon_code: couponCode || null,
        grand_total: subtotalAmount + (selectedShippingMethod?.cost || 0) - (discountApplied || 0),
        shipping_address_snapshot: shippingAddress,
        billing_address_snapshot: useShippingAsBilling ? shippingAddress : billingAddress,
        payment_method: paymentMethod,
        payment_status: 'pending',
        shipping_method_details: selectedShippingMethod,
        notes_customer: '', 
        placed_at: new Date().toISOString(),
        order_items: cartItems.map(item => ({
            variant_id: item.variantId,
            product_id: item.productId, 
            product_snapshot: { 
                name: item.name, 
                sku: item.sku, 
                imageUrl: item.imageUrl,
                attributes: item.attributes 
            },
            quantity: item.quantity,
            unit_price_at_purchase: item.price,
            total_price_at_purchase: item.price * item.quantity,
        }))
    };

    try {
        const { data: orderFunctionResponse, error: functionError } = await supabase.functions.invoke('place-order', {
            body: JSON.stringify(orderPayload),
        });

        if (functionError) {
            throw new Error(functionError.message || "Erro ao chamar a função de criação de pedido.");
        }

        if (!orderFunctionResponse || !orderFunctionResponse.success || !orderFunctionResponse.order_id) {
             const serverMessage = orderFunctionResponse?.error?.message || orderFunctionResponse?.message || "Resposta da função de criação de pedido inválida ou falha no processamento.";
            throw new Error(serverMessage);
        }
        
        toast({ 
            title: "Pedido Realizado com Sucesso!", 
            description: `Seu pedido ${orderFunctionResponse.order_number || orderFunctionResponse.order_id} foi confirmado.`,
            className: "bg-green-600 text-white dark:bg-green-700 dark:text-slate-100"
        });
        clearCart();
        navigate(`/order-confirmation/${orderFunctionResponse.order_id}`); 
        
        setState(prev => ({
            ...prev, // Manter outros estados que não são parte do initialCheckoutState se houver
            ...initialCheckoutState, // Resetar para o estado inicial do checkout
        }));

    } catch (err) {
        console.error("Erro ao finalizar pedido:", err);
        const errorMessage = err.message || "Ocorreu um erro ao processar seu pedido.";
        setState(prev => ({ ...prev, orderError: errorMessage }));
        toast({ title: "Erro no Pedido", description: errorMessage, variant: "destructive" });
    } finally {
        setState(prev => ({ ...prev, paymentProcessing: false }));
    }
  },
});
