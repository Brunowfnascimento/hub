
import React, { createContext, useContext, useState, useMemo, useCallback } from 'react';
import { useCart } from '@/app/contexts/CartContext';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

import { addressActions } from './checkout/actions/addressActions';
import { shippingActions } from './checkout/actions/shippingActions';
import { paymentActions } from './checkout/actions/paymentActions';
import { orderActions } from './checkout/actions/orderActions';
import { navigationActions } from './checkout/actions/navigationActions';

export const CHECKOUT_STEPS = ['address', 'shipping', 'payment', 'review'];

export const initialCheckoutState = {
  currentStep: CHECKOUT_STEPS[0],
  shippingAddress: null,
  billingAddress: null,
  useShippingAsBilling: true,
  selectedShippingMethod: null,
  availableShippingMethods: [],
  paymentMethod: 'credit_card',
  paymentProcessing: false,
  orderError: null,
  couponCode: '',
  discountApplied: 0,
  isFetchingShippingMethods: false,
};

const CheckoutContext = createContext({
  ...initialCheckoutState,
  setShippingAddress: () => {},
  setBillingAddress: () => {},
  setUseShippingAsBilling: () => {},
  fetchAvailableShippingMethods: async () => {},
  setSelectedShippingMethod: () => {},
  setPaymentMethod: () => {},
  applyCoupon: async () => {},
  placeOrder: async () => {},
  goToNextStep: () => {},
  goToPreviousStep: () => {},
  goToStep: () => {},
  steps: CHECKOUT_STEPS,
});

export const useCheckout = () => useContext(CheckoutContext);

export const CheckoutProvider = ({ children }) => {
  const [state, setState] = useState(initialCheckoutState);
  
  const { items: cartItems, clearCart, subtotalAmount } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();

  const helpers = { toast, navigate, clearCart, cartItems, subtotalAmount };

  const actions = useMemo(() => ({
    ...addressActions(setState, state, helpers),
    ...shippingActions(setState, state, helpers),
    ...paymentActions(setState, state, helpers),
    ...orderActions(setState, state, helpers), 
    ...navigationActions(setState, state, CHECKOUT_STEPS),
  }), [state, helpers]);


  const value = {
    ...state,
    ...actions,
    steps: CHECKOUT_STEPS,
  };

  return <CheckoutContext.Provider value={value}>{children}</CheckoutContext.Provider>;
};
