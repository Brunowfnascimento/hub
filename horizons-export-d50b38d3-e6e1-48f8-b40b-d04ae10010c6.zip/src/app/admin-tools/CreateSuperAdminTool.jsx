
    import React, { useState } from 'react';
    import { supabase } from '@/app/api/supabase';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    
    const CreateSuperAdminTool = () => {
      const [email, setEmail] = useState('brunof21@yahoo.com');
      const [password, setPassword] = useState('bruno@1234B');
      const [fullName, setFullName] = useState('Bruno F21 Admin');
      const [isLoading, setIsLoading] = useState(false);
      const [diagnosticResult, setDiagnosticResult] = useState(null);
      const { toast } = useToast();
    
      const handleDiagnoseSuperAdmin = async () => {
        setIsLoading(true);
        setDiagnosticResult(null);
    
        try {
          const { data, error: functionInvokeError } = await supabase.functions.invoke('diagnose-super-admin-creation', {
            body: JSON.stringify({ email, password, fullName }),
          });
    
          if (functionInvokeError) {
            console.error('Error invoking diagnostic function:', functionInvokeError);
            toast({
              title: "Erro ao Chamar Função de Diagnóstico",
              description: functionInvokeError.message || "Falha na comunicação com a Edge Function.",
              variant: "destructive",
            });
            setDiagnosticResult({
              error: "Falha ao invocar a Edge Function.",
              details: functionInvokeError.message
            });
            return;
          }
          
          if (data && data.error) { 
             toast({
                title: "Erro na Função de Diagnóstico",
                description: data.details || data.error,
                variant: "destructive",
             });
             setDiagnosticResult(data);
          } else if (data && data.diagnostic) { 
            setDiagnosticResult(data.diagnostic);
            const authOk = !data.diagnostic.authCreation.error;
            const profileOk = !data.diagnostic.profileCreation.error;
    
            if (authOk && profileOk) {
                toast({
                    title: "Diagnóstico Concluído",
                    description: "Criação/Atualização de Super Admin processada. Verifique os detalhes.",
                });
            } else {
                 toast({
                    title: "Diagnóstico Concluído com Erros",
                    description: "Alguma etapa falhou. Verifique os detalhes.",
                    variant: "destructive",
                });
            }
          } else {
             toast({
                title: "Resposta Inesperada",
                description: "A função de diagnóstico retornou um formato de dados inesperado.",
                variant: "destructive",
            });
            setDiagnosticResult({ error: "Resposta inesperada da função."});
          }
    
        } catch (error) {
          console.error('Client-side error invoking diagnostic function:', error);
          toast({
            title: "Erro no Cliente",
            description: `Falha ao chamar a função de diagnóstico: ${error.message}`,
            variant: "destructive",
          });
           setDiagnosticResult({
              error: "Erro no cliente ao chamar a função.",
              details: error.message
            });
        } finally {
          setIsLoading(false);
        }
      };
    
      const renderDiagnosticDetails = (result) => {
        if (!result) return null;
        return (
          <div className="mt-4 p-4 border rounded-md bg-slate-50 dark:bg-slate-800">
            <h4 className="font-semibold mb-2 text-lg">Resultados do Diagnóstico:</h4>
            {result.error && <p className="text-red-500">Erro Geral: {result.error} {result.details ? `- ${result.details}` : ''}</p>}
            
            {result.authCreation && (
              <div className="mb-2">
                <p><strong>Criação/Atualização no Auth:</strong> {result.authCreation.status}</p>
                {result.authCreation.data && <pre className="text-xs bg-slate-100 dark:bg-slate-700 p-2 rounded overflow-x-auto">ID: {result.authCreation.data.id}, Email: {result.authCreation.data.email}</pre>}
                {result.authCreation.error && <p className="text-red-500">Erro Auth: {result.authCreation.error}</p>}
              </div>
            )}
    
            {result.profileCreation && (
              <div>
                <p><strong>Criação/Atualização de Perfil:</strong> {result.profileCreation.status}</p>
                {result.profileCreation.data && <pre className="text-xs bg-slate-100 dark:bg-slate-700 p-2 rounded overflow-x-auto">{JSON.stringify(result.profileCreation.data, null, 2)}</pre>}
                {result.profileCreation.error && <p className="text-red-500">Erro Perfil: {result.profileCreation.error}</p>}
              </div>
            )}
          </div>
        );
      };
    
      return (
        <div className="container mx-auto p-4">
          <Card className="max-w-lg mx-auto">
            <CardHeader>
              <CardTitle>Diagnosticar Criação/Atualização de Super Administrador</CardTitle>
              <CardDescription>
                Esta ferramenta testa a criação/atualização do usuário no Auth e na tabela de perfis.
                Se o usuário já existir, tentará atualizar a senha e o perfil.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="password">Senha</Label>
                <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="fullName">Nome Completo</Label>
                <Input id="fullName" type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} />
              </div>
            </CardContent>
            <CardFooter className="flex flex-col items-start space-y-2">
              <Button onClick={handleDiagnoseSuperAdmin} disabled={isLoading}>
                {isLoading ? 'Diagnosticando...' : 'Executar Diagnóstico e Atualizar/Criar'}
              </Button>
              {renderDiagnosticDetails(diagnosticResult)}
            </CardFooter>
          </Card>
        </div>
      );
    };
    
    export default CreateSuperAdminTool;
  