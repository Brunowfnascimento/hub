
    import React from 'react';
    import { createClient } from '@supabase/supabase-js';

    const supabaseUrl = "https://mxivixkcvzeykmtuzgjt.supabase.co";
    const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im14aXZpeGtjdnpleWttdHV6Z2p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDcyMzA4ODgsImV4cCI6MjA2MjgwNjg4OH0.E6BhqEY-Xrn9qWnImItJ3ioSk1_Y17_aEZreKGSHQMY";

    if (!supabaseUrl) {
      console.error("Supabase URL is not defined. Check your environment variables or configuration.");
      throw new Error("Supabase URL is not defined. This should not happen if credentials are hardcoded.");
    }

    if (!supabaseAnonKey) {
      console.error("Supabase Anon Key is not defined. Check your environment variables or configuration.");
      throw new Error("Supabase Anon Key is not defined. This should not happen if credentials are hardcoded.");
    }

    export const supabase = createClient(supabaseUrl, supabaseAnonKey);
  