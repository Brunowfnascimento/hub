
import React from 'react';

export const UserProfileSchema = {
  id: '', // uuid, vem do user.id
  full_name: '',
  cpf_cnpj: '',
  phone: '',
  avatar_url: '',
  role: '', // 'customer' or 'admin'
  created_at: '',
  updated_at: '',
};

export const ProfileFormDataSchema = {
  full_name: '',
  cpf_cnpj: '',
  phone: '',
};

export const UserAddressSchema = {
  id: '', // uuid
  user_id: '', // uuid
  address_line1: '',
  address_line2: '',
  city: '',
  state_province: '',
  postal_code: '',
  country: '',
  address_type: 'shipping', // 'shipping' or 'billing'
  is_default_shipping: false,
  is_default_billing: false,
  created_at: '',
  updated_at: '',
};

export const AddressFormDataSchema = {
  address_line1: '',
  address_line2: '',
  city: '',
  state_province: '',
  postal_code: '',
  country: 'BR', // Default
  address_type: 'shipping',
};
