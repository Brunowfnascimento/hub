
import React from 'react';

// Interfaces para a Vitrine (Storefront)

// Interface para uma imagem de produto na vitrine
// export interface StorefrontProductImage {
//   id: string;
//   url: string | null;
//   alt_text?: string | null;
//   display_order: number;
// }

// Interface para uma variante de produto na vitrine
// export interface StorefrontVariant {
//   id: string;
//   sku: string;
//   price: number; // Preço final da variante (considerando price_override ou base_price)
//   compare_at_price?: number | null; // Preço de comparação da variante
//   attributes: Record<string, string> | null; // Ex: { "Cor": "Azul", "Tamanho": "M" }
//   inventory_quantity: number;
//   is_active: boolean;
//   image_id?: string | null; // ID da imagem específica da variante, se houver
//   image_url?: string | null; // URL da imagem específica da variante, se houver
// }

// Interface para um produto na vitrine
// export interface StorefrontProduct {
//   id: string;
//   name: string;
//   slug: string;
//   description_short?: string | null;
//   description_long?: string | null;
//   base_price: number;
//   compare_at_price?: number | null;
//   is_featured: boolean;
//   category: {
//     id: string;
//     name: string;
//     slug: string;
//   } | null;
//   brand: {
//     id: string;
//     name: string;
//     slug: string;
//   } | null;
//   main_image_url: string | null; // URL da imagem principal
//   images: StorefrontProductImage[];
//   variants: StorefrontVariant[]; // Apenas variantes ativas
//   tags?: string[] | null;
//   average_rating?: number | null; // Se houver sistema de avaliação
//   total_reviews?: number | null;  // Se houver sistema de avaliação
//   inventory_quantity_base?: number; // Estoque base se não houver variantes
// }

// Interface para uma categoria na vitrine
// export interface StorefrontCategory {
//   id: string;
//   name: string;
//   slug: string;
//   description?: string | null;
//   image_url?: string | null;
//   parent_category_id?: string | null;
//   product_count?: number; // Opcional: contagem de produtos ativos na categoria
// }

// Interface para uma marca na vitrine
// export interface StorefrontBrand {
//   id: string;
//   name: string;
//   slug: string;
//   logo_url?: string | null;
//   product_count?: number; // Opcional: contagem de produtos ativos da marca
// }

// Tipos para parâmetros de filtro, se necessário
// export type ProductFilters = {
//   categorySlug?: string | null;
//   brandSlug?: string | null;
//   minPrice?: number | null;
//   maxPrice?: number | null;
//   sortBy?: string; // ex: 'created_at', 'price', 'name'
//   sortOrder?: 'asc' | 'desc';
//   searchTerm?: string;
//   tags?: string[];
// };

// Tipos para Checkout

// export interface Address {
//   id?: string; // Opcional, se for um endereço salvo
//   user_id?: string; // Opcional
//   address_line1: string;
//   address_line2?: string | null;
//   city: string;
//   state_province: string; // Ou state
//   postal_code: string; // Ou zip_code
//   country: string;
//   phone_number?: string | null; // Adicionado para contato
//   full_name?: string | null; // Adicionado para destinatário
// }

// export interface ShippingMethod {
//   id: string;
//   name: string;
//   description?: string | null;
//   cost: number;
//   estimated_delivery_time: string; // Ex: "3-5 dias úteis"
//   carrier_logo_url?: string | null;
// }


// Nota: Como o projeto está configurado para .jsx e não TypeScript (.ts),
// estas interfaces são fornecidas como comentários para referência de estrutura.
// Em um projeto JavaScript puro, você normalmente não definiria tipos desta forma explícita
// a menos que estivesse usando JSDoc ou uma biblioteca de verificação de tipos em tempo de execução.
// Para este projeto, vamos nos concentrar na implementação dos serviços.
// As estruturas de dados retornadas pelos serviços Supabase serão implicitamente os "tipos".
