
import React from 'react';
import { z } from 'zod';


export const addressSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  user_id: z.string().uuid().optional().nullable(),
  full_name: z.string().min(3, "Nome completo é obrigatório."),
  cpf: z.string()
    .min(11, "CPF deve ter 11 dígitos.")
    .max(14, "CPF inválido.") 
    .regex(/^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$/, "Formato de CPF inválido.")
    .optional().nullable(), 
  postal_code: z.string()
    .min(8, "CEP deve ter 8 dígitos.")
    .max(9, "CEP inválido.")
    .regex(/^\d{5}-?\d{3}$/, "Formato de CEP inválido (XXXXX-XXX)."),
  address_line1: z.string().min(3, "Endereço é obrigatório."),
  address_number: z.string().min(1, "Número é obrigatório."),
  address_complement: z.string().optional().nullable(),
  address_district: z.string().min(2, "Bairro é obrigatório."),
  city: z.string().min(2, "Cidade é obrigatória."),
  state_province: z.string().min(2, "Estado é obrigatório.").max(2, "Use a sigla do estado (ex: SP)."),
  country: z.string().min(2, "País é obrigatório.").default("Brasil"),
  phone_number: z.string()
    .min(10, "Telefone deve ter no mínimo 10 dígitos.")
    .regex(/^\(?\d{2}\)?[\s-]?\d{4,5}-?\d{4}$/, "Formato de telefone inválido.")
    .optional().nullable(),
  address_type: z.enum(['shipping', 'billing']).optional().nullable(),
  is_default_shipping: z.boolean().optional(),
  is_default_billing: z.boolean().optional(),
  save_address: z.boolean().optional().default(false), 
});


export const statesBrazil = [
  { value: "AC", label: "Acre" }, { value: "AL", label: "Alagoas" }, { value: "AP", label: "Amapá" },
  { value: "AM", label: "Amazonas" }, { value: "BA", label: "Bahia" }, { value: "CE", label: "Ceará" },
  { value: "DF", label: "Distrito Federal" }, { value: "ES", label: "Espírito Santo" }, { value: "GO", label: "Goiás" },
  { value: "MA", label: "Maranhão" }, { value: "MT", label: "Mato Grosso" }, { value: "MS", label: "Mato Grosso do Sul" },
  { value: "MG", label: "Minas Gerais" }, { value: "PA", label: "Pará" }, { value: "PB", label: "Paraíba" },
  { value: "PR", label: "Paraná" }, { value: "PE", label: "Pernambuco" }, { value: "PI", label: "Piauí" },
  { value: "RJ", label: "Rio de Janeiro" }, { value: "RN", label: "Rio Grande do Norte" }, { value: "RS", label: "Rio Grande do Sul" },
  { value: "RO", label: "Rondônia" }, { value: "RR", label: "Roraima" }, { value: "SC", label: "Santa Catarina" },
  { value: "SP", label: "São Paulo" }, { value: "SE", label: "Sergipe" }, { value: "TO", label: "Tocantins" }
];

// export interface ShippingMethod { // Já definido em storefront.types.jsx, mas pode ser referenciado aqui
//   id: string;
//   name: string;
//   description?: string | null;
//   cost: number;
//   estimated_delivery_time: string; 
//   carrier_logo_url?: string | null;
// }
