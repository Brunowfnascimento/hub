
import React from 'react';

export const AdminOrderFilters = {
  status: '', 
  paymentStatus: '',
  customerQuery: '',
  dateFrom: null, 
  dateTo: null,
};

export const AdminOrderPagination = {
  page: 1,
  limit: 10,
};

export const AdminOrderSorting = {
  sortBy: 'placed_at', 
  sortOrder: 'desc', 
};

export const ORDER_STATUS_OPTIONS = [
  { value: 'pending_payment', label: 'Pagamento Pendente' },
  { value: 'processing', label: 'Processando' },
  { value: 'awaiting_shipment', label: 'Aguardando Envio' },
  { value: 'shipped', label: 'Enviado' },
  { value: 'delivered', label: 'Entregue' },
  { value: 'completed', label: 'Concluído' },
  { value: 'cancelled', label: 'Cancelado' },
  { value: 'refunded', label: 'Reembolsado' },
  { value: 'failed', label: 'Falhou' },
];

export const PAYMENT_STATUS_OPTIONS = [
  { value: 'pending', label: 'Pendente' },
  { value: 'paid', label: 'Pago' },
  { value: 'failed', label: 'Falhou' },
  { value: 'refunded', label: 'Reembolsado' },
  { value: 'authorized', label: 'Autorizado' },
  { value: 'partially_refunded', label: 'Parcialmente Reembolsado' },
];
