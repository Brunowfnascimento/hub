
import React from 'react';

export const ShippingCarrierSchema = {
  name: '',
  code: '',
  is_active: true,
  tracking_url_template: '',
  api_integration_details: null, 
};

export const ShippingZoneSchema = {
  name: '',
  description: '',
  countries: [], 
  states: [],    
  zip_code_ranges: [], 
  is_active: true,
};

export const ShippingMethodCalculationType = {
  TABLE_RATE: 'table_rate',
  API_CARRIER: 'api_carrier',
  FLAT_RATE_PER_ORDER: 'flat_rate_per_order',
  FLAT_RATE_PER_ITEM: 'flat_rate_per_item',
  FREE_SHIPPING: 'free_shipping',
};

export const CalculationTypeOptions = [
  { value: ShippingMethodCalculationType.TABLE_RATE, label: 'Taxa Baseada em Tabela' },
  { value: ShippingMethodCalculationType.API_CARRIER, label: 'API da Transportadora (Externo)' },
  { value: ShippingMethodCalculationType.FLAT_RATE_PER_ORDER, label: 'Taxa Fixa por Pedido' },
  { value: ShippingMethodCalculationType.FLAT_RATE_PER_ITEM, label: 'Taxa Fixa por Item' },
  { value: ShippingMethodCalculationType.FREE_SHIPPING, label: 'Frete Grátis' },
];

export const ShippingMethodSchema = {
  shipping_zone_id: '',
  carrier_id: null, 
  name: '',
  service_code: '',
  description: '',
  estimated_delivery_time_template: '',
  is_active: true,
  calculation_type: CalculationTypeOptions[0].value, 
  base_cost: 0,
};

export const ShippingRateSchema = {
  shipping_method_id: '',
  condition_min_weight_grams: null,
  condition_max_weight_grams: null,
  condition_min_subtotal: null,
  condition_max_subtotal: null,
  zip_code_start: '',
  zip_code_end: '',
  cost: 0,
  priority: 0,
};
