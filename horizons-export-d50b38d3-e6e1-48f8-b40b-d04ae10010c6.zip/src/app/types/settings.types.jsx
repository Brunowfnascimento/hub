
import React from 'react';

export const StoreSettingsSchema = {
  id: '', // uuid
  settings_key: 'main_settings',
  store_name: '',
  store_email_contact: '',
  store_phone_contact: '',
  store_address: '',
  store_cnpj: '',
  default_currency: 'BRL',
  logo_url: '',
  favicon_url: '',
  created_at: '',
  updated_at: '',
};

export const StoreSettingsFormDataSchema = {
  store_name: '',
  store_email_contact: '',
  store_phone_contact: '',
  store_address: '',
  store_cnpj: '',
  default_currency: 'BRL',
  logo_url: '', // Will hold URL, not file object
  favicon_url: '', // Will hold URL, not file object
};
