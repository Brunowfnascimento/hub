
import React from 'react';

export const DashboardMetricsSchema = {
  totalSales: 0,
  totalOrders: 0,
  averageOrderValue: 0,
  newCustomers: 0,
  activeProducts: 0,
  lowStockProductsCount: 0,
};

export const SalesOverTimeDataPointSchema = {
  date: '', 
  sales: 0,
};

export const RecentOrderItemSchema = {
  id: '',
  order_number: '',
  customer_name: '',
  grand_total: 0,
  status: '',
  placed_at: '',
};

export const TopSellingProductItemSchema = {
  product_id: '',
  variant_id: '',
  product_name: '',
  variant_sku: '',
  total_sold: 0,
  product_slug: '',
};

export const LowStockProductItemSchema = {
  product_id: '',
  variant_id: '',
  product_name: '',
  variant_sku: '',
  quantity: 0,
  product_slug: '',
};
