
import React from 'react';

export const AdminCustomerSchema = {
  id: '', // user_id from auth.users
  email: '',
  full_name: '',
  cpf_cnpj: '',
  phone: '',
  role: '', // from profiles table
  created_at: '', // user creation date from auth.users
  last_sign_in_at: '', // from auth.users
  banned_until: null, // from auth.users
  total_spent: 0, // Aggregated from orders
  order_count: 0, // Aggregated from orders
};

export const CustomerProfileAdminUpdateSchema = {
  full_name: '',
  cpf_cnpj: '',
  phone: '',
  role: '',
  // Banning is handled by a separate function
};

export const CustomerDetailsSchema = {
  profile: { /* ...AdminCustomerSchema fields from profiles and auth.users */ },
  addresses: [ /* ...AddressSchema from profile.types.jsx or checkout.types.jsx */ ],
  recent_orders: [ /* ...OrderItemSchema or a simplified version */ ],
};
