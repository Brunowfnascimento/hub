
import React from 'react';

export const CouponSchema = {
  id: '', // uuid
  code: '', // text, not null
  description: '', // text, nullable
  discount_type: 'percentage', // text, not null ('percentage' or 'fixed_amount')
  discount_value: 0, // numeric, not null
  max_uses_total: null, // integer, nullable
  max_uses_per_user: null, // integer, nullable
  min_purchase_amount: null, // numeric, nullable
  valid_from: null, // timestamp with time zone, nullable
  valid_until: null, // timestamp with time zone, nullable
  is_active: true, // boolean, not null
  created_at: '', // timestamp with time zone
  updated_at: '', // timestamp with time zone
  current_uses: 0, // For display, calculated or fetched if needed
};

export const CouponFormDataSchema = {
  code: '',
  description: '',
  discount_type: 'percentage',
  discount_value: '', // Input will be string, parse to number
  max_uses_total: '',
  max_uses_per_user: '',
  min_purchase_amount: '',
  valid_from: null,
  valid_until: null,
  is_active: true,
};

export const DiscountTypeOptions = [
  { value: 'percentage', label: 'Porcentagem (%)' },
  { value: 'fixed_amount', label: 'Valor Fixo (R$)' },
];
