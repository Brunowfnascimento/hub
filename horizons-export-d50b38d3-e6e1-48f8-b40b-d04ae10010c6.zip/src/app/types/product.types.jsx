
import React from 'react';
import { z } from 'zod';

export const productBaseSchema = z.object({
  name: z.string().min(3, "Nome do produto é obrigatório."),
  slug: z.string().min(3, "Slug é obrigatório.").regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Slug inválido. Use letras minúsculas, números e hífens."),
  description_short: z.string().max(255, "Descrição curta deve ter no máximo 255 caracteres.").optional().nullable(),
  description_long: z.string().optional().nullable(),
  is_active: z.boolean().default(true),
  is_featured: z.boolean().default(false),
  category_id: z.string().uuid("Categoria inválida.").optional().nullable(),
  brand_id: z.string().uuid("Marca inválida.").optional().nullable(),
  tags: z.array(z.string()).optional().default([]),
  meta_title: z.string().max(70, "Meta título deve ter no máximo 70 caracteres.").optional().nullable(),
  meta_description: z.string().max(160, "Meta descrição deve ter no máximo 160 caracteres.").optional().nullable(),
});

export const productPricingSchema = z.object({
  base_price: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseFloat(String(val)),
    z.number({ invalid_type_error: "Preço base deve ser um número." }).positive("Preço base deve ser positivo.").optional()
  ),
  compare_at_price: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseFloat(String(val)),
    z.number({ invalid_type_error: "Preço comparativo deve ser um número." }).positive("Preço comparativo deve ser positivo.").optional().nullable()
  ),
  sku_base: z.string().optional().nullable(),
  inventory_quantity_base: z.preprocess( // Para produto sem variantes
    (val) => (val === "" || val === undefined || val === null) ? 0 : parseInt(String(val), 10),
    z.number().int("Quantidade em estoque deve ser um número inteiro.").min(0, "Estoque não pode ser negativo.").default(0)
  ),
});

export const productShippingSchema = z.object({
  weight_grams: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseInt(String(val), 10),
    z.number().int("Peso deve ser um número inteiro.").min(0, "Peso não pode ser negativo.").optional().nullable()
  ),
  length_cm: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseInt(String(val), 10),
    z.number().int("Comprimento deve ser um número inteiro.").min(0, "Comprimento não pode ser negativo.").optional().nullable()
  ),
  width_cm: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseInt(String(val), 10),
    z.number().int("Largura deve ser um número inteiro.").min(0, "Largura não pode ser negativo.").optional().nullable()
  ),
  height_cm: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseInt(String(val), 10),
    z.number().int("Altura deve ser um número inteiro.").min(0, "Altura não pode ser negativo.").optional().nullable()
  ),
});

export const imageSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  file: z.any().optional().nullable(), 
  storage_path: z.string().optional().nullable(),
  alt_text: z.string().optional().nullable(),
  display_order: z.number().int().optional(),
  variant_id: z.string().uuid().optional().nullable(), 
});

export const variantAttributeOptionSchema = z.object({
  option_name: z.string().min(1, "Nome da opção é obrigatório (ex: Cor, Tamanho)."),
  values: z.array(z.string().min(1, "Valor da opção é obrigatório (ex: Azul, P).")).min(1, "Adicione pelo menos um valor para a opção."),
});

export const productVariantSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  sku: z.string().min(1, "SKU da variante é obrigatório."),
  price_override: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseFloat(String(val)),
    z.number({ invalid_type_error: "Preço deve ser um número." }).positive("Preço da variante deve ser positivo.").optional()
  ),
  compare_at_price_override: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseFloat(String(val)),
    z.number({ invalid_type_error: "Preço comparativo deve ser um número." }).positive("Preço comparativo deve ser positivo.").optional().nullable()
  ),
  attributes: z.record(z.string(), z.string()), 
  is_active: z.boolean().default(true),
  inventory_quantity: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? 0 : parseInt(String(val), 10),
    z.number().int("Quantidade deve ser um número inteiro.").min(0, "Estoque não pode ser negativo.").default(0)
  ),
  old_inventory_quantity: z.number().int().optional(), 
  image_id: z.string().uuid().optional().nullable(),
  weight_grams_override: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseInt(String(val), 10),
    z.number().int().min(0).optional().nullable()
  ),
  length_cm_override: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseInt(String(val), 10),
    z.number().int().min(0).optional().nullable()
  ),
  width_cm_override: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseInt(String(val), 10),
    z.number().int().min(0).optional().nullable()
  ),
  height_cm_override: z.preprocess(
    (val) => (val === "" || val === undefined || val === null) ? undefined : parseInt(String(val), 10),
    z.number().int().min(0).optional().nullable()
  ),
});

export const productFormSchema = productBaseSchema
  .merge(productPricingSchema)
  .merge(productShippingSchema)
  .extend({
    has_variants: z.boolean().default(false),
    variant_options: z.array(variantAttributeOptionSchema).optional(),
    variants: z.array(productVariantSchema).optional(),
    images: z.array(imageSchema).optional().default([]),
  })
  .refine(data => {
    if (data.has_variants) {
      return data.variants && data.variants.length > 0;
    }
    return true;
  }, {
    message: "Adicione pelo menos uma variante se 'Possui Variantes' estiver marcado.",
    path: ['variants'],
  })
  .refine(data => {
    if (data.has_variants) {
      return data.variant_options && data.variant_options.length > 0;
    }
    return true;
  }, {
    message: "Configure pelo menos uma opção de variante (ex: Cor, Tamanho).",
    path: ['variant_options'],
  })
  .refine(data => {
     if (!data.has_variants) {
      return data.base_price !== undefined && data.base_price > 0;
    }
    return true;
  }, {
    message: "Preço base é obrigatório para produtos sem variantes.",
    path: ['base_price'],
  })
  .refine(data => {
    if (!data.has_variants) {
      return data.sku_base && data.sku_base.trim() !== '';
    }
    return true;
  }, {
    message: "SKU base é obrigatório para produtos sem variantes.",
    path: ['sku_base'],
  });


export const productDefaultValues = {
  name: '',
  slug: '',
  description_short: '',
  description_long: '',
  base_price: undefined,
  compare_at_price: undefined,
  sku_base: '',
  inventory_quantity_base: 0,
  is_active: true,
  is_featured: false,
  category_id: null,
  brand_id: null,
  tags: [],
  weight_grams: undefined,
  length_cm: undefined,
  width_cm: undefined,
  height_cm: undefined,
  meta_title: '',
  meta_description: '',
  has_variants: false,
  variant_options: [{ option_name: '', values: [''] }],
  variants: [],
  images: [],
};

