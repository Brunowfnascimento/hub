
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Globe } from 'lucide-react';
    
    const AdminMarketingSeoPage = () => {
      return (
        <>
          <Helmet>
            <title>SEO - Marketing - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Otimização para Motores de Busca (SEO)
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Globe className="mr-3 h-8 w-8" />
                  Melhore sua Visibilidade
                </CardTitle>
                <CardDescription className="text-indigo-100">
                  Esta página está em desenvolvimento. Em breve, você terá ferramentas para otimizar o SEO da sua loja.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Dashboard de SEO com análise de palavras-chave e meta tags" src="https://images.unsplash.com/photo-1675023112817-52b789fd2ef0" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminMarketingSeoPage;
  