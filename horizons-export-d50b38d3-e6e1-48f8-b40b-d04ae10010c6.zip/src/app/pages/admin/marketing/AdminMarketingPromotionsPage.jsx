
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Gift } from 'lucide-react';
    
    const AdminMarketingPromotionsPage = () => {
      return (
        <>
          <Helmet>
            <title>Promoções - Marketing - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Gerenciamento de Promoções
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-pink-500 to-rose-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Gift className="mr-3 h-8 w-8" />
                  Crie Promoções Atrativas
                </CardTitle>
                <CardDescription className="text-pink-100">
                  Esta página está em desenvolvimento. Em breve, você poderá criar e gerenciar promoções para seus produtos.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Interface de criação de promoções com regras e descontos" src="https://images.unsplash.com/photo-1641803216631-47d43eb4f35e" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminMarketingPromotionsPage;
  