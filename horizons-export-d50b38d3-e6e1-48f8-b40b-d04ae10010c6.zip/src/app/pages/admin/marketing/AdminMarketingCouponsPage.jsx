
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import AdminCouponsPage from '@/app/pages/admin/AdminCouponsPage';
    
    const AdminMarketingCouponsPage = () => {
      return (
        <>
          <Helmet>
            <title>Campanhas de Cupons - Marketing - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <AdminCouponsPage isMarketingContext={true} />
          </motion.div>
        </>
      );
    };
    
    export default AdminMarketingCouponsPage;
  