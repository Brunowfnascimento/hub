
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { LayoutDashboard } from 'lucide-react';
    
    const AdminShippingSummaryPage = () => {
      return (
        <>
          <Helmet>
            <title>Resumo de Envios - Logística - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Resumo de Envios
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <LayoutDashboard className="mr-3 h-8 w-8" />
                  Dashboard de Logística
                </CardTitle>
                <CardDescription className="text-blue-200">
                  Esta página está em desenvolvimento. Em breve, você terá um resumo das suas operações de envio.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Dashboard de logística com gráficos de envios e status" src="https://images.unsplash.com/photo-1666291631431-85cd843669ee" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminShippingSummaryPage;
  