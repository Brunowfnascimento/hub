
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { MapPin } from 'lucide-react';
    import ZonesTab from '@/app/features/admin/shipping-management/components/ZonesTab';
    import ErrorBoundary from '@/app/components/common/ErrorBoundary';
    import ErrorDisplay from '@/app/components/common/ErrorDisplay';
    
    const AdminShippingZonesPage = () => {
      return (
        <>
          <Helmet>
            <title>Zonas de Entrega - Logística - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Zonas de Entrega
              </h1>
            </div>
            <ErrorBoundary fallback={<ErrorDisplay message="Ocorreu um erro ao carregar as Zonas de Entrega." />}>
              <ZonesTab />
            </ErrorBoundary>
          </motion.div>
        </>
      );
    };
    
    export default AdminShippingZonesPage;
  