
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Tag } from 'lucide-react';
    
    const AdminShippingLabelsPage = () => {
      return (
        <>
          <Helmet>
            <title>Etiquetas de Envio - Logística - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Gerenciamento de Etiquetas
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-green-500 to-teal-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Tag className="mr-3 h-8 w-8" />
                  Impressão de Etiquetas
                </CardTitle>
                <CardDescription className="text-green-100">
                  Esta página está em desenvolvimento. Em breve, você poderá gerar e imprimir etiquetas de envio.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Interface de geração de etiquetas de envio com opções de formato" src="https://images.unsplash.com/photo-1687989798028-9a190beab506" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminShippingLabelsPage;
  