
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { FileInput } from 'lucide-react';
    
    const AdminShippingQuotesPage = () => {
      return (
        <>
          <Helmet>
            <title>Cotação de Frete - Logística - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Cotação de Frete
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <FileInput className="mr-3 h-8 w-8" />
                  Simular Frete
                </CardTitle>
                <CardDescription className="text-purple-100">
                  Esta página está em desenvolvimento. Em breve, você poderá realizar cotações de frete.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Formulário de cotação de frete com campos de CEP, peso e dimensões" src="https://images.unsplash.com/photo-1685482934962-795ee97e12e7" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminShippingQuotesPage;
  