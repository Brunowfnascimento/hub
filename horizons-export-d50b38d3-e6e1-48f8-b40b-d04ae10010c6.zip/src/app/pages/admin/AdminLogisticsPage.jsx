
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Briefcase } from 'lucide-react';
    
    const AdminLogisticsPage = () => {
      return (
        <>
          <Helmet>
            <title>Logística - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Painel de Logística
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-teal-500 to-green-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Briefcase className="mr-3 h-8 w-8" />
                  Otimize sua Cadeia de Suprimentos
                </CardTitle>
                <CardDescription className="text-teal-100">
                  Esta seção está em desenvolvimento. Em breve, você terá ferramentas avançadas para gerenciar a logística da sua loja.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-teal-50">
                  <li>Gerenciamento de inventário multi-local</li>
                  <li>Otimização de rotas de entrega</li>
                  <li>Integração com transportadoras (além do básico em "Frete")</li>
                  <li>Gestão de devoluções e trocas</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Mapa com rotas de entrega e caminhões" className="mt-6 rounded-lg shadow-md w-full h-auto object-cover max-h-64 opacity-80" src="https://images.unsplash.com/photo-1655121894640-bdaf2b4c4a29" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminLogisticsPage;
  