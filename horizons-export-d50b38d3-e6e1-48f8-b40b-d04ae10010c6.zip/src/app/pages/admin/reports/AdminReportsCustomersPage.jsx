
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Users } from 'lucide-react';
    
    const AdminReportsCustomersPage = () => {
      return (
        <>
          <Helmet>
            <title>Relatório de Clientes - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Relatório de Clientes
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-green-500 to-emerald-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Users className="mr-3 h-8 w-8" />
                  Análise de Comportamento do Cliente
                </CardTitle>
                <CardDescription className="text-green-100">
                  Esta página está em desenvolvimento. Em breve, você terá acesso a relatórios detalhados sobre seus clientes.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Relatório de clientes com segmentação e valor de vida útil do cliente (LTV)" src="https://images.unsplash.com/photo-1686061594225-3e92c0cd51b0" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminReportsCustomersPage;
  