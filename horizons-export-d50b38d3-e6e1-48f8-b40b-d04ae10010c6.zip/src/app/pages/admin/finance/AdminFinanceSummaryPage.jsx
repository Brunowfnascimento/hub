
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { BarChart3 } from 'lucide-react';
    
    const AdminFinanceSummaryPage = () => {
      return (
        <>
          <Helmet>
            <title>Resumo Financeiro - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Resumo Financeiro
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-green-500 to-cyan-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <BarChart3 className="mr-3 h-8 w-8" />
                  Seu Resumo Financeiro
                </CardTitle>
                <CardDescription className="text-green-100">
                  Esta página está em desenvolvimento. Em breve, você verá um resumo completo das finanças da sua loja.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Dashboard financeiro com gráficos e números" src="https://images.unsplash.com/photo-1625296276703-3fbc924f07b5" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminFinanceSummaryPage;
  