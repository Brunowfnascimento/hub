
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { CreditCard } from 'lucide-react';
    
    const AdminFinanceBankAccountsPage = () => {
      return (
        <>
          <Helmet>
            <title>Contas Bancárias - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Gerenciamento de Contas Bancárias
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-pink-500 to-rose-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <CreditCard className="mr-3 h-8 w-8" />
                  Suas Contas Bancárias
                </CardTitle>
                <CardDescription className="text-pink-100">
                  Esta página está em desenvolvimento. Em breve, você poderá adicionar e gerenciar suas contas bancárias para recebimento.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Cartões de crédito e ícones bancários" src="https://images.unsplash.com/photo-1613243555978-636c48dc653c" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminFinanceBankAccountsPage;
  