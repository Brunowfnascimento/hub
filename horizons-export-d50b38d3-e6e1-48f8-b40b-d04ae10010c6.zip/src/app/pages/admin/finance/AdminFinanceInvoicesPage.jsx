
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { FileText } from 'lucide-react';
    
    const AdminFinanceInvoicesPage = () => {
      return (
        <>
          <Helmet>
            <title>Faturas - Financeiro - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Gerenciamento de Faturas
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <FileText className="mr-3 h-8 w-8" />
                  Suas Faturas
                </CardTitle>
                <CardDescription className="text-cyan-100">
                  Esta página está em desenvolvimento. Em breve, você poderá visualizar e gerenciar as faturas da sua loja.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Lista de faturas com status de pagamento e opções de download" src="https://images.unsplash.com/photo-1634733988138-bf2c3a2a13fa" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminFinanceInvoicesPage;
  