
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { BarChart3 } from 'lucide-react';
    
    const AdminSalesTransactionsPage = () => {
      return (
        <>
          <Helmet>
            <title>Transações de Vendas - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Transações de Vendas
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-teal-500 to-cyan-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <BarChart3 className="mr-3 h-8 w-8" />
                  Detalhes das Transações
                </CardTitle>
                <CardDescription className="text-teal-100">
                  Esta página está em desenvolvimento. Em breve, você poderá visualizar todas as transações de vendas.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Gráfico de pizza mostrando distribuição de vendas por canal" src="https://images.unsplash.com/photo-1675825547463-0788eca2320e" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSalesTransactionsPage;
  