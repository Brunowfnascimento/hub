
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Users } from 'lucide-react';
    
    const AdminSalesCustomersReportPage = () => {
      return (
        <>
          <Helmet>
            <title>Relatório de Vendas por Cliente - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Relatório de Vendas por Cliente
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Users className="mr-3 h-8 w-8" />
                  Análise de Clientes
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Esta página está em desenvolvimento. Em breve, você terá acesso a relatórios detalhados sobre o comportamento de compra dos seus clientes.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Lista de clientes com total de compras e data da última compra" src="https://images.unsplash.com/photo-1692914274321-d8d1b0c01d97" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSalesCustomersReportPage;
  