
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { FileText } from 'lucide-react';
    
    const AdminProductsAttributesPage = () => {
      return (
        <>
          <Helmet>
            <title>Atributos de Produtos - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Gerenciamento de Atributos
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-lime-500 to-green-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <FileText className="mr-3 h-8 w-8" />
                  Atributos Globais
                </CardTitle>
                <CardDescription className="text-lime-100">
                  Esta página está em desenvolvimento. Em breve, você poderá criar e gerenciar atributos globais para seus produtos (ex: Cor, Tamanho).
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Interface de criação de atributos com campos para nome e tipo de atributo" src="https://images.unsplash.com/photo-1479759868367-e2068a89dd2f" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminProductsAttributesPage;
  