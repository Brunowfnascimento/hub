
    import React from 'react';
    import AdminLoginForm from '@/app/features/admin/auth/components/AdminLoginForm';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { ShieldCheck } from 'lucide-react';
    import { Helmet } from 'react-helmet-async';
    
    const AdminLoginPage = () => {
      return (
        <>
        <Helmet><title>Login Admin - VittaHub</title></Helmet>
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900 p-4">
          <Card className="w-full max-w-md shadow-2xl bg-slate-100 dark:bg-slate-800 rounded-xl overflow-hidden">
            <CardHeader className="text-center p-8 bg-slate-200 dark:bg-slate-700">
              <div className="flex justify-center mb-4">
                <ShieldCheck className="h-16 w-16 text-sky-600 dark:text-sky-400" />
              </div>
              <CardTitle className="text-3xl font-bold text-slate-800 dark:text-slate-100">Acesso Administrativo</CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300 pt-1">
                Use suas credenciais para gerenciar a plataforma.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-8">
              <AdminLoginForm />
            </CardContent>
          </Card>
        </div>
        </>
      );
    };
    
    export default AdminLoginPage;
  