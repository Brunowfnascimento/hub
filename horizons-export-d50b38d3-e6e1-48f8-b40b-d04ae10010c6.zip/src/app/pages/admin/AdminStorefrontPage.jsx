
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Store } from 'lucide-react';
    
    const AdminStorefrontPage = () => {
      return (
        <>
          <Helmet>
            <title>Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Configurações da Loja Virtual
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-orange-500 to-yellow-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Store className="mr-3 h-8 w-8" />
                  Personalize sua Vitrine
                </CardTitle>
                <CardDescription className="text-orange-100">
                  Esta seção está em desenvolvimento. Em breve, você poderá customizar a aparência e funcionalidades da sua loja.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-orange-50">
                  <li>Editor de temas e layout</li>
                  <li>Gerenciamento de páginas (Sobre, Contato, etc.)</li>
                  <li>Configurações de SEO para a loja</li>
                  <li>Gestão de banners e promoções visuais</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Interface de um editor de website" className="mt-6 rounded-lg shadow-md w-full h-auto object-cover max-h-64 opacity-80" src="https://images.unsplash.com/photo-1607706189992-eae578626c86" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminStorefrontPage;
  