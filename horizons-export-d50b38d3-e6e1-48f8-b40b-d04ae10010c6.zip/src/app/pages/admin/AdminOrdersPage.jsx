
    import React, { useState, useMemo } from 'react';
    import { useQuery } from '@tanstack/react-query';
    import { fetchAdminOrders } from '@/app/features/admin/order-management/services/orderAdmin.service.jsx';
    import OrderFiltersAdmin from '@/app/features/admin/order-management/components/OrderFiltersAdmin.jsx';
    import AdminOrderList from '@/app/features/admin/order-management/components/AdminOrderList.jsx';
    import AdminOrderDetailModal from '@/app/features/admin/order-management/components/AdminOrderDetailModal.jsx';
    import LoadingSpinner from '@/app/components/common/LoadingSpinner';
    import ErrorDisplay from '@/app/components/common/ErrorDisplay';
    import { AdminOrderFilters, AdminOrderPagination, AdminOrderSorting } from '@/app/types/admin.types.jsx';
    import { motion } from 'framer-motion';
    import { useToast } from '@/components/ui/use-toast';
    import { Helmet } from 'react-helmet-async';
    import ErrorBoundary from '@/app/components/common/ErrorBoundary';
    
    const AdminOrdersPageContent = () => {
      const { toast } = useToast();
      const [filters, setFilters] = useState(AdminOrderFilters);
      const [appliedFilters, setAppliedFilters] = useState(AdminOrderFilters);
      const [pagination, setPagination] = useState(AdminOrderPagination);
      const [sorting, setSorting] = useState(AdminOrderSorting);
      const [selectedOrders, setSelectedOrders] = useState([]);
      const [isModalOpen, setIsModalOpen] = useState(false);
      const [currentOrderId, setCurrentOrderId] = useState(null);
    
      const queryParams = useMemo(() => ({
        ...appliedFilters,
        page: pagination.page,
        limit: pagination.limit,
        sortBy: sorting.sortBy,
        sortOrder: sorting.sortOrder,
      }), [appliedFilters, pagination, sorting]);
    
      const { data, isLoading, error, refetch, isError } = useQuery({
        queryKey: ['adminOrders', queryParams],
        queryFn: () => fetchAdminOrders(queryParams),
        keepPreviousData: true,
      });
    
      const orders = data?.orders || [];
      const totalCount = data?.totalCount || 0;
      const totalPages = Math.ceil(totalCount / pagination.limit);
    
      const handleFiltersChange = (newFilters) => {
        setFilters(newFilters);
      };
    
      const handleApplyFilters = () => {
        setPagination(prev => ({ ...prev, page: 1 }));
        setAppliedFilters(filters);
      };
    
      const handleClearFilters = () => {
        setFilters(AdminOrderFilters);
        setAppliedFilters(AdminOrderFilters);
        setPagination(prev => ({ ...prev, page: 1 }));
      };
    
      const handlePageChange = (newPage) => {
        if (newPage >= 1 && newPage <= totalPages) {
          setPagination(prev => ({ ...prev, page: newPage }));
        }
      };
      
      const handleSort = (column) => {
        setSorting(prev => ({
          sortBy: column,
          sortOrder: prev.sortBy === column && prev.sortOrder === 'asc' ? 'desc' : 'asc',
        }));
        setPagination(prev => ({ ...prev, page: 1 }));
      };
    
      const handleSelectOrder = (orderId) => {
        setSelectedOrders(prev => 
          prev.includes(orderId) ? prev.filter(id => id !== orderId) : [...prev, orderId]
        );
      };
    
      const handleSelectAllOrders = (isChecked) => {
        if (isChecked) {
          setSelectedOrders(orders.map(order => order.id));
        } else {
          setSelectedOrders([]);
        }
      };
    
      const openOrderDetailModal = (orderId) => {
        setCurrentOrderId(orderId);
        setIsModalOpen(true);
      };
    
      const handleBulkAction = (action) => {
        if(selectedOrders.length === 0) {
          toast({ title: "Atenção", description: "Nenhum pedido selecionado.", variant: "warning"});
          return;
        }
        toast({
          title: `Ação em Lote: ${action}`,
          description: `Aplicar em ${selectedOrders.length} pedido(s). Funcionalidade em desenvolvimento.`,
        });
      };
    
      if (isLoading) return <div className="flex justify-center items-center h-64"><LoadingSpinner size="h-16 w-16" /></div>;
      if (isError) return <ErrorDisplay message={error.message || "Não foi possível carregar os pedidos."} details={error.details} />;
    
      return (
        <>
        <Helmet><title>Gerenciar Pedidos - VittaHub Admin</title></Helmet>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Gerenciamento de Pedidos</h1>
          
          <OrderFiltersAdmin 
            filters={filters} 
            onFiltersChange={handleFiltersChange}
            onApplyFilters={handleApplyFilters}
            onClearFilters={handleClearFilters}
          />
    
          
             <AdminOrderList
                orders={orders}
                selectedOrders={selectedOrders}
                onSelectOrder={handleSelectOrder}
                onSelectAllOrders={handleSelectAllOrders}
                onSort={handleSort}
                onOpenDetailModal={openOrderDetailModal}
                pagination={pagination}
                totalPages={totalPages}
                totalCount={totalCount}
                onPageChange={handlePageChange}
                onBulkAction={handleBulkAction}
                toast={toast}
            />
          
          <AdminOrderDetailModal 
            orderId={currentOrderId}
            isOpen={isModalOpen}
            onClose={() => {
              setIsModalOpen(false);
              setCurrentOrderId(null);
              refetch();
            }}
          />
        </motion.div>
        </>
      );
    };
    
    const AdminOrdersPage = () => {
      return (
        <ErrorBoundary fallback={<ErrorDisplay message="Um erro crítico ocorreu na página de pedidos." />}>
          <AdminOrdersPageContent />
        </ErrorBoundary>
      )
    }
    
    export default AdminOrdersPage;
  