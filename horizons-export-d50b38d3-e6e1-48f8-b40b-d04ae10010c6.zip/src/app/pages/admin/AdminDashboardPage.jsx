
    import React from 'react';
    import { useQuery } from '@tanstack/react-query';
    import { 
      fetchDashboardMetrics, 
      fetchSalesOverTime,
      fetchRecentOrders,
      fetchTopSellingProducts,
      fetchLowStockProducts
    } from '@/app/features/admin/dashboard/services/dashboard.service';
    import MetricCard from '@/app/features/admin/dashboard/components/MetricCard';
    import SalesChart from '@/app/features/admin/dashboard/components/SalesChart';
    import RecentOrdersWidget from '@/app/features/admin/dashboard/components/RecentOrdersWidget';
    import TopProductsWidget from '@/app/features/admin/dashboard/components/TopProductsWidget';
    import LowStockProductsWidget from '@/app/features/admin/dashboard/components/LowStockProductsWidget';
    import LoadingSpinner from '@/app/components/common/LoadingSpinner';
    import ErrorDisplay from '@/app/components/common/ErrorDisplay';
    import { DollarSign, ShoppingCart, Users, Package, AlertTriangle } from 'lucide-react';
    import { motion } from 'framer-motion';
    import { Helmet } from 'react-helmet-async';
    
    const AdminDashboardPage = () => {
      const { data: metricsData, isLoading: isLoadingMetrics, error: metricsError } = useQuery({
        queryKey: ['dashboardMetrics'],
        queryFn: fetchDashboardMetrics,
      });
    
      const { data: salesOverTimeData, isLoading: isLoadingSalesChart, error: salesChartError } = useQuery({
        queryKey: ['salesOverTime'],
        queryFn: () => fetchSalesOverTime('last_30_days'),
      });
    
      const { data: recentOrdersData, isLoading: isLoadingRecentOrders, error: recentOrdersError } = useQuery({
        queryKey: ['recentOrdersDashboard'],
        queryFn: () => fetchRecentOrders(5),
      });
    
       const { data: topProductsData, isLoading: isLoadingTopProducts, error: topProductsError } = useQuery({
        queryKey: ['topSellingProductsDashboard'],
        queryFn: () => fetchTopSellingProducts(5),
      });
    
      const { data: lowStockData, isLoading: isLoadingLowStock, error: lowStockError } = useQuery({
        queryKey: ['lowStockProductsDashboard'],
        queryFn: () => fetchLowStockProducts(5, 10), // Threshold 10
      });
    
      const formatCurrency = (value) => {
        if (typeof value !== 'number') return 'R$ 0,00';
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      };
    
      const formatNumber = (value) => {
        if (typeof value !== 'number') return '0';
        return value.toString();
      };
    
      if (isLoadingMetrics) {
        return <div className="flex justify-center items-center h-screen"><LoadingSpinner size="h-20 w-20" /></div>;
      }
    
      if (metricsError) {
        return <ErrorDisplay message={`Erro ao carregar métricas: ${metricsError.message}`} />;
      }
    
      return (
        <>
        <Helmet><title>Dashboard - VittaHub Admin</title></Helmet>
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
        >
          <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Dashboard</h1>
    
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
            <MetricCard 
              title="Vendas Totais (30d)" 
              value={metricsData?.totalSales || 0} 
              icon={DollarSign} 
              formatFn={formatCurrency}
              isLoading={isLoadingMetrics}
            />
            <MetricCard 
              title="Total de Pedidos (30d)" 
              value={metricsData?.totalOrders || 0} 
              icon={ShoppingCart} 
              formatFn={formatNumber}
              isLoading={isLoadingMetrics}
            />
            <MetricCard 
              title="Ticket Médio (30d)" 
              value={metricsData?.averageOrderValue || 0} 
              icon={DollarSign} 
              formatFn={formatCurrency}
              isLoading={isLoadingMetrics}
            />
            <MetricCard 
              title="Novos Clientes (30d)" 
              value={metricsData?.newCustomers || 0} 
              icon={Users} 
              formatFn={formatNumber}
              isLoading={isLoadingMetrics}
            />
             <MetricCard 
              title="Produtos Ativos" 
              value={metricsData?.activeProducts || 0} 
              icon={Package} 
              formatFn={formatNumber}
              isLoading={isLoadingMetrics}
            />
          </div>
    
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 bg-white dark:bg-slate-800 p-4 rounded-xl shadow-lg">
              <h2 className="text-xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Vendas nos Últimos 30 Dias</h2>
              {isLoadingSalesChart && <div className="h-80 flex justify-center items-center"><LoadingSpinner /></div>}
              {salesChartError && <ErrorDisplay message="Erro ao carregar gráfico de vendas." />}
              {!isLoadingSalesChart && !salesChartError && salesOverTimeData && <SalesChart data={salesOverTimeData} />}
            </div>
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-lg">
              <h2 className="text-xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Pedidos Recentes</h2>
              {isLoadingRecentOrders && <div className="h-80 flex justify-center items-center"><LoadingSpinner /></div>}
              {recentOrdersError && <ErrorDisplay message="Erro ao carregar pedidos recentes." />}
              {!isLoadingRecentOrders && !recentOrdersError && recentOrdersData && <RecentOrdersWidget orders={recentOrdersData} />}
            </div>
          </div>
    
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-lg">
              <h2 className="text-xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Produtos Mais Vendidos (30d)</h2>
              {isLoadingTopProducts && <div className="h-80 flex justify-center items-center"><LoadingSpinner /></div>}
              {topProductsError && <ErrorDisplay message="Erro ao carregar produtos mais vendidos." />}
              {!isLoadingTopProducts && !topProductsError && topProductsData && <TopProductsWidget products={topProductsData} />}
            </div>
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-lg">
               <h2 className="text-xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Produtos com Baixo Estoque (&lt;10 un.)</h2>
              {isLoadingLowStock && <div className="h-80 flex justify-center items-center"><LoadingSpinner /></div>}
              {lowStockError && <ErrorDisplay message="Erro ao carregar produtos com baixo estoque." />}
              {!isLoadingLowStock && !lowStockError && lowStockData && <LowStockProductsWidget products={lowStockData} />}
            </div>
          </div>
    
        </motion.div>
        </>
      );
    };
    
    export default AdminDashboardPage;
  