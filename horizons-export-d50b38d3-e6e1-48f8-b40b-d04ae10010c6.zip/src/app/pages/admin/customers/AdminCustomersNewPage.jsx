
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { UserPlus } from 'lucide-react';
    
    const AdminCustomersNewPage = () => {
      return (
        <>
          <Helmet>
            <title>Adicionar Novo Cliente - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Adicionar Novo Cliente
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-green-400 to-emerald-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <UserPlus className="mr-3 h-8 w-8" />
                  Cadastro de Cliente
                </CardTitle>
                <CardDescription className="text-green-100">
                  Esta página está em desenvolvimento. Em breve, você poderá adicionar novos clientes manualmente.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Formulário de cadastro de novo cliente com campos de nome, email e telefone" src="https://images.unsplash.com/photo-1565250732404-64317a4e8b15" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminCustomersNewPage;
  