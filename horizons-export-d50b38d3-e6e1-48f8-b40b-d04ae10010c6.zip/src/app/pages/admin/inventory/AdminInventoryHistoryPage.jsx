
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { FileText } from 'lucide-react';
    
    const AdminInventoryHistoryPage = () => {
      return (
        <>
          <Helmet>
            <title>Histórico de Movimentações de Estoque - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Histórico de Movimentações
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-stone-500 to-neutral-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <FileText className="mr-3 h-8 w-8" />
                  Rastrear Estoque
                </CardTitle>
                <CardDescription className="text-stone-200">
                  Esta página está em desenvolvimento. Em breve, você poderá visualizar o histórico completo de movimentações do seu estoque.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Tabela com histórico de movimentações de estoque, incluindo data, produto e tipo de movimentação" src="https://images.unsplash.com/photo-1689942010216-dc412bb1e7a9" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminInventoryHistoryPage;
  