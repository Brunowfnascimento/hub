
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Repeat } from 'lucide-react';
    
    const AdminInventoryAdjustmentsPage = () => {
      return (
        <>
          <Helmet>
            <title>Ajustes Manuais de Estoque - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Ajustes Manuais de Estoque
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-slate-600 to-gray-700 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Repeat className="mr-3 h-8 w-8" />
                  Ajustar Quantidades
                </CardTitle>
                <CardDescription className="text-slate-300">
                  Esta página está em desenvolvimento. Em breve, você poderá realizar ajustes manuais no seu inventário.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Formulário de ajuste de estoque com campos para produto, quantidade e motivo" src="https://images.unsplash.com/photo-1586282023426-f4f6f305fa07" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminInventoryAdjustmentsPage;
  