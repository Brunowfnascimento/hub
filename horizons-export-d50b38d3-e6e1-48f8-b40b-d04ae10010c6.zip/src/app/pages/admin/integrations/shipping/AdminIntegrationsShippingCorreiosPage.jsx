
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Truck } from 'lucide-react';
    
    const AdminIntegrationsShippingCorreiosPage = () => {
      return (
        <>
          <Helmet>
            <title>Correios - Integração Transportadoras - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Correios
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-yellow-400 to-amber-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Truck className="mr-3 h-8 w-8" />
                  Correios
                </CardTitle>
                <CardDescription className="text-yellow-100">
                  Esta página está em desenvolvimento. Configure sua integração com os Correios.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Logo dos Correios" src="https://images.unsplash.com/photo-1701086033818-d048434b3c4a" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsShippingCorreiosPage;
  