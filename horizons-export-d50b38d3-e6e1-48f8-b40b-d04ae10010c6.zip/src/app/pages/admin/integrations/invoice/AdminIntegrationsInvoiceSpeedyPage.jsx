
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { FileText } from 'lucide-react';
    
    const AdminIntegrationsInvoiceSpeedyPage = () => {
      return (
        <>
          <Helmet>
            <title>Speedy - Notas Fiscais - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Speedy
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-purple-400 to-fuchsia-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <FileText className="mr-3 h-8 w-8" />
                  Speedy
                </CardTitle>
                <CardDescription className="text-purple-100">
                  Esta página está em desenvolvimento. Configure sua integração com Speedy para emissão de notas fiscais.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Logo da Speedy" src="https://images.unsplash.com/photo-1589648683104-f9e71318da86" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsInvoiceSpeedyPage;
  