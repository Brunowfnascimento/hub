
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { FileText } from 'lucide-react';
    
    const AdminIntegrationsInvoiceBlingPage = () => {
      return (
        <>
          <Helmet>
            <title>Bling - Notas Fiscais - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Bling
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-orange-400 to-amber-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <FileText className="mr-3 h-8 w-8" />
                  Bling
                </CardTitle>
                <CardDescription className="text-orange-100">
                  Esta página está em desenvolvimento. Configure sua integração com Bling para emissão de notas fiscais e gestão.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Logo da Bling" src="https://images.unsplash.com/photo-1694208590719-96139a8f2a32" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsInvoiceBlingPage;
  