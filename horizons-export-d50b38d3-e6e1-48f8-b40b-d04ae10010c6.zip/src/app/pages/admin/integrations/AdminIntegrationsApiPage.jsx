
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Zap } from 'lucide-react';
    
    const AdminIntegrationsApiPage = () => {
      return (
        <>
          <Helmet>
            <title>API - Integrações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Acesso API
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-sky-600 to-cyan-700 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Zap className="mr-3 h-8 w-8" />
                  Chaves de API e Documentação
                </CardTitle>
                <CardDescription className="text-sky-200">
                  Esta página está em desenvolvimento. Em breve, você poderá gerenciar suas chaves de API e acessar a documentação.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-sky-100">
                  <li>Geração e revogação de chaves de API</li>
                  <li>Logs de uso da API</li>
                  <li>Limites de taxa e permissões</li>
                  <li>Link para documentação completa da API</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Código de programação e ícones de API" src="https://images.unsplash.com/photo-1605907076977-092e0a203c92" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsApiPage;
  