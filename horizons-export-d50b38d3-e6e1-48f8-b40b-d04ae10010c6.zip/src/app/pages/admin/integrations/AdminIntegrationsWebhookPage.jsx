
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Briefcase } from 'lucide-react';
    
    const AdminIntegrationsWebhookPage = () => {
      return (
        <>
          <Helmet>
            <title>Webhooks - Integrações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Gerenciamento de Webhooks
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-indigo-500 to-purple-700 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Briefcase className="mr-3 h-8 w-8" />
                  Configure seus Webhooks
                </CardTitle>
                <CardDescription className="text-indigo-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar e gerenciar webhooks para integrar com serviços externos.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-indigo-50">
                  <li>Criação e edição de webhooks</li>
                  <li>Visualização de logs de eventos</li>
                  <li>Testes de endpoints de webhook</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Diagrama de fluxo de dados de webhook" src="https://images.unsplash.com/photo-1669189601173-90c4e5952411" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsWebhookPage;
  