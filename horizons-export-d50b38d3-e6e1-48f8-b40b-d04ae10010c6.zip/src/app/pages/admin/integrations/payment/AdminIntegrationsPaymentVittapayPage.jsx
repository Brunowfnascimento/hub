
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { CreditCard } from 'lucide-react';
    
    const AdminIntegrationsPaymentVittapayPage = () => {
      return (
        <>
          <Helmet>
            <title>VittaPay - Meios de Pagamento - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração VittaPay
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-green-500 to-emerald-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <CreditCard className="mr-3 h-8 w-8" />
                  VittaPay
                </CardTitle>
                <CardDescription className="text-green-100">
                  Esta página está em desenvolvimento. Configure sua integração com VittaPay.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Logo do VittaPay" src="https://images.unsplash.com/photo-1556742111-a301076d9d18" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsPaymentVittapayPage;
  