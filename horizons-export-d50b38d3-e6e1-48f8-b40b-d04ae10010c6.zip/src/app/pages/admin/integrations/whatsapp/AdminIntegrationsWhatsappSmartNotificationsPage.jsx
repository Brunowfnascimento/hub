
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Zap } from 'lucide-react';
    
    const AdminIntegrationsWhatsappSmartNotificationsPage = () => {
      return (
        <>
          <Helmet>
            <title>Notificações Inteligentes - WhatsApp - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Notificações Inteligentes (WhatsApp)
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Zap className="mr-3 h-8 w-8" />
                  Notificações Automatizadas e Inteligentes
                </CardTitle>
                <CardDescription className="text-teal-100">
                  Esta página está em desenvolvimento. Em breve, configure notificações inteligentes via WhatsApp.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Ícones de notificação e engrenagens" src="https://images.unsplash.com/photo-1697630725124-3fcce8e3c6f3" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsWhatsappSmartNotificationsPage;
  