
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { TextCursorInput } from 'lucide-react';
    
    const AdminIntegrationsWhatsappBotPage = () => {
      return (
        <>
          <Helmet>
            <title>Bot Conversa - Integração WhatsApp - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Bot Conversa (WhatsApp)
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-cyan-500 to-sky-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <TextCursorInput className="mr-3 h-8 w-8" />
                  Configure seu Bot de Conversa
                </CardTitle>
                <CardDescription className="text-cyan-100">
                  Esta página está em desenvolvimento. Em breve, você poderá criar e gerenciar fluxos de bot para WhatsApp.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Fluxograma de um bot de conversa" src="https://images.unsplash.com/photo-1619107278445-1c70db80eb9d" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsWhatsappBotPage;
  