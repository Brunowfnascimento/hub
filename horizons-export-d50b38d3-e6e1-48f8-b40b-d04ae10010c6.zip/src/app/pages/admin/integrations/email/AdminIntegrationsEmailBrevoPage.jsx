
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Mail } from 'lucide-react';
    
    const AdminIntegrationsEmailBrevoPage = () => {
      return (
        <>
          <Helmet>
            <title>Brevo - Email Marketing - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Brevo (Sendinblue)
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-sky-400 to-cyan-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Mail className="mr-3 h-8 w-8" />
                  Brevo
                </CardTitle>
                <CardDescription className="text-sky-100">
                  Esta página está em desenvolvimento. Configure sua integração com Brevo.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Logo da Brevo (anteriormente Sendinblue)" src="https://images.unsplash.com/photo-1675022991860-ad46e3e9c150" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsEmailBrevoPage;
  