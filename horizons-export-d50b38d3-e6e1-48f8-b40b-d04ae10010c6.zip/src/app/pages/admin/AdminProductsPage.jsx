
    import React, { useState, useEffect, useMemo } from 'react';
            import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
            import { Link } from 'react-router-dom';
            import { getAdminProducts as WorkspaceProducts } from '@/app/features/admin/product-management/services/productQueries.service.jsx';
            import { deleteProductAction } from '@/app/features/admin/product-management/services/productActions.service.jsx';
            import ProductListTable from '@/app/features/admin/product-management/components/ProductListTable.jsx';
            import ProductFiltersAdmin from '@/app/features/admin/product-management/components/ProductFiltersAdmin.jsx';
            import LoadingSpinner from '@/app/components/common/LoadingSpinner';
            import ErrorDisplay from '@/app/components/common/ErrorDisplay';
            import { Button } from '@/components/ui/button';
            import { PlusCircle, Search } from 'lucide-react';
            import { useToast } from "@/components/ui/use-toast";
            import {
              AlertDialog,
              AlertDialogAction,
              AlertDialogCancel,
              AlertDialogContent,
              AlertDialogDescription,
              AlertDialogFooter,
              AlertDialogHeader,
              AlertDialogTitle,
            } from "@/components/ui/alert-dialog";
            import {
              Pagination,
              PaginationContent,
              PaginationItem,
              PaginationLink,
              PaginationNext,
              PaginationPrevious,
              PaginationEllipsis,
            } from "@/components/ui/pagination";
            import { motion } from 'framer-motion';
            import { Helmet } from 'react-helmet-async';
            import ErrorBoundary from '@/app/components/common/ErrorBoundary';
            
            const AdminProductsPageContent = () => {
              const { toast } = useToast();
              const queryClient = useQueryClient();
              const [filters, setFilters] = useState({
                searchTerm: '',
                categoryId: 'all',
                brandId: 'all',
                status: 'all',
                sortBy: 'created_at',
                sortOrder: 'desc',
              });
              const [appliedFilters, setAppliedFilters] = useState(filters);
              const [currentPage, setCurrentPage] = useState(1);
              const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
              const [productToDelete, setProductToDelete] = useState(null);
            
              const queryParams = useMemo(() => ({
                ...appliedFilters,
                page: currentPage,
                limit: 10, 
              }), [appliedFilters, currentPage]);
            
              const { data, isLoading, error, isError } = useQuery({
                queryKey: ['adminProducts', queryParams],
                queryFn: () => WorkspaceProducts(queryParams),
                keepPreviousData: true,
              });
            
              const products = data?.data || [];
              const totalCount = data?.count || 0;
              const totalPages = data?.totalPages || 1;
            
              const deleteProductMutation = useMutation({
                mutationFn: deleteProductAction,
                onSuccess: (data) => {
                  toast({
                    title: "Produto Deletado",
                    description: `O produto foi deletado com sucesso.`,
                    variant: "success",
                  });
                  queryClient.invalidateQueries(['adminProducts']);
                },
                onError: (error) => {
                  toast({
                    title: "Erro ao Deletar",
                    description: error.message || "Não foi possível deletar o produto.",
                    variant: "destructive",
                  });
                },
                onSettled: () => {
                  setIsDeleteDialogOpen(false);
                  setProductToDelete(null);
                },
              });
            
              const handleFiltersChange = (newFilters) => {
                setFilters(newFilters);
              };
            
              const handleApplyFilters = () => {
                setCurrentPage(1);
                setAppliedFilters(filters);
              };
            
              const handleClearFilters = () => {
                const clearedFilters = {
                    searchTerm: '',
                    categoryId: 'all',
                    brandId: 'all',
                    status: 'all',
                    sortBy: 'created_at',
                    sortOrder: 'desc',
                };
                setFilters(clearedFilters);
                setCurrentPage(1);
                setAppliedFilters(clearedFilters);
              };
            
              const handlePageChange = (newPage) => {
                if (newPage >= 1 && newPage <= totalPages) {
                  setCurrentPage(newPage);
                }
              };
            
              const handleSort = (column) => {
                const newSortOrder = filters.sortBy === column && filters.sortOrder === 'asc' ? 'desc' : 'asc';
                const newFilters = { ...filters, sortBy: column, sortOrder: newSortOrder };
                setFilters(newFilters);
                setCurrentPage(1);
                setAppliedFilters(newFilters);
              };
            
              const openDeleteDialog = (product) => {
                setProductToDelete(product);
                setIsDeleteDialogOpen(true);
              };
            
              const confirmDeleteProduct = () => {
                if (productToDelete) {
                  deleteProductMutation.mutate(productToDelete.id);
                }
              };
            
              const renderPaginationItems = () => {
                const items = [];
                const maxPagesToShow = 3; 
                const pageBuffer = 1; 
            
                if (totalPages <= 1) return null;
            
                items.push(
                  <PaginationItem key="prev">
                    <PaginationPrevious 
                      href="#" 
                      onClick={(e) => { e.preventDefault(); handlePageChange(currentPage - 1); }}
                      disabled={currentPage === 1}
                      className={currentPage === 1 ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
                    />
                  </PaginationItem>
                );
            
                if (totalPages <= maxPagesToShow + (pageBuffer * 2)) {
                  for (let i = 1; i <= totalPages; i++) {
                    items.push(
                      <PaginationItem key={i}>
                        <PaginationLink
                          href="#"
                          isActive={currentPage === i}
                          onClick={(e) => { e.preventDefault(); handlePageChange(i); }}
                           className={currentPage === i ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
                        >
                          {i}
                        </PaginationLink>
                      </PaginationItem>
                    );
                  }
                } else {
                  items.push(
                    <PaginationItem key={1}>
                      <PaginationLink href="#" onClick={(e) => { e.preventDefault(); handlePageChange(1); }} className={currentPage === 1 ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>1</PaginationLink>
                    </PaginationItem>
                  );
            
                  if (currentPage > pageBuffer + 2) {
                    items.push(<PaginationItem key="start-ellipsis"><PaginationEllipsis /></PaginationItem>);
                  }
            
                  const startRange = Math.max(2, currentPage - pageBuffer);
                  const endRange = Math.min(totalPages - 1, currentPage + pageBuffer);
            
                  for (let i = startRange; i <= endRange; i++) {
                    items.push(
                      <PaginationItem key={i}>
                        <PaginationLink
                          href="#"
                          isActive={currentPage === i}
                          onClick={(e) => { e.preventDefault(); handlePageChange(i); }}
                          className={currentPage === i ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
                        >
                          {i}
                        </PaginationLink>
                      </PaginationItem>
                    );
                  }
            
                  if (currentPage < totalPages - pageBuffer - 1) {
                    items.push(<PaginationItem key="end-ellipsis"><PaginationEllipsis /></PaginationItem>);
                  }
            
                  items.push(
                    <PaginationItem key={totalPages}>
                      <PaginationLink href="#" onClick={(e) => { e.preventDefault(); handlePageChange(totalPages);}} className={currentPage === totalPages ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>{totalPages}</PaginationLink>
                    </PaginationItem>
                  );
                }
            
                items.push(
                  <PaginationItem key="next">
                    <PaginationNext 
                      href="#" 
                      onClick={(e) => { e.preventDefault(); handlePageChange(currentPage + 1); }}
                      disabled={currentPage === totalPages}
                      className={currentPage === totalPages ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
                    />
                  </PaginationItem>
                );
                return items;
              };
            
              if (isLoading) return <div className="flex justify-center items-center h-64"><LoadingSpinner size="h-16 w-16" /></div>;
              if (isError) return <ErrorDisplay message={error.message || "Não foi possível carregar os produtos."} details={error.details} />;
            
              return (
                <>
                <Helmet><title>Gerenciar Produtos - VittaHub Admin</title></Helmet>
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-6"
                >
                  <div className="flex justify-between items-center">
                    <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Gerenciamento de Produtos</h1>
                    <Link to="/admin/products/new">
                      <Button className="bg-sky-500 hover:bg-sky-600 dark:bg-sky-600 dark:hover:bg-sky-700 dark:text-white">
                        <PlusCircle className="mr-2 h-5 w-5" /> Adicionar Produto
                      </Button>
                    </Link>
                  </div>
            
                  <ProductFiltersAdmin 
                    initialFilters={filters}
                    onFiltersChange={handleFiltersChange}
                    onApplyFilters={handleApplyFilters}
                    onClearFilters={handleClearFilters}
                  />
            
                  
                    <>
                      <ProductListTable 
                        products={products} 
                        sortParams={filters}
                        onSort={handleSort}
                        onDeleteProduct={openDeleteDialog}
                        selectedProducts={[]}
                        setSelectedProducts={() => {}}
                        isLoading={isLoading}
                      />
                      {totalPages > 0 && (
                        <div className="mt-6 flex justify-center">
                          <Pagination>
                            <PaginationContent>
                              {renderPaginationItems()}
                            </PaginationContent>
                          </Pagination>
                        </div>
                      )}
                       {totalPages > 0 && (
                        <p className="text-center text-sm text-slate-600 dark:text-slate-400 mt-2">
                          Página {currentPage} de {totalPages}. Total de {totalCount} produtos.
                        </p>
                      )}
                    </>
                  
            
                  <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                    <AlertDialogContent className="dark:bg-slate-800">
                      <AlertDialogHeader>
                        <AlertDialogTitle className="dark:text-slate-100">Confirmar Deleção</AlertDialogTitle>
                        <AlertDialogDescription className="dark:text-slate-400">
                          Tem certeza que deseja deletar o produto "{productToDelete?.name}"? Esta ação não pode ser desfeita.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)} className="dark:bg-slate-700 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-600">Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDeleteProduct} className="bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700 dark:text-white">
                          {deleteProductMutation.isLoading ? <LoadingSpinner size="h-4 w-4" /> : "Deletar"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
            
                </motion.div>
                </>
              );
            };
        
        const AdminProductsPage = () => {
          return (
            <ErrorBoundary fallback={<ErrorDisplay message="Um erro crítico ocorreu na página de produtos." />}>
              <AdminProductsPageContent />
            </ErrorBoundary>
          )
        }
            
            export default AdminProductsPage;
  