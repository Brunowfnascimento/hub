
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Building } from 'lucide-react';
    
    const AdminStorefrontFiscalPage = () => {
      return (
        <>
          <Helmet>
            <title>Informações Fiscais - Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Informações Fiscais da Loja
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-gray-600 to-slate-800 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Building className="mr-3 h-8 w-8" />
                  Dados Fiscais
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Esta página está em desenvolvimento. Gerencie as informações fiscais da sua loja.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-gray-200">
                  <li>Configuração de CNPJ, Razão Social, Inscrição Estadual</li>
                  <li>Endereço fiscal da empresa</li>
                  <li>Regimes tributários</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Documentos fiscais e calculadora" src="https://images.unsplash.com/photo-1634901612914-cba6806093ba" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminStorefrontFiscalPage;
  