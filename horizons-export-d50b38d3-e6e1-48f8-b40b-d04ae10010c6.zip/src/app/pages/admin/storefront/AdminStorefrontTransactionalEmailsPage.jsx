
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Mail } from 'lucide-react';
    
    const AdminStorefrontTransactionalEmailsPage = () => {
      return (
        <>
          <Helmet>
            <title>Emails Informativos - Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Emails Informativos (Transacionais)
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-blue-500 to-sky-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Mail className="mr-3 h-8 w-8" />
                  Modelos de Email
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Esta página está em desenvolvimento. Gerencie os templates de emails transacionais.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-blue-50">
                  <li>Editor de templates de email (confirmação de pedido, envio, etc.)</li>
                  <li>Personalização com variáveis dinâmicas</li>
                  <li>Configurações de remetente</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Editor de template de email" src="https://images.unsplash.com/photo-1560015534-cee980ba7e13" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminStorefrontTransactionalEmailsPage;
  