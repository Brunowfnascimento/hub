
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Palette } from 'lucide-react';
    
    const AdminStorefrontAppearancePage = () => {
      return (
        <>
          <Helmet>
            <title>Aparência - Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Aparência da Loja (Design e Layout)
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-pink-500 to-purple-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Palette className="mr-3 h-8 w-8" />
                  Personalize sua Loja
                </CardTitle>
                <CardDescription className="text-pink-100">
                  Esta página está em desenvolvimento. Customize o visual da sua loja virtual.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-pink-50">
                  <li>Seleção e customização de temas</li>
                  <li>Upload de logo e favicon</li>
                  <li>Configuração de cores e fontes</li>
                  <li>Layout de páginas principais</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Paleta de cores e ferramentas de design" src="https://images.unsplash.com/photo-1509343256512-d77a5cb3791b" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminStorefrontAppearancePage;
  