
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { ShoppingBag } from 'lucide-react';
    
    const AdminStorefrontCheckoutSettingsPage = () => {
      return (
        <>
          <Helmet>
            <title>Configurações de Checkout - Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Configurações de Checkout
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-orange-500 to-yellow-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <ShoppingBag className="mr-3 h-8 w-8" />
                  Otimize seu Checkout
                </CardTitle>
                <CardDescription className="text-orange-100">
                  Esta página está em desenvolvimento. Configure as opções do processo de checkout.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-orange-50">
                  <li>Opções de checkout como convidado</li>
                  <li>Campos customizados no formulário</li>
                  <li>Configuração de termos e condições</li>
                  <li>Integração com análise de fraude</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Interface de checkout de e-commerce" src="https://images.unsplash.com/photo-1570824104453-dc67d9ebcedc" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminStorefrontCheckoutSettingsPage;
  