
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Zap } from 'lucide-react';
    
    const AdminIntegrationsPage = () => {
      return (
        <>
          <Helmet>
            <title>Integrações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Gerenciamento de Integrações
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-purple-500 to-pink-500 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Zap className="mr-3 h-8 w-8" />
                  Conecte suas Ferramentas
                </CardTitle>
                <CardDescription className="text-purple-100">
                  Esta seção está em desenvolvimento. Em breve, você poderá conectar VittaHub com outras plataformas e serviços.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-purple-50">
                  <li>Integração com ferramentas de marketing (Email, CRM)</li>
                  <li>Conexão com sistemas de ERP e contabilidade</li>
                  <li>Integrações com marketplaces</li>
                  <li>APIs para desenvolvedores</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Ícones de aplicativos conectados" className="mt-6 rounded-lg shadow-md w-full h-auto object-cover max-h-64 opacity-80" src="https://images.unsplash.com/photo-1626682561113-d1db402cc866" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminIntegrationsPage;
  