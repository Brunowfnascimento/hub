
    import React, { useState, useMemo } from 'react';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { 
      fetchAdminCoupons, 
      createAdminCoupon, 
      updateAdminCoupon, 
      deleteAdminCoupon 
    } from '@/app/features/admin/coupon-management/services/couponAdmin.service';
    import CouponForm from '@/app/features/admin/coupon-management/components/CouponForm';
    import CouponFiltersAdmin from '@/app/features/admin/coupon-management/components/CouponFiltersAdmin';
    import LoadingSpinner from '@/app/components/common/LoadingSpinner';
    import ErrorDisplay from '@/app/components/common/ErrorDisplay';
    import { Button } from '@/components/ui/button';
    import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Badge } from '@/components/ui/badge';
    import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
    import { MoreHorizontal, Edit, Trash2, PlusCircle } from 'lucide-react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from "@/components/ui/alert-dialog";
    import {
      Pagination,
      PaginationContent,
      PaginationItem,
      PaginationLink,
      PaginationNext,
      PaginationPrevious,
      PaginationEllipsis,
    } from "@/components/ui/pagination";
    import { useToast } from "@/components/ui/use-toast";
    import { motion, AnimatePresence } from 'framer-motion';
    import { Helmet } from 'react-helmet-async';
    import ErrorBoundary from '@/app/components/common/ErrorBoundary';
    
    const AdminCouponsPageContent = () => {
      const { toast } = useToast();
      const queryClient = useQueryClient();
    
      const [filters, setFilters] = useState({
        code: '',
        isActive: null,
        sortBy: 'created_at',
        sortOrder: 'desc',
      });
      const [appliedFilters, setAppliedFilters] = useState(filters);
      const [currentPage, setCurrentPage] = useState(1);
      const [isFormModalOpen, setIsFormModalOpen] = useState(false);
      const [currentCoupon, setCurrentCoupon] = useState(null); 
      const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
      const [couponToDelete, setCouponToDelete] = useState(null);
    
      const queryParams = useMemo(() => ({
        ...appliedFilters,
        page: currentPage,
        limit: 10,
      }), [appliedFilters, currentPage]);
    
      const { data, isLoading, error, isError, refetch } = useQuery({
        queryKey: ['adminCoupons', queryParams],
        queryFn: () => fetchAdminCoupons(queryParams),
        keepPreviousData: true,
      });
    
      const coupons = data?.coupons || [];
      const totalCount = data?.totalCount || 0;
      const totalPages = Math.ceil(totalCount / queryParams.limit);
    
      const couponMutation = useMutation({
        mutationFn: (couponData) => 
          currentCoupon 
            ? updateAdminCoupon(currentCoupon.id, couponData) 
            : createAdminCoupon(couponData),
        onSuccess: () => {
          toast({ title: "Sucesso", description: `Cupom ${currentCoupon ? 'atualizado' : 'criado'} com sucesso.` });
          queryClient.invalidateQueries(['adminCoupons']);
          setIsFormModalOpen(false);
          setCurrentCoupon(null);
        },
        onError: (err) => {
          toast({ title: "Erro", description: err.message || `Não foi possível ${currentCoupon ? 'atualizar' : 'criar'} o cupom.`, variant: "destructive" });
        },
      });
    
      const deleteMutation = useMutation({
        mutationFn: (couponId) => deleteAdminCoupon(couponId),
        onSuccess: () => {
          toast({ title: "Sucesso", description: "Cupom deletado com sucesso." });
          queryClient.invalidateQueries(['adminCoupons']);
        },
        onError: (err) => {
          toast({ title: "Erro", description: err.message || "Não foi possível deletar o cupom.", variant: "destructive" });
        },
        onSettled: () => {
          setIsDeleteDialogOpen(false);
          setCouponToDelete(null);
        }
      });
    
      const handleFiltersChange = (newFilters) => setFilters(newFilters);
      const handleApplyFilters = () => {
        setCurrentPage(1);
        setAppliedFilters(filters);
      };
      const handleClearFilters = () => {
        const cleared = { code: '', isActive: null, sortBy: 'created_at', sortOrder: 'desc' };
        setFilters(cleared);
        setCurrentPage(1);
        setAppliedFilters(cleared);
      };
    
      const handlePageChange = (newPage) => {
        if (newPage >= 1 && newPage <= totalPages) setCurrentPage(newPage);
      };
    
      const handleSort = (column) => {
        const newSortOrder = filters.sortBy === column && filters.sortOrder === 'asc' ? 'desc' : 'asc';
        const newFilters = { ...filters, sortBy: column, sortOrder: newSortOrder };
        setFilters(newFilters);
        setCurrentPage(1);
        setAppliedFilters(newFilters);
      };
    
      const openFormModal = (coupon = null) => {
        setCurrentCoupon(coupon);
        setIsFormModalOpen(true);
      };
    
      const openDeleteDialog = (coupon) => {
        setCouponToDelete(coupon);
        setIsDeleteDialogOpen(true);
      };
    
      const confirmDeleteCoupon = () => {
        if (couponToDelete) deleteMutation.mutate(couponToDelete.id);
      };
    
      const formatDiscount = (type, value) => {
        if (type === 'percentage') return `${value}%`;
        if (type === 'fixed_amount') return `R$ ${Number(value).toFixed(2)}`;
        return value;
      };
    
      const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString('pt-BR');
      };
    
      const renderPaginationItems = () => {
        const items = [];
        const maxPagesToShow = 3;
        const pageBuffer = 1;
    
        if (totalPages <= 1) return null;
    
        items.push(
          <PaginationItem key="prev">
            <PaginationPrevious href="#" onClick={(e) => { e.preventDefault(); handlePageChange(currentPage - 1); }} disabled={currentPage === 1}  className={currentPage === 1 ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed' : 'hover:bg-slate-100 dark:hover:bg-slate-700'} />
          </PaginationItem>
        );
    
        if (totalPages <= maxPagesToShow + (pageBuffer * 2)) {
          for (let i = 1; i <= totalPages; i++) {
            items.push(
              <PaginationItem key={i}>
                <PaginationLink href="#" isActive={currentPage === i} onClick={(e) => { e.preventDefault(); handlePageChange(i); }}  className={currentPage === i ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>{i}</PaginationLink>
              </PaginationItem>
            );
          }
        } else {
            items.push(<PaginationItem key={1}><PaginationLink href="#" onClick={(e) => { e.preventDefault(); handlePageChange(1); }}  className={currentPage === 1 ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>1</PaginationLink></PaginationItem>);
            if (currentPage > pageBuffer + 2) items.push(<PaginationItem key="start-ellipsis"><PaginationEllipsis /></PaginationItem>);
            const startRange = Math.max(2, currentPage - pageBuffer);
            const endRange = Math.min(totalPages - 1, currentPage + pageBuffer);
            for (let i = startRange; i <= endRange; i++) items.push(<PaginationItem key={i}><PaginationLink href="#" isActive={currentPage === i} onClick={(e) => { e.preventDefault(); handlePageChange(i); }}  className={currentPage === i ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>{i}</PaginationLink></PaginationItem>);
            if (currentPage < totalPages - pageBuffer - 1) items.push(<PaginationItem key="end-ellipsis"><PaginationEllipsis /></PaginationItem>);
            items.push(<PaginationItem key={totalPages}><PaginationLink href="#" onClick={(e) => { e.preventDefault(); handlePageChange(totalPages);}}  className={currentPage === totalPages ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>{totalPages}</PaginationLink></PaginationItem>);
        }
    
        items.push(
          <PaginationItem key="next">
            <PaginationNext href="#" onClick={(e) => { e.preventDefault(); handlePageChange(currentPage + 1); }} disabled={currentPage === totalPages}  className={currentPage === totalPages ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed' : 'hover:bg-slate-100 dark:hover:bg-slate-700'} />
          </PaginationItem>
        );
        return items;
      };
    
      if (isLoading) return <div className="flex justify-center items-center h-64"><LoadingSpinner size="h-16 w-16" /></div>;
      if (isError) return <ErrorDisplay message={error?.message || "Não foi possível carregar os cupons."} onRetry={refetch} />;
    
      return (
        <>
        <Helmet><title>Gerenciar Cupons - VittaHub Admin</title></Helmet>
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
        >
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Gerenciamento de Cupons</h1>
            <Button onClick={() => openFormModal()} className="bg-sky-500 hover:bg-sky-600 dark:bg-sky-600 dark:hover:bg-sky-700 dark:text-white">
              <PlusCircle className="mr-2 h-5 w-5" /> Adicionar Cupom
            </Button>
          </div>
    
          <CouponFiltersAdmin
            filters={filters}
            onFiltersChange={handleFiltersChange}
            onApplyFilters={handleApplyFilters}
            onClearFilters={handleClearFilters}
          />
    
          
            <div className="bg-white dark:bg-slate-800 shadow-xl rounded-lg overflow-hidden">
               <div className="p-4 border-b border-slate-200 dark:border-slate-700">
                 <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200">Lista de Cupons</h2>
               </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-slate-50 dark:bg-slate-700">
                    <TableRow>
                      <TableHead onClick={() => handleSort('code')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Código</TableHead>
                      <TableHead className="px-4 text-slate-600 dark:text-slate-300">Descrição</TableHead>
                      <TableHead onClick={() => handleSort('discount_value')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Desconto</TableHead>
                      <TableHead onClick={() => handleSort('valid_from')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Válido De</TableHead>
                      <TableHead onClick={() => handleSort('valid_until')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Válido Até</TableHead>
                      <TableHead className="px-4 text-slate-600 dark:text-slate-300">Usos Totais</TableHead>
                      <TableHead onClick={() => handleSort('is_active')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Status</TableHead>
                      <TableHead className="text-center px-4 text-slate-600 dark:text-slate-300">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                  <AnimatePresence>
                    {coupons.length > 0 ? coupons.map((coupon) => (
                      <motion.tr 
                        key={coupon.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
                        >
                        <TableCell className="font-medium text-sky-600 dark:text-sky-400 px-4">{coupon.code}</TableCell>
                        <TableCell className="text-slate-600 dark:text-slate-300 px-4 truncate max-w-xs">{coupon.description || 'N/D'}</TableCell>
                        <TableCell className="text-slate-700 dark:text-slate-200 px-4">{formatDiscount(coupon.discount_type, coupon.discount_value)}</TableCell>
                        <TableCell className="text-slate-600 dark:text-slate-300 px-4">{formatDate(coupon.valid_from)}</TableCell>
                        <TableCell className="text-slate-600 dark:text-slate-300 px-4">{formatDate(coupon.valid_until)}</TableCell>
                        <TableCell className="text-slate-600 dark:text-slate-300 px-4">{coupon.max_uses_total !== null ? `${coupon.current_uses || 0} / ${coupon.max_uses_total}` : 'Ilimitado'}</TableCell>
                        <TableCell className="px-4">
                          <Badge variant={coupon.is_active ? 'success' : 'outline'} className={coupon.is_active ? "bg-green-500/20 text-green-700 dark:bg-green-700/30 dark:text-green-400" : "bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-400"}>
                            {coupon.is_active ? 'Ativo' : 'Inativo'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center px-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
                                <span className="sr-only">Abrir menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="dark:bg-slate-700 dark:border-slate-600">
                              <DropdownMenuItem onClick={() => openFormModal(coupon)} className="dark:hover:bg-slate-600">
                                <Edit className="mr-2 h-4 w-4" /> Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => openDeleteDialog(coupon)} className="text-red-600 dark:text-red-400 dark:hover:bg-red-700/20 focus:text-red-600 dark:focus:text-red-400">
                                <Trash2 className="mr-2 h-4 w-4" /> Deletar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </motion.tr>
                    )) : (
                      <TableRow>
                        <TableCell colSpan={8} className="h-24 text-center text-slate-500 dark:text-slate-400">
                          Nenhum cupom encontrado com os filtros atuais.
                        </TableCell>
                      </TableRow>
                    )}
                    </AnimatePresence>
                  </TableBody>
                </Table>
              </div>
              {totalPages > 0 && (
                <div className="p-4 border-t border-slate-200 dark:border-slate-700">
                  <Pagination>
                    <PaginationContent>{renderPaginationItems()}</PaginationContent>
                  </Pagination>
                  <p className="text-center text-sm text-slate-600 dark:text-slate-400 mt-2">
                    Página {currentPage} de {totalPages}. Total de {totalCount} cupons.
                  </p>
                </div>
              )}
            </div>
          
    
          <Dialog open={isFormModalOpen} onOpenChange={(isOpen) => {
            setIsFormModalOpen(isOpen);
            if (!isOpen) setCurrentCoupon(null);
          }}>
            <DialogContent className="sm:max-w-2xl dark:bg-slate-800">
              <DialogHeader>
                <DialogTitle className="dark:text-slate-100">{currentCoupon ? 'Editar' : 'Adicionar'} Cupom</DialogTitle>
                <DialogDescription className="dark:text-slate-400">
                  {currentCoupon ? 'Modifique os detalhes do cupom.' : 'Preencha os detalhes para criar um novo cupom.'}
                </DialogDescription>
              </DialogHeader>
              <CouponForm 
                initialData={currentCoupon} 
                onSubmit={couponMutation.mutate} 
                isLoading={couponMutation.isLoading}
                onCancel={() => {
                    setIsFormModalOpen(false);
                    setCurrentCoupon(null);
                }}
              />
            </DialogContent>
          </Dialog>
    
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent className="dark:bg-slate-800">
              <AlertDialogHeader>
                <AlertDialogTitle className="dark:text-slate-100">Confirmar Deleção</AlertDialogTitle>
                <AlertDialogDescription className="dark:text-slate-400">
                  Tem certeza que deseja deletar o cupom "{couponToDelete?.code}"? Esta ação não pode ser desfeita.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)} className="dark:bg-slate-700 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-600">Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDeleteCoupon} className="bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700 dark:text-white">
                  {deleteMutation.isLoading ? <LoadingSpinner size="h-4 w-4" /> : "Deletar"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </motion.div>
        </>
      );
    };
    
    const AdminCouponsPage = () => {
      return (
        <ErrorBoundary fallback={<ErrorDisplay message="Um erro crítico ocorreu na página de cupons." onRetry={() => window.location.reload()} />}>
          <AdminCouponsPageContent />
        </ErrorBoundary>
      );
    }
    
    export default AdminCouponsPage;
  