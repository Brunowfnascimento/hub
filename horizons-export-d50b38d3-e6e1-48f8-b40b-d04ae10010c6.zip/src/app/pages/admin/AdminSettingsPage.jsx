
    import React, { useState } from 'react';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
    import StoreSettingsTab from '@/app/features/admin/settings-management/components/StoreSettingsTab';
    // import PaymentSettingsTab from '@/app/features/admin/settings-management/components/PaymentSettingsTab';
    // import TaxSettingsTab from '@/app/features/admin/settings-management/components/TaxSettingsTab';
    import { Settings, CreditCard, PercentSquare, Palette, BellRing, ShieldCheck } from 'lucide-react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Helmet } from 'react-helmet-async';
    
    const AdminSettingsPage = () => {
      const [activeTab, setActiveTab] = useState("store");
    
      const tabsConfig = [
        { value: "store", label: "Loja", icon: Settings, component: <StoreSettingsTab /> },
        // { value: "payments", label: "Pagamentos", icon: CreditCard, component: <PaymentSettingsTab /> },
        // { value: "taxes", label: "Impostos", icon: PercentSquare, component: <TaxSettingsTab /> },
        // { value: "appearance", label: "Aparência", icon: Palette, component: <p>Configurações de Aparência (Em desenvolvimento)</p> },
        // { value: "notifications", label: "Notificações", icon: BellRing, component: <p>Configurações de Notificações (Em desenvolvimento)</p> },
        // { value: "security", label: "Segurança", icon: ShieldCheck, component: <p>Configurações de Segurança (Em desenvolvimento)</p> },
      ];
    
      return (
        <>
        <Helmet><title>Configurações - VittaHub Admin</title></Helmet>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto px-3 py-6"
        >
          <h1 className="text-3xl font-bold mb-8 text-slate-800 dark:text-slate-100">Configurações</h1>
    
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-2 mb-6 bg-slate-200 dark:bg-slate-700 p-1 rounded-lg">
              {tabsConfig.map(tab => (
                <TabsTrigger 
                  key={tab.value} 
                  value={tab.value} 
                  className="flex items-center justify-center data-[state=active]:bg-white data-[state=active]:text-sky-600 data-[state=active]:shadow-md dark:data-[state=active]:bg-slate-800 dark:data-[state=active]:text-sky-400 py-2.5"
                >
                  <tab.icon className="mr-2 h-5 w-5" /> {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
            
            <AnimatePresence mode="wait">
              {tabsConfig.map(tab => (
                activeTab === tab.value && (
                  <motion.div
                    key={tab.value}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <TabsContent value={tab.value}>
                      {tab.component}
                    </TabsContent>
                  </motion.div>
                )
              ))}
            </AnimatePresence>
          </Tabs>
        </motion.div>
        </>
      );
    };
    
    export default AdminSettingsPage;
  