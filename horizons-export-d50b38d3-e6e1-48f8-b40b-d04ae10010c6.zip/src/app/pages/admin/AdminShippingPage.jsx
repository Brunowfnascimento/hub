
    import React, { useState } from 'react';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
    import CarriersTab from '@/app/features/admin/shipping-management/components/CarriersTab';
    import ZonesTab from '@/app/features/admin/shipping-management/components/ZonesTab';
    import ShippingMethodsTab from '@/app/features/admin/shipping-management/components/ShippingMethodsTab';
    import { Truck, MapPin, Waypoints } from 'lucide-react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Helmet } from 'react-helmet-async';
    import ErrorBoundary from '@/app/components/common/ErrorBoundary';
    import ErrorDisplay from '@/app/components/common/ErrorDisplay';
    
    const AdminShippingPage = () => {
      const [activeTab, setActiveTab] = useState("carriers");
    
      return (
        <ErrorBoundary fallback={<ErrorDisplay message="Um erro crítico ocorreu na página de frete." onRetry={() => window.location.reload()} />}>
          <Helmet><title>Gerenciar Frete - VittaHub Admin</title></Helmet>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-3 py-6"
          >
            <h1 className="text-3xl font-bold mb-8 text-slate-800 dark:text-slate-100">Gerenciamento de Frete</h1>
    
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-1 sm:grid-cols-3 mb-6 bg-slate-200 dark:bg-slate-700 p-1 rounded-lg">
                <TabsTrigger value="carriers" className="flex items-center justify-center data-[state=active]:bg-white data-[state=active]:text-sky-600 data-[state=active]:shadow-md dark:data-[state=active]:bg-slate-800 dark:data-[state=active]:text-sky-400 py-2.5">
                  <Truck className="mr-2 h-5 w-5" /> Transportadoras
                </TabsTrigger>
                <TabsTrigger value="zones" className="flex items-center justify-center data-[state=active]:bg-white data-[state=active]:text-sky-600 data-[state=active]:shadow-md dark:data-[state=active]:bg-slate-800 dark:data-[state=active]:text-sky-400 py-2.5">
                  <MapPin className="mr-2 h-5 w-5" /> Zonas de Entrega
                </TabsTrigger>
                <TabsTrigger value="methods" className="flex items-center justify-center data-[state=active]:bg-white data-[state=active]:text-sky-600 data-[state=active]:shadow-md dark:data-[state=active]:bg-slate-800 dark:data-[state=active]:text-sky-400 py-2.5">
                  <Waypoints className="mr-2 h-5 w-5" /> Métodos de Envio
                </TabsTrigger>
              </TabsList>
    
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, x: activeTab === "carriers" ? 0 : (activeTab === "zones" && "carriers" ? 20 : -20) }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: activeTab === "carriers" ? 0 : (activeTab === "zones" && "carriers" ? -20 : 20) }}
                  transition={{ duration: 0.3 }}
                >
                  <TabsContent value="carriers">
                    <ErrorBoundary fallback={<ErrorDisplay message="Erro ao carregar aba de Transportadoras." />}>
                      <CarriersTab />
                    </ErrorBoundary>
                  </TabsContent>
                  <TabsContent value="zones">
                     <ErrorBoundary fallback={<ErrorDisplay message="Erro ao carregar aba de Zonas de Entrega." />}>
                      <ZonesTab />
                    </ErrorBoundary>
                  </TabsContent>
                  <TabsContent value="methods">
                    <ErrorBoundary fallback={<ErrorDisplay message="Erro ao carregar aba de Métodos de Envio." />}>
                      <ShippingMethodsTab />
                    </ErrorBoundary>
                  </TabsContent>
                </motion.div>
              </AnimatePresence>
            </Tabs>
          </motion.div>
        </ErrorBoundary>
      );
    };
    
    export default AdminShippingPage;
  