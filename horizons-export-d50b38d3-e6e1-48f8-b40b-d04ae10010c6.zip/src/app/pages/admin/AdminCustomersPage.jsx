
    import React, { useState, useMemo, useCallback } from 'react';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { 
      fetchAdminCustomers, 
      updateCustomerProfileAdmin,
      deleteCustomerAdmin,
      toggleCustomerBanStatus
    } from '@/app/features/admin/customer-management/services/customerAdmin.service.jsx';
    import CustomerFiltersAdmin from '@/app/features/admin/customer-management/components/CustomerFiltersAdmin';
    import CustomerDetailModal from '@/app/features/admin/customer-management/components/CustomerDetailModal';
    import CustomerProfileEditForm from '@/app/features/admin/customer-management/components/CustomerProfileEditForm';
    import LoadingSpinner from '@/app/components/common/LoadingSpinner';
    import ErrorDisplay from '@/app/components/common/ErrorDisplay';
    import { Button } from '@/components/ui/button';
    import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Badge } from '@/components/ui/badge';
    import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
    import { MoreHorizontal, Eye, Trash2, Edit, UserX, UserCheck, UserCog } from 'lucide-react';
    import { useToast } from "@/components/ui/use-toast";
    import {
      Pagination,
      PaginationContent,
      PaginationItem,
      PaginationLink,
      PaginationNext,
      PaginationPrevious,
      PaginationEllipsis,
    } from "@/components/ui/pagination";
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from "@/components/ui/alert-dialog";
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Helmet } from 'react-helmet-async';
    import ErrorBoundary from '@/app/components/common/ErrorBoundary';
    
    const CustomerTable = ({ 
      customers, 
      selectedCustomers, 
      isAllSelected, 
      onSelectCustomer, 
      onSelectAllCustomers, 
      onSort, 
      onViewDetails, 
      onEdit, 
      onToggleBan, 
      onDelete 
    }) => {
      const formatRole = (role, banned_until) => {
        const isBanned = banned_until && new Date(banned_until) > new Date();
        if (isBanned) return <Badge variant="destructive" className="bg-red-600 text-white">Banido</Badge>;
        if (role === 'admin') return <Badge className="bg-amber-500 text-white">Admin</Badge>;
        if (role === 'super_admin') return <Badge className="bg-purple-600 text-white">Super Admin</Badge>;
        if (role === 'customer') return <Badge variant="secondary" className="bg-blue-500 text-white">Cliente</Badge>;
        return <Badge variant="outline">{role || 'N/D'}</Badge>;
      };
    
      const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
      };
    
      return (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-slate-50 dark:bg-slate-700">
              <TableRow>
                <TableHead className="w-[50px] px-4">
                  <Checkbox
                    checked={isAllSelected}
                    onCheckedChange={onSelectAllCustomers}
                    aria-label="Selecionar todos os clientes"
                    className="border-slate-400 data-[state=checked]:bg-sky-500 data-[state=checked]:border-sky-500"
                  />
                </TableHead>
                <TableHead onClick={() => onSort('full_name')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Nome</TableHead>
                <TableHead onClick={() => onSort('email')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Email</TableHead>
                <TableHead onClick={() => onSort('phone')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Telefone</TableHead>
                <TableHead onClick={() => onSort('role')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Status/Role</TableHead>
                <TableHead onClick={() => onSort('created_at')} className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 px-4 text-slate-600 dark:text-slate-300">Registrado em</TableHead>
                <TableHead className="text-center px-4 text-slate-600 dark:text-slate-300">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <AnimatePresence>
                {customers.length > 0 ? customers.map((customer) => (
                  <motion.tr 
                    key={customer.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
                  >
                    <TableCell className="px-4">
                      <Checkbox
                        checked={selectedCustomers.includes(customer.id)}
                        onCheckedChange={() => onSelectCustomer(customer.id)}
                        aria-label={`Selecionar cliente ${customer.full_name}`}
                        className="border-slate-400 data-[state=checked]:bg-sky-500 data-[state=checked]:border-sky-500"
                      />
                    </TableCell>
                    <TableCell className="font-medium text-slate-700 dark:text-slate-200 px-4">{customer.full_name || 'N/D'}</TableCell>
                    <TableCell className="text-slate-600 dark:text-slate-300 px-4">{customer.email}</TableCell>
                    <TableCell className="text-slate-600 dark:text-slate-300 px-4">{customer.phone || 'N/D'}</TableCell>
                    <TableCell className="px-4">{formatRole(customer.role, customer.banned_until)}</TableCell>
                    <TableCell className="text-slate-600 dark:text-slate-300 px-4">{formatDate(customer.created_at)}</TableCell>
                    <TableCell className="text-center px-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
                            <span className="sr-only">Abrir menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="dark:bg-slate-700 dark:border-slate-600">
                          <DropdownMenuItem onClick={() => onViewDetails(customer)} className="dark:hover:bg-slate-600">
                            <Eye className="mr-2 h-4 w-4" /> Ver Detalhes
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onEdit(customer)} className="dark:hover:bg-slate-600">
                            <Edit className="mr-2 h-4 w-4" /> Editar Perfil
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onToggleBan(customer)} className="dark:hover:bg-slate-600">
                            {customer.banned_until && new Date(customer.banned_until) > new Date() ? (
                              <UserCheck className="mr-2 h-4 w-4 text-green-500" />
                            ) : (
                              <UserX className="mr-2 h-4 w-4 text-red-500" />
                            )}
                            {customer.banned_until && new Date(customer.banned_until) > new Date() ? 'Desbanir' : 'Banir'} Cliente
                          </DropdownMenuItem>
                          <DropdownMenuSeparator className="dark:bg-slate-600" />
                          <DropdownMenuItem onClick={() => onDelete(customer)} className="text-red-600 dark:text-red-400 dark:hover:bg-red-700/20 focus:text-red-600 dark:focus:text-red-400">
                            <Trash2 className="mr-2 h-4 w-4" /> Deletar Cliente
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </motion.tr>
                )) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center text-slate-500 dark:text-slate-400">
                      Nenhum cliente encontrado com os filtros atuais.
                    </TableCell>
                  </TableRow>
                )}
              </AnimatePresence>
            </TableBody>
          </Table>
        </div>
      );
    };
    
    const CustomerPagination = ({ currentPage, totalPages, onPageChange }) => {
      const renderPaginationItems = () => {
        const items = [];
        const maxPagesToShow = 3;
        const pageBuffer = 1;
    
        if (totalPages <= 1) return null;
    
        items.push(
          <PaginationItem key="prev">
            <PaginationPrevious
              href="#"
              onClick={(e) => { e.preventDefault(); onPageChange(currentPage - 1); }}
              disabled={currentPage === 1}
              className={currentPage === 1 ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
            />
          </PaginationItem>
        );
    
        if (totalPages <= maxPagesToShow + (pageBuffer * 2)) {
          for (let i = 1; i <= totalPages; i++) {
            items.push(
              <PaginationItem key={i}>
                <PaginationLink
                  href="#"
                  isActive={currentPage === i}
                  onClick={(e) => { e.preventDefault(); onPageChange(i); }}
                  className={currentPage === i ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
                >
                  {i}
                </PaginationLink>
              </PaginationItem>
            );
          }
        } else {
           items.push(
            <PaginationItem key={1}>
              <PaginationLink href="#" onClick={(e) => { e.preventDefault(); onPageChange(1); }} className={currentPage === 1 ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>1</PaginationLink>
            </PaginationItem>
          );
    
          if (currentPage > pageBuffer + 2) {
            items.push(<PaginationItem key="start-ellipsis"><PaginationEllipsis /></PaginationItem>);
          }
    
          const startRange = Math.max(2, currentPage - pageBuffer);
          const endRange = Math.min(totalPages - 1, currentPage + pageBuffer);
    
          for (let i = startRange; i <= endRange; i++) {
            items.push(
              <PaginationItem key={i}>
                <PaginationLink
                  href="#"
                  isActive={currentPage === i}
                  onClick={(e) => { e.preventDefault(); onPageChange(i); }}
                  className={currentPage === i ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
                >
                  {i}
                </PaginationLink>
              </PaginationItem>
            );
          }
    
          if (currentPage < totalPages - pageBuffer - 1) {
            items.push(<PaginationItem key="end-ellipsis"><PaginationEllipsis /></PaginationItem>);
          }
          
           items.push(
            <PaginationItem key={totalPages}>
              <PaginationLink href="#" onClick={(e) => { e.preventDefault(); onPageChange(totalPages);}} className={currentPage === totalPages ? 'bg-sky-500 text-white hover:bg-sky-600 dark:bg-sky-600 dark:text-white dark:hover:bg-sky-700' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}>{totalPages}</PaginationLink>
            </PaginationItem>
          );
        }
    
        items.push(
          <PaginationItem key="next">
            <PaginationNext
              href="#"
              onClick={(e) => { e.preventDefault(); onPageChange(currentPage + 1); }}
              disabled={currentPage === totalPages}
              className={currentPage === totalPages ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}
            />
          </PaginationItem>
        );
        return items;
      };
    
      if (totalPages <= 1) return null;
    
      return (
        <Pagination>
          <PaginationContent>
            {renderPaginationItems()}
          </PaginationContent>
        </Pagination>
      );
    };
    
    const AdminCustomersPageContent = () => {
      const { toast } = useToast();
      const queryClient = useQueryClient();
    
      const [filters, setFilters] = useState({
        searchTerm: '',
        role: 'all',
        sortBy: 'created_at',
        sortOrder: 'desc',
      });
      const [appliedFilters, setAppliedFilters] = useState(filters);
      const [currentPage, setCurrentPage] = useState(1);
      const [selectedCustomers, setSelectedCustomers] = useState([]);
      
      const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
      const [isEditModalOpen, setIsEditModalOpen] = useState(false);
      const [currentCustomer, setCurrentCustomer] = useState(null);
      
      const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
      const [customerToDelete, setCustomerToDelete] = useState(null);
    
      const queryParams = useMemo(() => ({
        ...appliedFilters,
        page: currentPage,
        limit: 10,
      }), [appliedFilters, currentPage]);
    
      const { data, isLoading, error, isError } = useQuery({
        queryKey: ['adminCustomers', queryParams],
        queryFn: () => fetchAdminCustomers(queryParams),
        keepPreviousData: true,
      });
    
      const customers = data?.customers || [];
      const totalCount = data?.totalCount || 0;
      const totalPages = Math.ceil(totalCount / queryParams.limit);
    
      const updateCustomerMutation = useMutation({
        mutationFn: ({ customerId, profileData }) => updateCustomerProfileAdmin(customerId, profileData),
        onSuccess: () => {
          toast({ title: "Sucesso", description: "Perfil do cliente atualizado." });
          queryClient.invalidateQueries(['adminCustomers']);
          queryClient.invalidateQueries(['adminCustomerDetail', currentCustomer?.id]);
          setIsEditModalOpen(false);
          setCurrentCustomer(null);
        },
        onError: (err) => {
          toast({ title: "Erro", description: err.message || "Não foi possível atualizar o perfil.", variant: "destructive" });
        },
      });
    
      const deleteCustomerMutation = useMutation({
        mutationFn: (customerId) => deleteCustomerAdmin(customerId),
        onSuccess: () => {
          toast({ title: "Sucesso", description: "Cliente deletado." });
          queryClient.invalidateQueries(['adminCustomers']);
          setSelectedCustomers([]);
        },
        onError: (err) => {
          toast({ title: "Erro", description: err.message || "Não foi possível deletar o cliente.", variant: "destructive" });
        },
        onSettled: () => {
          setIsDeleteDialogOpen(false);
          setCustomerToDelete(null);
        },
      });
    
      const toggleBanMutation = useMutation({
        mutationFn: ({ customerId, currentBannedUntil }) => toggleCustomerBanStatus(customerId, currentBannedUntil),
        onSuccess: (data) => {
          const isNowBanned = data.banned_until && new Date(data.banned_until) > new Date();
          toast({ title: "Sucesso", description: `Cliente ${isNowBanned ? 'banido' : 'desbanido'}.` });
          queryClient.invalidateQueries(['adminCustomers']);
          queryClient.invalidateQueries(['adminCustomerDetail', currentCustomer?.id]);
        },
        onError: (err) => {
          toast({ title: "Erro", description: err.message || "Não foi possível alterar status de banimento.", variant: "destructive" });
        },
      });
    
      const handleFiltersChange = useCallback((newFilters) => {
        setFilters(prev => ({...prev, ...newFilters}));
      }, []);
    
      const handleApplyFilters = useCallback(() => {
        setCurrentPage(1);
        setAppliedFilters(filters);
      }, [filters]);
    
      const handleClearFilters = useCallback(() => {
        const cleared = { searchTerm: '', role: 'all', sortBy: 'created_at', sortOrder: 'desc' };
        setFilters(cleared);
        setCurrentPage(1);
        setAppliedFilters(cleared);
      }, []);
    
      const handlePageChange = useCallback((newPage) => {
        if (newPage >= 1 && newPage <= totalPages) {
          setCurrentPage(newPage);
        }
      }, [totalPages]);
    
      const handleSort = useCallback((column) => {
        const newSortOrder = filters.sortBy === column && filters.sortOrder === 'asc' ? 'desc' : 'asc';
        const newFilters = { ...filters, sortBy: column, sortOrder: newSortOrder };
        setFilters(newFilters);
        setCurrentPage(1); 
        setAppliedFilters(newFilters);
      }, [filters]);
    
      const handleSelectCustomer = useCallback((customerId) => {
        setSelectedCustomers(prev =>
          prev.includes(customerId) ? prev.filter(id => id !== customerId) : [...prev, customerId]
        );
      }, []);
    
      const handleSelectAllCustomers = useCallback((isChecked) => {
        setSelectedCustomers(isChecked ? customers.map(c => c.id) : []);
      }, [customers]);
    
      const openCustomerDetailModal = useCallback((customer) => {
        setCurrentCustomer(customer);
        setIsDetailModalOpen(true);
      }, []);
    
      const openEditModal = useCallback((customer) => {
        setCurrentCustomer(customer);
        setIsEditModalOpen(true);
      }, []);
    
      const openDeleteDialog = useCallback((customer) => {
        setCustomerToDelete(customer);
        setIsDeleteDialogOpen(true);
      }, []);
    
      const confirmDeleteCustomer = useCallback(() => {
        if (customerToDelete) {
          deleteCustomerMutation.mutate(customerToDelete.id);
        }
      }, [customerToDelete, deleteCustomerMutation]);
    
      const handleToggleBan = useCallback((customer) => {
        toggleBanMutation.mutate({ customerId: customer.id, currentBannedUntil: customer.banned_until });
      }, [toggleBanMutation]);
    
      const handleBulkAction = (action) => {
        if (selectedCustomers.length === 0) {
          toast({ title: "Atenção", description: "Nenhum cliente selecionado.", variant: "warning" });
          return;
        }
        
        toast({
          title: `Ação em Lote: ${action}`,
          description: `Aplicar em ${selectedCustomers.length} cliente(s). Funcionalidade em desenvolvimento.`,
        });
      };
    
      const isAllSelected = customers.length > 0 && selectedCustomers.length === customers.length;
    
      if (isLoading) return <div className="flex justify-center items-center h-64"><LoadingSpinner size="h-16 w-16" /></div>;
      if (isError) return <ErrorDisplay message={error.message || "Não foi possível carregar os clientes."} details={error.details} />;
    
      return (
        <>
        <Helmet><title>Gerenciar Clientes - VittaHub Admin</title></Helmet>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Gerenciamento de Clientes</h1>
             <DropdownMenu>
                <DropdownMenuTrigger asChild>
                <Button variant="outline" disabled={selectedCustomers.length === 0} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                    Ações em Lote <MoreHorizontal className="ml-2 h-4 w-4" />
                </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="dark:bg-slate-700 dark:border-slate-600">
                <DropdownMenuItem onClick={() => handleBulkAction('Banir Selecionados')} className="dark:hover:bg-slate-600">
                    <UserX className="mr-2 h-4 w-4" /> Banir Selecionados
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleBulkAction('Desbanir Selecionados')} className="dark:hover:bg-slate-600">
                    <UserCheck className="mr-2 h-4 w-4" /> Desbanir Selecionados
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleBulkAction('Mudar Role')} className="dark:hover:bg-slate-600">
                    <UserCog className="mr-2 h-4 w-4" /> Mudar Role
                </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
          </div>
    
          <CustomerFiltersAdmin
            initialFilters={filters}
            onFiltersChange={handleFiltersChange}
          />
           <div className="flex space-x-2">
            <Button onClick={handleApplyFilters} className="bg-sky-500 hover:bg-sky-600 text-white">
                Aplicar Filtros
            </Button>
            <Button onClick={handleClearFilters} variant="outline" className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                Limpar Filtros
            </Button>
          </div>
    
          
            <div className="bg-white dark:bg-slate-800 shadow-xl rounded-lg overflow-hidden">
               <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200">Lista de Clientes</h2>
                {selectedCustomers.length > 0 && (
                <span className="text-sm text-slate-500 dark:text-slate-400">({selectedCustomers.length} selecionado(s))</span>
                )}
            </div>
              <CustomerTable
                customers={customers}
                selectedCustomers={selectedCustomers}
                isAllSelected={isAllSelected}
                onSelectCustomer={handleSelectCustomer}
                onSelectAllCustomers={handleSelectAllCustomers}
                onSort={handleSort}
                onViewDetails={openCustomerDetailModal}
                onEdit={openEditModal}
                onToggleBan={handleToggleBan}
                onDelete={openDeleteDialog}
              />
              {totalPages > 0 && (
                <div className="p-4 border-t border-slate-200 dark:border-slate-700">
                  <CustomerPagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                   <p className="text-center text-sm text-slate-600 dark:text-slate-400 mt-2">
                    Página {currentPage} de {totalPages}. Total de {totalCount} clientes.
                   </p>
                </div>
              )}
            </div>
          
    
          {currentCustomer && isDetailModalOpen && (
            <CustomerDetailModal
              userId={currentCustomer.id}
              isOpen={isDetailModalOpen}
              onClose={() => {
                setIsDetailModalOpen(false);
                setCurrentCustomer(null);
              }}
            />
          )}
    
          {currentCustomer && isEditModalOpen && (
            <Dialog open={isEditModalOpen} onOpenChange={() => { setIsEditModalOpen(false); setCurrentCustomer(null);}}>
              <DialogContent className="dark:bg-slate-800 dark:border-slate-700">
                <DialogHeader>
                  <DialogTitle className="dark:text-slate-100">Editar Perfil do Cliente</DialogTitle>
                  <DialogDescription className="dark:text-slate-400">
                    Modifique os dados do cliente {currentCustomer.full_name}.
                  </DialogDescription>
                </DialogHeader>
                <CustomerProfileEditForm
                  profile={currentCustomer}
                  onSubmit={(profileData) => updateCustomerMutation.mutate({ customerId: currentCustomer.id, profileData })}
                  isSubmitting={updateCustomerMutation.isLoading}
                  onCancel={() => { setIsEditModalOpen(false); setCurrentCustomer(null);}}
                />
              </DialogContent>
            </Dialog>
          )}
    
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent className="dark:bg-slate-800">
              <AlertDialogHeader>
                <AlertDialogTitle className="dark:text-slate-100">Confirmar Deleção</AlertDialogTitle>
                <AlertDialogDescription className="dark:text-slate-400">
                  Tem certeza que deseja deletar o cliente "{customerToDelete?.full_name}" (Email: {customerToDelete?.email})? Esta ação não pode ser desfeita e removerá o usuário do sistema de autenticação e todos os dados associados permanentemente.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)} className="dark:bg-slate-700 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-600">Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDeleteCustomer} className="bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700 dark:text-white">
                  {deleteCustomerMutation.isLoading ? <LoadingSpinner size="h-4 w-4" /> : "Deletar"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
    
        </motion.div>
        </>
      );
    };
    
    const AdminCustomersPage = () => {
      return (
        <ErrorBoundary fallback={<ErrorDisplay message="Um erro crítico ocorreu na página de clientes." />}>
          <AdminCustomersPageContent />
        </ErrorBoundary>
      )
    }
    
    export default AdminCustomersPage;
  