
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { ShoppingCart } from 'lucide-react';
    
    const AdminSettingsStoreCheckoutPage = () => {
      return (
        <>
          <Helmet>
            <title>Configurações do Checkout - Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Configurações do Checkout
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-orange-500 to-red-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <ShoppingCart className="mr-3 h-8 w-8" />
                  Otimize sua Conversão
                </CardTitle>
                <CardDescription className="text-orange-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar as opções do processo de checkout.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Opções de configuração de checkout, como campos obrigatórios e checkout de convidado" src="https://images.unsplash.com/photo-1652803450909-7d03ce356360" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsStoreCheckoutPage;
  