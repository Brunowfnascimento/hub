
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Map } from 'lucide-react';
    
    const AdminSettingsStoreLocalizationPage = () => {
      return (
        <>
          <Helmet>
            <title>Localização - Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Configurações de Localização
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-lime-500 to-green-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Map className="mr-3 h-8 w-8" />
                  Moedas, Impostos e Regiões
                </CardTitle>
                <CardDescription className="text-lime-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar moedas, impostos e outras opções de localização.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Configurações de localização com opções de moeda, formato de data e impostos" src="https://images.unsplash.com/photo-1554224154-22dec7ec8818" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsStoreLocalizationPage;
  