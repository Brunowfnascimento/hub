
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { MessageSquare } from 'lucide-react';
    
    const AdminSettingsStoreTransactionalSmsPage = () => {
      return (
        <>
          <Helmet>
            <title>SMS Transacionais - Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Configuração de SMS Transacionais
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <MessageSquare className="mr-3 h-8 w-8" />
                  Notificações por SMS
                </CardTitle>
                <CardDescription className="text-cyan-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar o envio de SMS transacionais.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Configurações de SMS transacional com templates e gatilhos" src="https://images.unsplash.com/photo-1628611225387-c7662c2d6e6c" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsStoreTransactionalSmsPage;
  