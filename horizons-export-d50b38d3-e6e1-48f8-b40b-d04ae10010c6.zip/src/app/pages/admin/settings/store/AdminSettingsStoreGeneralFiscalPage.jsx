
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Briefcase } from 'lucide-react';
    
    const AdminSettingsStoreGeneralFiscalPage = () => {
      return (
        <>
          <Helmet>
            <title>Informações Gerais e Fiscais - Loja Virtual - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Informações Gerais e Fiscais da Loja
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-blue-500 to-sky-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Briefcase className="mr-3 h-8 w-8" />
                  Dados da Sua Loja
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar as informações gerais e fiscais da sua loja virtual.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Formulário de configurações da loja com campos para nome, CNPJ e endereço" src="https://images.unsplash.com/photo-1612200870105-22f8cc963ee1" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsStoreGeneralFiscalPage;
  