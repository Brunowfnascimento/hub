
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { UserCog } from 'lucide-react';
    
    const AdminSettingsProfilePage = () => {
      return (
        <>
          <Helmet>
            <title>Perfil do Administrador - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Perfil do Administrador
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-slate-700 to-gray-800 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <UserCog className="mr-3 h-8 w-8" />
                  Gerenciar seu Perfil
                </CardTitle>
                <CardDescription className="text-slate-300">
                  Esta página está em desenvolvimento. Em breve, você poderá editar suas informações de perfil e senha.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Formulário de edição de perfil de administrador com campos de nome, email e senha" src="https://images.unsplash.com/photo-1652841190565-b96e0acbae17" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsProfilePage;
  