
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Palette } from 'lucide-react';
    
    const AdminSettingsAdminAppearancePage = () => {
      return (
        <>
          <Helmet>
            <title>Aparência do Painel - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Aparência do Painel Administrativo
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-gray-600 to-slate-700 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Palette className="mr-3 h-8 w-8" />
                  Personalize seu Painel
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Esta página está em desenvolvimento. Em breve, você poderá personalizar temas e outras configurações de aparência do painel.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Opções de personalização de tema para o painel administrativo" src="https://images.unsplash.com/photo-1687031317737-53bd68f49e9f" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsAdminAppearancePage;
  