
    import React from 'react';
    import { motion } from 'framer-motion';

    const AdminSettingsOverviewPage = () => {
      return (
        <div className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 min-h-screen text-white">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <h1 className="text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-sky-400 to-blue-500">
              Página Principal de Configurações
            </h1>
            <p className="mt-2 text-lg text-slate-300">
              Cards de configuração e opções aparecerão aqui em breve.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Perfil do Administrador", description: "Gerencie seus dados pessoais e de acesso.", icon: "UserCog" },
              { title: "Aparência do Painel", description: "Personalize temas e layout do painel.", icon: "Palette" },
              { title: "Usuários do Painel", description: "Adicione e gerencie usuários com acesso ao painel.", icon: "Users" },
              { title: "Loja Virtual", description: "Configurações gerais da sua loja online.", icon: "Store" },
              { title: "Integrações", description: "Conecte serviços externos e APIs.", icon: "PlugZap" },
              { title: "Segurança", description: "Ajustes de segurança e privacidade.", icon: "ShieldCheck" },
            ].map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="bg-slate-800/50 backdrop-blur-md p-6 rounded-xl shadow-2xl hover:shadow-sky-500/30 transition-shadow duration-300"
              >
                <div className="flex items-center text-sky-400 mb-3">
                  {/* Placeholder para ícone futuro, se necessário */}
                  <div className="p-2 bg-sky-500/10 rounded-lg mr-3">
                    {/* <card.icon className="h-6 w-6" />  // Ícones Lucide podem ser mapeados aqui */}
                  </div>
                  <h2 className="text-xl font-semibold text-slate-100">{card.title}</h2>
                </div>
                <p className="text-slate-400 text-sm">
                  {card.description}
                </p>
                <button className="mt-4 text-sm text-sky-400 hover:text-sky-300 transition-colors duration-200">
                  Acessar {'>'}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      );
    };
    
    export default AdminSettingsOverviewPage;
  