
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Webhook } from 'lucide-react';
    
    const AdminSettingsIntegrationsWebhookPage = () => {
      return (
        <>
          <Helmet>
            <title>Webhook - Integrações - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Gerenciamento de Webhooks
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Webhook className="mr-3 h-8 w-8" />
                  Configure seus Webhooks
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Esta página está em desenvolvimento. Em breve, você poderá criar e gerenciar webhooks para integrações externas.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Interface de gerenciamento de webhooks com lista de endpoints e eventos" src="https://images.unsplash.com/photo-1518734549841-b417d28c22aa" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsIntegrationsWebhookPage;
  