
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { FileText } from 'lucide-react';
    
    const AdminSettingsIntegrationsInvoiceBlingPage = () => {
      return (
        <>
          <Helmet>
            <title>Bling - Notas Fiscais - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Bling
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-orange-500 to-red-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <FileText className="mr-3 h-8 w-8" />
                  Configure o Bling
                </CardTitle>
                <CardDescription className="text-orange-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar a integração com o Bling para emissão de notas fiscais.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Configurações de integração Bling" src="https://images.unsplash.com/photo-1677306963569-4c7dffc64aa1" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsIntegrationsInvoiceBlingPage;
  