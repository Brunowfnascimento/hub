
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { CreditCard } from 'lucide-react';
    
    const AdminSettingsIntegrationsPaymentMercadopagoPage = () => {
      return (
        <>
          <Helmet>
            <title>Mercado Pago - Meios de Pagamento - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Mercado Pago
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <CreditCard className="mr-3 h-8 w-8" />
                  Configure o Mercado Pago
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar a integração com o Mercado Pago.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Configurações de integração Mercado Pago" src="https://images.unsplash.com/photo-1586880244543-0528a802be97" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsIntegrationsPaymentMercadopagoPage;
  