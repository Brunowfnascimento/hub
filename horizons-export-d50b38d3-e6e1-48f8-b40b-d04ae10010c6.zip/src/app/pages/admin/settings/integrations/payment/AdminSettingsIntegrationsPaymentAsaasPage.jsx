
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { CreditCard } from 'lucide-react';
    
    const AdminSettingsIntegrationsPaymentAsaasPage = () => {
      return (
        <>
          <Helmet>
            <title>Asaas - Meios de Pagamento - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Asaas
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-teal-500 to-cyan-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <CreditCard className="mr-3 h-8 w-8" />
                  Configure o Asaas
                </CardTitle>
                <CardDescription className="text-teal-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar a integração com o Asaas.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Configurações de integração Asaas" src="https://images.unsplash.com/photo-1642132652809-8c6ab1971169" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsIntegrationsPaymentAsaasPage;
  