
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { CreditCard } from 'lucide-react';
    
    const AdminSettingsIntegrationsPaymentPagarmePage = () => {
      return (
        <>
          <Helmet>
            <title>Pagar.me - Meios de Pagamento - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Pagar.me
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <CreditCard className="mr-3 h-8 w-8" />
                  Configure o Pagar.me
                </CardTitle>
                <CardDescription className="text-emerald-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar a integração com o Pagar.me.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Configurações de integração Pagar.me" src="https://images.unsplash.com/photo-1586880244543-0528a802be97" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsIntegrationsPaymentPagarmePage;
  