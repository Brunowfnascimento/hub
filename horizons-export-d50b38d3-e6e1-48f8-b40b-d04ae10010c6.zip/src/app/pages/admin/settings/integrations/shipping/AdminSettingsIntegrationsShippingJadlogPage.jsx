
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Truck } from 'lucide-react';
    
    const AdminSettingsIntegrationsShippingJadlogPage = () => {
      return (
        <>
          <Helmet>
            <title>Jadlog - Transportadoras - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Integração Jadlog
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-sky-500 to-blue-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Truck className="mr-3 h-8 w-8" />
                  Configure a Jadlog
                </CardTitle>
                <CardDescription className="text-sky-100">
                  Esta página está em desenvolvimento. Em breve, você poderá configurar a integração com a Jadlog.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Configurações de integração Jadlog" src="https://images.unsplash.com/photo-1621737499363-c3a5eb37ba6a" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsIntegrationsShippingJadlogPage;
  