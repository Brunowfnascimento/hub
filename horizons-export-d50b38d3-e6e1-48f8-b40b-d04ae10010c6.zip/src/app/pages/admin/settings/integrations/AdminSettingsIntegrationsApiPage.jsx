
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { TerminalSquare } from 'lucide-react';
    
    const AdminSettingsIntegrationsApiPage = () => {
      return (
        <>
          <Helmet>
            <title>API - Integrações - Configurações - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Acesso API
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-purple-500 to-pink-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <TerminalSquare className="mr-3 h-8 w-8" />
                  Gerencie suas Chaves de API
                </CardTitle>
                <CardDescription className="text-purple-100">
                  Esta página está em desenvolvimento. Em breve, você poderá gerar e gerenciar chaves de API para acesso programático.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Aguarde novidades!
                </p>
                <img  alt="Gerenciador de chaves de API com opções de criar e revogar chaves" src="https://images.unsplash.com/photo-1604291460124-bf80fd39891a" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminSettingsIntegrationsApiPage;
  