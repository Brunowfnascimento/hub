
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import ProductForm from '@/app/features/admin/product-management/components/ProductForm';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

const AdminAddEditProductPage = () => {
  const { productId } = useParams();
  const navigate = useNavigate();
  const isEditMode = !!productId;

  return (
    <div className="container mx-auto p-4 md:p-8 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950 min-h-screen">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex items-center justify-between mb-8 pb-4 border-b border-slate-300 dark:border-slate-700"
      >
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate('/admin/products')} 
            className="mr-3 text-slate-600 hover:bg-slate-200 dark:text-slate-400 dark:hover:bg-slate-700"
            aria-label="Voltar para lista de produtos"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold text-slate-800 dark:text-slate-100 tracking-tight">
            {isEditMode ? 'Editar Produto' : 'Adicionar Novo Produto'}
          </h1>
        </div>
      </motion.div>
      
      <ProductForm productId={productId} />
    </div>
  );
};

export default AdminAddEditProductPage;
