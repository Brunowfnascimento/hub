
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { DollarSign } from 'lucide-react';
    
    const AdminFinancePage = () => {
      return (
        <>
          <Helmet>
            <title>Financeiro - VittaHub Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                Painel Financeiro
              </h1>
            </div>
    
            <Card className="bg-gradient-to-br from-sky-500 to-indigo-600 text-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <DollarSign className="mr-3 h-8 w-8" />
                  Visão Geral Financeira
                </CardTitle>
                <CardDescription className="text-sky-100">
                  Esta seção está em desenvolvimento. Em breve, você poderá gerenciar todas as finanças da sua loja aqui.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg">
                  Funcionalidades planejadas incluem:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-sky-50">
                  <li>Relatórios de vendas e lucros</li>
                  <li>Gestão de pagamentos e recebíveis</li>
                  <li>Configurações de gateway de pagamento</li>
                  <li>Análise de fluxo de caixa</li>
                  <li>E muito mais!</li>
                </ul>
                <img  alt="Gráfico financeiro abstrato" className="mt-6 rounded-lg shadow-md w-full h-auto object-cover max-h-64 opacity-80" src="https://images.unsplash.com/photo-1618044733300-9472054094ee" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };
    
    export default AdminFinancePage;
  