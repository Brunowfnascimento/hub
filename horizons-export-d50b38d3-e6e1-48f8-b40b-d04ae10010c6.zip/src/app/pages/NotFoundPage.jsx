
import React from 'react';
import { Link } from 'react-router-dom';

const NotFoundPage = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white p-4">
      <h1 className="text-6xl font-bold mb-4 text-sky-400">404</h1>
      <p className="text-2xl text-slate-300 mb-8">Página Não Encontrada</p>
      <img  class="w-64 h-64 mb-8" alt="Astronauta perdido no espaço" src="https://images.unsplash.com/photo-1695088560164-84c9c42bbadd" />
      <Link
        to="/"
        className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg shadow-md transition-colors duration-300"
      >
        Voltar para a Página Inicial
      </Link>
    </div>
  );
};

export default NotFoundPage;
  