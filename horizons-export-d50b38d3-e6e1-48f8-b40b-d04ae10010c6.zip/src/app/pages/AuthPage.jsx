
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/app/contexts/AuthContext';
import LoginForm from '@/app/features/auth/components/LoginForm';
import SignupForm from '@/app/features/auth/components/SignupForm';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { Chrome, Loader2 } from 'lucide-react'; // Usando Chrome como ícone genérico para Google

const AuthPage = () => {
  const navigate = useNavigate();
  const { user, loginWithGoogle, isLoadingUser } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      navigate('/'); // Ou para /admin se for admin, lógica a ser adicionada
    }
  }, [user, navigate]);

  const handleGoogleLogin = async () => {
    const { error } = await loginWithGoogle();
    if (error) {
      toast({
        variant: "destructive",
        title: "Erro no Login com Google",
        description: error.message || "Não foi possível fazer login com o Google.",
      });
    } else {
      toast({
        title: "Login com Google iniciado!",
        description: "Você será redirecionado.",
      });
      // O redirecionamento é tratado pelo Supabase e pelo onAuthStateChange
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-500 via-indigo-600 to-purple-700 dark:from-sky-800 dark:via-indigo-900 dark:to-purple-950 p-4">
      <Card className="w-full max-w-md shadow-2xl bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <CardHeader className="text-center p-6 bg-slate-50 dark:bg-slate-700">
          <CardTitle className="text-3xl font-bold text-slate-800 dark:text-slate-100">Bem-vindo!</CardTitle>
          <CardDescription className="text-slate-600 dark:text-slate-300">
            Acesse sua conta ou crie uma nova para começar.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 sm:p-8">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-slate-200 dark:bg-slate-700">
              <TabsTrigger value="login" className="py-2.5 data-[state=active]:bg-sky-500 data-[state=active]:text-white dark:data-[state=active]:bg-sky-600">Entrar</TabsTrigger>
              <TabsTrigger value="signup" className="py-2.5 data-[state=active]:bg-emerald-500 data-[state=active]:text-white dark:data-[state=active]:bg-emerald-600">Registrar</TabsTrigger>
            </TabsList>
            <TabsContent value="login">
              <LoginForm />
            </TabsContent>
            <TabsContent value="signup">
              <SignupForm />
            </TabsContent>
          </Tabs>

          <div className="mt-6 relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-slate-300 dark:border-slate-600" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white dark:bg-slate-800 px-2 text-slate-500 dark:text-slate-400">
                Ou continue com
              </span>
            </div>
          </div>

          <Button
            variant="outline"
            className="w-full mt-6 border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
            onClick={handleGoogleLogin}
            disabled={isLoadingUser}
          >
            {isLoadingUser ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Chrome className="mr-2 h-5 w-5 text-red-500" /> 
            )}
            Entrar com Google
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default AuthPage;
  