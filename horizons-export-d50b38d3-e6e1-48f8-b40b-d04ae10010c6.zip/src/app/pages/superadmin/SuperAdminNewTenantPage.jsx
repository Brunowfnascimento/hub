
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { UserCog } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Link } from 'react-router-dom';

    const SuperAdminNewTenantPage = () => {
      return (
        <>
          <Helmet>
            <title>Adicionar Novo Tenant - VittaHub Super Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8 max-w-2xl"
          >
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100">
                Adicionar Novo Tenant
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-300">
                Cadastre uma nova empresa na plataforma VittaHub.
              </p>
            </div>

            <Card className="shadow-xl dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-slate-700 dark:text-slate-200 flex items-center">
                  <UserCog className="mr-2 h-6 w-6 text-red-500" /> Informações do Novo Tenant
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="tenantName" className="text-slate-700 dark:text-slate-300">Nome da Empresa</Label>
                  <Input id="tenantName" placeholder="Ex: Loja Incrível LTDA" className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200" />
                </div>
                <div>
                  <Label htmlFor="ownerEmail" className="text-slate-700 dark:text-slate-300">Email do Proprietário</Label>
                  <Input id="ownerEmail" type="email" placeholder="ex: proprietario@loja.com" className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200" />
                </div>
                <div>
                  <Label htmlFor="subdomain" className="text-slate-700 dark:text-slate-300">Subdomínio (<span className="text-xs">opcional</span>)</Label>
                  <Input id="subdomain" placeholder="ex: lojaincrivel (para lojaincrivel.vittahub.com)" className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200" />
                </div>
                <div>
                  <Label htmlFor="plan" className="text-slate-700 dark:text-slate-300">Plano Inicial</Label>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Seleção de plano será implementada aqui (ex: Básico, Profissional, Empresarial).</p>
                </div>
                <div className="flex justify-end space-x-3 pt-4">
                  <Button variant="outline" asChild className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
                     <Link to="/superadmin/tenants">Cancelar</Link>
                  </Button>
                  <Button className="bg-red-600 hover:bg-red-700 text-white">
                    Criar Tenant
                  </Button>
                </div>
                 <img  alt="Formulário de cadastro de novo tenant com campos para nome da empresa, email do proprietário e subdomínio" src="https://images.unsplash.com/photo-1623295080944-9ba74d587748" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };

    export default SuperAdminNewTenantPage;
  