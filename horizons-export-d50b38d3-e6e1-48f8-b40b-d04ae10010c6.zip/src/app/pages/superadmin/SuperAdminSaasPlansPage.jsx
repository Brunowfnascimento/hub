
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Tags, PlusCircle } from 'lucide-react';
    import { Button } from '@/components/ui/button';

    const SuperAdminSaasPlansPage = () => {
      return (
        <>
          <Helmet>
            <title>Planos de Assinatura - VittaHub Super Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100">
                  Planos de Assinatura (SaaS)
                </h1>
                <p className="text-lg text-slate-600 dark:text-slate-300">
                  Gerencie os planos de assinatura oferecidos pela VittaHub.
                </p>
              </div>
              <Button className="bg-red-600 hover:bg-red-700 text-white">
                <PlusCircle className="mr-2 h-5 w-5" /> Adicionar Novo Plano
              </Button>
            </div>

            <Card className="shadow-xl dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-slate-700 dark:text-slate-200">Lista de Planos</CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  CRUD para os diferentes planos de assinatura, com limites de recursos e preços.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96 flex items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg">
                  <p className="text-slate-500 dark:text-slate-400">Gerenciamento de planos SaaS será implementado aqui...</p>
                </div>
                 <img  alt="Cards mostrando diferentes planos de assinatura (Básico, Pro, Enterprise) com seus recursos e preços" src="https://images.unsplash.com/photo-1623295080944-9ba74d587748" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };

    export default SuperAdminSaasPlansPage;
  