
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Building2, PlusCircle } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Link } from 'react-router-dom';

    const SuperAdminTenantsListPage = () => {
      return (
        <>
          <Helmet>
            <title>Gerenciamento de Tenants - VittaHub Super Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100">
                  Gerenciamento de Tenants
                </h1>
                <p className="text-lg text-slate-600 dark:text-slate-300">
                  Visualize e gerencie todas as empresas na plataforma.
                </p>
              </div>
              <Button asChild className="bg-red-600 hover:bg-red-700 text-white">
                <Link to="/superadmin/tenants/new">
                  <PlusCircle className="mr-2 h-5 w-5" /> Adicionar Novo Tenant
                </Link>
              </Button>
            </div>

            <Card className="shadow-xl dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-slate-700 dark:text-slate-200">Lista de Tenants</CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Tabela com todos os tenants, status, planos e ações.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96 flex items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg">
                  <p className="text-slate-500 dark:text-slate-400">Tabela de tenants será implementada aqui...</p>
                </div>
                 <img  alt="Tabela de tenants com colunas para nome, status, plano e data de criação" src="https://images.unsplash.com/photo-1569083676317-dafd0fc965f7" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };

    export default SuperAdminTenantsListPage;
  