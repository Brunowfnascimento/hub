
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Activity, Users, BarChart2, DollarSign } from 'lucide-react';

    const SuperAdminDashboardPage = () => {
      return (
        <>
          <Helmet>
            <title>Super Admin Dashboard - VittaHub</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100">
                Super Admin Dashboard
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-300">
                Visão geral da plataforma VittaHub SaaS.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="bg-gradient-to-r from-red-500 to-orange-500 text-white shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Tenants</CardTitle>
                  <Users className="h-5 w-5 text-red-100" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">150</div>
                  <p className="text-xs text-red-50">
                    +10% from last month
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-r from-sky-500 to-cyan-500 text-white shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Subscriptions</CardTitle>
                  <Activity className="h-5 w-5 text-sky-100" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">125</div>
                  <p className="text-xs text-sky-50">
                    +5 since last week
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-r from-emerald-500 to-green-500 text-white shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Platform MRR</CardTitle>
                  <DollarSign className="h-5 w-5 text-emerald-100" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">R$12,350.00</div>
                  <p className="text-xs text-emerald-50">
                    Based on active plans
                  </p>
                </CardContent>
              </Card>
               <Card className="bg-gradient-to-r from-purple-500 to-fuchsia-500 text-white shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">New Signups (30d)</CardTitle>
                  <BarChart2 className="h-5 w-5 text-purple-100" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">32</div>
                  <p className="text-xs text-purple-50">
                    Growth trend positive
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <Card className="shadow-xl dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-slate-700 dark:text-slate-200">Overview</CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Página do Dashboard do Super Administrador. Conteúdo específico será adicionado aqui.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg">
                  <p className="text-slate-500 dark:text-slate-400">Gráficos e métricas globais da plataforma em breve...</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };

    export default SuperAdminDashboardPage;
  