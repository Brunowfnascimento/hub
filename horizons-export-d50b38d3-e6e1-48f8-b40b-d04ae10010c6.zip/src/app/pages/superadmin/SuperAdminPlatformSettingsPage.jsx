
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Settings } from 'lucide-react';

    const SuperAdminPlatformSettingsPage = () => {
      return (
        <>
          <Helmet>
            <title>Configurações da Plataforma - VittaHub Super Admin</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100">
                Configurações da Plataforma
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-300">
                Ajustes globais que afetam toda a plataforma VittaHub SaaS.
              </p>
            </div>

            <Card className="shadow-xl dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-slate-700 dark:text-slate-200">Configurações Globais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg">
                  <p className="text-slate-500 dark:text-slate-400">Opções de configuração global da plataforma em breve...</p>
                </div>
                <img  alt="Interface de configurações da plataforma com opções para integrações de pagamento globais e configurações de email do sistema" src="https://images.unsplash.com/photo-1586880244543-0528a802be97" />
              </CardContent>
            </Card>
          </motion.div>
        </>
      );
    };

    export default SuperAdminPlatformSettingsPage;
  