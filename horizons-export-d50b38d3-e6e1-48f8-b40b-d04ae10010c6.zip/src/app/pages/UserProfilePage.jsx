
import React from 'react';
import { useAuth } from '@/app/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'; // Supondo que você tenha ou vá criar este componente
import { Button } from '@/components/ui/button';

// Se o Avatar não existir, crie um placeholder ou use um ícone
const FallbackAvatar = ({ name }) => {
  const initial = name ? name.charAt(0).toUpperCase() : "U";
  return (
    <div className="h-10 w-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-semibold">
      {initial}
    </div>
  )
}


const UserProfilePage = () => {
  const { user, logout } = useAuth();

  if (!user) {
    return (
      <div className="container mx-auto py-10 px-4">
        <Card className="max-w-lg mx-auto bg-card text-card-foreground">
          <CardHeader>
            <CardTitle>Perfil do Usuário</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Usuário não encontrado ou não está logado.</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const userFullName = user.user_metadata?.full_name || user.email;
  const userEmail = user.email;
  const userAvatarUrl = user.user_metadata?.avatar_url; // Pode não existir inicialmente

  return (
    <div className="container mx-auto py-10 px-4 text-foreground">
      <Card className="max-w-2xl mx-auto shadow-xl bg-card dark:bg-slate-800 rounded-lg">
        <CardHeader className="text-center border-b dark:border-slate-700 pb-6">
          <div className="flex justify-center mb-4">
            {userAvatarUrl ? (
               <img  src={userAvatarUrl} alt={userFullName || 'Avatar do usuário'} className="h-24 w-24 rounded-full object-cover border-4 border-primary" src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
            ) : (
              <FallbackAvatar name={userFullName} />
            )}
          </div>
          <CardTitle className="text-3xl font-bold">{userFullName}</CardTitle>
          <CardDescription className="text-lg text-muted-foreground">{userEmail}</CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div>
            <h3 className="text-xl font-semibold mb-2">Informações da Conta</h3>
            <div className="space-y-2">
              <p><strong>ID do Usuário:</strong> <span className="font-mono text-sm bg-muted p-1 rounded">{user.id}</span></p>
              <p><strong>Último Login:</strong> {user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleString() : 'N/A'}</p>
              <p><strong>Email Confirmado:</strong> {user.email_confirmed_at ? 'Sim' : 'Não'}</p>
            </div>
          </div>
          
          {/* Seção para mais detalhes do perfil, como endereço, telefone, etc. pode ser adicionada aqui */}
          {/* Exemplo:
          <div>
            <h3 className="text-xl font-semibold mb-2">Detalhes Pessoais</h3>
            <p>Telefone: (XX) XXXXX-XXXX</p>
            <p>Endereço: Rua Exemplo, 123, Cidade, Estado</p>
          </div> 
          */}

          <div className="pt-4 border-t dark:border-slate-700">
            <Button 
              onClick={logout} 
              variant="destructive" 
              className="w-full sm:w-auto bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600"
            >
              Sair da Conta
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserProfilePage;
  