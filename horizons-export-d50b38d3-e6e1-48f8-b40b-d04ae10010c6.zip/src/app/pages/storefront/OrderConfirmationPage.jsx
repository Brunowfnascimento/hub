
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { CheckCircle, ShoppingBag, Package, Printer } from 'lucide-react';
import { motion } from 'framer-motion';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { fetchOrderByIdForCustomer } from '@/app/features/orders/services/orderStorefront.service.jsx';
import { useAuth } from '@/app/contexts/AuthContext';
import OrderSummaryDisplay from '@/app/features/orders/components/OrderSummaryDisplay.jsx';
import OrderAddressDisplay from '@/app/features/orders/components/OrderAddressDisplay.jsx';
import OrderPaymentDetailsDisplay from '@/app/features/orders/components/OrderPaymentDetailsDisplay.jsx';

const OrderConfirmationPage = () => {
  const { orderId } = useParams();
  const { user } = useAuth();

  const { data: order, isLoading, error } = useQuery({
    queryKey: ['orderConfirmation', orderId, user?.id],
    queryFn: () => fetchOrderByIdForCustomer(orderId, user?.id),
    enabled: !!orderId,
  });

  const handlePrint = () => {
    window.print();
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-200px)] flex items-center justify-center">
        <LoadingSpinner size="h-16 w-16" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-200px)] flex items-center justify-center">
        <ErrorDisplay message={error.message || "Não foi possível carregar os detalhes do pedido."} />
      </div>
    );
  }

  if (!order) {
     return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-200px)] flex items-center justify-center">
        <ErrorDisplay message="Pedido não encontrado." />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-3xl mx-auto"
      >
        <Card className="shadow-xl bg-gradient-to-br from-sky-50 via-white to-indigo-50 dark:from-slate-800 dark:via-slate-800/80 dark:to-slate-900 border-green-500 dark:border-green-600 print:shadow-none print:border-none print:bg-white">
          <CardHeader className="text-center items-center pt-8 print:pt-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200, damping: 10 }}
            >
              <CheckCircle className="h-16 w-16 text-green-500 dark:text-green-400 mb-3 print:h-12 print:w-12" />
            </motion.div>
            <CardTitle className="text-3xl font-bold text-slate-800 dark:text-slate-50 print:text-2xl">Pedido Confirmado!</CardTitle>
            <CardDescription className="text-lg text-slate-600 dark:text-slate-300 pt-1 print:text-base">
              Obrigado pela sua compra, {order.customer_name || 'Cliente'}!
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 py-6 print:py-4">
            <div className="text-center">
              <p className="text-slate-700 dark:text-slate-200">
                Seu pedido <strong className="text-sky-600 dark:text-sky-400">{order.order_number}</strong> foi recebido.
              </p>
              <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                Um e-mail de confirmação foi enviado para <strong className="text-slate-700 dark:text-slate-100">{order.customer_email}</strong>.
              </p>
            </div>

            <Separator className="dark:bg-slate-700 print:bg-slate-300" />

            <div>
              <h3 className="text-lg font-semibold mb-2 text-slate-700 dark:text-slate-200">Resumo do Pedido</h3>
              <OrderSummaryDisplay
                orderItems={order.order_items}
                totalItemsPrice={order.total_items_price}
                shippingCost={order.shipping_cost}
                discountAmount={order.discount_amount}
                couponCode={order.coupon_code}
                grandTotal={order.grand_total}
                shippingMethodName={order.shipping_method_details?.name}
              />
            </div>
            
            <Separator className="dark:bg-slate-700 print:bg-slate-300" />

            <OrderAddressDisplay address={order.shipping_address_snapshot} title="Endereço de Entrega" />

            <Separator className="dark:bg-slate-700 print:bg-slate-300" />
            
            <OrderPaymentDetailsDisplay
              paymentMethod={order.payment_method}
              paymentStatus={order.payment_status}
              paymentDetails={order.payment_details}
            />

          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row justify-center gap-4 pb-8 print:hidden">
            <Button variant="outline" size="lg" onClick={handlePrint} className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
              <Printer className="mr-2 h-5 w-5" /> Imprimir Pedido
            </Button>
            <Button size="lg" className="bg-sky-500 hover:bg-sky-600 text-white" asChild>
              <Link to="/products">
                <ShoppingBag className="mr-2 h-5 w-5" /> Continuar Comprando
              </Link>
            </Button>
            <Button variant="outline" size="lg" className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700" asChild>
              <Link to="/profile/orders">
                <Package className="mr-2 h-5 w-5" /> Ver Meus Pedidos
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default OrderConfirmationPage;
