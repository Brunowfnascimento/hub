
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { ArrowRight, ShoppingBag, Tag, Zap } from 'lucide-react';
import ProductGrid from '@/app/features/products/components/ProductGrid';
import { useQuery } from '@tanstack/react-query';
import { WorkspaceFeaturedProducts } from '@/app/features/products/services/modules/featuredAndRelated';
import MetaTags from '@/app/components/common/MetaTags';
import { fetchStoreSettings } from '@/app/features/admin/settings-management/services/settingsAdmin.service';

const HomePage = () => {
  const { data: featuredProducts, isLoading: isLoadingFeatured } = useQuery({
    queryKey: ['featuredProducts'],
    queryFn: () => WorkspaceFeaturedProducts({ limit: 8 }),
    staleTime: 1000 * 60 * 5, 
  });

  const { data: storeSettings } = useQuery({
    queryKey: ['storeSettings'],
    queryFn: fetchStoreSettings,
    staleTime: Infinity,
  });

  const storeName = storeSettings?.store_name || "VittaHub";
  const storeSlogan = storeSettings?.store_slogan || "Sua jornada para uma vida mais saudável e vibrante começa aqui!";
  const heroTitle = storeSettings?.hero_title || "Bem-vindo à VittaHub!";
  const heroSubtitle = storeSettings?.hero_subtitle || "Descubra produtos incríveis para seu bem-estar.";

  const pageTitle = `${storeName} - ${storeSlogan}`;
  const pageDescription = `Explore ${storeName} para encontrar os melhores produtos. ${storeSlogan}`;


  return (
    <>
      <MetaTags title={storeName} description={pageDescription}>
         <meta property="og:title" content={pageTitle} />
      </MetaTags>
      <div className="flex flex-col min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-emerald-50 dark:from-slate-900 dark:via-sky-900/30 dark:to-emerald-900/30">
        <motion.section
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="py-16 md:py-24 text-center bg-cover bg-center relative"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1536500152107-01ab1422f932?q=80&w=2070&auto=format&fit=crop')" }}
        >
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.h1 
              className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              {heroTitle}
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl text-slate-200 mb-8 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              {heroSubtitle}
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <Button asChild size="lg" className="bg-emerald-500 hover:bg-emerald-600 text-white dark:bg-emerald-600 dark:hover:bg-emerald-700 text-lg px-8 py-3 rounded-full shadow-lg transition-transform hover:scale-105">
                <Link to="/products">
                  Explorar Produtos <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </motion.div>
          </div>
        </motion.section>

        <section className="py-12 md:py-16 bg-white dark:bg-slate-800/50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center text-slate-800 dark:text-white mb-10">Por que escolher a {storeName}?</h2>
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <motion.div 
                className="p-6 bg-slate-100 dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-2xl transition-shadow"
                whileHover={{ y: -5 }}
              >
                <ShoppingBag className="h-12 w-12 text-sky-500 dark:text-sky-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-200 mb-2">Variedade Incrível</h3>
                <p className="text-slate-600 dark:text-slate-400">Produtos selecionados para todas as suas necessidades.</p>
              </motion.div>
              <motion.div 
                className="p-6 bg-slate-100 dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-2xl transition-shadow"
                whileHover={{ y: -5 }}
              >
                <Tag className="h-12 w-12 text-emerald-500 dark:text-emerald-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-200 mb-2">Qualidade Garantida</h3>
                <p className="text-slate-600 dark:text-slate-400">Compromisso com a excelência e satisfação do cliente.</p>
              </motion.div>
              <motion.div 
                className="p-6 bg-slate-100 dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-2xl transition-shadow"
                whileHover={{ y: -5 }}
              >
                <Zap className="h-12 w-12 text-amber-500 dark:text-amber-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-200 mb-2">Entrega Rápida</h3>
                <p className="text-slate-600 dark:text-slate-400">Receba seus produtos no conforto da sua casa.</p>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Produtos em Destaque</h2>
              <Button asChild variant="outline" className="border-sky-500 text-sky-500 hover:bg-sky-500 hover:text-white dark:border-sky-400 dark:text-sky-400 dark:hover:bg-sky-400 dark:hover:text-slate-900">
                <Link to="/products">
                  Ver Todos <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
            <ProductGrid products={featuredProducts} isLoading={isLoadingFeatured} />
          </div>
        </section>

        <section className="py-12 md:py-16 bg-sky-600 dark:bg-sky-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Pronto para começar?</h2>
            <p className="text-lg mb-8">Junte-se à nossa comunidade e transforme sua vida.</p>
            <Button asChild size="lg" variant="secondary" className="bg-white text-sky-600 hover:bg-slate-100 dark:bg-slate-100 dark:text-sky-700 dark:hover:bg-slate-200 text-lg px-8 py-3 rounded-full shadow-lg transition-transform hover:scale-105">
              <Link to="/auth">
                Crie sua Conta
              </Link>
            </Button>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;
