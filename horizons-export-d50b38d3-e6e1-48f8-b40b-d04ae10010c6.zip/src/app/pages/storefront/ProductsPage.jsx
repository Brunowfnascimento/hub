
import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useQuery, useInfiniteQuery } from '@tanstack/react-query';
import { WorkspaceStorefrontProducts } from '@/app/features/products/services/modules/products';
import { WorkspaceStorefrontCategories } from '@/app/features/products/services/modules/categories';
import { WorkspaceStorefrontBrands } from '@/app/features/products/services/modules/brands';
import ProductGrid from '@/app/features/products/components/ProductGrid';
import ProductFiltersStorefront from '@/app/features/products/components/ProductFiltersStorefront';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, SlidersHorizontal, Home, ChevronRight } from 'lucide-react';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb.jsx";
import MetaTags from '@/app/components/common/MetaTags';

const STOREFRONT_PAGE_SIZE = 12;

const ProductsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState({
    searchTerm: searchParams.get('q') || '',
    category: searchParams.get('category') || '',
    brand: searchParams.get('brand') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    sortBy: searchParams.get('sortBy') || 'created_at_desc',
    tags: searchParams.getAll('tags') || [],
  });
  const [showFilters, setShowFilters] = useState(false);

  const { data: categoriesData, isLoading: isLoadingCategories } = useQuery({
    queryKey: ['storefrontCategories'],
    queryFn: WorkspaceStorefrontCategories,
    staleTime: 1000 * 60 * 60, // 1 hour
  });

  const { data: brandsData, isLoading: isLoadingBrands } = useQuery({
    queryKey: ['storefrontBrands'],
    queryFn: WorkspaceStorefrontBrands,
    staleTime: 1000 * 60 * 60, // 1 hour
  });

  const debouncedFilters = useMemo(() => filters, [filters]);

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    error,
    refetch
  } = useInfiniteQuery({
    queryKey: ['storefrontProducts', debouncedFilters],
    queryFn: ({ pageParam = 0 }) => 
      WorkspaceStorefrontProducts({ 
        ...debouncedFilters, 
        page: pageParam, 
        limit: STOREFRONT_PAGE_SIZE 
      }),
    getNextPageParam: (lastPage, allPages) => {
      return lastPage.products.length === STOREFRONT_PAGE_SIZE ? allPages.length : undefined;
    },
    initialPageParam: 0,
  });

  useEffect(() => {
    const newSearchParams = new URLSearchParams();
    if (filters.searchTerm) newSearchParams.set('q', filters.searchTerm);
    if (filters.category) newSearchParams.set('category', filters.category);
    if (filters.brand) newSearchParams.set('brand', filters.brand);
    if (filters.minPrice) newSearchParams.set('minPrice', filters.minPrice);
    if (filters.maxPrice) newSearchParams.set('maxPrice', filters.maxPrice);
    if (filters.sortBy) newSearchParams.set('sortBy', filters.sortBy);
    filters.tags.forEach(tag => newSearchParams.append('tags', tag));
    setSearchParams(newSearchParams, { replace: true });
  }, [filters, setSearchParams]);

  const handleFilterChange = (newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters, page: 0 }));
  };
  
  const allProducts = useMemo(() => data?.pages.flatMap(page => page.products) || [], [data]);
  const totalProducts = data?.pages[0]?.totalCount || 0;

  const selectedCategory = useMemo(() => {
    if (filters.category && categoriesData) {
      return categoriesData.find(cat => cat.slug === filters.category);
    }
    return null;
  }, [filters.category, categoriesData]);

  const pageTitle = selectedCategory ? selectedCategory.name : "Todos os Produtos";
  const pageDescription = selectedCategory 
    ? selectedCategory.description || `Explore produtos na categoria ${selectedCategory.name}.`
    : "Navegue por nossa coleção completa de produtos.";


  return (
    <>
      <MetaTags title={pageTitle} description={pageDescription} />
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb className="mb-6">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/" className="flex items-center text-slate-600 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400">
                  <Home className="h-4 w-4 mr-1.5" /> Início
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator><ChevronRight className="h-4 w-4" /></BreadcrumbSeparator>
            <BreadcrumbItem>
              {selectedCategory ? (
                <BreadcrumbLink asChild>
                  <Link to="/products" className="text-slate-600 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400">Produtos</Link>
                </BreadcrumbLink>
              ) : (
                <BreadcrumbPage className="font-medium text-slate-800 dark:text-slate-200">Produtos</BreadcrumbPage>
              )}
            </BreadcrumbItem>
            {selectedCategory && (
              <>
                <BreadcrumbSeparator><ChevronRight className="h-4 w-4" /></BreadcrumbSeparator>
                <BreadcrumbItem>
                  <BreadcrumbPage className="font-medium text-slate-800 dark:text-slate-200">{selectedCategory.name}</BreadcrumbPage>
                </BreadcrumbItem>
              </>
            )}
          </BreadcrumbList>
        </Breadcrumb>

        <div className="flex flex-col md:flex-row gap-8">
          <aside className={`md:w-1/4 transition-all duration-300 ease-in-out ${showFilters ? 'block' : 'hidden md:block'}`}>
            <div className="sticky top-24">
              <ProductFiltersStorefront
                filters={filters}
                onFilterChange={handleFilterChange}
                categories={categoriesData || []}
                brands={brandsData || []}
                isLoadingCategories={isLoadingCategories}
                isLoadingBrands={isLoadingBrands}
                productCount={totalProducts}
              />
            </div>
          </aside>

          <main className="md:w-3/4">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-3xl font-bold text-slate-800 dark:text-white">
                {selectedCategory ? selectedCategory.name : 'Todos os Produtos'}
              </h1>
              <Button 
                variant="outline" 
                className="md:hidden border-slate-300 dark:border-slate-600"
                onClick={() => setShowFilters(!showFilters)}
              >
                <SlidersHorizontal className="mr-2 h-4 w-4" /> Filtros
              </Button>
            </div>
            
            <AnimatePresence mode="wait">
              <motion.div
                key={JSON.stringify(debouncedFilters)}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                {isLoading && !allProducts.length ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array.from({ length: STOREFRONT_PAGE_SIZE }).map((_, index) => (
                      <ProductGrid products={[]} isLoading={true} key={`skeleton-${index}`} />
                    ))}
                  </div>
                ) : error ? (
                  <ErrorDisplay message={error.message} onRetry={refetch} />
                ) : allProducts.length === 0 ? (
                  <div className="text-center py-12">
                    <img  alt="Nenhum produto encontrado" class="mx-auto mb-4 w-40 h-40 text-slate-400 dark:text-slate-500" src="https://images.unsplash.com/photo-1696744404432-d829841194f4" />
                    <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-300 mb-2">Nenhum produto encontrado</h2>
                    <p className="text-slate-500 dark:text-slate-400">Tente ajustar seus filtros ou pesquisar por algo diferente.</p>
                  </div>
                ) : (
                  <ProductGrid products={allProducts} isLoading={false} />
                )}
              </motion.div>
            </AnimatePresence>

            {hasNextPage && (
              <div className="mt-10 text-center">
                <Button
                  onClick={() => fetchNextPage()}
                  disabled={isFetchingNextPage}
                  variant="outline"
                  size="lg"
                  className="border-sky-500 text-sky-500 hover:bg-sky-500 hover:text-white dark:border-sky-400 dark:text-sky-400 dark:hover:bg-sky-400 dark:hover:text-slate-900"
                >
                  {isFetchingNextPage ? (
                    <>
                      <LoadingSpinner size="sm" className="mr-2" /> Carregando...
                    </>
                  ) : (
                    <>
                      Carregar Mais <ChevronDown className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            )}
          </main>
        </div>
      </div>
    </>
  );
};

export default ProductsPage;
