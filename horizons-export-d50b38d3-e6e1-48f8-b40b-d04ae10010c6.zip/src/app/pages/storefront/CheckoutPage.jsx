
import React from 'react';
import { CheckoutProvider, useCheckout } from '@/app/contexts/CheckoutContext';
import { useAuth } from '@/app/contexts/AuthContext';
import { useCart } from '@/app/contexts/CartContext';
import CheckoutAddressStep from '@/app/features/checkout/components/CheckoutAddressStep';
import CheckoutShippingStep from '@/app/features/checkout/components/CheckoutShippingStep';
import CheckoutPaymentStep from '@/app/features/checkout/components/CheckoutPaymentStep';
import CheckoutReviewStep from '@/app/features/checkout/components/CheckoutReviewStep';
import CheckoutSummary from '@/app/features/checkout/components/CheckoutSummary';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { Navigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, ChevronLeft, ChevronRight } from 'lucide-react';

const CheckoutStepsDisplay = () => {
  const { currentStep, steps, goToStep } = useCheckout();
  const currentStepIndex = steps.indexOf(currentStep);

  const stepLabels = {
    address: 'Endereço',
    shipping: 'Frete',
    payment: 'Pagamento',
    review: 'Revisão',
  };

  return (
    <div className="mb-8 flex items-center justify-center space-x-2 sm:space-x-4 p-2 sm:p-4 bg-slate-100 dark:bg-slate-800 rounded-xl shadow">
      {steps.map((step, index) => {
        const isActive = index === currentStepIndex;
        const isCompleted = index < currentStepIndex;
        return (
          <React.Fragment key={step}>
            <button
              onClick={() => isCompleted && goToStep(step)} 
              disabled={!isCompleted && !isActive}
              className={`flex flex-col sm:flex-row items-center p-2 sm:px-4 sm:py-2 rounded-lg transition-all duration-300
                ${isActive ? 'bg-sky-500 text-white scale-105 shadow-md' : ''}
                ${isCompleted ? 'bg-green-500 text-white hover:bg-green-600' : ''}
                ${!isActive && !isCompleted ? 'bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 cursor-not-allowed' : ''}
              `}
            >
              {isCompleted && !isActive ? <CheckCircle className="h-5 w-5 mb-1 sm:mb-0 sm:mr-2" /> : <span className="sm:mr-2 text-sm font-bold">{index + 1}</span>}
              <span className="text-xs sm:text-sm">{stepLabels[step]}</span>
            </button>
            {index < steps.length - 1 && (
              <ChevronRight className="h-5 w-5 text-slate-300 dark:text-slate-600 hidden sm:block" />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};


const CheckoutPageContent = () => {
  const { currentStep } = useCheckout();
  const { user, isLoadingUser } = useAuth();
  const { items: cartItems, isCartLoading } = useCart();

  if (isLoadingUser || isCartLoading) {
    return <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-200px)] flex items-center justify-center"><LoadingSpinner size="w-12 h-12" /></div>;
  }

  if (!user) {
    return <Navigate to="/auth?mode=login&redirect=/checkout" replace />;
  }

  if (cartItems.length === 0 && !isCartLoading) {
     return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-semibold mb-4">Seu carrinho está vazio.</h1>
        <p className="mb-6">Adicione produtos ao seu carrinho antes de prosseguir para o checkout.</p>
        <Button asChild><Navigate to="/products">Continuar Comprando</Navigate></Button>
      </div>
    );
  }
  
  const renderStepComponent = () => {
    switch (currentStep) {
      case 'address':
        return <CheckoutAddressStep />;
      case 'shipping':
        return <CheckoutShippingStep />;
      case 'payment':
        return <CheckoutPaymentStep />;
      case 'review':
        return <CheckoutReviewStep />;
      default:
        return <div>Etapa desconhecida</div>;
    }
  };

  return (
    <div className="container mx-auto px-2 sm:px-4 py-8 md:py-12">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-slate-50 mb-8 text-center"
      >
        Finalizar Compra
      </motion.h1>
      
      <CheckoutStepsDisplay />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12 items-start">
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
            >
              {renderStepComponent()}
            </motion.div>
          </AnimatePresence>
        </div>
        <div className="lg:col-span-1">
          <CheckoutSummary />
        </div>
      </div>
    </div>
  );
};

const CheckoutPage = () => {
  return (
    <CheckoutProvider>
      <CheckoutPageContent />
    </CheckoutProvider>
  );
};

export default CheckoutPage;
