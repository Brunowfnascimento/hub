
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import ProfileAddressesTab from '@/app/features/profile/components/ProfileAddressesTab';

    const ProfileAddressesPage = () => {
      return (
        <>
          <Helmet>
            <title>Meus Endereços - VittaHub</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
             <h2 className="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Meus Endereços</h2>
            <ProfileAddressesTab />
          </motion.div>
        </>
      );
    };

    export default ProfileAddressesPage;
  