
    import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import ProfileOrdersTab from '@/app/features/profile/components/ProfileOrdersTab';

    const ProfileOrdersPage = () => {
      return (
        <>
          <Helmet>
            <title>Meus Pedidos - VittaHub</title>
          </Helmet>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-2xl font-semibold text-slate-800 dark:text-slate-100 mb-6">Meus Pedidos</h2>
            <ProfileOrdersTab />
          </motion.div>
        </>
      );
    };

    export default ProfileOrdersPage;
  