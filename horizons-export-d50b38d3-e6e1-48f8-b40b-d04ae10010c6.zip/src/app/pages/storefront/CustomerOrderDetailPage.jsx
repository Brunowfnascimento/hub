
import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Package, ArrowLeft, HelpCircle, ExternalLink, Info as InfoIcon, Truck as TruckIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { fetchOrderByIdForCustomer } from '@/app/features/orders/services/orderStorefront.service.jsx';
import { useAuth } from '@/app/contexts/AuthContext';
import OrderSummaryDisplay from '@/app/features/orders/components/OrderSummaryDisplay.jsx';
import OrderAddressDisplay from '@/app/features/orders/components/OrderAddressDisplay.jsx';
import OrderPaymentDetailsDisplay from '@/app/features/orders/components/OrderPaymentDetailsDisplay.jsx';
import OrderStatusBadge from '@/app/features/admin/order-management/components/OrderStatusBadge.jsx';
import { ORDER_STATUS_OPTIONS } from '@/app/types/admin.types.jsx'; // For status history labels

const CustomerOrderDetailPage = () => {
  const { orderId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: order, isLoading, error } = useQuery({
    queryKey: ['customerOrderDetail', orderId, user?.id],
    queryFn: () => fetchOrderByIdForCustomer(orderId, user?.id),
    enabled: !!orderId && !!user,
  });

  const formatDate = (dateString) => dateString ? new Date(dateString).toLocaleString('pt-BR') : 'N/A';

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-200px)] flex items-center justify-center">
        <LoadingSpinner size="h-16 w-16" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-200px)] flex items-center justify-center">
        <ErrorDisplay message={error.message || "Não foi possível carregar os detalhes do pedido."} />
      </div>
    );
  }

  if (!order) {
     return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-200px)] flex items-center justify-center">
        <ErrorDisplay message="Pedido não encontrado." />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Button variant="outline" onClick={() => navigate('/profile/orders')} className="mb-6 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700">
          <ArrowLeft className="mr-2 h-4 w-4" /> Voltar para Meus Pedidos
        </Button>

        <Card className="shadow-xl bg-white dark:bg-slate-800">
          <CardHeader className="border-b dark:border-slate-700">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
              <div>
                <CardTitle className="text-2xl font-bold text-slate-800 dark:text-slate-100">
                  Pedido #{order.order_number}
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400 mt-1">
                  Realizado em: {formatDate(order.placed_at)}
                </CardDescription>
              </div>
              <div className="mt-2 sm:mt-0">
                <OrderStatusBadge status={order.status} />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6 space-y-8">
            
            <section>
              <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Resumo do Pedido</h2>
              <OrderSummaryDisplay
                orderItems={order.order_items}
                totalItemsPrice={order.total_items_price}
                shippingCost={order.shipping_cost}
                discountAmount={order.discount_amount}
                couponCode={order.coupon_code}
                grandTotal={order.grand_total}
                shippingMethodName={order.shipping_method_details?.name}
              />
            </section>

            <Separator className="dark:bg-slate-700" />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <section>
                <OrderAddressDisplay address={order.shipping_address_snapshot} title="Endereço de Entrega" />
              </section>
              <section>
                <OrderAddressDisplay address={order.billing_address_snapshot || order.shipping_address_snapshot} title="Endereço de Cobrança" />
              </section>
            </div>
            
            <Separator className="dark:bg-slate-700" />

            <section>
              <OrderPaymentDetailsDisplay
                paymentMethod={order.payment_method}
                paymentStatus={order.payment_status}
                paymentDetails={order.payment_details}
              />
            </section>

            {order.tracking_code && (
              <>
                <Separator className="dark:bg-slate-700" />
                <section>
                  <h3 className="text-lg font-semibold mb-2 text-slate-700 dark:text-slate-200 flex items-center">
                    <TruckIcon className="h-5 w-5 mr-2 text-sky-500" /> Rastreamento do Envio
                  </h3>
                  <div className="p-4 bg-slate-100 dark:bg-slate-700/50 rounded-md text-sm">
                    <p className="text-slate-600 dark:text-slate-300">
                      Código: <span className="font-medium text-slate-800 dark:text-slate-100">{order.tracking_code}</span>
                    </p>
                    {order.tracking_url && (
                      <p className="text-slate-600 dark:text-slate-300">
                        Link: 
                        <a href={order.tracking_url} target="_blank" rel="noopener noreferrer" className="text-sky-600 dark:text-sky-400 hover:underline ml-1">
                          Acompanhar Envio <ExternalLink className="inline h-3 w-3" />
                        </a>
                      </p>
                    )}
                  </div>
                </section>
              </>
            )}

            {order.order_status_history && order.order_status_history.length > 0 && (
              <>
                <Separator className="dark:bg-slate-700" />
                <section>
                  <h3 className="text-lg font-semibold mb-3 text-slate-700 dark:text-slate-200 flex items-center">
                    <InfoIcon className="h-5 w-5 mr-2 text-sky-500" /> Histórico do Pedido
                  </h3>
                  <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                    {order.order_status_history.sort((a,b) => new Date(b.changed_at) - new Date(a.changed_at)).map(entry => (
                      <div key={entry.id} className="p-3 bg-slate-100 dark:bg-slate-700/50 rounded-md text-sm">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-slate-700 dark:text-slate-200">
                            {ORDER_STATUS_OPTIONS.find(opt => opt.value === entry.status_to)?.label || entry.status_to}
                          </span>
                          <span className="text-xs text-slate-500 dark:text-slate-400">{formatDate(entry.changed_at)}</span>
                        </div>
                        {entry.notes && <p className="text-xs mt-1 text-slate-600 dark:text-slate-300">Nota: {entry.notes}</p>}
                      </div>
                    ))}
                  </div>
                </section>
              </>
            )}
            
            <Separator className="dark:bg-slate-700" />

            <div className="text-center pt-4">
              <Button variant="ghost" className="text-sky-600 dark:text-sky-400 hover:bg-sky-100 dark:hover:bg-sky-700/30" asChild>
                <a href="mailto:suporte@vittahub.com?subject=Ajuda com o Pedido #{order.order_number}">
                  <HelpCircle className="mr-2 h-4 w-4" /> Preciso de ajuda com este pedido
                </a>
              </Button>
            </div>

          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default CustomerOrderDetailPage;
