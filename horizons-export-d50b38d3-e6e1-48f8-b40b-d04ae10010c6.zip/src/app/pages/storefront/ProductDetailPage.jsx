
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { WorkspaceStorefrontProductBySlug } from '@/app/features/products/services/modules/products';
import { WorkspaceRelatedProducts } from '@/app/features/products/services/modules/featuredAndRelated';
import ProductImageGalleryStorefront from '@/app/features/products/components/ProductImageGalleryStorefront';
import ProductInfoStorefront from '@/app/features/products/components/ProductInfoStorefront';
import ProductGrid from '@/app/features/products/components/ProductGrid';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import ErrorDisplay from '@/app/components/common/ErrorDisplay';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { Home, ChevronRight } from 'lucide-react';
import MetaTags from '@/app/components/common/MetaTags';
import { getOptimizedImageUrl } from '@/lib/imageUtils';
import VariantSelectorStorefront from '@/app/features/products/components/VariantSelectorStorefront';
import ProductQuantitySelectorStorefront from '@/app/features/products/components/ProductQuantitySelectorStorefront';
import AddToCartButtonStorefront from '@/app/features/products/components/AddToCartButtonStorefront';
import { useToast } from '@/components/ui/use-toast';

const useProductVariantSelection = (product) => {
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (product && product.variants && product.variants.length > 0) {
      const defaultVariant = product.variants.find(v => v.is_default && v.is_active && v.inventory_quantity > 0) || 
                             product.variants.find(v => v.is_active && v.inventory_quantity > 0) || 
                             product.variants[0];
      setSelectedVariant(defaultVariant);
    } else if (product && (!product.variants || product.variants.length === 0)) {
      setSelectedVariant(null);
    }
    setQuantity(1); 
  }, [product]);

  const handleVariantChange = (variant) => {
    setSelectedVariant(variant);
    setQuantity(1); 
  };

  const currentProductData = useMemo(() => {
    if (!product) return null;
    
    const baseData = {
      ...product,
      effectivePrice: product.base_price,
      effectiveCompareAtPrice: product.compare_at_price,
      effectiveSku: product.sku_base,
      effectiveWeight: product.weight_grams,
      selectedVariantId: null,
      images: product.images || [],
      currentStock: product.inventory_quantity_base || 0,
      isAvailable: product.is_active && (product.inventory_quantity_base || 0) > 0,
    };

    if (selectedVariant) {
      return {
        ...baseData,
        effectivePrice: selectedVariant.price_override !== null && selectedVariant.price_override !== undefined ? selectedVariant.price_override : product.base_price,
        effectiveCompareAtPrice: selectedVariant.compare_at_price_override !== null && selectedVariant.compare_at_price_override !== undefined ? selectedVariant.compare_at_price_override : product.compare_at_price,
        effectiveSku: selectedVariant.sku,
        effectiveWeight: selectedVariant.weight_grams_override !== null && selectedVariant.weight_grams_override !== undefined ? selectedVariant.weight_grams_override : product.weight_grams,
        selectedVariantId: selectedVariant.id,
        currentStock: selectedVariant.inventory_quantity || 0,
        isAvailable: product.is_active && selectedVariant.is_active && (selectedVariant.inventory_quantity || 0) > 0,
        attributes: selectedVariant.attributes,
      };
    }
    return baseData;
  }, [product, selectedVariant]);

  return {
    selectedVariant,
    currentProductData,
    quantity,
    setQuantity,
    handleVariantChange,
  };
};


const ProductDetailPage = () => {
  const { slug } = useParams();
  const { toast } = useToast();

  const { data: product, isLoading, error, refetch } = useQuery({
    queryKey: ['product', slug],
    queryFn: () => WorkspaceStorefrontProductBySlug(slug),
    enabled: !!slug,
  });

  const { 
    selectedVariant, 
    currentProductData, 
    quantity, 
    setQuantity, 
    handleVariantChange 
  } = useProductVariantSelection(product);

  const { data: relatedProducts, isLoading: isLoadingRelated } = useQuery({
    queryKey: ['relatedProducts', product?.id],
    queryFn: () => WorkspaceRelatedProducts({ productId: product.id, limit: 4 }),
    enabled: !!product?.id,
  });

  const addToCartDisabledReason = useMemo(() => {
    if (!currentProductData) return "Produto indisponível";
    if (!currentProductData.isAvailable) return "Produto indisponível";
    if (product?.has_variants && !selectedVariant) return "Selecione uma variante";
    if (selectedVariant && (!selectedVariant.is_active || selectedVariant.inventory_quantity <= 0)) return "Variante indisponível";
    if (quantity > (selectedVariant?.inventory_quantity || product?.inventory_quantity_base || 0)) return "Quantidade indisponível";
    return null;
  }, [currentProductData, selectedVariant, quantity, product]);


  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 min-h-[60vh] flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error) {
    return <ErrorDisplay message={error.message} onRetry={refetch} />;
  }

  if (!product || !currentProductData) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-semibold">Produto não encontrado.</h1>
        <Link to="/products" className="text-sky-600 hover:underline">Voltar aos produtos</Link>
      </div>
    );
  }
  
  const productImages = currentProductData.images || [];
  const mainImageForSchema = productImages.length > 0 ? getOptimizedImageUrl(productImages[0].storage_path, { width: 1200, height:1200 }) : '/placeholder-image.svg';

  const productSchema = {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": currentProductData.name,
    "image": mainImageForSchema,
    "description": currentProductData.description_short || currentProductData.description_long,
    "sku": currentProductData.effectiveSku,
    "mpn": currentProductData.effectiveSku, 
    "brand": {
      "@type": "Brand",
      "name": currentProductData.brand?.name || "Marca Desconhecida"
    },
    "offers": {
      "@type": "Offer",
      "url": window.location.href,
      "priceCurrency": currentProductData.default_currency || "BRL",
      "price": currentProductData.effectivePrice,
      "priceValidUntil": new Date(new Date().getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 
      "itemCondition": "https://schema.org/NewCondition",
      "availability": currentProductData.isAvailable ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      "seller": {
        "@type": "Organization",
        "name": "VittaHub" 
      }
    },
    ...(currentProductData.reviews && currentProductData.reviews.length > 0 && {
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": currentProductData.average_rating || "4.5", 
        "reviewCount": currentProductData.review_count || currentProductData.reviews.length
      },
      "review": currentProductData.reviews.map(review => ({
        "@type": "Review",
        "author": {"@type": "Person", "name": review.author_name},
        "datePublished": review.created_at,
        "reviewBody": review.content,
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": review.rating
        }
      }))
    })
  };

  return (
    <>
      <MetaTags
        title={currentProductData.meta_title || currentProductData.name}
        description={currentProductData.meta_description || currentProductData.description_short}
        image={mainImageForSchema}
        type="product"
      >
        <script type="application/ld+json">
          {JSON.stringify(productSchema)}
        </script>
      </MetaTags>
      <main className="container mx-auto px-4 py-8">
        <Breadcrumb className="mb-8" aria-label="Navegação estrutural">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/" className="flex items-center text-slate-600 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400">
                  <Home className="h-4 w-4 mr-1.5" aria-hidden="true" /> Início
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator><ChevronRight className="h-4 w-4" aria-hidden="true" /></BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/products" className="text-slate-600 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400">Produtos</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            {product.category && (
              <>
                <BreadcrumbSeparator><ChevronRight className="h-4 w-4" aria-hidden="true" /></BreadcrumbSeparator>
                <BreadcrumbItem>
                  <BreadcrumbLink asChild>
                    <Link to={`/products?category=${product.category.slug}`} className="text-slate-600 hover:text-sky-600 dark:text-slate-400 dark:hover:text-sky-400">
                      {product.category.name}
                    </Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
              </>
            )}
            <BreadcrumbSeparator><ChevronRight className="h-4 w-4" aria-hidden="true" /></BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage className="font-medium text-slate-800 dark:text-slate-200" aria-current="page">{currentProductData.name}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          <section aria-labelledby="product-gallery-heading">
            <h2 id="product-gallery-heading" className="sr-only">Galeria de Imagens do Produto</h2>
            <ProductImageGalleryStorefront images={productImages} productName={currentProductData.name} />
          </section>
          <section aria-labelledby="product-info-heading" className="space-y-6">
             <h2 id="product-info-heading" className="sr-only">Informações do Produto e Compra</h2>
            <ProductInfoStorefront 
              product={currentProductData} 
              selectedVariant={selectedVariant}
            />
            {product.has_variants && product.variants && product.variants.length > 0 && (
              <VariantSelectorStorefront
                product={product}
                onVariantSelect={handleVariantChange}
                currentSelectedVariant={selectedVariant}
              />
            )}
            <div className="flex items-center gap-4">
              <ProductQuantitySelectorStorefront
                quantity={quantity}
                setQuantity={setQuantity}
                maxQuantity={currentProductData.currentStock}
                disabled={!currentProductData.isAvailable || (product.has_variants && !selectedVariant)}
              />
              <AddToCartButtonStorefront
                product={currentProductData}
                selectedVariant={selectedVariant}
                quantity={quantity}
                disabledReason={addToCartDisabledReason}
              />
            </div>
             {!currentProductData.isAvailable && (
              <p className="text-red-600 dark:text-red-400 text-sm font-medium">Este produto está indisponível no momento.</p>
            )}
            {currentProductData.isAvailable && quantity > currentProductData.currentStock && (
              <p className="text-red-600 dark:text-red-400 text-sm font-medium">A quantidade selecionada excede o estoque disponível ({currentProductData.currentStock}).</p>
            )}
          </section>
        </div>

        {currentProductData.description_long && (
          <section aria-labelledby="product-long-description-heading" className="mt-12 py-8 border-t dark:border-slate-700">
            <h2 id="product-long-description-heading" className="text-2xl font-semibold text-slate-800 dark:text-white mb-4">Descrição Detalhada</h2>
            <div 
              className="prose dark:prose-invert max-w-none text-slate-700 dark:text-slate-300"
              dangerouslySetInnerHTML={{ __html: currentProductData.description_long }} 
            />
          </section>
        )}

        {relatedProducts && relatedProducts.length > 0 && (
          <section aria-labelledby="related-products-heading" className="mt-12 py-8 border-t dark:border-slate-700">
            <h2 id="related-products-heading" className="text-2xl font-semibold text-slate-800 dark:text-white mb-6">Você também pode gostar</h2>
            <ProductGrid products={relatedProducts} isLoading={isLoadingRelated} />
          </section>
        )}
      </main>
    </>
  );
};

export default ProductDetailPage;
