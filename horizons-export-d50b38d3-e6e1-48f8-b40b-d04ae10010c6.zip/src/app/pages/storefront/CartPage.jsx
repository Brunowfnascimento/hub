
import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '@/app/contexts/CartContext';
import CartItemRow from '@/app/features/cart/components/CartItemRow';
import CartSummary from '@/app/features/cart/components/CartSummary';
import LoadingSpinner from '@/app/components/common/LoadingSpinner';
import { Button } from '@/components/ui/button';
import { ShoppingCart, PackageOpen } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const CartPage = () => {
  const { items, totalItems, isCartLoading } = useCart();

  if (isCartLoading) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-200px)] flex items-center justify-center">
        <LoadingSpinner className="text-sky-500" size="w-12 h-12" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-2 sm:px-4 py-8 md:py-12">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-slate-50 flex items-center">
          <ShoppingCart className="mr-3 h-8 w-8 text-sky-500" />
          Seu Carrinho de Compras
        </h1>
      </motion.div>

      {totalItems === 0 ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center py-16 bg-white dark:bg-slate-800/50 shadow-lg rounded-xl border dark:border-slate-700"
        >
          <PackageOpen className="mx-auto h-20 w-20 text-slate-400 dark:text-slate-500 mb-6" />
          <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200 mb-3">
            Seu carrinho está vazio.
          </h2>
          <p className="text-slate-500 dark:text-slate-400 mb-8">
            Parece que você ainda não adicionou nenhum produto.
          </p>
          <Button size="lg" className="bg-sky-500 hover:bg-sky-600 text-white" asChild>
            <Link to="/products">Continuar Comprando</Link>
          </Button>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-2 bg-white dark:bg-slate-800/50 shadow-lg rounded-xl border dark:border-slate-700 overflow-hidden"
          >
            <div className="hidden sm:flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
              <span className="font-semibold text-slate-600 dark:text-slate-300 w-2/5">Produto</span>
              <span className="font-semibold text-slate-600 dark:text-slate-300 w-1/5 text-center">Preço Unit.</span>
              <span className="font-semibold text-slate-600 dark:text-slate-300 w-1/5 text-center">Quantidade</span>
              <span className="font-semibold text-slate-600 dark:text-slate-300 w-1/5 text-center">Total Item</span>
              <span className="font-semibold text-slate-600 dark:text-slate-300 w-auto text-center">Ação</span>
            </div>
            <AnimatePresence>
              {items.map(item => (
                <CartItemRow key={item.variantId || item.productId} item={item} />
              ))}
            </AnimatePresence>
          </motion.div>
          
          <div className="lg:col-span-1">
            <CartSummary />
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;
