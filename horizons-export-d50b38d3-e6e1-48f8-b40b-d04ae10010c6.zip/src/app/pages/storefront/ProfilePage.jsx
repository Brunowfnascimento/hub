
    import React from 'react';
    import { NavLink, Routes, Route, Navigate, useLocation } from 'react-router-dom';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { User, ShoppingBag, MapPin, LogOut, ChevronRight } from 'lucide-react';
    import { useAuth } from '@/app/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { cn } from '@/lib/utils';

    import ProfileOrdersPage from './profile/ProfileOrdersPage';
    import ProfileAddressesPage from './profile/ProfileAddressesPage';
    import ProfileDetailsPage from './profile/ProfileDetailsPage';
    import CustomerOrderDetailPage from './CustomerOrderDetailPage';

    const profileNavItems = [
      { to: 'orders', label: 'Meus Pedidos', icon: ShoppingBag },
      { to: 'addresses', label: 'Meus Endereços', icon: MapPin },
      { to: 'details', label: 'Detalhes da Conta', icon: User },
    ];

    const ProfilePage = () => {
      const { user, logout } = useAuth();
      const location = useLocation();

      if (!user) {
        return <Navigate to="/auth/login" replace />;
      }
      
      const userFullName = user.user_metadata?.full_name || user.email;

      // Check if we are on a sub-route like /profile/orders/:orderId
      const isOnOrderDetailPage = location.pathname.match(/^\/profile\/orders\/[^/]+$/);

      return (
        <>
          <Helmet>
            <title>Meu Perfil - VittaHub</title>
          </Helmet>
          <div className="container mx-auto px-4 py-8">
            {/* Only show main header and navigation if not on a specific order detail page */}
            {!isOnOrderDetailPage && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="mb-8"
              >
                <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-slate-50">
                  Olá, {userFullName}!
                </h1>
                <p className="text-lg text-slate-600 dark:text-slate-400 mt-1">
                  Gerencie suas informações, pedidos e endereços.
                </p>
              </motion.div>
            )}

            <div className="flex flex-col md:flex-row gap-8">
              {/* Only show sidebar navigation if not on a specific order detail page */}
              {!isOnOrderDetailPage && (
                <aside className="md:w-1/4 lg:w-1/5">
                  <Card className="shadow-lg dark:bg-slate-800/50 dark:border-slate-700">
                    <CardHeader>
                      <CardTitle className="text-xl text-slate-800 dark:text-slate-100">Navegação</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <nav className="flex flex-col space-y-1 p-2">
                        {profileNavItems.map((item) => (
                          <NavLink
                            key={item.to}
                            to={item.to}
                            end={item.to === 'orders'} 
                            className={({ isActive }) =>
                              cn(
                                'flex items-center justify-between px-4 py-3 rounded-md text-sm font-medium transition-colors',
                                'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700',
                                isActive && 'bg-sky-100 text-sky-600 dark:bg-sky-700/30 dark:text-sky-400 font-semibold'
                              )
                            }
                          >
                            <div className="flex items-center">
                              <item.icon className="mr-3 h-5 w-5" />
                              {item.label}
                            </div>
                            <ChevronRight className="h-4 w-4 text-slate-400 dark:text-slate-500" />
                          </NavLink>
                        ))}
                        <Button
                          variant="ghost"
                          onClick={logout}
                          className="w-full justify-start px-4 py-3 text-sm font-medium text-red-600 hover:bg-red-100 dark:text-red-400 dark:hover:bg-red-700/20"
                        >
                          <LogOut className="mr-3 h-5 w-5" />
                          Sair
                        </Button>
                      </nav>
                    </CardContent>
                  </Card>
                </aside>
              )}

              <main className={cn(
                  "min-h-[400px]",
                  isOnOrderDetailPage ? "w-full" : "md:w-3/4 lg:w-4/5" 
                )}>
                {/* Card wrapper only if not on order detail page, or adjust styling as needed */}
                {!isOnOrderDetailPage ? (
                    <Card className="shadow-lg dark:bg-slate-800/50 dark:border-slate-700 ">
                        <CardContent className="p-4 sm:p-6">
                            <Routes>
                                <Route index element={<Navigate to="orders" replace />} />
                                <Route path="orders" element={<ProfileOrdersPage />} />
                                <Route path="orders/:orderId" element={<CustomerOrderDetailPage />} />
                                <Route path="addresses" element={<ProfileAddressesPage />} />
                                <Route path="details" element={<ProfileDetailsPage />} />
                            </Routes>
                        </CardContent>
                    </Card>
                ) : (
                    <Routes> 
                        {/* This ensures CustomerOrderDetailPage is still routed when sidebar is hidden */}
                        <Route path="orders/:orderId" element={<CustomerOrderDetailPage />} />
                        {/* Optional: Redirect other profile paths if accessed directly while on order detail - though current logic might make this redundant */}
                        <Route path="*" element={<Navigate to={`orders/${location.pathname.split('/').pop()}`} replace />} />
                    </Routes>
                )}
              </main>
            </div>
          </div>
        </>
      );
    };

    export default ProfilePage;
  