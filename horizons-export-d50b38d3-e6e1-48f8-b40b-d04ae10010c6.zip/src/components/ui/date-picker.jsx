
import React from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar as CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const DatePicker = ({ date, onDateChange, placeholder = "Selecione uma data", className, disabled }) => {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant={"outline"}
          className={cn(
            "w-full justify-start text-left font-normal",
            !date && "text-muted-foreground",
            className
          )}
          disabled={disabled}
        >
          <CalendarIcon className="mr-2 h-4 w-4" />
          {date ? format(date, "PPP", { locale: ptBR }) : <span>{placeholder}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0 dark:bg-slate-800">
        <Calendar
          mode="single"
          selected={date}
          onSelect={onDateChange}
          initialFocus
          locale={ptBR}
          disabled={disabled}
          className="dark:bg-slate-800 dark:text-slate-50"
           classNames={{
            day_selected: "dark:bg-sky-500 dark:text-white",
            day_today: "dark:bg-slate-700 dark:text-slate-200",
            head_cell: "dark:text-slate-400",
            nav_button: "dark:hover:bg-slate-700 dark:text-slate-300",
            caption_label: "dark:text-slate-200",
          }}
        />
      </PopoverContent>
    </Popover>
  );
};
DatePicker.displayName = "DatePicker";

export { DatePicker };
