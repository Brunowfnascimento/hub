
    import React from 'react';
    import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
    import AppRoutes from '@/app/routes/index';
    import { Toaster } from "@/components/ui/toaster";
    import { ThemeProvider } from '@/app/contexts/ThemeContext';
    import { AuthProviderFinal as AuthProvider } from '@/app/contexts/AuthContext'; // Alterado para AuthProviderFinal
    import { CartProvider } from '@/app/contexts/CartContext';
    import { HelmetProvider } from 'react-helmet-async';


    const queryClient = new QueryClient();

    function App() {
      return (
        <HelmetProvider>
          <QueryClientProvider client={queryClient}>
            <ThemeProvider>
              <AuthProvider>
                <CartProvider>
                  <AppRoutes />
                  <Toaster />
                </CartProvider>
              </AuthProvider>
            </ThemeProvider>
          </QueryClientProvider>
        </HelmetProvider>
      );
    }

    export default App;
  